<style>
    :root {
        --sidebar-width: 250px;
        --sidebar-bg: #0d3b66;
        --footer-text: #ffffff;
    }

    .footer {
        position: fixed;
        bottom: 0;
        left: var(--sidebar-width);
        width: calc(100% - var(--sidebar-width));
        text-align: center;
        padding: 12px 20px;
        background-color: var(--sidebar-bg); /* same as sidebar */
        color: var(--footer-text);
        font-size: 0.9rem;
        border-top: 1px solid rgba(255, 255, 255, 0.15);
        z-index: 900;
         background-color: #077932;
         box-shadow: 0 2px 6px rgba(0, 0, 0, 0.3);
    }
</style>

<footer class="footer">
    © 2026 JLC Payroll Management System. All rights reserved.
</footer>
