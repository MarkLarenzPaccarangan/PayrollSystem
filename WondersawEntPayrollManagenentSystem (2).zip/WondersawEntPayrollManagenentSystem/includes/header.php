<?php
// Get the current page filename
$current_page = basename($_SERVER['PHP_SELF']);

// Map page filenames to display titles
$page_titles = [
    'home.php' => 'HOME',
    'employee.php' => 'EMPLOYEE LIST',
    'branch.php' => 'BRANCH MANAGEMENT',
    'deductionList.php' => 'DEDUCTION',
    'payrollList.php' => 'PAYROLL',
    'salarySlip.php' => 'SALARY SLIP',
    'user.php' => 'PROFILE'
];

// Get the title for the current page, default to empty if not found
$page_title = isset($page_titles[$current_page]) ? $page_titles[$current_page] : '';
?>

<style>
    :root {
        --sidebar-width: 250px;
        --sidebar-bg: #0d3b66;
        --header-text: #ffffff;
    }

    .header {
        width: calc(100% - var(--sidebar-width));
        height: 100px; /* Increased height */
        display: flex;
        justify-content: space-between;
        align-items: center;
        background-color: var(--sidebar-bg);
        padding: 0 30px; /* Increased padding */
        position: fixed;
        top: 0;
        left: var(--sidebar-width);
        z-index: 1000;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.4);
        background-color: #077932;
    }

    .header-left {
        display: flex;
        align-items: center;
    }

    .page-title {
        font-size: 2.4rem; /* Increased from 1.8rem to 2.4rem */
        font-weight: 800; /* Increased from 600 to 800 (extra bold) */
        color: var(--header-text);
        letter-spacing: 1px; /* Increased from 0.5px */
        text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3); /* Enhanced shadow */
        margin: 0;
        padding: 10px 0; /* Increased padding */
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; /* Modern font */
        text-transform: uppercase;
    }

    .header-right {
        display: flex;
        align-items: center;
        font-weight: bold;
        color: var(--header-text);
        gap: 25px; /* Increased from 20px */
    }

    .admin-text {
        font-size: 1.6rem; /* Increased from 1.1rem to 1.6rem */
        letter-spacing: 1px; /* Increased from 0.5px */
        font-weight: 700; /* Increased from 600 to 700 */
        text-shadow: 1px 1px 3px rgba(251, 249, 249, 0.3); /* Enhanced shadow */
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        padding: 8px 15px;
        
        border-radius: 8px;
    }

    .logout-icon {
        display: flex;
        align-items: center;
        justify-content: center;
        text-decoration: none;
    }

    .logout-icon img {
        height: 60px; /* Increased from 30px to 38px */
        width: 60px; /* Increased from 30px to 38px */
        cursor: pointer;
        transition: transform 0.2s ease, opacity 0.2s ease;
    
        padding: 8px; /* Increased from 5px */
        border-radius: 8px;
    }

    .logout-icon img:hover {
        transform: scale(1.15); /* Increased from 1.1 to 1.15 */
        opacity: 0.9;
       
    }

    /* Logout modal overlay */
    .logout-overlay {
        display: none;
        position: fixed;
        inset: 0;
        background-color: rgba(0, 0, 0, 0.5);
        justify-content: center;
        align-items: center;
        z-index: 2000;
    }

    .logout-content {
        background-color: #ffffff;
        padding: 30px; /* Increased from 25px */
        width: 420px; /* Increased from 400px */
        border-radius: 10px; /* Increased from 8px */
        text-align: center;
        box-shadow: 0px 10px 25px rgba(0, 0, 0, 0.4); /* Enhanced shadow */
    }

    .logout-header {
        font-size: 1.8rem; /* Increased from 1.5rem */
        margin-bottom: 15px; /* Increased from 10px */
        font-weight: 800; /* Changed from bold to 800 */
        color: #1e293b;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    /* Responsive adjustments */
    @media (max-width: 1024px) {
        .header {
            height: 90px;
            padding: 0 25px;
        }
        
        .page-title {
            font-size: 2rem;
        }
        
        .admin-text {
            font-size: 1.4rem;
            padding: 6px 12px;
        }
        
        .logout-icon img {
            height: 50px;
            width: 34px;
        }
    }

    @media (max-width: 768px) {
        .header {
            width: 100%;
            left: 0;
            padding: 0 20px;
            height: 85px;
        }
        
        .page-title {
            font-size: 1.8rem;
            letter-spacing: 0.8px;
        }
        
        .admin-text {
            font-size: 1.2rem;
            padding: 5px 10px;
            letter-spacing: 0.8px;
        }
        
        .logout-icon img {
            height: 30px;
            width: 30px;
            padding: 6px;
        }
        
        .header-right {
            gap: 15px;
        }
    }

    @media (max-width: 480px) {
        .header {
            padding: 0 15px;
            height: 80px;
        }
        
        .page-title {
            font-size: 1.5rem;
        }
        
        .admin-text {
            font-size: 1rem;
            padding: 4px 8px;
        }
        
        .logout-icon img {
            height: 28px;
            width: 28px;
        }
        
        .header-right {
            gap: 12px;
        }
    }
</style>

<header class="header">
    <div class="header-left">
        <?php if (!empty($page_title)): ?>
            <h1 class="page-title"><?php echo htmlspecialchars($page_title); ?></h1>
        <?php endif; ?>
    </div>
    
    <div class="header-right">
        <span class="admin-text">ADMINISTRATOR</span>
        <a href="#" class="logout-icon" onclick="showLogoutConfirmation(event)">
            <img src="./assets/images/logout2.png" alt="Logout">
        </a>
    </div>
</header>