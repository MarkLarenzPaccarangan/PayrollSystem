<style>
/* General Styling */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
}

/* Sidebar Full Height */
.sidebar {
    width: 250px;
    height: 100vh; /* Full viewport height */
    position: fixed;
    top: 0;
    left: 0;
    background-color: #0d3b66; /* 60% primary color */
    display: flex;
    flex-direction: column;
    padding-top: 30px;
    box-shadow: 2px 0 15px rgba(0,0,0,0.1);
    z-index: 10;
}

/* Sidebar Logo */
.sidebar-logo {
    display: flex;
    justify-content: center;
    margin-bottom: 40px;
}

.sidebar-logo img {
    width: 140px;
    height: auto;
    border-radius: 12px;
    box-shadow: 0 5px 20px rgba(0,0,0,0.2);
}

/* Sidebar Menu */
.sidebar ul {
    list-style: none;
    width: 100%;
    flex: 1; /* take full vertical space */
    display: flex;
    flex-direction: column;
}

.sidebar ul li {
    width: 100%;
}

.sidebar ul li a {
    display: flex;
    align-items: center;
    padding: 15px 25px;
    color: #ffffff; /* white text */
    font-weight: 600;
    text-decoration: none;
    border-radius: 10px;
    margin: 5px 15px;
    transition: all 0.3s ease;
}

.sidebar ul li a:hover {
    background-color: #4763ca; /* 10% highlight color */
    box-shadow: 0 4px 12px rgba(52,168,83,0.3);
    transform: translateX(5px);
}

.sidebar ul li.active a {
    background-color: #4881c3;
    color: #ffffff;
    box-shadow: 0 4px 12px rgba(52,168,83,0.3);
}

/* Icons */
.icon {
    margin-right: 12px;
    font-size: 18px;
}

/* Content area */
.content {
    margin-left: 250px;
    padding: 40px;
    width: calc(100% - 250px);
    min-height: 100vh;
    background-color: #ffffff; /* 30% secondary */
    color: #0d3b66;
    overflow-y: auto;
    transition: all 0.3s ease;
}

/* Scrollbar for content */
.content::-webkit-scrollbar {
    width: 8px;
}

.content::-webkit-scrollbar-thumb {
    background-color: #4755da;
    border-radius: 5px;
}

/* Responsive */
@media (max-width: 900px) {
    .sidebar {
        width: 200px;
        padding-top: 20px;
    }

    .sidebar-logo img {
        width: 120px;
    }

    .content {
        margin-left: 200px;
        padding: 30px;
    }
}
</style>

<!-- Sidebar HTML -->
<div class="sidebar">
    <div class="sidebar-logo">
        <img src="assets/images/logo2.png" alt="Logo">
    </div>
    <ul>
        <li><a href="home.php"><span class="icon">🏠</span>Home</a></li>
        <li><a href="payrollList.php"><span class="icon">💸</span>Payroll</a></li>
        <li><a href="employee.php"><span class="icon">👥</span>Employees</a></li>
        <li><a href="branch.php"><span class="icon">🏢</span>Branch</a></li>
        <li><a href="deductionList.php"><span class="icon">➖</span>Deduction</a></li>
        <li><a href="salarySlip.php"><span class="icon">📄</span>Salary Slip</a></li>
        <li><a href="user.php"><span class="icon">👤</span>Profile</a></li>
    </ul>
</div>


