<style>
    :root {
        --sidebar-width: 250px;
        --sidebar-bg: #0d3b66;
        --header-text: #ffffff;
    }

    .header {
        width: calc(100% - var(--sidebar-width));
        height: 90px;
        display: flex;
        align-items: center;
        background-color: var(--sidebar-bg);
        padding: 0 25px;
        position: fixed;
        top: 0;
        left: var(--sidebar-width);
        z-index: 1000;
        box-shadow: 0 2px 6px rgba(0, 0, 0, 0.3);
    }

    .header-right {
        display: flex;
        align-items: center;
        font-weight: bold;
        color: var(--header-text);
        margin-left: auto; /* push to right */
    }

    .admin-text {
        margin-right: 15px;
        font-size: 1.1rem;
        letter-spacing: 0.5px;
    }

    .logout-icon img {
        height: 25px;
        cursor: pointer;
        transition: transform 0.2s ease, opacity 0.2s ease;
    }

    .logout-icon img:hover {
        transform: scale(1.1);
        opacity: 0.8;
    }

    /* Logout modal overlay */
    .logout-overlay {
        display: none;
        position: fixed;
        inset: 0;
        background-color: rgba(0, 0, 0, 0.5);
        justify-content: center;
        align-items: center;
        z-index: 2000;
    }

    .logout-content {
        background-color: #ffffff;
        padding: 25px;
        width: 400px;
        border-radius: 8px;
        text-align: center;
        box-shadow: 0px 8px 20px rgba(0, 0, 0, 0.3);
    }

    .logout-header {
        font-size: 1.5rem;
        margin-bottom: 10px;
        font-weight: bold;
        color: #1e293b;
    }
</style>

<header class="header">
    <div class="header-right">
        <span class="admin-text">ADMINISTRATOR</span>
        <a href="#" class="logout-icon" onclick="showLogoutConfirmation(event)">
            <img src="./assets/images/logout.png" alt="Logout">
        </a>
    </div>
</header>
