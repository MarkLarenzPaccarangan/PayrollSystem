<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="./assets/css/home.css">
    <style>
        /* Center the image horizontally and vertically */
        .background-image {
            display: block;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            max-width: 50%;
            height: auto;
        }

        /* Make sure the body takes full height */
        body, html {
            margin: 0;
            padding: 0;
            height: 100%;
            position: relative;
            font-family: Arial, sans-serif;
        }

        main.content {
            /* optional: push your content below the image if needed */
            margin-top: 20px;
        }
    </style>
</head>
<body>

    <!-- header -->
    <?php include_once("./includes/header.php"); ?>

    <!-- sidebar -->
    <?php include_once("./includes/sidebar.php"); ?>

    <!-- Add Image Here -->
    <img src="./assets/images/logo--home.jpg" alt="Background Image" class="background-image">

    <main class="content">
        <!-- Your content here -->
    </main>

    <!-- footer -->
    <?php include_once("./includes/footer.php"); ?>
    <!-- modal -->
    <?php include_once("./modal/logout-modal.php"); ?>

</body>
</html>