<?php
session_start();
include_once("connection.php");

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

header('Content-Type: application/json');

if (!isset($_SESSION['Admin_User'])) {
    echo json_encode(['error' => 'Not authorized']);
    exit;
}

// Get parameters
$employee_id = isset($_POST['employee_id']) ? intval($_POST['employee_id']) : 0;
$date = isset($_POST['date']) ? $_POST['date'] : '';

if (!$employee_id || !$date) {
    echo json_encode(['error' => 'Missing parameters']);
    exit;
}

try {
    // Check if attendance already exists for this employee on this date
    $check_sql = "SELECT id, status, time_in, time_out, remarks FROM attendance WHERE employee_id = ? AND DATE(date) = DATE(?)";
    $check_stmt = $conn->prepare($check_sql);
    
    if (!$check_stmt) {
        throw new Exception("Prepare failed: " . $conn->error);
    }
    
    $check_stmt->bind_param("is", $employee_id, $date);
    $check_stmt->execute();
    $result = $check_stmt->get_result();
    
    if ($result->num_rows > 0) {
        $attendance = $result->fetch_assoc();
        
        // Return the attendance data
        echo json_encode([
            'exists' => true,
            'attendance' => [
                'id' => $attendance['id'],
                'status' => $attendance['status'],
                'time_in' => $attendance['time_in'],
                'time_out' => $attendance['time_out'],
                'remarks' => $attendance['remarks']
            ]
        ]);
    } else {
        echo json_encode([
            'exists' => false
        ]);
    }
    
    $check_stmt->close();
    
} catch (Exception $e) {
    echo json_encode(['error' => $e->getMessage()]);
}

$conn->close();
?>