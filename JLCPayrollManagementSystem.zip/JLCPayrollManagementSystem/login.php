<?php 
session_start();

$error_message = '';
$show_modal = false;
$forgot_password = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['username']) && isset($_POST['password'])) {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    include_once("connection.php");

    $stmt = $conn->prepare("SELECT id, name, username, password FROM super_user WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($id, $name, $storedUsername, $storedPassword);
        $stmt->fetch();

        if ($password === $storedPassword) {
            $_SESSION['user_id'] = $id;
            $_SESSION['Admin_User'] = $username;
            $show_modal = true;
        } else {
            $error_message = "Invalid password. Please try again.";
        }
    } else {
        $error_message = "Username not found. Please try again.";
    }

    $stmt->close();
    $conn->close();
}

if (isset($_GET['forgot_password']) && $_GET['forgot_password'] === 'true') {
    $forgot_password = true;
}

if (isset($_GET['error'])) {
    $error_message = "Incorrect answers. Please try again.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>JLC Payroll System</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>

<style>
* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
}

html, body {
    width: 100%;
    height: 100%;
    font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
}

/* FULL SCREEN BACKGROUND – ORIGINAL IMAGE COLOR */
.background {
    width: 100%;
    min-height: 100vh;
    background-image: url('assets/images/logo3.png');
    background-repeat: no-repeat;
    background-position: center;
    background-size: cover;
    display: flex;
    justify-content: flex-start; /* start from left */
    align-items: center;
    position: relative;
}

/* LOGIN CARD – TRANSPARENT & 75% RIGHT */
.login-container {
    width: 380px;
    padding: 40px;
    background: rgb(255, 255, 255); /* semi-transparent */
    border-radius: 18px;
    box-shadow: 0 20px 40px rgba(0,0,0,0.15);
    backdrop-filter: blur(10px);
    position: absolute;
    left: 84%; /* move container 75% from the left */
    transform: translateX(-50%); /* center it at that 75% */
}

.login-container h1 {
    text-align: center;
    margin-bottom: 25px;
    font-size: 26px;
    font-weight: 700;
    color: #1e293b;
}

.input-group {
    display: flex;
    align-items: center;
    border: 1px solid #cfd8dc;
    border-radius: 10px;
    padding: 10px 15px;
    margin-bottom: 15px;
    background: rgba(255,255,255,0.5);
}

.input-group:focus-within {
    border-color: #1e88e5;
    box-shadow: 0 0 8px rgba(30,136,229,0.3);
}

.icon {
    font-size: 18px;
    color: #1e88e5;
    margin-right: 10px;
}

.input-group input {
    border: none;
    outline: none;
    width: 100%;
    font-size: 16px;
    background: transparent;
}

.login-container button {
    width: 100%;
    background: #52cc8f;
    color: #fff;
    padding: 14px;
    border: none;
    border-radius: 10px;
    font-size: 16px;
    font-weight: 700;
    cursor: pointer;
    transition: transform 0.2s ease, box-shadow 0.3s ease;
}

.login-container button:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 25px rgba(0,0,0,0.3);
}

.forgot-password {
    display: block;
    margin-top: 15px;
    text-align: center;
    font-size: 14px;
    color: #1e88e5;
    text-decoration: none;
}

.forgot-password:hover {
    text-decoration: underline;
}

.error {
    background: rgba(255, 0, 0, 0.2);
    color: #b71c1c;
    padding: 10px;
    border-radius: 8px;
    font-size: 14px;
    margin-bottom: 15px;
    text-align: center;
}

/* MODAL */
.modal-header {
    background-color: #1e293b;
    color: #fff;
}

/* MOBILE */
@media (max-width: 900px) {
    .login-container {
        position: static;
        transform: none;
        margin: 0 auto;
    }
    .background {
        justify-content: center;
    }
}
</style>
</head>

<body>

<div class="background">

    <div class="login-container">
        <h1>Admin Login</h1>

        <?php if (!empty($error_message)): ?>
            <div class="error"><?php echo htmlspecialchars($error_message); ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="input-group">
                <span class="icon">👤</span>
                <input type="text" name="username" placeholder="Username" required>
            </div>

            <div class="input-group">
                <span class="icon">🔒</span>
                <input type="password" name="password" placeholder="Password" required>
            </div>

            <button type="submit">Log In</button>
            <a href="?forgot_password=true" class="forgot-password">Forgot Password?</a>
        </form>
    </div>

</div>

<!-- SECURITY QUESTIONS MODAL -->
<?php if ($show_modal || $forgot_password): ?>
<div class="modal fade show" id="securityModal" tabindex="-1" style="display:block;">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Security Questions</h5>
            </div>
            <div class="modal-body">
                <form method="POST" action="verify_security.php">
                    <div class="form-group">
                        <label>What is your Middle Name?</label>
                        <input type="text" class="form-control" name="answer1" required>
                    </div>
                    <div class="form-group">
                        <label>What is your First Name?</label>
                        <input type="text" class="form-control" name="answer2" required>
                    </div>
                    <div class="form-group">
                        <label>What is your Last Name?</label>
                        <input type="text" class="form-control" name="answer3" required>
                    </div>
                    <button type="submit" class="btn btn-success">Submit</button>
                    <a href="login.php" class="btn btn-secondary">Cancel</a>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function(){
    $('#securityModal').modal({ backdrop: 'static', keyboard: false });
});
</script>
<?php endif; ?>

</body>
</html>
