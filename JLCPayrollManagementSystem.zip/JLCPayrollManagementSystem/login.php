<?php 
session_start();

$error_message = '';
$success_message = '';
$show_login_form = false;
$show_create_form = false;
$show_security_form = false;
$selected_role = '';

// Default to showing admin login form
$show_login_form = true;
$selected_role = 'admin';

// Handle login form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login_direct'])) {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    $role = $_POST['role'];
    
    include_once("connection.php");
    
    $authenticated = false;
    $user_data = [];
    
    // Check based on role
    if ($role === 'admin') {
        // Check super_user table for admin
        $stmt = $conn->prepare("SELECT id, name, username, password, 'admin' as role, 'super_user' as user_type FROM super_user WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            // In a real application, use password_verify() if passwords are hashed
            if ($password === $user['password']) {
                $authenticated = true;
                $user_data = [
                    'id' => $user['id'],
                    'username' => $user['username'],
                    'full_name' => $user['name'],
                    'role' => 'admin',
                    'user_type' => 'super_user'
                ];
            }
        }
    } else {
        // Check user_accounts table for ceo and user
        $stmt = $conn->prepare("SELECT id, username, password_hash as password, full_name as name, role, 'user_account' as user_type FROM user_accounts WHERE username = ? AND role = ? AND is_active = 1");
        $stmt->bind_param("ss", $username, $role);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            // In a real application, use password_verify() if passwords are hashed
            if ($password === $user['password']) {
                $authenticated = true;
                $user_data = [
                    'id' => $user['id'],
                    'username' => $user['username'],
                    'full_name' => $user['name'],
                    'role' => $user['role'],
                    'user_type' => 'user_account'
                ];
                
                // Update last login
                $update = $conn->prepare("UPDATE user_accounts SET last_login = NOW() WHERE id = ?");
                $update->bind_param("i", $user['id']);
                $update->execute();
                $update->close();
            }
        }
    }
    
    $stmt->close();
    $conn->close();
    
    if ($authenticated) {
        $_SESSION['user_id'] = $user_data['id'];
        $_SESSION['Admin_User'] = $user_data['username']; // This is the key your home.php checks for
        $_SESSION['username'] = $user_data['username'];
        $_SESSION['full_name'] = $user_data['full_name'];
        $_SESSION['role'] = $user_data['role'];
        $_SESSION['user_type'] = $user_data['user_type'];
        
        // Redirect to home.php upon successful login
        header("Location: home.php");
        exit;
    } else {
        $error_message = "Invalid username or password for selected role.";
        $show_login_form = true;
        $selected_role = $role;
    }
}

// Handle create account form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_account_direct'])) {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    $confirm_password = trim($_POST['confirm_password']);
    $full_name = trim($_POST['full_name']);
    $email = trim($_POST['email']);
    $role = $_POST['role'];
    $answer1 = trim($_POST['answer1']);
    $answer2 = trim($_POST['answer2']);
    $answer3 = trim($_POST['answer3']);
    
    if ($password !== $confirm_password) {
        $error_message = "Passwords do not match!";
        $show_create_form = true;
        $selected_role = $role;
    } elseif (strlen($password) < 6) {
        $error_message = "Password must be at least 6 characters!";
        $show_create_form = true;
        $selected_role = $role;
    } else {
        include_once("connection.php");
        
        // Check if username exists
        $check = $conn->prepare("SELECT id FROM user_accounts WHERE username = ?");
        $check->bind_param("s", $username);
        $check->execute();
        $check->store_result();
        
        if ($check->num_rows > 0) {
            $error_message = "Username already exists!";
            $show_create_form = true;
            $selected_role = $role;
        } else {
            // Insert new user account
            $stmt = $conn->prepare("INSERT INTO user_accounts (username, password_hash, full_name, email, role, security_answer1, security_answer2, security_answer3, created_at, is_active) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW(), 1)");
            $stmt->bind_param("ssssssss", $username, $password, $full_name, $email, $role, $answer1, $answer2, $answer3);
            
            if ($stmt->execute()) {
                $success_message = "Account created successfully! You can now login as " . strtoupper($role) . ".";
                // Show login form after successful account creation
                $show_login_form = true;
                $show_create_form = false;
                $selected_role = $role;
            } else {
                $error_message = "Error creating account: " . $conn->error;
                $show_create_form = true;
                $selected_role = $role;
            }
        }
        
        $check->close();
        $stmt->close();
        $conn->close();
    }
}

// Handle form display from URL
if (isset($_GET['action'])) {
    if ($_GET['action'] === 'login') {
        $show_login_form = true;
        $show_create_form = false;
        $selected_role = $_GET['role'] ?? 'admin';
    } elseif ($_GET['action'] === 'create') {
        $show_create_form = true;
        $show_login_form = false;
        $selected_role = $_GET['role'] ?? 'user';
    }
}

if (isset($_GET['forgot_password']) && $_GET['forgot_password'] === 'true') {
    $show_security_form = true;
    $show_login_form = false;
    $show_create_form = false;
}

if (isset($_GET['error'])) {
    $error_message = "Incorrect answers. Please try again.";
    $show_security_form = true;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JLC Payroll System - Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        html, body { width: 100%; height: 100%; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        
        .background {
            width: 100%; min-height: 100vh;
            background-image: url('assets/images/logo3.png');
            background-repeat: no-repeat; background-position: center; background-size: cover;
            display: flex;
            flex-direction: column;
            position: relative;
        }
        
        /* Header with buttons only */
        .login-header {
            width: 100%;
            padding: 20px 40px;
            display: flex;
            justify-content: flex-end;
            align-items: center;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1000;
            background: transparent;
        }
        
        .button-area {
            display: flex;
            gap: 15px;
        }
        
        .btn-header {
            padding: 10px 24px;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 8px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }
        
        .btn-login {
            background: white;
            color: #2E7D32;
            border: 2px solid #2E7D32;
        }
        
        .btn-login:hover {
            background: #2E7D32;
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(46, 125, 50, 0.3);
        }
        
        .btn-create {
            background: linear-gradient(135deg, #4CAF50, #2E7D32);
            color: white;
            border: 2px solid transparent;
        }
        
        .btn-create:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(46, 125, 50, 0.4);
        }
        
        .btn-active {
            background: #2E7D32 !important;
            color: white !important;
            border-color: #2E7D32 !important;
        }
        
        /* Dropdown Menu */
        .dropdown-menu-custom {
            min-width: 280px;
            padding: 15px;
            border: none;
            border-radius: 16px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.2);
            margin-top: 15px !important;
            background: white;
        }
        
        .role-option {
            display: flex;
            align-items: center;
            padding: 12px;
            border-radius: 12px;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-bottom: 5px;
        }
        
        .role-option:hover {
            background: linear-gradient(135deg, #f8fafc, #f1f5f9);
            transform: translateX(5px);
        }
        
        .role-option-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 12px;
            font-size: 18px;
            color: white;
        }
        
        .role-option.admin .role-option-icon { background: linear-gradient(135deg, #667eea, #764ba2); }
        .role-option.ceo .role-option-icon { background: linear-gradient(135deg, #f093fb, #f5576c); }
        .role-option.user .role-option-icon { background: linear-gradient(135deg, #4facfe, #00f2fe); }
        
        .role-option-info h4 {
            margin: 0;
            font-size: 15px;
            font-weight: 700;
            color: #1e293b;
        }
        
        .role-option-info p {
            margin: 3px 0 0;
            font-size: 11px;
            color: #64748b;
        }
        
        /* Main Content Area */
        .main-content {
            width: 100%;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: flex-end;
            padding: 100px 60px 20px 20px;
        }
        
        /* Form Container - SMALLER and on the RIGHT */
        .form-container {
            width: 100%;
            max-width: 380px;
            background: white;
            border-radius: 16px;
            box-shadow: 0 25px 50px rgba(0,0,0,0.25);
            overflow: hidden;
            animation: slideIn 0.5s ease;
        }
        
        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateX(30px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }
        
        .form-body {
            padding: 30px 25px;
        }
        
        .form-group {
            margin-bottom: 18px;
        }
        
        .form-group label {
            font-weight: 600;
            color: #475569;
            margin-bottom: 6px;
            display: block;
            font-size: 13px;
        }
        
        .form-control {
            padding: 10px 14px;
            border: 2px solid #e2e8f0;
            border-radius: 10px;
            font-size: 13px;
            transition: all 0.3s ease;
            width: 100%;
        }
        
        .form-control:focus {
            border-color: #4CAF50;
            box-shadow: 0 0 0 3px rgba(76, 175, 80, 0.1);
            outline: none;
        }
        
        .btn-submit {
            width: 100%;
            padding: 12px;
            background: linear-gradient(135deg, #4CAF50, #2E7D32);
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 15px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-top: 12px;
        }
        
        .btn-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(46, 125, 50, 0.3);
        }
        
        .alert {
            border-radius: 10px;
            padding: 12px 16px;
            margin-bottom: 20px;
            border: none;
            font-size: 13px;
        }
        
        .alert-success {
            background: rgba(76, 175, 80, 0.1);
            color: #2E7D32;
            border-left: 4px solid #2E7D32;
        }
        
        .alert-danger {
            background: rgba(239, 68, 68, 0.1);
            color: #b91c1c;
            border-left: 4px solid #b91c1c;
        }
        
        /* Role Badge - SMALLER */
        .role-badge {
            display: flex;
            align-items: center;
            gap: 12px;
            background: #f8fafc;
            padding: 12px 16px;
            border-radius: 10px;
            margin-bottom: 20px;
            border: 2px solid #e2e8f0;
        }
        
        .role-badge-icon {
            width: 48px;
            height: 48px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 22px;
            color: white;
        }
        
        .role-badge.admin .role-badge-icon { background: linear-gradient(135deg, #667eea, #764ba2); }
        .role-badge.ceo .role-badge-icon { background: linear-gradient(135deg, #f093fb, #f5576c); }
        .role-badge.user .role-badge-icon { background: linear-gradient(135deg, #4facfe, #00f2fe); }
        
        .role-badge-text {
            font-size: 18px;
            font-weight: 700;
            color: #1e293b;
            line-height: 1.2;
        }
        
        .role-badge small {
            font-size: 11px;
            color: #64748b;
            display: block;
        }
        
        .forgot-password-link {
            text-align: center;
            margin-top: 16px;
        }
        
        .forgot-password-link a {
            color: #4CAF50;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s ease;
            font-size: 13px;
        }
        
        .forgot-password-link a:hover {
            color: #2E7D32;
            text-decoration: underline;
        }
        
        /* Success Message Overlay */
        .success-message {
            position: fixed;
            top: 100px;
            left: 50%;
            transform: translateX(-50%);
            z-index: 2000;
            min-width: 350px;
            text-align: center;
        }
        
        /* Role Indicator - SMALLER */
        .role-indicator {
            display: flex;
            align-items: center;
            gap: 8px;
            margin-top: 8px;
            margin-bottom: 15px;
            padding: 8px 12px;
            background: #f1f5f9;
            border-radius: 8px;
            font-size: 12px;
            color: #475569;
        }
        
        .role-indicator i {
            color: #4CAF50;
            font-size: 12px;
        }
        
        @media (max-width: 768px) {
            .login-header {
                padding: 15px 20px;
                justify-content: center;
            }
            
            .button-area {
                width: 100%;
                justify-content: center;
            }
            
            .btn-header {
                padding: 8px 16px;
                font-size: 13px;
            }
            
            .success-message {
                min-width: 90%;
                top: 80px;
            }
            
            .main-content {
                justify-content: center;
                padding: 100px 20px 20px;
            }
            
            .form-container {
                max-width: 350px;
            }
        }
    </style>
</head>
<body>
    <div class="background">
        <!-- Header with Login and Create Account Buttons (with Dropdown) -->
        <div class="login-header">
            <div class="button-area">
                <!-- Login Button with Dropdown -->
                <div class="dropdown">
                    <button class="btn-header btn-login <?php echo $show_login_form ? 'btn-active' : ''; ?>" id="loginDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fas fa-sign-in-alt"></i> Login
                    </button>
                    <div class="dropdown-menu dropdown-menu-custom" aria-labelledby="loginDropdown">
                        <h6 style="padding: 8px 12px; color: #64748b; font-weight: 600; margin: 0; font-size: 13px;">Select Role to Login</h6>
                        <div class="role-option admin" onclick="window.location.href='?action=login&role=admin'">
                            <div class="role-option-icon">
                                <i class="fas fa-shield-alt"></i>
                            </div>
                            <div class="role-option-info">
                                <h4>Administrator</h4>
                                <p>Full system access & management</p>
                            </div>
                        </div>
                        <div class="role-option ceo" onclick="window.location.href='?action=login&role=ceo'">
                            <div class="role-option-icon">
                                <i class="fas fa-crown"></i>
                            </div>
                            <div class="role-option-info">
                                <h4>CEO / Executive</h4>
                                <p>View reports & analytics</p>
                            </div>
                        </div>
                        <div class="role-option user" onclick="window.location.href='?action=login&role=user'">
                            <div class="role-option-icon">
                                <i class="fas fa-user"></i>
                            </div>
                            <div class="role-option-info">
                                <h4>Regular User</h4>
                                <p>Basic access & operations</p>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Create Account Button with Dropdown -->
                <div class="dropdown">
                    <button class="btn-header btn-create <?php echo $show_create_form ? 'btn-active' : ''; ?>" id="createDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fas fa-user-plus"></i> Create Account
                    </button>
                    <div class="dropdown-menu dropdown-menu-custom" aria-labelledby="createDropdown">
                        <h6 style="padding: 8px 12px; color: #64748b; font-weight: 600; margin: 0; font-size: 13px;">Select Role to Create</h6>
                        <div class="role-option admin" onclick="window.location.href='?action=create&role=admin'">
                            <div class="role-option-icon">
                                <i class="fas fa-shield-alt"></i>
                            </div>
                            <div class="role-option-info">
                                <h4>Administrator</h4>
                                <p>Create admin account</p>
                            </div>
                        </div>
                        <div class="role-option ceo" onclick="window.location.href='?action=create&role=ceo'">
                            <div class="role-option-icon">
                                <i class="fas fa-crown"></i>
                            </div>
                            <div class="role-option-info">
                                <h4>CEO / Executive</h4>
                                <p>Create CEO account</p>
                            </div>
                        </div>
                        <div class="role-option user" onclick="window.location.href='?action=create&role=user'">
                            <div class="role-option-icon">
                                <i class="fas fa-user"></i>
                            </div>
                            <div class="role-option-info">
                                <h4>Regular User</h4>
                                <p>Create user account</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Success Message (if any) -->
        <?php if (!empty($success_message)): ?>
            <div class="success-message">
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($success_message); ?>
                </div>
            </div>
        <?php endif; ?>
        
        <!-- Main Content Area - Form on the RIGHT side -->
        <div class="main-content">
            <!-- LOGIN FORM - SMALLER and on the RIGHT -->
            <?php if ($show_login_form): ?>
            <div class="form-container">
                <div class="form-body">
                    <!-- Role Badge - Changes based on selected role -->
                    <div class="role-badge <?php echo $selected_role; ?>">
                        <div class="role-badge-icon">
                            <i class="fas fa-<?php 
                                echo $selected_role === 'admin' ? 'shield-alt' : 
                                    ($selected_role === 'ceo' ? 'crown' : 'user'); 
                            ?>"></i>
                        </div>
                        <div>
                            <small>Logging in as</small>
                            <div class="role-badge-text">
                                <?php 
                                    echo $selected_role === 'admin' ? 'ADMINISTRATOR' : 
                                        ($selected_role === 'ceo' ? 'CHIEF EXECUTIVE' : 'REGULAR USER'); 
                                ?>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Role Indicator (shows current selection) -->
                    <div class="role-indicator">
                        <i class="fas fa-info-circle"></i>
                        <span>You are logging in as <strong><?php echo strtoupper($selected_role); ?></strong></span>
                    </div>
                    
                    <?php if (!empty($error_message)): ?>
                        <div class="alert alert-danger">
                            <i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($error_message); ?>
                        </div>
                    <?php endif; ?>
                    
                    <form method="POST">
                        <input type="hidden" name="role" value="<?php echo htmlspecialchars($selected_role); ?>">
                        <input type="hidden" name="login_direct" value="1">
                        
                        <div class="form-group">
                            <label><i class="fas fa-user"></i> Username</label>
                            <input type="text" class="form-control" name="username" placeholder="Enter your username" required autofocus>
                        </div>
                        
                        <div class="form-group">
                            <label><i class="fas fa-lock"></i> Password</label>
                            <input type="password" class="form-control" name="password" placeholder="Enter your password" required>
                        </div>
                        
                        <button type="submit" class="btn-submit">
                            <i class="fas fa-sign-in-alt"></i> 
                            Login as <?php 
                                echo $selected_role === 'admin' ? 'Administrator' : 
                                    ($selected_role === 'ceo' ? 'CEO' : 'User'); 
                            ?>
                        </button>
                        
                        <!-- Forgot Password Link -->
                        <div class="forgot-password-link">
                            <a href="?forgot_password=true">
                                <i class="fas fa-key"></i> Forgot Password?
                            </a>
                        </div>
                    </form>
                </div>
            </div>
            <?php endif; ?>
            
            <!-- CREATE ACCOUNT FORM - SMALLER and on the RIGHT -->
            <?php if ($show_create_form): ?>
            <div class="form-container">
                <div class="form-body">
                    <!-- Role Badge -->
                    <div class="role-badge <?php echo $selected_role; ?>">
                        <div class="role-badge-icon">
                            <i class="fas fa-<?php 
                                echo $selected_role === 'admin' ? 'shield-alt' : 
                                    ($selected_role === 'ceo' ? 'crown' : 'user'); 
                            ?>"></i>
                        </div>
                        <div>
                            <small>Creating</small>
                            <div class="role-badge-text">
                                <?php echo strtoupper($selected_role); ?> ACCOUNT
                            </div>
                        </div>
                    </div>
                    
                    <!-- Role Indicator -->
                    <div class="role-indicator">
                        <i class="fas fa-info-circle"></i>
                        <span>Creating <strong><?php echo strtoupper($selected_role); ?></strong> account</span>
                    </div>
                    
                    <?php if (!empty($error_message)): ?>
                        <div class="alert alert-danger">
                            <i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($error_message); ?>
                        </div>
                    <?php endif; ?>
                    
                    <form method="POST" onsubmit="return validateCreatePassword()">
                        <input type="hidden" name="role" value="<?php echo htmlspecialchars($selected_role); ?>">
                        <input type="hidden" name="create_account_direct" value="1">
                        
                        <div class="form-group">
                            <label><i class="fas fa-user"></i> Full Name</label>
                            <input type="text" class="form-control" name="full_name" placeholder="Enter full name" required>
                        </div>
                        
                        <div class="form-group">
                            <label><i class="fas fa-envelope"></i> Email Address</label>
                            <input type="email" class="form-control" name="email" placeholder="Enter email" required>
                        </div>
                        
                        <div class="form-group">
                            <label><i class="fas fa-user-circle"></i> Username</label>
                            <input type="text" class="form-control" name="username" placeholder="Choose username" required>
                        </div>
                        
                        <div class="form-group">
                            <label><i class="fas fa-lock"></i> Password</label>
                            <input type="password" class="form-control" name="password" id="create_password" placeholder="Min. 6 characters" required>
                        </div>
                        
                        <div class="form-group">
                            <label><i class="fas fa-lock"></i> Confirm Password</label>
                            <input type="password" class="form-control" name="confirm_password" id="create_confirm_password" placeholder="Confirm password" required>
                        </div>
                        
                        <div style="background: #f8fafc; padding: 16px; border-radius: 10px; margin-top: 16px;">
                            <h6 style="color: #1e293b; font-weight: 700; margin-bottom: 12px; font-size: 14px;">
                                <i class="fas fa-shield-alt"></i> Security Questions
                            </h6>
                            <p style="color: #64748b; font-size: 11px; margin-bottom: 16px;">
                                These will be used to recover your account
                            </p>
                            
                            <div class="form-group">
                                <label style="font-size: 12px;">What is your Middle Name?</label>
                                <input type="text" class="form-control" name="answer1" required>
                            </div>
                            
                            <div class="form-group">
                                <label style="font-size: 12px;">What is your First Name?</label>
                                <input type="text" class="form-control" name="answer2" required>
                            </div>
                            
                            <div class="form-group">
                                <label style="font-size: 12px;">What is your Last Name?</label>
                                <input type="text" class="form-control" name="answer3" required>
                            </div>
                        </div>
                        
                        <button type="submit" class="btn-submit">
                            <i class="fas fa-check-circle"></i> Create <?php echo strtoupper($selected_role); ?> Account
                        </button>
                    </form>
                </div>
            </div>
            <?php endif; ?>
            
            <!-- SECURITY QUESTIONS FORM (Forgot Password) -->
            <?php if ($show_security_form): ?>
            <div class="form-container">
                <div class="form-body">
                    <h4 style="color: #1e293b; font-weight: 700; margin-bottom: 10px; font-size: 18px;">
                        <i class="fas fa-shield-alt"></i> Account Recovery
                    </h4>
                    <p style="color: #64748b; margin-bottom: 20px; font-size: 13px;">
                        Please answer your security questions to reset your password.
                    </p>
                    
                    <?php if (!empty($error_message)): ?>
                        <div class="alert alert-danger">
                            <i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($error_message); ?>
                        </div>
                    <?php endif; ?>
                    
                    <form method="POST" action="verify_security.php">
                        <div class="form-group">
                            <label>What is your Middle Name?</label>
                            <input type="text" class="form-control" name="answer1" required>
                        </div>
                        <div class="form-group">
                            <label>What is your First Name?</label>
                            <input type="text" class="form-control" name="answer2" required>
                        </div>
                        <div class="form-group">
                            <label>What is your Last Name?</label>
                            <input type="text" class="form-control" name="answer3" required>
                        </div>
                        <button type="submit" class="btn-submit">
                            <i class="fas fa-check"></i> Verify
                        </button>
                        <a href="login.php" class="btn" style="width: 100%; margin-top: 8px; padding: 10px; background: #64748b; color: white; text-decoration: none; border-radius: 10px; display: inline-block; text-align: center; font-size: 14px;">
                            <i class="fas fa-times"></i> Cancel
                        </a>
                    </form>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
    
    <script>
        // Validate password for create account
        function validateCreatePassword() {
            var password = document.getElementById("create_password").value;
            var confirm = document.getElementById("create_confirm_password").value;
            
            if (password != confirm) {
                alert("Passwords do not match!");
                return false;
            }
            if (password.length < 6) {
                alert("Password must be at least 6 characters long!");
                return false;
            }
            return true;
        }
        
        // Auto-hide success message after 5 seconds
        $(document).ready(function(){
            setTimeout(function() {
                $('.alert-success').fadeOut('slow');
            }, 5000);
        });
    </script>
</body>
</html>