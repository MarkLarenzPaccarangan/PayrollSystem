<?php
session_start();
include_once("connection.php");

header('Content-Type: application/json');

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (!isset($_SESSION['Admin_User'])) {
    echo json_encode(['success' => false, 'message' => 'Not authorized']);
    exit;
}

$site_id = isset($_GET['site_id']) ? intval($_GET['site_id']) : 0;
$date = isset($_GET['date']) ? $_GET['date'] : date('Y-m-d');

// Log for debugging
error_log("=== get_attendance_by_site.php ===");
error_log("Site ID: " . $site_id);
error_log("Date: " . $date);

if (!$site_id) {
    echo json_encode(['success' => false, 'message' => 'Site ID required']);
    exit;
}

try {
    // Get site details
    $site_query = "SELECT sm.*, so.assignment_type, so.person_group 
                   FROM site_monitoring sm 
                   LEFT JOIN site_others so ON sm.id = so.site_id 
                   WHERE sm.id = ?";
    $site_stmt = $conn->prepare($site_query);
    $site_stmt->bind_param("i", $site_id);
    $site_stmt->execute();
    $site_result = $site_stmt->get_result();
    $site = $site_result->fetch_assoc();
    
    if (!$site) {
        echo json_encode(['success' => false, 'message' => 'Site not found']);
        exit;
    }
    
    $site_name = $site['site_name'];
    error_log("Site Name: " . $site_name);
    
    // First, let's check what attendance records exist for this date
    $check_query = "SELECT COUNT(*) as total FROM attendance WHERE DATE(date) = DATE(?)";
    $check_stmt = $conn->prepare($check_query);
    $check_stmt->bind_param("s", $date);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();
    $check_row = $check_result->fetch_assoc();
    error_log("Total attendance records for $date: " . $check_row['total']);
    $check_stmt->close();
    
    // Check what site assignments exist in attendance
    $site_check_query = "SELECT DISTINCT site_assignment_am, site_assignment_pm, site_assignment_night 
                         FROM attendance 
                         WHERE DATE(date) = DATE(?) 
                         AND (site_assignment_am IS NOT NULL OR site_assignment_pm IS NOT NULL OR site_assignment_night IS NOT NULL)";
    $site_check_stmt = $conn->prepare($site_check_query);
    $site_check_stmt->bind_param("s", $date);
    $site_check_stmt->execute();
    $site_check_result = $site_check_stmt->get_result();
    $found_sites = [];
    while ($row = $site_check_result->fetch_assoc()) {
        if ($row['site_assignment_am']) $found_sites[] = $row['site_assignment_am'];
        if ($row['site_assignment_pm']) $found_sites[] = $row['site_assignment_pm'];
        if ($row['site_assignment_night']) $found_sites[] = $row['site_assignment_night'];
    }
    error_log("Sites found in attendance: " . json_encode(array_unique($found_sites)));
    $site_check_stmt->close();
    
    // Get attendance records where employee was assigned to this site
    $attendance_query = "SELECT DISTINCT 
                                a.employee_id,
                                a.status,
                                a.pm_status,
                                a.night_status,
                                a.time_in_am,
                                a.time_out_am,
                                a.time_in_pm,
                                a.time_out_pm,
                                a.time_in_night,
                                a.time_out_night,
                                a.site_assignment_am,
                                a.site_assignment_pm,
                                a.site_assignment_night,
                                a.total_hours,
                                a.remarks,
                                e.first_name,
                                e.middle_name,
                                e.last_name,
                                e.position
                         FROM attendance a
                         INNER JOIN employees e ON a.employee_id = e.id
                         WHERE DATE(a.date) = DATE(?)
                         AND (
                             a.site_assignment_am = ? OR 
                             a.site_assignment_pm = ? OR 
                             a.site_assignment_night = ?
                         )
                         ORDER BY e.last_name, e.first_name";
    
    $att_stmt = $conn->prepare($attendance_query);
    $att_stmt->bind_param("ssss", $date, $site_name, $site_name, $site_name);
    $att_stmt->execute();
    $att_result = $att_stmt->get_result();
    
    error_log("Query returned " . $att_result->num_rows . " rows");
    
    $employees = [];
    $total_hours_sum = 0;
    $present_count = 0;
    $absent_count = 0;
    
    while ($row = $att_result->fetch_assoc()) {
        error_log("Found employee: " . $row['first_name'] . " " . $row['last_name']);
        error_log("  - site_assignment_am: " . $row['site_assignment_am']);
        error_log("  - site_assignment_pm: " . $row['site_assignment_pm']);
        error_log("  - site_assignment_night: " . $row['site_assignment_night']);
        
        // Format employee name
        $full_name = trim($row['first_name'] . ' ' . 
                        (!empty($row['middle_name']) ? substr($row['middle_name'], 0, 1) . '. ' : '') . 
                        $row['last_name']);
        
        // Determine which session(s) they are assigned to this site
        $assigned_sessions = [];
        if ($row['site_assignment_am'] == $site_name) {
            $assigned_sessions[] = 'AM';
        }
        if ($row['site_assignment_pm'] == $site_name) {
            $assigned_sessions[] = 'PM';
        }
        if ($row['site_assignment_night'] == $site_name) {
            $assigned_sessions[] = 'Night';
        }
        
        // Determine overall status
        if ($row['status'] == 'Present' || $row['pm_status'] == 'Present' || $row['night_status'] == 'Present') {
            $present_count++;
        } else {
            $absent_count++;
        }
        
        // Format times
        $time_in_am = !empty($row['time_in_am']) ? date('h:i A', strtotime($row['time_in_am'])) : '-';
        $time_out_am = !empty($row['time_out_am']) ? date('h:i A', strtotime($row['time_out_am'])) : '-';
        $time_in_pm = !empty($row['time_in_pm']) ? date('h:i A', strtotime($row['time_in_pm'])) : '-';
        $time_out_pm = !empty($row['time_out_pm']) ? date('h:i A', strtotime($row['time_out_pm'])) : '-';
        $time_in_night = !empty($row['time_in_night']) ? date('h:i A', strtotime($row['time_in_night'])) : '-';
        $time_out_night = !empty($row['time_out_night']) ? date('h:i A', strtotime($row['time_out_night'])) : '-';
        
        $total_hours_sum += floatval($row['total_hours']);
        
        $employees[] = [
            'employee_id' => $row['employee_id'],
            'employee_name' => $full_name,
            'position' => $row['position'] ?? 'N/A',
            'status' => $row['status'] ?? 'No Record',
            'pm_status' => $row['pm_status'] ?? 'No Record',
            'night_status' => $row['night_status'] ?? 'No Record',
            'assigned_sessions' => $assigned_sessions,
            'time_in_am' => $time_in_am,
            'time_out_am' => $time_out_am,
            'time_in_pm' => $time_in_pm,
            'time_out_pm' => $time_out_pm,
            'time_in_night' => $time_in_night,
            'time_out_night' => $time_out_night,
            'site_assignment_am' => $row['site_assignment_am'],
            'site_assignment_pm' => $row['site_assignment_pm'],
            'site_assignment_night' => $row['site_assignment_night'],
            'total_hours' => number_format($row['total_hours'], 2),
            'remarks' => $row['remarks'] ?? '-'
        ];
    }
    
    $response = [
        'success' => true,
        'site' => $site,
        'employees' => $employees,
        'summary' => [
            'total' => count($employees),
            'present' => $present_count,
            'absent' => $absent_count,
            'total_hours' => number_format($total_hours_sum, 2)
        ],
        'date' => $date,
        'debug' => [
            'site_name_searched' => $site_name,
            'total_attendance_records' => $check_row['total'],
            'sites_found_in_attendance' => array_unique($found_sites)
        ]
    ];
    
    error_log("Response: " . json_encode($response));
    echo json_encode($response);
    
    $att_stmt->close();
    $site_stmt->close();
    
} catch (Exception $e) {
    error_log("ERROR: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}

$conn->close();
?>