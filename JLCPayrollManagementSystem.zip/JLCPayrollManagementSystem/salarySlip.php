<?php
session_start();

// Redirect if the admin is not logged in
if (!isset($_SESSION['Admin_User'])) {
    header("Location: login.php");
    exit;
}

// Include database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "payrollsystem";

$conn = new mysqli($servername, $username, $password, $database);

// Check database connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch employee salary slip details (if employee_id is passed via GET)
$employeeData = null;
$deductionsData = [];
$payrollId = null;

if (isset($_GET['employee_id'])) {
    $employeeId = $_GET['employee_id'];

    // Check if payroll record already exists for the employee
    $payrollQuery = "
        SELECT id FROM payroll 
        WHERE employee_id = ? 
        LIMIT 1
    ";
    $stmt = $conn->prepare($payrollQuery);
    $stmt->bind_param("i", $employeeId);
    $stmt->execute();
    $payrollResult = $stmt->get_result();

    // If payroll record does not exist, create a new one
    if ($payrollResult->num_rows === 0) {
        $insertPayrollQuery = "
            INSERT INTO payroll (employee_id, date_from, date_to)
            VALUES (?, NOW(), NOW() + INTERVAL 1 MONTH)
        ";
        $stmt = $conn->prepare($insertPayrollQuery);
        $stmt->bind_param("i", $employeeId);
        $stmt->execute();

        // Retrieve the generated payroll ID
        $payrollId = $conn->insert_id;
    } else {
        // Get the existing payroll ID if it exists
        $payrollId = $payrollResult->fetch_assoc()['id'];
    }

    // Fetch salary details
    $salaryDetailsQuery = "
    SELECT 
        e.id, 
        CONCAT(e.first_name, ' ', e.last_name) AS employee_name, 
        e.contact_num, 
        e.position, 
        e.monthly_salary, 
        (e.monthly_salary - COALESCE(SUM(d.amount), 0)) AS net_salary, 
        e.email, 
        b.branch_name, 
        b.department_manager, 
        b.department_address,
        COALESCE(SUM(d.amount), 0) AS total_deductions,
        p.id AS payroll_id,
        p.date_from,
        p.date_to
    FROM employees e
    LEFT JOIN branch_employee be ON e.id = be.employee_id
    LEFT JOIN branch b ON be.branch_id = b.id
    LEFT JOIN deduction d ON e.id = d.employee_id
    LEFT JOIN payroll p ON e.id = p.employee_id
    WHERE e.id = ? 
    AND p.id = ? 
    AND e.status = 'active'  -- Ensure employee is active
    GROUP BY e.id, p.id
";

    $stmt = $conn->prepare($salaryDetailsQuery);
    $stmt->bind_param("ii", $employeeId, $payrollId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $employeeData = $result->fetch_assoc();
    }

    // Fetch all deductions for the employee
    $deductionsQuery = "
    SELECT d.deduction_name, d.amount, d.status
    FROM deduction d
    WHERE d.employee_id = ? AND d.status != 'disabled'
";

    $stmt = $conn->prepare($deductionsQuery);
    $stmt->bind_param("i", $employeeId);
    $stmt->execute();
    $deductionsResult = $stmt->get_result();

    while ($row = $deductionsResult->fetch_assoc()) {
        $deductionsData[] = $row;
    }
}

// Handle disabling an employee
if (isset($_POST['disable_employee_id'])) {
    $disableEmployeeId = $_POST['disable_employee_id'];

    // Update the status of the employee in the deductions table to 'disabled'
    $updateStatusQuery = "
        UPDATE deduction 
        SET status = 'disabled' 
        WHERE employee_id = ?
    ";
    $stmt = $conn->prepare($updateStatusQuery);
    $stmt->bind_param("i", $disableEmployeeId);
    $stmt->execute();

    // Redirect back to the salary slip page
    header("Location: salarySlip.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Salary Slip</title>
    <link rel="stylesheet" href="./assets/css/salarySlip2.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/0.5.0-beta4/html2canvas.min.js"></script>
    <style>
        .content-wrapper {
            min-height: calc(100vh - var(--header-height) - 40px);
        }
        
        .employee-info {
            display: grid;
            gap: 4px;
        }
        
        .employee-info strong {
            color: var(--sidebar-dark-green);
            font-weight: 600;
        }
        
        .net-pay-cell {
            font-weight: 700;
            color: var(--success-color);
        }
        
        .deductions-cell {
            color: var(--danger-color);
        }
        
        .controls-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin: 20px 0;
            padding: 15px 20px;
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
        }
        
        .search-section {
            display: flex;
            align-items: center;
            gap: 15px;
            flex: 1;
        }
        
        .generate-report-btn {
            background-color: var(--sidebar-green);
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 25px;
            font-size: 0.95rem;
            font-weight: 600;
            cursor: pointer;
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 8px;
            box-shadow: var(--box-shadow);
            white-space: nowrap;
            text-decoration: none;
        }
        
        .generate-report-btn:hover {
            background-color: var(--sidebar-dark-green);
            transform: translateY(-2px);
            box-shadow: 0 6px 8px rgba(0, 0, 0, 0.15);
        }
        
        .pay-period {
            color: #666;
            font-size: 0.9rem;
            font-style: italic;
        }
    </style>
</head>
<body>
    <!-- Header -->
    <?php include_once("./includes/header.php"); ?>

    <main class="content">
        <div class="content-wrapper">

            <!-- Search Controls -->
            <div class="controls">
                <div class="search-container">
                    <input type="text" placeholder="Search employees..." class="search-bar">
                    <button class="search-btn">
                        <i class="fas fa-search"></i>
                    </button>
                </div>
            </div>

            <!-- Generate Report Button -->
            <a href="generate_salary_report.php" class="generate-report-btn" style="margin: 20px 0; display: inline-block;">
                <i class="fas fa-chart-bar"></i> Generate Salary Report
            </a>

            <!-- Salary Table -->
            <div class="table-responsive">
                <table class="form-container">
                    <thead>
                        <tr>
                            <th>Employee ID</th>
                            <th>Employee Name</th>
                            <th>Position</th>
                            <th>Monthly Salary</th>
                            <th>Total Deductions</th>
                            <th>Net Salary</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $salaryDetailsQuery = "
                                SELECT 
                                    e.id, 
                                    CONCAT(e.first_name, ' ', e.last_name) AS employee_name, 
                                    e.position,
                                    e.monthly_salary, 
                                    (e.monthly_salary - COALESCE(SUM(d.amount), 0)) AS net_salary, 
                                    COALESCE(SUM(d.amount), 0) AS total_deductions
                                FROM employees e
                                LEFT JOIN deduction d ON e.id = d.employee_id
                                WHERE d.status != 'disabled'  -- Exclude disabled employees
                                GROUP BY e.id
                                ORDER BY e.first_name, e.last_name
                            ";
                            $result = $conn->query($salaryDetailsQuery);

                            if ($result->num_rows > 0):
                                while ($row = $result->fetch_assoc()):
                        ?>
                            <tr>
                                <td><strong><?= $row['id'] ?></strong></td>
                                <td>
                                    <div class="employee-info">
                                        <div><strong>Name:</strong> <?= htmlspecialchars($row['employee_name']) ?></div>
                                    </div>
                                </td>
                                <td><?= htmlspecialchars($row['position']) ?></td>
                                <td class="currency">₱<?= number_format($row['monthly_salary'], 2) ?></td>
                                <td class="currency deductions-cell">₱<?= number_format($row['total_deductions'], 2) ?></td>
                                <td class="currency net-pay-cell">₱<?= number_format($row['net_salary'], 2) ?></td>
                                <td>
                                    <a href="salarySlip.php?employee_id=<?= $row['id'] ?>" class="view" title="View Salary Slip">
                                        <i class="fas fa-eye"></i> View Slip
                                    </a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="7">
                                    <div class="empty-state">
                                        <i class="fas fa-file-invoice-dollar"></i>
                                        <p>No salary data found</p>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

    <!-- Footer -->
    <?php include_once("./includes/footer.php"); ?>

    <!-- Salary Slip Modal -->
    <?php if ($employeeData): ?>
    <div id="salary-modal" class="salary-modal">
        <div class="salary-modal-content" id="salary-slip-content">
            <div class="salary-header">
                <h2><i class="fas fa-file-invoice-dollar"></i> SALARY SLIP</h2>
                <p><?= date('F Y') ?> • Pay Period: <?= date('M d', strtotime($employeeData['date_from'])) ?> - <?= date('M d, Y', strtotime($employeeData['date_to'])) ?></p>
            </div>
            
            <div class="employee-info-modal">
                <div>
                    <strong><i class="fas fa-id-card"></i> Employee ID:</strong>
                    <span><?= htmlspecialchars($employeeData['id']) ?></span>
                </div>
                <div>
                    <strong><i class="fas fa-user"></i> Employee Name:</strong>
                    <span><?= htmlspecialchars($employeeData['employee_name']) ?></span>
                </div>
                <div>
                    <strong><i class="fas fa-briefcase"></i> Position:</strong>
                    <span><?= htmlspecialchars($employeeData['position']) ?></span>
                </div>
                <div>
                    <strong><i class="fas fa-building"></i> Branch:</strong>
                    <span><?= htmlspecialchars($employeeData['branch_name'] ?? 'Not Assigned') ?></span>
                </div>
            </div>

            <table class="salary-table">
                <thead>
                    <tr>
                        <th>Earnings</th>
                        <th>Amount</th>
                        <th>Deductions</th>
                        <th>Amount</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><strong>Base Salary</strong></td>
                        <td class="currency">₱<?= number_format($employeeData['monthly_salary'], 2) ?></td>
                        <td>
                            <?php if (count($deductionsData) > 0): ?>
                                <?php foreach ($deductionsData as $index => $deduction): ?>
                                    <?php if ($deduction['status'] !== 'disabled'): ?>
                                        <div><?= htmlspecialchars($deduction['deduction_name']) ?></div>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <div>-</div>
                            <?php endif; ?>
                        </td>
                        <td class="currency">
                            <?php if (count($deductionsData) > 0): ?>
                                <?php foreach ($deductionsData as $deduction): ?>
                                    <?php if ($deduction['status'] !== 'disabled'): ?>
                                        <div>₱<?= number_format($deduction['amount'], 2) ?></div>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <div>-</div>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <td><strong>Total Earnings</strong></td>
                        <td class="currency">₱<?= number_format($employeeData['monthly_salary'], 2) ?></td>
                        <td><strong>Total Deductions</strong></td>
                        <td class="currency deductions-cell">₱<?= number_format($employeeData['total_deductions'], 2) ?></td>
                    </tr>
                </tbody>
            </table>
            
            <div class="net-pay">
                <i class="fas fa-money-check-alt"></i> 
                <strong>NET PAY: ₱<?= number_format($employeeData['net_salary'], 2) ?></strong>
            </div>

            <div class="modal-buttons">
                <button class="close-btn" onclick="closeModal()">
                    <i class="fas fa-times"></i> Close
                </button>
                <button class="send-btn" onclick="saveAsImage()">
                    <i class="fas fa-download"></i> Save as Image
                </button>
            </div>
        </div>
    </div>
    
    <!-- Loading Overlay -->
    <div class="loading-overlay" id="loadingOverlay">
        <div class="loading-spinner"></div>
        <p>Saving salary slip...</p>
    </div>
    
    <!-- Download Success Message -->
    <div class="download-success" id="downloadSuccess">
        <i class="fas fa-check-circle"></i> Salary slip saved successfully!
    </div>
    <?php endif; ?>
    
    <?php include_once("./modal/logout-modal.php"); ?>

    <script>
        // Ensure the modal opens automatically if the page is loaded with an employee ID
        document.addEventListener('DOMContentLoaded', function() {
            <?php if ($employeeData): ?>
                document.getElementById('salary-modal').style.display = 'flex';
                document.body.classList.add('modal-open');
            <?php endif; ?>
        });

        // Close the modal
        function closeModal() {
            document.getElementById('salary-modal').style.display = 'none';
            document.body.classList.remove('modal-open');
            window.history.pushState({}, document.title, window.location.pathname);
        }

        // Function to save the salary slip as an image
        function saveAsImage() {
            var salarySlipContent = document.getElementById('salary-slip-content');
            var modalButtons = document.querySelector('.modal-buttons');
            var loadingOverlay = document.getElementById('loadingOverlay');

            // Show loading overlay
            loadingOverlay.style.display = 'flex';
            
            // Hide buttons temporarily
            modalButtons.style.display = 'none';

            html2canvas(salarySlipContent, {
                scale: 3,
                useCORS: true,
                backgroundColor: '#ffffff',
                onclone: function(clonedDoc) {
                    clonedDoc.querySelector('.modal-buttons').style.display = 'none';
                }
            }).then(function(canvas) {
                // Convert canvas to image
                var link = document.createElement('a');
                link.href = canvas.toDataURL('image/png', 1.0);
                link.download = `Salary_Slip_${<?= $employeeData['id'] ?? '0' ?>}_<?= date('Y_m_d') ?>.png`;

                // Trigger download
                link.click();

                // Restore buttons
                modalButtons.style.display = 'flex';
                loadingOverlay.style.display = 'none';
                
                // Show success message
                showDownloadSuccess();
            }).catch(function(error) {
                console.error('Error capturing salary slip:', error);
                modalButtons.style.display = 'flex';
                loadingOverlay.style.display = 'none';
                alert('Error saving salary slip. Please try again.');
            });
        }

        // Show download success message
        function showDownloadSuccess() {
            const successMsg = document.getElementById('downloadSuccess');
            successMsg.style.display = 'block';
            setTimeout(() => {
                successMsg.style.display = 'none';
            }, 3000);
        }

        // Close modal when clicking outside
        window.onclick = function(event) {
            const modal = document.getElementById('salary-modal');
            if (event.target === modal) {
                closeModal();
            }
        }

        // Close modal with Escape key
        document.addEventListener('keydown', function(event) {
            if (event.key === 'Escape') {
                closeModal();
            }
        });

        // Search functionality
        document.querySelector('.search-btn').addEventListener('click', function() {
            const searchTerm = document.querySelector('.search-bar').value.toLowerCase();
            const rows = document.querySelectorAll('.form-container tbody tr');
            
            rows.forEach(row => {
                const employeeName = row.querySelector('td:nth-child(2)').textContent.toLowerCase();
                const employeeId = row.querySelector('td:nth-child(1)').textContent.toLowerCase();
                
                if (employeeName.includes(searchTerm) || employeeId.includes(searchTerm)) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        });

        // Enter key for search
        document.querySelector('.search-bar').addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                document.querySelector('.search-btn').click();
            }
        });
    </script>

</body>
</html>