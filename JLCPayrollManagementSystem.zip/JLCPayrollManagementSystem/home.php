<?php
// Start session - MUST BE THE VERY FIRST THING, NO SPACES BEFORE <?php
session_start();

if (!isset($_SESSION['Admin_User'])) {
    header("Location: login.php");
    exit;
}

// Include database connection
include_once("connection.php");

// ============================================
// DASHBOARD FUNCTIONS
// ============================================

/**
 * Get sites with employee counts and attendance for a specific date
 */
function getSitesWithAttendance($conn, $filter_date = null) {
    if (!$filter_date) {
        $filter_date = date('Y-m-d');
    }
    
    $query = "SELECT 
                s.id,
                s.site_name,
                s.site_manager,
                s.site_address,
                COUNT(DISTINCT se.employee_id) as total_employees,
                COUNT(DISTINCT CASE WHEN a.date = ? AND a.status = 'Present' 
                    THEN a.employee_id END) as present_count
              FROM site_monitoring s
              LEFT JOIN site_employee se ON s.id = se.site_id
              LEFT JOIN attendance a ON se.employee_id = a.employee_id 
                  AND a.date = ?
              GROUP BY s.id, s.site_name, s.site_manager, s.site_address
              ORDER BY s.site_name";
    
    $stmt = $conn->prepare($query);
    if (!$stmt) {
        error_log("Error preparing query: " . $conn->error);
        return [];
    }
    
    $stmt->bind_param("ss", $filter_date, $filter_date);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $sites = [];
    while ($row = $result->fetch_assoc()) {
        $sites[] = $row;
    }
    
    return $sites;
}

/**
 * Get available dates for filter dropdown
 */
function getAvailableDates($conn) {
    $query = "SELECT DISTINCT date 
              FROM attendance 
              ORDER BY date DESC 
              LIMIT 30";
    $result = $conn->query($query);
    
    $dates = [];
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $dates[] = $row['date'];
        }
    }
    
    return $dates;
}

/**
 * Get total statistics across all sites
 */
function getTotalStats($conn, $filter_date = null) {
    if (!$filter_date) {
        $filter_date = date('Y-m-d');
    }
    
    $query = "SELECT 
                COUNT(DISTINCT s.id) as total_sites,
                COUNT(DISTINCT se.employee_id) as total_employees,
                COUNT(DISTINCT CASE WHEN a.date = ? AND a.status = 'Present' 
                    THEN a.employee_id END) as total_present
              FROM site_monitoring s
              LEFT JOIN site_employee se ON s.id = se.site_id
              LEFT JOIN attendance a ON se.employee_id = a.employee_id AND a.date = ?";
    
    $stmt = $conn->prepare($query);
    if (!$stmt) {
        error_log("Error preparing query: " . $conn->error);
        return ['total_sites' => 0, 'total_employees' => 0, 'total_present' => 0];
    }
    
    $stmt->bind_param("ss", $filter_date, $filter_date);
    $stmt->execute();
    $result = $stmt->get_result();
    
    return $result->fetch_assoc();
}

// ============================================
// GET DASHBOARD DATA
// ============================================

// Get filter date from URL parameter or use today
$filter_date = isset($_GET['date']) ? $_GET['date'] : date('Y-m-d');

// Validate date format
if (!preg_match("/^\d{4}-\d{2}-\d{2}$/", $filter_date)) {
    $filter_date = date('Y-m-d');
}

// Fetch sites data
$sites = getSitesWithAttendance($conn, $filter_date);

// Fetch total statistics
$total_stats = getTotalStats($conn, $filter_date);

// Fetch available dates for filter
$available_dates = getAvailableDates($conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Site Monitoring</title>
    <link rel="stylesheet" href="./assets/css/home2.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            height: 100vh;
            overflow: hidden;
            background-color: #f0f2f5;
            position: relative;
        }

        /* Main Content Area - Perfectly Centered with Space Around */
        .content {
            display: flex;
            flex-direction: column;
            height: 100vh;
            overflow: hidden;
        }

        .main-content {
            flex: 1;
            margin-top: 80px; /* Space for header */
            padding: 30px 40px;
            width: 100%;
            height: calc(100vh - 80px);
            overflow-y: auto;
            overflow-x: hidden;
            background-color: transparent;
            color: #333;
            position: relative;
            display: flex;
            justify-content: center;
        }

        /* Custom Scrollbar - Better Visibility */
        .main-content::-webkit-scrollbar {
            width: 10px;
        }

        .main-content::-webkit-scrollbar-track {
            background: #e9ecef;
            border-radius: 10px;
        }

        .main-content::-webkit-scrollbar-thumb {
            background: #2E7D32;
            border-radius: 10px;
            border: 2px solid #e9ecef;
        }

        .main-content::-webkit-scrollbar-thumb:hover {
            background: #1B5E20;
        }

        /* Dashboard Container - Fixed Width for Better View */
        .dashboard-container {
            max-width: 1400px;
            width: 100%;
            margin: 0 auto;
            padding: 0 20px 30px 20px; /* Bottom padding for scroll visibility */
        }

        /* Dashboard Header */
        .dashboard-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            flex-wrap: wrap;
            background: white;
            padding: 20px 30px;
            border-radius: 16px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.05);
            width: 100%;
            border: 1px solid #e9ecef;
        }

        .dashboard-title {
            font-size: 24px;
            font-weight: 700;
            color: #1e293b;
            margin: 0;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .dashboard-title i {
            color: #2E7D32;
            font-size: 26px;
        }

        /* Date Filter */
        .date-filter {
            background: #f8fafc;
            padding: 12px 20px;
            border-radius: 40px;
            display: flex;
            align-items: center;
            gap: 12px;
            border: 1px solid #e2e8f0;
            flex-wrap: wrap;
        }

        .date-filter label {
            font-weight: 600;
            color: #475569;
            font-size: 14px;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .date-filter input {
            padding: 8px 16px;
            border: 1px solid #cbd5e1;
            border-radius: 30px;
            font-size: 14px;
            background: white;
            transition: all 0.3s ease;
        }

        .date-filter input:focus {
            outline: none;
            border-color: #4CAF50;
            box-shadow: 0 0 0 3px rgba(76, 175, 80, 0.1);
        }

        .date-filter button {
            padding: 8px 20px;
            background: linear-gradient(135deg, #2E7D32 0%, #1B5E20 100%);
            color: white;
            border: none;
            border-radius: 30px;
            cursor: pointer;
            font-weight: 600;
            font-size: 14px;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s ease;
            box-shadow: 0 2px 4px rgba(46, 125, 50, 0.2);
        }

        .date-filter button:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 12px rgba(46, 125, 50, 0.3);
        }

        .quick-select {
            padding: 8px 16px;
            border: 1px solid #cbd5e1;
            border-radius: 30px;
            background: white;
            font-size: 14px;
            cursor: pointer;
        }

        /* Statistics Cards Grid */
        .stats-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
            width: 100%;
        }

        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 16px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.05);
            display: flex;
            justify-content: space-between;
            align-items: center;
            transition: all 0.3s ease;
            border: 1px solid #e9ecef;
        }

        .stat-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 16px rgba(0,0,0,0.1);
            border-color: #4CAF50;
        }

        .stat-info h3 {
            margin: 0;
            font-size: 14px;
            color: #64748b;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            font-weight: 600;
        }

        .stat-info .number {
            font-size: 32px;
            font-weight: 700;
            color: #0f172a;
            margin-top: 6px;
            line-height: 1;
        }

        .stat-info .number.present {
            color: #059669;
        }

        .stat-icon {
            font-size: 42px;
            color: #2E7D32;
            opacity: 0.8;
        }

        /* Sites Container */
        .sites-container {
            background: white;
            border-radius: 16px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.05);
            padding: 25px;
            margin-top: 20px;
            width: 100%;
            border: 1px solid #e9ecef;
            margin-bottom: 20px; /* Space at bottom */
        }

        .sites-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid #f1f5f9;
            flex-wrap: wrap;
            gap: 15px;
        }

        .sites-header h2 {
            font-size: 20px;
            font-weight: 700;
            color: #1e293b;
            display: flex;
            align-items: center;
            gap: 10px;
            margin: 0;
        }

        .sites-header h2 i {
            color: #2E7D32;
        }

        /* Sites Grid - Responsive Cards */
        .sites-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(340px, 1fr));
            gap: 20px;
            width: 100%;
        }

        .site-card {
            background: white;
            border-radius: 16px;
            border: 1px solid #e9ecef;
            overflow: hidden;
            transition: all 0.3s ease;
            height: 100%;
            display: flex;
            flex-direction: column;
        }

        .site-card:hover {
            border-color: #4CAF50;
            box-shadow: 0 8px 16px rgba(0,0,0,0.08);
            transform: translateY(-2px);
        }

        .site-header {
            background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
            padding: 16px 20px;
            border-bottom: 1px solid #e9ecef;
        }

        .site-header h3 {
            margin: 0;
            font-size: 18px;
            font-weight: 700;
            color: #0f172a;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .site-header h3 i {
            color: #2E7D32;
            font-size: 18px;
        }

        .site-header p {
            margin: 6px 0 0;
            color: #64748b;
            font-size: 13px;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .site-content {
            padding: 20px;
            flex: 1;
        }

        .employee-stats {
            display: flex;
            justify-content: space-around;
            margin-bottom: 20px;
            background: #f8fafc;
            padding: 12px;
            border-radius: 12px;
        }

        .stat-item {
            text-align: center;
        }

        .stat-label {
            font-size: 11px;
            color: #64748b;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .stat-value {
            font-size: 24px;
            font-weight: 700;
            color: #0f172a;
            line-height: 1.2;
        }

        .stat-value.present {
            color: #059669;
        }

        .stat-value.absent {
            color: #dc2626;
        }

        .progress-section {
            margin-bottom: 20px;
        }

        .progress-header {
            display: flex;
            justify-content: space-between;
            margin-bottom: 6px;
            font-size: 12px;
        }

        .progress-label {
            color: #64748b;
            font-weight: 500;
        }

        .progress-percent {
            font-weight: 700;
            color: #2E7D32;
        }

        .progress-bar {
            width: 100%;
            height: 6px;
            background-color: #e2e8f0;
            border-radius: 4px;
            overflow: hidden;
        }

        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, #4CAF50, #2E7D32);
            border-radius: 4px;
            transition: width 0.5s ease;
        }

        .site-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 16px;
            padding-top: 16px;
            border-top: 1px solid #e9ecef;
        }

        .view-details-btn {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            background: #f1f5f9;
            color: #334155;
            padding: 6px 14px;
            border-radius: 30px;
            text-decoration: none;
            font-size: 12px;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .view-details-btn:hover {
            background: #2E7D32;
            color: white;
        }

        .manager-badge {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            background: rgba(46, 125, 50, 0.1);
            padding: 4px 12px;
            border-radius: 30px;
            font-size: 12px;
            color: #1B5E20;
        }

        /* No Data State */
        .no-data {
            text-align: center;
            padding: 50px 20px;
            background: white;
            border-radius: 16px;
            color: #64748b;
        }

        .no-data i {
            font-size: 48px;
            color: #94a3b8;
            margin-bottom: 16px;
        }

        .no-data p {
            font-size: 16px;
            margin-bottom: 8px;
        }

        .no-data .sub-text {
            font-size: 14px;
            color: #94a3b8;
        }

        /* Date Info Footer */
        .date-info {
            margin-top: 20px;
            margin-bottom: 10px;
            text-align: right;
            padding: 16px 20px;
            background: #f8fafc;
            border-radius: 16px;
            color: #475569;
            font-size: 14px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
            border: 1px solid #e9ecef;
        }

        .today-link {
            color: #2E7D32;
            text-decoration: none;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }

        .today-link:hover {
            text-decoration: underline;
        }

        /* Responsive Design - Comfortable Spacing */
        @media (max-width: 1400px) {
            .dashboard-container {
                max-width: 1300px;
            }
        }

        @media (max-width: 1200px) {
            .dashboard-container {
                max-width: 1100px;
            }
            
            .sites-grid {
                grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            }
        }

        @media (max-width: 1024px) {
            .main-content {
                padding: 25px 30px;
            }
            
            .dashboard-container {
                max-width: 100%;
                padding: 0 15px 30px 15px;
            }
        }

        @media (max-width: 768px) {
            .main-content {
                margin-top: 70px;
                padding: 20px 25px;
            }
            
            .dashboard-container {
                padding: 0 10px 30px 10px;
            }
            
            .dashboard-header {
                flex-direction: column;
                align-items: stretch;
                padding: 20px;
            }
            
            .date-filter {
                width: 100%;
                justify-content: space-between;
            }
            
            .sites-grid {
                grid-template-columns: 1fr;
            }
            
            .stats-cards {
                grid-template-columns: 1fr;
            }
            
            .sites-header {
                flex-direction: column;
                align-items: flex-start;
            }
        }

        @media (max-width: 576px) {
            .main-content {
                padding: 15px 20px;
            }
            
            .dashboard-container {
                padding: 0 5px 30px 5px;
            }
            
            .dashboard-title {
                font-size: 20px;
            }
            
            .date-filter {
                flex-direction: column;
                align-items: stretch;
                border-radius: 16px;
            }
            
            .date-filter input,
            .date-filter button,
            .quick-select {
                width: 100%;
            }
            
            .stat-card {
                padding: 16px;
            }
            
            .stat-info .number {
                font-size: 26px;
            }
            
            .stat-icon {
                font-size: 36px;
            }
            
            .employee-stats {
                flex-direction: column;
                gap: 12px;
            }
            
            .date-info {
                flex-direction: column;
                text-align: center;
            }
        }

        /* Loading State */
        .loading {
            text-align: center;
            padding: 40px;
            color: #64748b;
        }

        .loading i {
            font-size: 32px;
            margin-bottom: 12px;
            color: #2E7D32;
        }

        /* Ensure smooth scrolling */
        html {
            scroll-behavior: smooth;
        }

        /* Print Styles */
        @media print {
            .main-content {
                margin-left: 0;
                width: 100%;
                overflow: visible;
            }
            
            .date-filter,
            .view-details-btn,
            .today-link {
                display: none;
            }
        }
    </style>
</head>
<body>

    <!-- header -->
    <?php include_once("./includes/header.php"); ?>

    <!-- sidebar - Commented out since you don't have a sidebar -->
    <?php // include_once("./includes/sidebar.php"); ?>

    <main class="content">
        <div class="main-content">
            <div class="dashboard-container">
                <!-- Dashboard Header with Date Filter -->
                <div class="dashboard-header">
                    <div class="dashboard-title">
                        <i class="fas fa-chart-line"></i>
                        Site Monitoring Dashboard
                    </div>
                    
                    <div class="date-filter">
                        <label>
                            <i class="fas fa-calendar-alt"></i>
                            Date:
                        </label>
                        <input 
                            type="date" 
                            id="filter_date" 
                            name="date" 
                            value="<?php echo htmlspecialchars($filter_date); ?>"
                            max="<?php echo date('Y-m-d'); ?>"
                        >
                        <button onclick="filterByDate()">
                            <i class="fas fa-filter"></i>
                            Apply
                        </button>
                        
                        <?php if (!empty($available_dates)): ?>
                        <select id="quick_date" class="quick-select" onchange="quickDateSelect(this.value)">
                            <option value="">Quick Select</option>
                            <?php foreach ($available_dates as $date): ?>
                            <option value="<?php echo htmlspecialchars($date); ?>" <?php echo $date == $filter_date ? 'selected' : ''; ?>>
                                <?php echo date('M d, Y', strtotime($date)); ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Statistics Cards -->
                <div class="stats-cards">
                    <div class="stat-card">
                        <div class="stat-info">
                            <h3>Total Sites</h3>
                            <div class="number"><?php echo number_format($total_stats['total_sites'] ?? 0); ?></div>
                        </div>
                        <div class="stat-icon">
                            <i class="fas fa-building"></i>
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-info">
                            <h3>Total Employees</h3>
                            <div class="number"><?php echo number_format($total_stats['total_employees'] ?? 0); ?></div>
                        </div>
                        <div class="stat-icon">
                            <i class="fas fa-users"></i>
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-info">
                            <h3>Present</h3>
                            <div class="number present">
                                <?php echo number_format($total_stats['total_present'] ?? 0); ?>
                            </div>
                        </div>
                        <div class="stat-icon">
                            <i class="fas fa-check-circle"></i>
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-info">
                            <h3>Attendance Rate</h3>
                            <div class="number">
                                <?php 
                                $total_emp = $total_stats['total_employees'] ?? 0;
                                $total_present = $total_stats['total_present'] ?? 0;
                                $rate = $total_emp > 0 ? round(($total_present / $total_emp) * 100) : 0;
                                echo $rate . '%';
                                ?>
                            </div>
                        </div>
                        <div class="stat-icon">
                            <i class="fas fa-percentage"></i>
                        </div>
                    </div>
                </div>

                <!-- Sites Dashboard Section -->
                <div class="sites-container">
                    <div class="sites-header">
                        <h2>
                            <i class="fas fa-map-marked-alt"></i>
                            Site Status Overview
                        </h2>
                        <span class="manager-badge">
                            <i class="fas fa-calendar-check"></i>
                            <?php echo date('F d, Y', strtotime($filter_date)); ?>
                        </span>
                    </div>
                    
                    <?php if (empty($sites)): ?>
                        <div class="no-data">
                            <i class="fas fa-map-marked-alt"></i>
                            <p>No sites found</p>
                            <div class="sub-text">
                                <?php if (empty($total_stats['total_sites'])): ?>
                                    Please add sites in the Site Monitoring page.
                                <?php else: ?>
                                    No employees assigned to any site yet.
                                <?php endif; ?>
                            </div>
                            <a href="site_monitoring.php" style="display: inline-block; margin-top: 20px; padding: 10px 24px; background: #2E7D32; color: white; text-decoration: none; border-radius: 30px; font-weight: 600;">
                                <i class="fas fa-plus-circle"></i> Manage Sites
                            </a>
                        </div>
                    <?php else: ?>
                        <div class="sites-grid">
                            <?php foreach ($sites as $site): ?>
                                <?php 
                                $total_employees = intval($site['total_employees'] ?? 0);
                                $present_count = intval($site['present_count'] ?? 0);
                                $absent_count = max(0, $total_employees - $present_count);
                                $attendance_rate = $total_employees > 0 ? round(($present_count / $total_employees) * 100) : 0;
                                ?>
                                <div class="site-card">
                                    <div class="site-header">
                                        <h3>
                                            <i class="fas fa-building"></i>
                                            <?php echo htmlspecialchars($site['site_name']); ?>
                                        </h3>
                                        <p>
                                            <i class="fas fa-user-tie"></i>
                                            <?php echo htmlspecialchars($site['site_manager'] ?? 'No manager'); ?>
                                        </p>
                                        <p>
                                            <i class="fas fa-map-marker-alt"></i>
                                            <?php echo htmlspecialchars($site['site_address'] ?? 'No address'); ?>
                                        </p>
                                    </div>
                                    <div class="site-content">
                                        <div class="employee-stats">
                                            <div class="stat-item">
                                                <div class="stat-label">Total</div>
                                                <div class="stat-value"><?php echo $total_employees; ?></div>
                                            </div>
                                            <div class="stat-item">
                                                <div class="stat-label">Present</div>
                                                <div class="stat-value present"><?php echo $present_count; ?></div>
                                            </div>
                                            <div class="stat-item">
                                                <div class="stat-label">Absent</div>
                                                <div class="stat-value absent"><?php echo $absent_count; ?></div>
                                            </div>
                                        </div>
                                        
                                        <div class="progress-section">
                                            <div class="progress-header">
                                                <span class="progress-label">Attendance Rate</span>
                                                <span class="progress-percent"><?php echo $attendance_rate; ?>%</span>
                                            </div>
                                            <div class="progress-bar">
                                                <div class="progress-fill" style="width: <?php echo $attendance_rate; ?>%;"></div>
                                            </div>
                                        </div>
                                        
                                        <div class="site-footer">
                                            <span style="color: #64748b; font-size: 12px;">
                                                <i class="fas fa-users"></i>
                                                <?php echo $total_employees; ?> assigned
                                            </span>
                                            <a href="site_monitoring.php?edit=<?php echo $site['id']; ?>" class="view-details-btn">
                                                <i class="fas fa-arrow-right"></i>
                                                Details
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Date Information Footer -->
                <div class="date-info">
                    <span>
                        <i class="fas fa-info-circle"></i>
                        Showing data for: <strong><?php echo date('F d, Y', strtotime($filter_date)); ?></strong>
                    </span>
                    <?php if ($filter_date != date('Y-m-d')): ?>
                    <a href="home.php" class="today-link">
                        <i class="fas fa-calendar-day"></i>
                        View Today
                    </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </main>

    <!-- footer -->
    <?php include_once("./includes/footer.php"); ?>
    
    <!-- modal -->
    <?php include_once("./modal/logout-modal.php"); ?>

    <script>
        // Filter by date
        function filterByDate() {
            const dateInput = document.getElementById('filter_date');
            if (dateInput && dateInput.value) {
                window.location.href = 'home.php?date=' + encodeURIComponent(dateInput.value);
            }
        }
        
        // Quick date select
        function quickDateSelect(date) {
            if (date) {
                window.location.href = 'home.php?date=' + encodeURIComponent(date);
            }
        }
        
        // Set max date to today
        document.addEventListener('DOMContentLoaded', function() {
            const dateInput = document.getElementById('filter_date');
            if (dateInput) {
                dateInput.max = new Date().toISOString().split('T')[0];
            }
            
            // Add animation to progress bars
            setTimeout(() => {
                document.querySelectorAll('.progress-fill').forEach(bar => {
                    const width = bar.style.width;
                    bar.style.width = '0%';
                    setTimeout(() => {
                        bar.style.width = width;
                    }, 100);
                });
            }, 200);
        });
    </script>

</body>
</html>
<?php $conn->close(); ?>