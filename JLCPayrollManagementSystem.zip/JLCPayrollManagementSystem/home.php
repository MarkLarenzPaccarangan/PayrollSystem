<?php
// Start session - MUST BE THE VERY FIRST THING, NO SPACES BEFORE <?php
session_start();

if (!isset($_SESSION['Admin_User'])) {
    header("Location: login.php");
    exit;
}

// Include database connection
include_once("connection.php");

// ============================================
// DASHBOARD FUNCTIONS
// ============================================

/**
 * Get sites with employee counts and attendance for a specific date
 */
function getSitesWithAttendance($conn, $filter_date = null, $search = '', $sort_by = 'site_name', $sort_order = 'ASC') {
    if (!$filter_date) {
        $filter_date = date('Y-m-d');
    }
    
    $valid_sort_columns = ['site_name', 'site_manager', 'total_employees', 'present_count', 'attendance_rate'];
    if (!in_array($sort_by, $valid_sort_columns)) {
        $sort_by = 'site_name';
    }
    $sort_order = strtoupper($sort_order) === 'DESC' ? 'DESC' : 'ASC';
    
    $query = "SELECT 
                s.id,
                s.site_name,
                s.site_manager,
                s.site_address,
                s.is_others,
                so.assignment_type,
                so.person_group,
                COUNT(DISTINCT se.employee_id) as total_employees,
                COUNT(DISTINCT CASE WHEN a.date = ? AND a.status = 'Present' 
                    THEN a.employee_id END) as present_count,
                ROUND(COUNT(DISTINCT CASE WHEN a.date = ? AND a.status = 'Present' 
                    THEN a.employee_id END) * 100.0 / NULLIF(COUNT(DISTINCT se.employee_id), 0), 0) as attendance_rate
              FROM site_monitoring s
              LEFT JOIN site_others so ON s.others_id = so.id
              LEFT JOIN site_employee se ON s.id = se.site_id
              LEFT JOIN attendance a ON se.employee_id = a.employee_id 
                  AND a.date = ?
              WHERE 1=1";
    
    $params = [$filter_date, $filter_date, $filter_date];
    $types = "sss";
    
    if (!empty($search)) {
        $query .= " AND (s.site_name LIKE ? OR s.site_manager LIKE ? OR s.site_address LIKE ? OR so.assignment_type LIKE ? OR so.person_group LIKE ?)";
        $search_term = '%' . $search . '%';
        $params = array_merge($params, [$search_term, $search_term, $search_term, $search_term, $search_term]);
        $types .= "sssss";
    }
    
    $query .= " GROUP BY s.id, s.site_name, s.site_manager, s.site_address, s.is_others, so.assignment_type, so.person_group";
    
    // Handle sorting
    switch ($sort_by) {
        case 'site_name':
            $query .= " ORDER BY s.site_name $sort_order";
            break;
        case 'site_manager':
            $query .= " ORDER BY s.site_manager $sort_order";
            break;
        case 'total_employees':
            $query .= " ORDER BY total_employees $sort_order";
            break;
        case 'present_count':
            $query .= " ORDER BY present_count $sort_order";
            break;
        case 'attendance_rate':
            $query .= " ORDER BY attendance_rate $sort_order";
            break;
        default:
            $query .= " ORDER BY s.site_name $sort_order";
    }
    
    $stmt = $conn->prepare($query);
    if (!$stmt) {
        error_log("Error preparing query: " . $conn->error);
        return [];
    }
    
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $sites = [];
    while ($row = $result->fetch_assoc()) {
        $sites[] = $row;
    }
    
    return $sites;
}

/**
 * Get available dates for filter dropdown
 */
function getAvailableDates($conn) {
    $query = "SELECT DISTINCT date 
              FROM attendance 
              ORDER BY date DESC 
              LIMIT 30";
    $result = $conn->query($query);
    
    $dates = [];
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $dates[] = $row['date'];
        }
    }
    
    return $dates;
}

/**
 * Get total statistics across all sites
 */
function getTotalStats($conn, $filter_date = null) {
    if (!$filter_date) {
        $filter_date = date('Y-m-d');
    }
    
    $query = "SELECT 
                COUNT(DISTINCT s.id) as total_sites,
                COUNT(DISTINCT se.employee_id) as total_employees,
                COUNT(DISTINCT CASE WHEN a.date = ? AND a.status = 'Present' 
                    THEN a.employee_id END) as total_present
              FROM site_monitoring s
              LEFT JOIN site_employee se ON s.id = se.site_id
              LEFT JOIN attendance a ON se.employee_id = a.employee_id AND a.date = ?";
    
    $stmt = $conn->prepare($query);
    if (!$stmt) {
        error_log("Error preparing query: " . $conn->error);
        return ['total_sites' => 0, 'total_employees' => 0, 'total_present' => 0];
    }
    
    $stmt->bind_param("ss", $filter_date, $filter_date);
    $stmt->execute();
    $result = $stmt->get_result();
    
    return $result->fetch_assoc();
}

/**
 * Get employees with attendance status for a specific site and date
 */
function getSiteEmployeesWithAttendance($conn, $site_id, $filter_date = null) {
    if (!$filter_date) {
        $filter_date = date('Y-m-d');
    }
    
    $employees = [];
    
    $query = "SELECT 
                e.id,
                e.first_name,
                e.last_name,
                e.position,
                e.email,
                se.assigned_date,
                COALESCE(a.status, 'Absent') as attendance_status,
                a.time_in_am,
                a.time_out_am,
                a.time_in_pm,
                a.time_out_pm,
                a.remarks
              FROM employees e
              INNER JOIN site_employee se ON e.id = se.employee_id
              LEFT JOIN attendance a ON e.id = a.employee_id AND a.date = ?
              WHERE se.site_id = ? AND se.status = 'active'
              AND e.status = 'active' AND e.is_active = 1
              ORDER BY e.first_name, e.last_name";
    
    $stmt = $conn->prepare($query);
    if (!$stmt) {
        error_log("Error preparing query: " . $conn->error);
        return $employees;
    }
    
    $stmt->bind_param("si", $filter_date, $site_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while ($row = $result->fetch_assoc()) {
        $employees[] = $row;
    }
    
    return $employees;
}

// ============================================
// GET DASHBOARD DATA
// ============================================

// Get filter date from URL parameter or use today
$filter_date = isset($_GET['date']) ? $_GET['date'] : date('Y-m-d');

// Validate date format
if (!preg_match("/^\d{4}-\d{2}-\d{2}$/", $filter_date)) {
    $filter_date = date('Y-m-d');
}

// Get search and sort parameters
$search_query = isset($_GET['search']) ? $_GET['search'] : '';
$sort_by = isset($_GET['sort_by']) ? $_GET['sort_by'] : 'site_name';
$sort_order = isset($_GET['sort_order']) ? $_GET['sort_order'] : 'ASC';

// Get site ID for employee view modal
$view_site_id = isset($_GET['view_site']) ? (int)$_GET['view_site'] : 0;
$view_employees = [];
$view_site_details = null;

if ($view_site_id > 0) {
    // Get site details
    $site_query = "SELECT s.*, so.assignment_type, so.person_group 
                   FROM site_monitoring s 
                   LEFT JOIN site_others so ON s.others_id = so.id 
                   WHERE s.id = ?";
    $stmt = $conn->prepare($site_query);
    $stmt->bind_param("i", $view_site_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $view_site_details = $result->fetch_assoc();
    
    // Get employees with attendance
    $view_employees = getSiteEmployeesWithAttendance($conn, $view_site_id, $filter_date);
}

// Fetch sites data with search and sort
$sites = getSitesWithAttendance($conn, $filter_date, $search_query, $sort_by, $sort_order);

// Fetch total statistics
$total_stats = getTotalStats($conn, $filter_date);

// Fetch available dates for filter
$available_dates = getAvailableDates($conn);

// Format display date
$display_date = date('m/d/Y', strtotime($filter_date));
$month = date('m', strtotime($filter_date));
$year = date('Y', strtotime($filter_date));
$day = date('d', strtotime($filter_date));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Site Monitoring</title>
    <link rel="stylesheet" href="./assets/css/home2.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            height: 100vh;
            overflow: hidden;
            background-color: #f0f2f5;
            position: relative;
        }

        /* Main Content Area - Perfectly Centered with Space Around */
        .content {
            display: flex;
            flex-direction: column;
            height: 100vh;
            overflow: hidden;
        }

        .main-content {
            flex: 1;
            margin-top: 80px; /* Space for header */
            padding: 30px 40px;
            width: 100%;
            height: calc(100vh - 80px);
            overflow-y: auto;
            overflow-x: hidden;
            background-color: transparent;
            color: #333;
            position: relative;
            display: flex;
            justify-content: center;
        }

        /* Custom Scrollbar - Better Visibility */
        .main-content::-webkit-scrollbar {
            width: 10px;
        }

        .main-content::-webkit-scrollbar-track {
            background: #e9ecef;
            border-radius: 10px;
        }

        .main-content::-webkit-scrollbar-thumb {
            background: #2E7D32;
            border-radius: 10px;
            border: 2px solid #e9ecef;
        }

        .main-content::-webkit-scrollbar-thumb:hover {
            background: #1B5E20;
        }

        /* Dashboard Container - Fixed Width for Better View */
        .dashboard-container {
            max-width: 1400px;
            width: 100%;
            margin: 0 auto;
            padding: 0 20px 30px 20px; /* Bottom padding for scroll visibility */
        }

        /* Dashboard Header */
        .dashboard-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            flex-wrap: wrap;
            background: white;
            padding: 20px 30px;
            border-radius: 16px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.05);
            width: 100%;
            border: 1px solid #e9ecef;
        }

        .dashboard-title {
            font-size: 24px;
            font-weight: 700;
            color: #1e293b;
            margin: 0;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .dashboard-title i {
            color: #2E7D32;
            font-size: 26px;
        }

        /* ============ SIMPLIFIED DATE FILTER STYLES ============ */
        .date-filter {
            background: #f8fafc;
            padding: 12px 20px;
            border-radius: 40px;
            display: flex;
            align-items: center;
            gap: 12px;
            border: 1px solid #e2e8f0;
            flex-wrap: wrap;
        }

        .date-filter label {
            font-weight: 600;
            color: #475569;
            font-size: 14px;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .date-filter label i {
            color: #2E7D32;
        }

        .main-date-picker-wrapper {
            position: relative;
            width: 160px;
        }
        
        .main-date-input-group {
            display: flex;
            align-items: center;
            position: relative;
            width: 100%;
        }
        
        .main-date-field {
            width: 100%;
            padding: 8px 30px 8px 12px;
            border: 2px solid #e0e0e0;
            border-radius: 30px;
            font-size: 0.9rem;
            transition: all 0.3s;
            background: white;
            cursor: pointer;
            color: #2c3e50;
            font-weight: 500;
            height: 38px;
        }
        
        .main-date-field:hover {
            border-color: #75e6da;
        }
        
        .main-date-field:focus {
            border-color: #75e6da;
            box-shadow: 0 0 0 3px rgba(117, 230, 218, 0.1);
            outline: none;
        }
        
        .main-calendar-dropdown-btn {
            position: absolute;
            right: 8px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            color: #64748b;
            cursor: pointer;
            font-size: 0.8rem;
            padding: 5px;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s;
            z-index: 1;
        }
        
        .main-calendar-dropdown-btn:hover {
            color: #2E7D32;
        }
        
        /* Main Calendar Dropdown Styles with Month/Year Selectors */
        .main-calendar-wrapper {
            position: absolute;
            top: calc(100% + 8px);
            left: 50%;
            transform: translateX(-50%);
            background: white;
            border: 1px solid #e0e0e0;
            border-radius: 12px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
            z-index: 10000;
            display: none;
            width: 300px;
        }
        
        .main-calendar-wrapper.show {
            display: block;
        }
        
        .main-calendar-box {
            width: 100%;
            background: white;
            border-radius: 12px;
            overflow: hidden;
        }
        
        .main-calendar-header {
            background: linear-gradient(135deg, #75e6da, #62d4c8);
            color: white;
            padding: 15px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .main-calendar-month-year {
            font-weight: 600;
            font-size: 1rem;
        }
        
        .main-calendar-nav {
            display: flex;
            gap: 10px;
        }
        
        .main-calendar-nav-btn {
            background: rgba(255, 255, 255, 0.2);
            border: none;
            color: white;
            width: 28px;
            height: 28px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s;
            font-size: 1.1rem;
            line-height: 1;
        }
        
        .main-calendar-nav-btn:hover {
            background: rgba(255, 255, 255, 0.3);
            transform: scale(1.1);
        }
        
        /* Month/Year Selector Dropdowns */
        .main-calendar-selectors {
            display: flex;
            gap: 8px;
            padding: 12px 12px 5px 12px;
            background: white;
        }
        
        .main-calendar-select {
            flex: 1;
            padding: 6px 8px;
            border: 1px solid #e0e0e0;
            border-radius: 6px;
            font-size: 0.85rem;
            font-weight: 500;
            color: #2c3e50;
            background: white;
            cursor: pointer;
            transition: all 0.3s;
            outline: none;
        }
        
        .main-calendar-select:hover {
            border-color: #75e6da;
        }
        
        .main-calendar-select:focus {
            border-color: #75e6da;
            box-shadow: 0 0 0 2px rgba(117, 230, 218, 0.2);
        }
        
        .main-calendar-weekdays {
            display: grid;
            grid-template-columns: repeat(7, 1fr);
            background: #f8f9fa;
            padding: 10px 8px;
            text-align: center;
            font-weight: 600;
            font-size: 0.75rem;
            color: #2c3e50;
            border-bottom: 1px solid #e9ecef;
        }
        
        .main-calendar-days-grid {
            display: grid;
            grid-template-columns: repeat(7, 1fr);
            gap: 2px;
            padding: 8px;
            background: white;
        }
        
        .main-calendar-day {
            aspect-ratio: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 6px;
            cursor: pointer;
            border-radius: 50%;
            transition: all 0.2s;
            font-size: 0.85rem;
            color: #2c3e50;
            text-decoration: none;
            border: none;
            background: none;
            width: 100%;
            height: 100%;
            min-width: 30px;
            min-height: 30px;
        }
        
        .main-calendar-day:hover {
            background: #e8f5e9;
            color: #2E7D32;
        }
        
        .main-calendar-day.selected {
            background: #75e6da;
            color: white;
            font-weight: 600;
        }
        
        .main-calendar-day.today {
            border: 2px solid #75e6da;
            font-weight: 600;
        }
        
        .main-calendar-day.weekend {
            color: #e74c3c;
        }
        
        .main-calendar-day.other-month {
            color: #bdc3c7;
        }
        
        .main-calendar-footer {
            padding: 10px;
            background: #f8f9fa;
            border-top: 1px solid #e9ecef;
            display: flex;
            justify-content: space-between;
        }
        
        .main-calendar-action-btn {
            padding: 6px 14px;
            border-radius: 30px;
            font-size: 0.8rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 5px;
            border: none;
        }
        
        .main-calendar-action-btn.clear {
            background: #f8f9fa;
            color: #7f8c8d;
            border: 1px solid #bdc3c7;
        }
        
        .main-calendar-action-btn.clear:hover {
            background: #e74c3c;
            color: white;
            border-color: #e74c3c;
        }
        
        .main-calendar-action-btn.today {
            background: #75e6da;
            color: white;
            border: 1px solid #75e6da;
        }
        
        .main-calendar-action-btn.today:hover {
            background: #62d4c8;
        }

        .quick-select {
            padding: 8px 16px;
            border: 1px solid #cbd5e1;
            border-radius: 30px;
            background: white;
            font-size: 14px;
            cursor: pointer;
            min-width: 120px;
        }

        /* Statistics Cards Grid */
        .stats-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
            width: 100%;
        }

        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 16px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.05);
            display: flex;
            justify-content: space-between;
            align-items: center;
            transition: all 0.3s ease;
            border: 1px solid #e9ecef;
        }

        .stat-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 16px rgba(0,0,0,0.1);
            border-color: #4CAF50;
        }

        .stat-info h3 {
            margin: 0;
            font-size: 14px;
            color: #64748b;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            font-weight: 600;
        }

        .stat-info .number {
            font-size: 32px;
            font-weight: 700;
            color: #0f172a;
            margin-top: 6px;
            line-height: 1;
        }

        .stat-info .number.present {
            color: #059669;
        }

        .stat-icon {
            font-size: 42px;
            color: #2E7D32;
            opacity: 0.8;
        }

        /* Sites Container */
        .sites-container {
            background: white;
            border-radius: 16px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.05);
            padding: 25px;
            margin-top: 20px;
            width: 100%;
            border: 1px solid #e9ecef;
            margin-bottom: 20px;
        }

        .sites-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid #f1f5f9;
            flex-wrap: wrap;
            gap: 15px;
        }

        .sites-header h2 {
            font-size: 20px;
            font-weight: 700;
            color: #1e293b;
            display: flex;
            align-items: center;
            gap: 10px;
            margin: 0;
        }

        .sites-header h2 i {
            color: #2E7D32;
        }

        /* Sites Controls - Search and Sort */
        .sites-controls {
            display: flex;
            align-items: center;
            gap: 15px;
            flex-wrap: wrap;
        }

        /* Site Search Container */
        .site-search-container {
            display: flex;
            align-items: center;
            border: 2px solid #75e6da;
            border-radius: 25px;
            padding: 3px 3px 3px 15px;
            background-color: white;
            transition: all 0.3s ease;
            min-width: 250px;
        }

        .site-search-container:focus-within {
            border-color: #2E7D32;
            box-shadow: 0 0 0 3px rgba(46, 125, 50, 0.1);
        }

        .site-search-bar {
            border: none;
            outline: none;
            width: 100%;
            font-size: 0.9rem;
            background-color: transparent;
            padding: 8px 5px;
        }

        .site-search-btn {
            background: #75e6da;
            border: none;
            color: white;
            font-size: 1rem;
            cursor: pointer;
            padding: 8px 16px;
            border-radius: 25px;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .site-search-btn:hover {
            background: #62d4c8;
        }

        /* Site Sort Container */
        .site-sort-container {
            display: flex;
            align-items: center;
            gap: 8px;
            background: #f5f5f5;
            padding: 5px 12px;
            border-radius: 25px;
            border: 1px solid #e0e0e0;
        }

        .site-sort-select {
            padding: 6px 10px;
            border: 1px solid #e0e0e0;
            border-radius: 20px;
            font-size: 0.85rem;
            background: white;
            cursor: pointer;
            transition: all 0.3s;
            outline: none;
        }

        .site-sort-select:focus {
            border-color: #75e6da;
        }

        .site-sort-btn {
            padding: 6px 12px;
            border: 1px solid #e0e0e0;
            border-radius: 20px;
            background: white;
            color: #666;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 5px;
            font-size: 0.85rem;
        }

        .site-sort-btn:hover {
            background: #f0f9f8;
            border-color: #75e6da;
            color: #2E7D32;
        }

        /* Clear Search Button */
        .clear-search-btn {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 24px;
            background: #f1f5f9;
            color: #334155;
            text-decoration: none;
            border-radius: 30px;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .clear-search-btn:hover {
            background: #e2e8f0;
            transform: translateY(-2px);
        }

        .clear-search-btn i {
            margin-right: 5px;
        }

        /* Sites Grid - Responsive Cards */
        .sites-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(340px, 1fr));
            gap: 20px;
            width: 100%;
        }

        .site-card {
            background: white;
            border-radius: 16px;
            border: 1px solid #e9ecef;
            overflow: hidden;
            transition: all 0.3s ease;
            height: 100%;
            display: flex;
            flex-direction: column;
        }

        .site-card:hover {
            border-color: #4CAF50;
            box-shadow: 0 8px 16px rgba(0,0,0,0.08);
            transform: translateY(-2px);
        }

        .site-header {
            background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
            padding: 16px 20px;
            border-bottom: 1px solid #e9ecef;
        }

        .site-header h3 {
            margin: 0;
            font-size: 18px;
            font-weight: 700;
            color: #0f172a;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .site-header h3 i {
            color: #2E7D32;
            font-size: 18px;
        }

        .site-header p {
            margin: 6px 0 0;
            color: #64748b;
            font-size: 13px;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .site-content {
            padding: 20px;
            flex: 1;
        }

        .employee-stats {
            display: flex;
            justify-content: space-around;
            margin-bottom: 20px;
            background: #f8fafc;
            padding: 12px;
            border-radius: 12px;
        }

        .stat-item {
            text-align: center;
        }

        .stat-label {
            font-size: 11px;
            color: #64748b;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .stat-value {
            font-size: 24px;
            font-weight: 700;
            color: #0f172a;
            line-height: 1.2;
        }

        .stat-value.present {
            color: #059669;
        }

        .stat-value.absent {
            color: #dc2626;
        }

        .progress-section {
            margin-bottom: 20px;
        }

        .progress-header {
            display: flex;
            justify-content: space-between;
            margin-bottom: 6px;
            font-size: 12px;
        }

        .progress-label {
            color: #64748b;
            font-weight: 500;
        }

        .progress-percent {
            font-weight: 700;
            color: #2E7D32;
        }

        .progress-bar {
            width: 100%;
            height: 6px;
            background-color: #e2e8f0;
            border-radius: 4px;
            overflow: hidden;
        }

        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, #4CAF50, #2E7D32);
            border-radius: 4px;
            transition: width 0.5s ease;
        }

        .site-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 16px;
            padding-top: 16px;
            border-top: 1px solid #e9ecef;
        }

        .view-details-btn {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            background: #f1f5f9;
            color: #334155;
            padding: 6px 14px;
            border-radius: 30px;
            text-decoration: none;
            font-size: 12px;
            font-weight: 600;
            transition: all 0.3s ease;
            cursor: pointer;
            border: none;
        }

        .view-details-btn:hover {
            background: #2E7D32;
            color: white;
        }

        .manager-badge {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            background: rgba(46, 125, 50, 0.1);
            padding: 4px 12px;
            border-radius: 30px;
            font-size: 12px;
            color: #1B5E20;
        }

        /* No Data State */
        .no-data {
            text-align: center;
            padding: 50px 20px;
            background: white;
            border-radius: 16px;
            color: #64748b;
        }

        .no-data i {
            font-size: 48px;
            color: #94a3b8;
            margin-bottom: 16px;
        }

        .no-data p {
            font-size: 16px;
            margin-bottom: 8px;
        }

        .no-data .sub-text {
            font-size: 14px;
            color: #94a3b8;
        }

        /* Date Info Footer */
        .date-info {
            margin-top: 20px;
            margin-bottom: 10px;
            text-align: right;
            padding: 16px 20px;
            background: #f8fafc;
            border-radius: 16px;
            color: #475569;
            font-size: 14px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
            border: 1px solid #e9ecef;
        }

        .today-link {
            color: #75e6da;
            text-decoration: none;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }

        .today-link:hover {
            text-decoration: underline;
        }

        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            justify-content: center;
            align-items: center;
            z-index: 10000;
            padding: 20px;
            overflow-y: auto;
        }

        .modal-content {
            background: white;
            border-radius: 16px;
            width: 100%;
            max-width: 800px;
            max-height: 90vh;
            overflow-y: auto;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
            animation: modalSlideIn 0.3s ease;
        }

        @keyframes modalSlideIn {
            from {
                opacity: 0;
                transform: translateY(-50px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .modal-header {
            background: linear-gradient(135deg, #75e6da 0%, #58c3b8 100%);
            color: white;
            padding: 20px 25px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-radius: 16px 16px 0 0;
        }

        .modal-header h3 {
            margin: 0;
            font-size: 1.3rem;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .modal-close {
            background: none;
            border: none;
            color: white;
            font-size: 1.5rem;
            cursor: pointer;
            transition: all 0.3s;
            padding: 0;
            width: 30px;
            height: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .modal-close:hover {
            background: rgba(255, 255, 255, 0.1);
            border-radius: 50%;
        }

        .modal-body {
            padding: 25px;
        }

        .modal-footer {
            padding: 15px 25px;
            background-color: #f8fafc;
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            border-top: 1px solid #e9ecef;
            border-radius: 0 0 16px 16px;
        }

        .btn {
            padding: 10px 24px;
            border: none;
            border-radius: 30px;
            font-size: 0.95rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        .btn-primary {
            background: #75e6da;
            color: white;
        }

        .btn-primary:hover {
            background: #62d4c8;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(46, 125, 50, 0.2);
        }

        .btn-secondary {
            background: #e2e8f0;
            color: #334155;
        }

        .btn-secondary:hover {
            background: #cbd5e1;
        }

        /* Site Info in Modal */
        .site-info-modal {
            background: #f8fafc;
            border-radius: 12px;
            padding: 15px 20px;
            margin-bottom: 20px;
            border: 1px solid #e9ecef;
        }

        .site-info-modal p {
            margin: 8px 0;
            display: flex;
            align-items: center;
            gap: 10px;
            color: #475569;
        }

        .site-info-modal i {
            color: #75e6da;
            width: 20px;
        }

        /* Employee Table */
        .employees-table-container {
            max-height: 400px;
            overflow-y: auto;
            border: 1px solid #e9ecef;
            border-radius: 12px;
        }

        .employees-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.9rem;
        }

        .employees-table thead {
            background: #f1f5f9;
            position: sticky;
            top: 0;
            z-index: 10;
        }

        .employees-table th {
            padding: 12px 15px;
            text-align: left;
            font-weight: 600;
            color: #334155;
            border-bottom: 2px solid #e2e8f0;
        }

        .employees-table td {
            padding: 12px 15px;
            border-bottom: 1px solid #e9ecef;
        }

        .employees-table tbody tr:hover {
            background: #f8fafc;
        }

        .status-badge {
            display: inline-flex;
            align-items: center;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
        }

        .status-present {
            background: #dcfce7;
            color: #059669;
        }

        .status-absent {
            background: #fee2e2;
            color: #dc2626;
        }

        .time-badge {
            font-size: 0.8rem;
            color: #64748b;
            display: flex;
            align-items: center;
            gap: 4px;
        }

        .employee-count-badge {
            background: #2E7D32;
            color: white;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.8rem;
            margin-left: 10px;
        }

        .no-employees {
            text-align: center;
            padding: 40px;
            color: #64748b;
        }

        .no-employees i {
            font-size: 48px;
            color: #94a3b8;
            margin-bottom: 16px;
        }

        /* Loading State */
        .loading {
            text-align: center;
            padding: 40px;
            color: #64748b;
        }

        .loading i {
            font-size: 32px;
            margin-bottom: 12px;
            color: #2E7D32;
        }

        /* Ensure smooth scrolling */
        html {
            scroll-behavior: smooth;
        }

        /* Print Styles */
        @media print {
            .main-content {
                margin-left: 0;
                width: 100%;
                overflow: visible;
            }
            
            .date-filter,
            .view-details-btn,
            .today-link,
            .modal {
                display: none;
            }
        }

        /* Responsive Design */
        @media (max-width: 1400px) {
            .dashboard-container {
                max-width: 1300px;
            }
        }

        @media (max-width: 1200px) {
            .dashboard-container {
                max-width: 1100px;
            }
            
            .sites-grid {
                grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            }
        }

        @media (max-width: 1024px) {
            .main-content {
                padding: 25px 30px;
            }
            
            .dashboard-container {
                max-width: 100%;
                padding: 0 15px 30px 15px;
            }
        }

        @media (max-width: 768px) {
            .main-content {
                margin-top: 70px;
                padding: 20px 25px;
            }
            
            .dashboard-container {
                padding: 0 10px 30px 10px;
            }
            
            .dashboard-header {
                flex-direction: column;
                align-items: stretch;
                padding: 20px;
            }
            
            .date-filter {
                width: 100%;
                justify-content: space-between;
            }
            
            .sites-grid {
                grid-template-columns: 1fr;
            }
            
            .stats-cards {
                grid-template-columns: 1fr;
            }
            
            .sites-header {
                flex-direction: column;
                align-items: flex-start;
            }
            
            .sites-controls {
                flex-direction: column;
                align-items: stretch;
                width: 100%;
            }
            
            .site-search-container {
                min-width: 100%;
            }
            
            .site-sort-container {
                justify-content: space-between;
                width: 100%;
            }
            
            .modal-content {
                max-width: 95%;
            }
            
            .employees-table {
                font-size: 0.8rem;
            }
            
            .employees-table th,
            .employees-table td {
                padding: 8px 10px;
            }
            
            .main-calendar-wrapper {
                left: 50%;
                transform: translateX(-50%);
                width: 280px;
            }
        }

        @media (max-width: 576px) {
            .main-content {
                padding: 15px 20px;
            }
            
            .dashboard-container {
                padding: 0 5px 30px 5px;
            }
            
            .dashboard-title {
                font-size: 20px;
            }
            
            .date-filter {
                flex-direction: column;
                align-items: stretch;
                border-radius: 16px;
            }
            
            .date-filter input,
            .date-filter button,
            .quick-select {
                width: 100%;
            }
            
            .stat-card {
                padding: 16px;
            }
            
            .stat-info .number {
                font-size: 26px;
            }
            
            .stat-icon {
                font-size: 36px;
            }
            
            .employee-stats {
                flex-direction: column;
                gap: 12px;
            }
            
            .date-info {
                flex-direction: column;
                text-align: center;
            }
            
            .site-sort-container {
                flex-wrap: wrap;
            }
            
            .site-sort-select {
                flex: 1;
            }
            
            .main-calendar-wrapper {
                left: 50%;
                transform: translateX(-50%);
                width: 260px;
            }
        }
    </style>
</head>
<body>

    <!-- header -->
    <?php include_once("./includes/header.php"); ?>

    <main class="content">
        <div class="main-content">
            <div class="dashboard-container">
                <!-- Dashboard Header with Date Filter -->
                <div class="dashboard-header">
                    <div class="dashboard-title">
                        <i class="fas fa-chart-line"></i>
                        Site Monitoring Dashboard
                    </div>
                    
                    <div class="date-filter">
                        <label>
                            <i class="fas fa-calendar-alt"></i>
                            Date:
                        </label>
                        
                        <!-- SIMPLIFIED DATE PICKER - NO ICON -->
                        <div class="main-date-picker-wrapper">
                            <div class="main-date-input-group">
                                <input type="text" 
                                       id="mainDateField" 
                                       class="main-date-field" 
                                       value="<?= $display_date ?>"
                                       placeholder="MM/DD/YYYY"
                                       autocomplete="off"
                                       readonly
                                       onclick="toggleMainCalendar()">
                                <input type="hidden" id="selectedDate" name="date" value="<?= $filter_date ?>">
                                <button type="button" class="main-calendar-dropdown-btn" onclick="toggleMainCalendar()">
                                    <i class="fas fa-chevron-down"></i>
                                </button>
                            </div>
                            
                            <!-- Main Calendar Dropdown with Month/Year Selectors -->
                            <div class="main-calendar-wrapper" id="mainCalendarWrapper">
                                <div class="main-calendar-box">
                                    <div class="main-calendar-header">
                                        <div class="main-calendar-month-year" id="mainCalendarMonthYear">
                                            <?= date('F Y', strtotime($filter_date)) ?>
                                        </div>
                                        <div class="main-calendar-nav">
                                            <button type="button" class="main-calendar-nav-btn" onclick="navigateMainMonth(-1)">‹</button>
                                            <button type="button" class="main-calendar-nav-btn" onclick="navigateMainMonth(1)">›</button>
                                        </div>
                                    </div>
                                    
                                    <!-- Month and Year Dropdown Selectors -->
                                    <div class="main-calendar-selectors">
                                        <select id="mainMonthSelect" class="main-calendar-select" onchange="changeMainMonthYear()">
                                            <option value="0">January</option>
                                            <option value="1">February</option>
                                            <option value="2">March</option>
                                            <option value="3">April</option>
                                            <option value="4">May</option>
                                            <option value="5">June</option>
                                            <option value="6">July</option>
                                            <option value="7">August</option>
                                            <option value="8">September</option>
                                            <option value="9">October</option>
                                            <option value="10">November</option>
                                            <option value="11">December</option>
                                        </select>
                                        
                                        <select id="mainYearSelect" class="main-calendar-select" onchange="changeMainMonthYear()">
                                            <?php for($y = date('Y') - 10; $y <= date('Y') + 10; $y++): ?>
                                                <option value="<?= $y ?>" <?= $y == $year ? 'selected' : '' ?>><?= $y ?></option>
                                            <?php endfor; ?>
                                        </select>
                                    </div>
                                    
                                    <div class="main-calendar-weekdays">
                                        <div>Su</div>
                                        <div>Mo</div>
                                        <div>Tu</div>
                                        <div>We</div>
                                        <div>Th</div>
                                        <div>Fr</div>
                                        <div>Sa</div>
                                    </div>
                                    
                                    <div class="main-calendar-days-grid" id="mainCalendarDaysGrid">
                                        <!-- Days will be populated here by JavaScript -->
                                    </div>
                                    
                                    <div class="main-calendar-footer">
                                        <button type="button" class="main-calendar-action-btn clear" onclick="clearMainDate()">
                                            <i class="fas fa-times"></i> Clear
                                        </button>
                                        <button type="button" class="main-calendar-action-btn today" onclick="setMainToday()">
                                            <i class="fas fa-calendar-check"></i> Today
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <?php if (!empty($available_dates)): ?>
                        <select id="quick_date" class="quick-select" onchange="quickDateSelect(this.value)">
                            <option value="">Quick Select</option>
                            <?php foreach ($available_dates as $date): ?>
                            <option value="<?php echo htmlspecialchars($date); ?>" <?php echo $date == $filter_date ? 'selected' : ''; ?>>
                                <?php echo date('M d, Y', strtotime($date)); ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Statistics Cards -->
                <div class="stats-cards">
                    <div class="stat-card">
                        <div class="stat-info">
                            <h3>Total Sites</h3>
                            <div class="number"><?php echo number_format($total_stats['total_sites'] ?? 0); ?></div>
                        </div>
                        <div class="stat-icon">
                            <i class="fas fa-building"></i>
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-info">
                            <h3>Total Employees</h3>
                            <div class="number"><?php echo number_format($total_stats['total_employees'] ?? 0); ?></div>
                        </div>
                        <div class="stat-icon">
                            <i class="fas fa-users"></i>
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-info">
                            <h3>Present</h3>
                            <div class="number present">
                                <?php echo number_format($total_stats['total_present'] ?? 0); ?>
                            </div>
                        </div>
                        <div class="stat-icon">
                            <i class="fas fa-check-circle"></i>
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-info">
                            <h3>Attendance Rate</h3>
                            <div class="number">
                                <?php 
                                $total_emp = $total_stats['total_employees'] ?? 0;
                                $total_present = $total_stats['total_present'] ?? 0;
                                $rate = $total_emp > 0 ? round(($total_present / $total_emp) * 100) : 0;
                                echo $rate . '%';
                                ?>
                            </div>
                        </div>
                        <div class="stat-icon">
                            <i class="fas fa-percentage"></i>
                        </div>
                    </div>
                </div>

                <!-- Sites Dashboard Section -->
                <div class="sites-container">
                    <div class="sites-header">
                        <h2>
                            <i class="fas fa-map-marked-alt"></i>
                            Site Status Overview
                        </h2>
                        <div class="sites-controls">
                            <!-- Search Bar -->
                            <div class="site-search-container">
                                <form method="GET" action="home.php" id="searchForm" style="display: flex; align-items: center; width: 100%;">
                                    <input type="hidden" name="date" value="<?php echo htmlspecialchars($filter_date); ?>">
                                    <input type="hidden" name="sort_by" value="<?php echo htmlspecialchars($sort_by); ?>">
                                    <input type="hidden" name="sort_order" value="<?php echo htmlspecialchars($sort_order); ?>">
                                    <input type="text" name="search" 
                                           value="<?php echo htmlspecialchars($search_query); ?>" 
                                           placeholder="Search sites..." 
                                           class="site-search-bar">
                                    <button type="submit" class="site-search-btn">
                                        <i class="fas fa-search"></i>
                                    </button>
                                </form>
                            </div>
                            
                            <!-- Sort Controls -->
                            <div class="site-sort-container">
                                <form method="GET" action="home.php" id="sortForm" style="display: flex; align-items: center; gap: 8px;">
                                    <input type="hidden" name="date" value="<?php echo htmlspecialchars($filter_date); ?>">
                                    <input type="hidden" name="search" value="<?php echo htmlspecialchars($search_query); ?>">
                                    <select name="sort_by" class="site-sort-select" onchange="document.getElementById('sortForm').submit();">
                                        <option value="site_name" <?php echo $sort_by == 'site_name' ? 'selected' : ''; ?>>Site Name</option>
                                        <option value="site_manager" <?php echo $sort_by == 'site_manager' ? 'selected' : ''; ?>>Manager</option>
                                        <option value="total_employees" <?php echo $sort_by == 'total_employees' ? 'selected' : ''; ?>>Total Employees</option>
                                        <option value="present_count" <?php echo $sort_by == 'present_count' ? 'selected' : ''; ?>>Present</option>
                                        <option value="attendance_rate" <?php echo $sort_by == 'attendance_rate' ? 'selected' : ''; ?>>Attendance Rate</option>
                                    </select>
                                    <button type="submit" name="sort_order" value="<?php echo $sort_order == 'ASC' ? 'DESC' : 'ASC'; ?>" class="site-sort-btn">
                                        <i class="fas fa-sort-amount-<?php echo $sort_order == 'ASC' ? 'down' : 'up'; ?>"></i>
                                        <?php echo $sort_order == 'ASC' ? 'Asc' : 'Desc'; ?>
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                    
                    <?php if (empty($sites)): ?>
                        <div class="no-data">
                            <i class="fas fa-map-marked-alt"></i>
                            <p>No sites found</p>
                            <div class="sub-text">
                                <?php if (!empty($search_query)): ?>
                                    No sites match your search criteria.
                                <?php elseif (empty($total_stats['total_sites'])): ?>
                                    Please add sites in the Site Monitoring page.
                                <?php else: ?>
                                    No employees assigned to any site yet.
                                <?php endif; ?>
                            </div>
                            <?php if (!empty($search_query)): ?>
                            <a href="home.php?date=<?php echo urlencode($filter_date); ?>" class="clear-search-btn">
                                <i class="fas fa-times"></i> Clear Search
                            </a>
                            <?php else: ?>
                            <a href="site_monitoring.php" style="display: inline-block; margin-top: 20px; padding: 10px 24px; background: #2E7D32; color: white; text-decoration: none; border-radius: 30px; font-weight: 600;">
                                <i class="fas fa-plus-circle"></i> Manage Sites
                            </a>
                            <?php endif; ?>
                        </div>
                    <?php else: ?>
                        <div class="sites-grid">
                            <?php foreach ($sites as $site): ?>
                                <?php 
                                $total_employees = intval($site['total_employees'] ?? 0);
                                $present_count = intval($site['present_count'] ?? 0);
                                $absent_count = max(0, $total_employees - $present_count);
                                $attendance_rate = intval($site['attendance_rate'] ?? 0);
                                $display_name = ($site['is_others'] == 1 && !empty($site['assignment_type'])) 
                                    ? $site['assignment_type'] 
                                    : $site['site_name'];
                                ?>
                                <div class="site-card">
                                    <div class="site-header">
                                        <h3>
                                            <?php if ($site['is_others'] == 1): ?>
                                                <i class="fas fa-tasks"></i>
                                            <?php else: ?>
                                                <i class="fas fa-building"></i>
                                            <?php endif; ?>
                                            <?php echo htmlspecialchars($display_name); ?>
                                            <?php if ($site['is_others'] == 1): ?>
                                                <span style="font-size: 11px; background: #e8f5e9; color: #2E7D32; padding: 3px 8px; border-radius: 12px; margin-left: 8px;">
                                                    Others
                                                </span>
                                            <?php endif; ?>
                                        </h3>
                                        <p>
                                            <i class="fas fa-user-tie"></i>
                                            <?php echo htmlspecialchars($site['site_manager'] ?? 'No manager'); ?>
                                        </p>
                                        <p>
                                            <i class="fas fa-map-marker-alt"></i>
                                            <?php echo htmlspecialchars($site['site_address'] ?? 'No address'); ?>
                                        </p>
                                        <?php if ($site['is_others'] == 1 && !empty($site['person_group'])): ?>
                                        <p style="color: #2E7D32;">
                                            <i class="fas fa-users"></i>
                                            Group: <?php echo htmlspecialchars($site['person_group']); ?>
                                        </p>
                                        <?php endif; ?>
                                    </div>
                                    <div class="site-content">
                                        <div class="employee-stats">
                                            <div class="stat-item">
                                                <div class="stat-label">Total</div>
                                                <div class="stat-value"><?php echo $total_employees; ?></div>
                                            </div>
                                            <div class="stat-item">
                                                <div class="stat-label">Present</div>
                                                <div class="stat-value present"><?php echo $present_count; ?></div>
                                            </div>
                                            <div class="stat-item">
                                                <div class="stat-label">Absent</div>
                                                <div class="stat-value absent"><?php echo $absent_count; ?></div>
                                            </div>
                                        </div>
                                        
                                        <div class="progress-section">
                                            <div class="progress-header">
                                                <span class="progress-label">Attendance Rate</span>
                                                <span class="progress-percent"><?php echo $attendance_rate; ?>%</span>
                                            </div>
                                            <div class="progress-bar">
                                                <div class="progress-fill" style="width: <?php echo $attendance_rate; ?>%;"></div>
                                            </div>
                                        </div>
                                        
                                        <div class="site-footer">
                                            <span style="color: #64748b; font-size: 12px;">
                                                <i class="fas fa-users"></i>
                                                <?php echo $total_employees; ?> assigned
                                            </span>
                                            <button onclick="viewSiteEmployees(<?php echo $site['id']; ?>)" class="view-details-btn">
                                                <i class="fas fa-eye"></i>
                                                More Details
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Date Information Footer -->
                <div class="date-info">
                    <span>
                        <i class="fas fa-info-circle"></i>
                        Showing data for: <strong><?php echo date('F d, Y', strtotime($filter_date)); ?></strong>
                    </span>
                    <?php if ($filter_date != date('Y-m-d')): ?>
                    <a href="home.php" class="today-link">
                        <i class="fas fa-calendar-day"></i>
                        View Today
                    </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </main>

    <!-- Site Employees Modal -->
    <div id="siteEmployeesModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>
                    <i class="fas fa-users"></i>
                    Site Employees
                </h3>
                <button class="modal-close" onclick="closeEmployeesModal()">&times;</button>
            </div>
            <div class="modal-body">
                <div id="siteInfoContainer" class="site-info-modal">
                    <!-- Site info will be loaded here -->
                </div>
                <div id="employeesListModalContainer">
                    <div class="loading">
                        <i class="fas fa-spinner fa-spin"></i>
                        <p>Loading employees...</p>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeEmployeesModal()">
                    <i class="fas fa-times"></i>
                    Close
                </button>
                <a href="site_monitoring.php" class="btn btn-primary">
                    <i class="fas fa-cog"></i>
                    Manage Sites
                </a>
            </div>
        </div>
    </div>

    <!-- footer -->
    <?php include_once("./includes/footer.php"); ?>
    
    <!-- modal -->
    <?php include_once("./modal/logout-modal.php"); ?>

    <script>
        // ============================================
        // DATE FILTER CALENDAR FUNCTIONS
        // ============================================
        let mainCurrentDate = new Date('<?= $filter_date ?>');
        let mainSelectedDate = '<?= $filter_date ?>';

        function toggleMainCalendar() {
            const calendar = document.getElementById('mainCalendarWrapper');
            if (calendar) {
                if (calendar.style.display === 'block') {
                    calendar.style.display = 'none';
                } else {
                    // Update dropdowns to match current date
                    updateMainCalendarSelectors();
                    generateMainCalendarDays();
                    calendar.style.display = 'block';
                }
            }
        }

        function updateMainCalendarSelectors() {
            const monthSelect = document.getElementById('mainMonthSelect');
            const yearSelect = document.getElementById('mainYearSelect');
            
            if (monthSelect) {
                monthSelect.value = mainCurrentDate.getMonth();
            }
            if (yearSelect) {
                yearSelect.value = mainCurrentDate.getFullYear();
            }
        }

        function changeMainMonthYear() {
            const monthSelect = document.getElementById('mainMonthSelect');
            const yearSelect = document.getElementById('mainYearSelect');
            
            if (monthSelect && yearSelect) {
                const newMonth = parseInt(monthSelect.value);
                const newYear = parseInt(yearSelect.value);
                
                mainCurrentDate = new Date(newYear, newMonth, 1);
                generateMainCalendarDays();
            }
        }

        function generateMainCalendarDays() {
            const year = mainCurrentDate.getFullYear();
            const month = mainCurrentDate.getMonth();
            const daysGrid = document.getElementById('mainCalendarDaysGrid');
            const monthYearDisplay = document.getElementById('mainCalendarMonthYear');
            
            if (!daysGrid || !monthYearDisplay) return;
            
            monthYearDisplay.textContent = mainCurrentDate.toLocaleDateString('en-US', { 
                month: 'long', 
                year: 'numeric' 
            });
            
            // Update dropdowns to match
            updateMainCalendarSelectors();
            
            const firstDay = new Date(year, month, 1).getDay();
            const daysInMonth = new Date(year, month + 1, 0).getDate();
            const today = new Date();
            
            let html = '';
            
            // Previous month days
            const prevMonthDays = new Date(year, month, 0).getDate();
            for (let i = firstDay - 1; i >= 0; i--) {
                const day = prevMonthDays - i;
                const dateStr = `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
                html += `<div class="main-calendar-day other-month" onclick="selectMainDate('${dateStr}')">${day}</div>`;
            }
            
            // Current month days
            for (let day = 1; day <= daysInMonth; day++) {
                const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
                const isToday = today.getFullYear() === year && today.getMonth() === month && today.getDate() === day;
                const isSelected = dateStr === mainSelectedDate;
                const isWeekend = new Date(year, month, day).getDay() === 0 || new Date(year, month, day).getDay() === 6;
                
                let classes = 'main-calendar-day';
                if (isToday) classes += ' today';
                if (isSelected) classes += ' selected';
                if (isWeekend) classes += ' weekend';
                
                html += `<div class="${classes}" onclick="selectMainDate('${dateStr}')">${day}</div>`;
            }
            
            // Next month days
            const totalCells = 42;
            const cellsUsed = firstDay + daysInMonth;
            const nextMonthDays = totalCells - cellsUsed;
            for (let day = 1; day <= nextMonthDays; day++) {
                const dateStr = `${year}-${String(month + 2).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
                html += `<div class="main-calendar-day other-month" onclick="selectMainDate('${dateStr}')">${day}</div>`;
            }
            
            daysGrid.innerHTML = html;
        }

        function navigateMainMonth(direction) {
            mainCurrentDate.setMonth(mainCurrentDate.getMonth() + direction);
            generateMainCalendarDays();
        }

        function selectMainDate(dateStr) {
            const date = new Date(dateStr);
            const formattedDisplay = date.toLocaleDateString('en-US', {
                month: '2-digit',
                day: '2-digit',
                year: 'numeric'
            });
            
            const dateField = document.getElementById('mainDateField');
            const dateHidden = document.getElementById('selectedDate');
            
            if (dateField) dateField.value = formattedDisplay;
            if (dateHidden) dateHidden.value = dateStr;
            
            mainSelectedDate = dateStr;
            mainCurrentDate = new Date(dateStr);
            
            generateMainCalendarDays();
            
            const calendar = document.getElementById('mainCalendarWrapper');
            if (calendar) calendar.style.display = 'none';
            
            // Submit the form with the new date
            const currentUrl = new URL(window.location.href);
            currentUrl.searchParams.set('date', dateStr);
            currentUrl.searchParams.set('search', '<?= $search_query ?>');
            currentUrl.searchParams.set('sort_by', '<?= $sort_by ?>');
            currentUrl.searchParams.set('sort_order', '<?= $sort_order ?>');
            window.location.href = currentUrl.toString();
        }

        function clearMainDate() {
            const dateField = document.getElementById('mainDateField');
            const dateHidden = document.getElementById('selectedDate');
            
            if (dateField) dateField.value = '';
            if (dateHidden) dateHidden.value = '';
            
            mainSelectedDate = '';
            
            const calendar = document.getElementById('mainCalendarWrapper');
            if (calendar) calendar.style.display = 'none';
        }

        function setMainToday() {
            const today = new Date();
            const year = today.getFullYear();
            const month = String(today.getMonth() + 1).padStart(2, '0');
            const day = String(today.getDate()).padStart(2, '0');
            const dateStr = `${year}-${month}-${day}`;
            
            mainCurrentDate = new Date(dateStr);
            selectMainDate(dateStr);
        }

        // Quick date select
        function quickDateSelect(date) {
            if (date) {
                window.location.href = 'home.php?date=' + encodeURIComponent(date) +
                    '&search=<?php echo urlencode($search_query); ?>' +
                    '&sort_by=<?php echo urlencode($sort_by); ?>' +
                    '&sort_order=<?php echo urlencode($sort_order); ?>';
            }
        }
        
        // View site employees
        function viewSiteEmployees(siteId) {
            // Show modal
            const modal = document.getElementById('siteEmployeesModal');
            modal.style.display = 'flex';
            document.body.classList.add('modal-open');
            
            // Load site employees via AJAX
            loadSiteEmployees(siteId);
        }
        
        // Close employees modal
        function closeEmployeesModal() {
            const modal = document.getElementById('siteEmployeesModal');
            modal.style.display = 'none';
            document.body.classList.remove('modal-open');
            
            // Reset content
            document.getElementById('siteInfoContainer').innerHTML = '';
            document.getElementById('employeesListModalContainer').innerHTML = `
                <div class="loading">
                    <i class="fas fa-spinner fa-spin"></i>
                    <p>Loading employees...</p>
                </div>
            `;
        }
        
        // Load site employees via AJAX
        async function loadSiteEmployees(siteId) {
            const date = '<?php echo $filter_date; ?>';
            
            try {
                const response = await fetch(`get_site_employees_attendance.php?site_id=${siteId}&date=${encodeURIComponent(date)}`);
                const data = await response.json();
                
                if (data.success) {
                    // Update site info
                    const siteInfoContainer = document.getElementById('siteInfoContainer');
                    siteInfoContainer.innerHTML = `
                        <p><i class="fas fa-building"></i> <strong>${data.site_name}</strong></p>
                        <p><i class="fas fa-user-tie"></i> Manager: ${data.site_manager}</p>
                        <p><i class="fas fa-map-marker-alt"></i> Address: ${data.site_address}</p>
                        <p><i class="fas fa-calendar-alt"></i> Date: ${new Date(data.date).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}</p>
                        <p><i class="fas fa-users"></i> Total Employees: ${data.employees.length}</p>
                    `;
                    
                    // Update employees list
                    const container = document.getElementById('employeesListModalContainer');
                    
                    if (data.employees && data.employees.length > 0) {
                        let html = `
                            <div class="employees-table-container">
                                <table class="employees-table">
                                    <thead>
                                        <tr>
                                            <th>Employee</th>
                                            <th>Position</th>
                                            <th>Status</th>
                                            <th>Time</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                        `;
                        
                        data.employees.forEach(emp => {
                            const statusClass = emp.attendance_status === 'Present' ? 'status-present' : 'status-absent';
                            let timeDisplay = '—';
                            
                            if (emp.attendance_status === 'Present') {
                                const times = [];
                                if (emp.time_in_am) times.push(`IN: ${emp.time_in_am.substring(0,5)}`);
                                if (emp.time_out_am) times.push(`OUT: ${emp.time_out_am.substring(0,5)}`);
                                if (emp.time_in_pm) times.push(`IN: ${emp.time_in_pm.substring(0,5)}`);
                                if (emp.time_out_pm) times.push(`OUT: ${emp.time_out_pm.substring(0,5)}`);
                                timeDisplay = times.join(' • ') || 'Present';
                            }
                            
                            html += `
                                <tr>
                                    <td>
                                        <strong>${emp.first_name} ${emp.last_name}</strong>
                                        <div style="font-size: 0.75rem; color: #64748b;">ID: ${emp.id}</div>
                                    </td>
                                    <td>${emp.position || '—'}</td>
                                    <td>
                                        <span class="status-badge ${statusClass}">
                                            <i class="fas ${emp.attendance_status === 'Present' ? 'fa-check-circle' : 'fa-times-circle'}"></i>
                                            ${emp.attendance_status}
                                        </span>
                                        ${emp.remarks ? `<div style="font-size: 0.7rem; color: #64748b; margin-top: 4px;">${emp.remarks}</div>` : ''}
                                    </td>
                                    <td>
                                        <span class="time-badge">
                                            <i class="fas fa-clock"></i>
                                            ${timeDisplay}
                                        </span>
                                    </td>
                                </tr>
                            `;
                        });
                        
                        html += `
                                    </tbody>
                                </table>
                            </div>
                        `;
                        
                        container.innerHTML = html;
                    } else {
                        container.innerHTML = `
                            <div class="no-employees">
                                <i class="fas fa-user-slash"></i>
                                <p>No employees assigned to this site</p>
                            </div>
                        `;
                    }
                } else {
                    throw new Error(data.message || 'Failed to load employees');
                }
            } catch (error) {
                console.error('Error loading site employees:', error);
                document.getElementById('employeesListModalContainer').innerHTML = `
                    <div class="no-employees">
                        <i class="fas fa-exclamation-triangle" style="color: #dc2626;"></i>
                        <p>Error loading employees</p>
                        <div class="sub-text">${error.message}</div>
                    </div>
                `;
            }
        }
        
        // Close modal when clicking outside
        window.onclick = function(event) {
            const modal = document.getElementById('siteEmployeesModal');
            if (event.target === modal) {
                closeEmployeesModal();
            }
        }
        
        // Close modal with Escape key
        document.addEventListener('keydown', function(event) {
            if (event.key === 'Escape') {
                closeEmployeesModal();
                
                // Close calendar if open
                const calendar = document.getElementById('mainCalendarWrapper');
                if (calendar && calendar.style.display === 'block') {
                    calendar.style.display = 'none';
                }
            }
        });

        // Close calendar when clicking outside
        document.addEventListener('click', function(e) {
            const mainDatePicker = document.querySelector('.main-date-picker-wrapper');
            const mainCalendar = document.getElementById('mainCalendarWrapper');
            
            if (mainDatePicker && mainCalendar && !mainDatePicker.contains(e.target)) {
                mainCalendar.style.display = 'none';
            }
        });
        
        // Initialize calendar on page load
        document.addEventListener('DOMContentLoaded', function() {
            generateMainCalendarDays();
            
            // Add animation to progress bars
            setTimeout(() => {
                document.querySelectorAll('.progress-fill').forEach(bar => {
                    const width = bar.style.width;
                    bar.style.width = '0%';
                    setTimeout(() => {
                        bar.style.width = width;
                    }, 100);
                });
            }, 200);
        });
    </script>

</body>
</html>
<?php $conn->close(); ?>