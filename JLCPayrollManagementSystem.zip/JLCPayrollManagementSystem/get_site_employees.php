<?php
session_start();

if (!isset($_SESSION['Admin_User'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

header('Content-Type: application/json');

include_once("connection.php");

$site_id = isset($_GET['site_id']) ? intval($_GET['site_id']) : 0;
$filter_date = isset($_GET['date']) ? $_GET['date'] : date('Y-m-d');

if (!$site_id) {
    echo json_encode(['success' => false, 'message' => 'Missing site ID']);
    exit;
}

try {
    $query = "SELECT e.id, e.first_name, e.last_name, e.position, e.email, se.assigned_date
              FROM employees e 
              INNER JOIN site_employee se ON e.id = se.employee_id 
              WHERE se.site_id = ? 
              AND (se.assigned_date <= ? OR se.assigned_date IS NULL)
              ORDER BY e.first_name, e.last_name";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param("is", $site_id, $filter_date);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $employees = [];
    while ($row = $result->fetch_assoc()) {
        $employees[] = $row;
    }
    
    echo json_encode([
        'success' => true,
        'employees' => $employees,
        'filter_date' => $filter_date
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}

$conn->close();
?>