<?php
session_start();

if (!isset($_SESSION['Admin_User'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

header('Content-Type: application/json');

include_once("connection.php");

// Fetch sites from your existing sites table
// Adjust table name and column names based on your Employee Tracking sites table
$sql = "SELECT id, site_name, location, address, status 
        FROM sites 
        WHERE status = 'Active' 
        ORDER BY site_name ASC";

$result = $conn->query($sql);

$sites = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $sites[] = [
            'id' => $row['id'],
            'site_name' => $row['site_name'],
            'address' => $row['address'] ?? $row['location'] ?? '',
            'location' => $row['location'] ?? ''
        ];
    }
}

echo json_encode([
    'success' => true,
    'sites' => $sites
]);

$conn->close();
?>