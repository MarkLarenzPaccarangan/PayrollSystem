<?php
session_start();

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (!isset($_SESSION['Admin_User'])) {
    header("Location: login.php");
    exit;
}

include_once("connection.php");

// Debug: Log POST data
error_log("========================================");
error_log("ADD_ATTENDANCE.PHP ACCESSED");
error_log("POST Data: " . print_r($_POST, true));
error_log("========================================");

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data with validation
    $employee_id = isset($_POST['employee_id']) ? trim($_POST['employee_id']) : '';
    $date = isset($_POST['date']) ? trim($_POST['date']) : '';
    $status = isset($_POST['status']) ? trim($_POST['status']) : ''; // AM Status
    $pm_status = isset($_POST['pm_status']) ? trim($_POST['pm_status']) : ''; // PM Status
    $night_status = isset($_POST['night_status']) ? trim($_POST['night_status']) : ''; // Night Status
    $remarks = isset($_POST['remarks']) ? trim($_POST['remarks']) : '';
    $attendance_id = isset($_POST['attendance_id']) ? intval($_POST['attendance_id']) : 0;
    
    // Get leave type - standalone, can be set regardless of status
    $leave_type = isset($_POST['leave_type']) ? trim($_POST['leave_type']) : NULL;
    if (empty($leave_type)) {
        $leave_type = NULL;
    }
    
    // Get workday type - standalone, can be set regardless of status
    $workday_type = isset($_POST['workday_type']) ? trim($_POST['workday_type']) : NULL;
    if (empty($workday_type)) {
        $workday_type = NULL;
    }
    
    // Time fields – set to NULL if empty or '00:00:00'
    $time_in_am = (!empty($_POST['time_in_am']) && $_POST['time_in_am'] !== '00:00:00') ? trim($_POST['time_in_am']) : NULL;
    $time_out_am = (!empty($_POST['time_out_am']) && $_POST['time_out_am'] !== '00:00:00') ? trim($_POST['time_out_am']) : NULL;
    $time_in_pm = (!empty($_POST['time_in_pm']) && $_POST['time_in_pm'] !== '00:00:00') ? trim($_POST['time_in_pm']) : NULL;
    $time_out_pm = (!empty($_POST['time_out_pm']) && $_POST['time_out_pm'] !== '00:00:00') ? trim($_POST['time_out_pm']) : NULL;
    $time_in_night = (!empty($_POST['time_in_night']) && $_POST['time_in_night'] !== '00:00:00') ? trim($_POST['time_in_night']) : NULL;
    $time_out_night = (!empty($_POST['time_out_night']) && $_POST['time_out_night'] !== '00:00:00') ? trim($_POST['time_out_night']) : NULL;
    
    // Function to calculate hours between two times
    function calculateHours($time_in, $time_out) {
        if (empty($time_in) || empty($time_out) || $time_in === '00:00:00' || $time_out === '00:00:00') {
            return 0;
        }
        
        $time_in_ts = strtotime($time_in);
        $time_out_ts = strtotime($time_out);
        
        if ($time_out_ts < $time_in_ts) {
            $time_out_ts += 86400; // Add 24 hours if time_out is next day
        }
        
        $hours = round(($time_out_ts - $time_in_ts) / 3600, 2);
        return $hours;
    }
    
    // Calculate total hours (including night session)
    $am_hours = calculateHours($time_in_am, $time_out_am);
    $pm_hours = calculateHours($time_in_pm, $time_out_pm);
    $night_hours = calculateHours($time_in_night, $time_out_night);
    $total_hours = $am_hours + $pm_hours + $night_hours;
    
    // If AM is Absent, set AM time fields to NULL
    if ($status === 'Absent') {
        $time_in_am = $time_out_am = NULL;
    }
    
    // If PM is Absent, set PM time fields to NULL
    if ($pm_status === 'Absent') {
        $time_in_pm = $time_out_pm = NULL;
    }
    
    // If Night is Absent, set Night time fields to NULL
    if ($night_status === 'Absent') {
        $time_in_night = $time_out_night = NULL;
    }
    
    // If status is Present but no times, set to No Record
    if ($status === 'Present' && !$time_in_am && !$time_out_am) {
        $status = 'No Record';
    }
    
    // If PM status is Present but no times, set to No Record
    if ($pm_status === 'Present' && !$time_in_pm && !$time_out_pm) {
        $pm_status = 'No Record';
    }
    
    // If Night status is Present but no times, set to No Record
    if ($night_status === 'Present' && !$time_in_night && !$time_out_night) {
        $night_status = 'No Record';
    }
    
    // If no status selected for a session, set to No Record
    if (empty($status)) {
        $status = 'No Record';
    }
    if (empty($pm_status)) {
        $pm_status = 'No Record';
    }
    if (empty($night_status)) {
        $night_status = 'No Record';
    }
    
    error_log("Processing attendance for:");
    error_log("- Employee ID: " . $employee_id);
    error_log("- Date: " . $date);
    error_log("- AM Status: " . $status);
    error_log("- PM Status: " . $pm_status);
    error_log("- Night Status: " . $night_status);
    error_log("- Leave Type: " . ($leave_type ? $leave_type : 'NULL'));
    error_log("- Workday Type: " . ($workday_type ? $workday_type : 'NULL'));
    
    // Validate required fields
    if (empty($employee_id) || empty($date)) {
        $_SESSION['error'] = "Please select employee and date";
        error_log("VALIDATION FAILED: Missing required fields");
        header("Location: attendance.php?date=" . urlencode($date));
        exit;
    }
    
    // Leave type is optional - no validation required
    // Workday type is optional - no validation required
    
    try {
        // Check if attendance already exists for this employee on this date
        $check_sql = "SELECT id FROM attendance WHERE employee_id = ? AND DATE(date) = DATE(?)";
        error_log("Checking existing record: " . $check_sql);
        
        $check_stmt = $conn->prepare($check_sql);
        if (!$check_stmt) {
            throw new Exception("Prepare failed: " . $conn->error);
        }
        
        $check_stmt->bind_param("is", $employee_id, $date);
        if (!$check_stmt->execute()) {
            throw new Exception("Execute failed: " . $check_stmt->error);
        }
        
        $check_result = $check_stmt->get_result();
        $existing_record = $check_result->fetch_assoc();
        
        if ($existing_record) {
            // Update existing record
            $attendance_id = $existing_record['id'];
            error_log("Updating existing record ID: " . $attendance_id);
            
            // Check if columns exist
            $columns_check = $conn->query("SHOW COLUMNS FROM attendance LIKE 'time_in_night'");
            $has_night_columns = $columns_check && $columns_check->num_rows > 0;
            
            $workday_check = $conn->query("SHOW COLUMNS FROM attendance LIKE 'workday_type'");
            $has_workday_column = $workday_check && $workday_check->num_rows > 0;
            
            if ($has_night_columns && $has_workday_column) {
                // Update with night session columns and workday type
                $update_sql = "UPDATE attendance SET 
                              status = ?,
                              pm_status = ?,
                              night_status = ?,
                              time_in_am = ?, 
                              time_out_am = ?, 
                              time_in_pm = ?,
                              time_out_pm = ?,
                              time_in_night = ?,
                              time_out_night = ?,
                              remarks = ?,
                              leave_type = ?,
                              workday_type = ?,
                              total_hours = ?,
                              updated_at = CURRENT_TIMESTAMP
                              WHERE id = ?";
                
                error_log("Update SQL: " . $update_sql);
                
                $update_stmt = $conn->prepare($update_sql);
                if (!$update_stmt) {
                    throw new Exception("Update prepare failed: " . $conn->error);
                }
                
                $update_stmt->bind_param("ssssssssssssdi", 
                    $status,
                    $pm_status,
                    $night_status,
                    $time_in_am, 
                    $time_out_am, 
                    $time_in_pm, 
                    $time_out_pm,
                    $time_in_night,
                    $time_out_night,
                    $remarks, 
                    $leave_type, 
                    $workday_type, 
                    $total_hours,
                    $attendance_id
                );
            } else {
                $_SESSION['error'] = "Database needs to be updated. Please add workday_type column.";
                header("Location: attendance.php?date=" . urlencode($date));
                exit;
            }
            
            if ($update_stmt->execute()) {
                $_SESSION['success'] = "✅ Attendance record updated successfully for Employee ID: $employee_id";
                error_log("UPDATE SUCCESSFUL - Affected rows: " . $update_stmt->affected_rows);
            } else {
                throw new Exception("Update execute failed: " . $update_stmt->error);
            }
            
            $update_stmt->close();
        } else {
            // Insert new record
            error_log("Inserting new record");
            
            // Check if columns exist
            $columns_check = $conn->query("SHOW COLUMNS FROM attendance LIKE 'time_in_night'");
            $has_night_columns = $columns_check && $columns_check->num_rows > 0;
            
            $workday_check = $conn->query("SHOW COLUMNS FROM attendance LIKE 'workday_type'");
            $has_workday_column = $workday_check && $workday_check->num_rows > 0;
            
            if ($has_night_columns && $has_workday_column) {
                // Insert with night session columns and workday type
                $insert_sql = "INSERT INTO attendance (
                              employee_id, 
                              date, 
                              status,
                              pm_status,
                              night_status,
                              time_in_am, 
                              time_out_am, 
                              time_in_pm, 
                              time_out_pm,
                              time_in_night,
                              time_out_night,
                              remarks, 
                              leave_type,
                              workday_type,
                              total_hours,
                              created_at
                              ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)";
                
                error_log("Insert SQL: " . $insert_sql);
                
                $insert_stmt = $conn->prepare($insert_sql);
                if (!$insert_stmt) {
                    throw new Exception("Insert prepare failed: " . $conn->error);
                }
                
                $insert_stmt->bind_param("isssssssssssssd", 
                    $employee_id, 
                    $date, 
                    $status,
                    $pm_status,
                    $night_status,
                    $time_in_am, 
                    $time_out_am, 
                    $time_in_pm, 
                    $time_out_pm,
                    $time_in_night,
                    $time_out_night,
                    $remarks, 
                    $leave_type,
                    $workday_type,
                    $total_hours
                );
            } else {
                $_SESSION['error'] = "Database needs to be updated. Please add workday_type column.";
                header("Location: attendance.php?date=" . urlencode($date));
                exit;
            }
            
            if ($insert_stmt->execute()) {
                $new_id = $insert_stmt->insert_id;
                $_SESSION['success'] = "✅ Attendance record added successfully for Employee ID: $employee_id";
                error_log("INSERT SUCCESSFUL - New ID: " . $new_id);
            } else {
                throw new Exception("Insert execute failed: " . $insert_stmt->error);
            }
            
            $insert_stmt->close();
        }
        
        $check_stmt->close();
        
    } catch (Exception $e) {
        error_log("DATABASE ERROR: " . $e->getMessage());
        $_SESSION['error'] = "Database error: " . $e->getMessage();
    }
    
    // Get employee name for enhanced success message
    if (isset($_SESSION['success'])) {
        $name_sql = "SELECT CONCAT(first_name, ' ', last_name) as full_name FROM employees WHERE id = ?";
        $name_stmt = $conn->prepare($name_sql);
        if ($name_stmt) {
            $name_stmt->bind_param("i", $employee_id);
            $name_stmt->execute();
            $name_result = $name_stmt->get_result();
            if ($name_row = $name_result->fetch_assoc()) {
                $_SESSION['success'] = "✅ Attendance record for " . $name_row['full_name'] . " on " . date('F j, Y', strtotime($date)) . " has been saved successfully.";
            }
            $name_stmt->close();
        }
    }
    
    // Redirect back to attendance page
    $redirect_url = "attendance.php?date=" . urlencode($date);
    error_log("Redirecting to: " . $redirect_url);
    
    header("Location: " . $redirect_url);
    exit;
    
} else {
    error_log("INVALID REQUEST METHOD: " . $_SERVER["REQUEST_METHOD"]);
    $_SESSION['error'] = "Invalid request method";
    header("Location: attendance.php");
    exit;
}

$conn->close();
?>

