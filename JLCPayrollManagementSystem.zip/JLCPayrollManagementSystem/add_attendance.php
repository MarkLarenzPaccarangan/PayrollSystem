<?php
session_start();

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (!isset($_SESSION['Admin_User'])) {
    header("Location: login.php");
    exit;
}

include_once("connection.php");

// Debug: Log POST data
error_log("========================================");
error_log("ADD_ATTENDANCE.PHP ACCESSED");
error_log("POST Data: " . print_r($_POST, true));
error_log("========================================");

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data with validation
    $employee_id = isset($_POST['employee_id']) ? trim($_POST['employee_id']) : '';
    $date = isset($_POST['date']) ? trim($_POST['date']) : '';
    $status = isset($_POST['status']) ? trim($_POST['status']) : ''; // AM Status
    $pm_status = isset($_POST['pm_status']) ? trim($_POST['pm_status']) : 'Absent'; // PM Status
    $remarks = isset($_POST['remarks']) ? trim($_POST['remarks']) : '';
    $attendance_id = isset($_POST['attendance_id']) ? intval($_POST['attendance_id']) : 0;
    
    // Get leave type - only relevant if status is 'On Leave'
    $leave_type = isset($_POST['leave_type']) ? trim($_POST['leave_type']) : NULL;
    if ($status !== 'On Leave') {
        $leave_type = NULL;
    }
    
    // Time fields – set to NULL if empty or '00:00:00'
    $time_in_am = (!empty($_POST['time_in_am']) && $_POST['time_in_am'] !== '00:00:00') ? trim($_POST['time_in_am']) : NULL;
    $time_out_am = (!empty($_POST['time_out_am']) && $_POST['time_out_am'] !== '00:00:00') ? trim($_POST['time_out_am']) : NULL;
    $time_in_pm = (!empty($_POST['time_in_pm']) && $_POST['time_in_pm'] !== '00:00:00') ? trim($_POST['time_in_pm']) : NULL;
    $time_out_pm = (!empty($_POST['time_out_pm']) && $_POST['time_out_pm'] !== '00:00:00') ? trim($_POST['time_out_pm']) : NULL;
    
    // Function to calculate hours between two times
    function calculateHours($time_in, $time_out) {
        if (empty($time_in) || empty($time_out) || $time_in === '00:00:00' || $time_out === '00:00:00') {
            return 0;
        }
        
        $time_in_ts = strtotime($time_in);
        $time_out_ts = strtotime($time_out);
        
        if ($time_out_ts < $time_in_ts) {
            $time_out_ts += 86400; // Add 24 hours if time_out is next day
        }
        
        $hours = round(($time_out_ts - $time_in_ts) / 3600, 2);
        return $hours;
    }
    
    // Calculate total hours
    $am_hours = calculateHours($time_in_am, $time_out_am);
    $pm_hours = calculateHours($time_in_pm, $time_out_pm);
    $total_hours = $am_hours + $pm_hours;
    
    // If status is On Leave, force all time fields to NULL and set both statuses to 'On Leave'
    if ($status === 'On Leave') {
        $time_in_am = $time_out_am = $time_in_pm = $time_out_pm = NULL;
        $status = 'On Leave';
        $pm_status = 'On Leave';
        $total_hours = 0;
    }
    
    // If AM is Absent, set AM time fields to NULL
    if ($status === 'Absent') {
        $time_in_am = $time_out_am = NULL;
    }
    
    // If PM is Absent, set PM time fields to NULL
    if ($pm_status === 'Absent') {
        $time_in_pm = $time_out_pm = NULL;
    }
    
    // If PM status is Present but no times, set to Absent
    if ($pm_status === 'Present' && !$time_in_pm && !$time_out_pm) {
        $pm_status = 'Absent';
    }
    
    error_log("Processing attendance for:");
    error_log("- Employee ID: " . $employee_id);
    error_log("- Date: " . $date);
    error_log("- AM Status: " . $status);
    error_log("- PM Status: " . $pm_status);
    error_log("- Leave Type: " . ($leave_type ? $leave_type : 'NULL'));
    error_log("- Time In AM: " . ($time_in_am ? $time_in_am : 'NULL'));
    error_log("- Time Out AM: " . ($time_out_am ? $time_out_am : 'NULL'));
    error_log("- Time In PM: " . ($time_in_pm ? $time_in_pm : 'NULL'));
    error_log("- Time Out PM: " . ($time_out_pm ? $time_out_pm : 'NULL'));
    error_log("- Total Hours: " . $total_hours);
    error_log("- Remarks: " . $remarks);
    error_log("- Attendance ID: " . $attendance_id);
    
    // Validate required fields
    if (empty($employee_id) || empty($date) || empty($status)) {
        $_SESSION['error'] = "Please fill all required fields";
        error_log("VALIDATION FAILED: Missing required fields");
        header("Location: attendance.php?date=" . urlencode($date));
        exit;
    }
    
    // If status is On Leave, validate leave type
    if ($status === 'On Leave' && empty($leave_type)) {
        $_SESSION['error'] = "Please select a leave type";
        error_log("VALIDATION FAILED: Missing leave type");
        header("Location: attendance.php?date=" . urlencode($date));
        exit;
    }
    
    try {
        // Check if attendance already exists for this employee on this date
        $check_sql = "SELECT id FROM attendance WHERE employee_id = ? AND DATE(date) = DATE(?)";
        error_log("Checking existing record: " . $check_sql);
        
        $check_stmt = $conn->prepare($check_sql);
        if (!$check_stmt) {
            throw new Exception("Prepare failed: " . $conn->error);
        }
        
        $check_stmt->bind_param("is", $employee_id, $date);
        if (!$check_stmt->execute()) {
            throw new Exception("Execute failed: " . $check_stmt->error);
        }
        
        $check_result = $check_stmt->get_result();
        $existing_record = $check_result->fetch_assoc();
        
        if ($existing_record) {
            // Update existing record - WITH ALL COLUMNS including status_am and status_pm
            $attendance_id = $existing_record['id'];
            error_log("Updating existing record ID: " . $attendance_id);
            
            // Check if status_am and status_pm columns exist
            $columns_check = $conn->query("SHOW COLUMNS FROM attendance LIKE 'status_am'");
            $has_status_am = $columns_check->num_rows > 0;
            
            if ($has_status_am) {
                // Use new table structure with separate AM/PM status columns
                $update_sql = "UPDATE attendance SET 
                              status = ?,
                              status_am = ?,
                              status_pm = ?,
                              time_in_am = ?, 
                              time_out_am = ?, 
                              time_in_pm = ?,
                              time_out_pm = ?,
                              remarks = ?,
                              leave_type = ?,
                              total_hours = ?,
                              updated_at = CURRENT_TIMESTAMP
                              WHERE id = ?";
                
                error_log("Update SQL (with AM/PM columns): " . $update_sql);
                
                $update_stmt = $conn->prepare($update_sql);
                if (!$update_stmt) {
                    throw new Exception("Update prepare failed: " . $conn->error);
                }
                
                $update_stmt->bind_param("sssssssssdi", 
                    $status,      // main status (for backward compatibility)
                    $status,      // status_am - use AM status
                    $pm_status,   // status_pm - use PM status
                    $time_in_am, 
                    $time_out_am, 
                    $time_in_pm, 
                    $time_out_pm, 
                    $remarks, 
                    $leave_type, 
                    $total_hours,
                    $attendance_id
                );
            } else {
                // Use old table structure
                $update_sql = "UPDATE attendance SET 
                              status = ?, 
                              time_in_am = ?, 
                              time_out_am = ?, 
                              time_in_pm = ?,
                              time_out_pm = ?,
                              remarks = ?,
                              leave_type = ?,
                              total_hours = ?,
                              updated_at = CURRENT_TIMESTAMP
                              WHERE id = ?";
                
                error_log("Update SQL (old structure): " . $update_sql);
                
                $update_stmt = $conn->prepare($update_sql);
                if (!$update_stmt) {
                    throw new Exception("Update prepare failed: " . $conn->error);
                }
                
                $update_stmt->bind_param("sssssssdi", 
                    $status, 
                    $time_in_am, 
                    $time_out_am, 
                    $time_in_pm, 
                    $time_out_pm, 
                    $remarks, 
                    $leave_type, 
                    $total_hours,
                    $attendance_id
                );
            }
            
            if ($update_stmt->execute()) {
                $_SESSION['success'] = "✅ Attendance record updated successfully for Employee ID: $employee_id";
                error_log("UPDATE SUCCESSFUL - Affected rows: " . $update_stmt->affected_rows);
            } else {
                throw new Exception("Update execute failed: " . $update_stmt->error);
            }
            
            $update_stmt->close();
        } else {
            // Insert new record
            error_log("Inserting new record");
            
            // Check if status_am and status_pm columns exist
            $columns_check = $conn->query("SHOW COLUMNS FROM attendance LIKE 'status_am'");
            $has_status_am = $columns_check->num_rows > 0;
            
            if ($has_status_am) {
                // Use new table structure with separate AM/PM status columns
                $insert_sql = "INSERT INTO attendance (
                              employee_id, 
                              date, 
                              status,
                              status_am,
                              status_pm,
                              time_in_am, 
                              time_out_am, 
                              time_in_pm, 
                              time_out_pm, 
                              remarks, 
                              leave_type,
                              total_hours,
                              created_at
                              ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)";
                
                error_log("Insert SQL (with AM/PM columns): " . $insert_sql);
                
                $insert_stmt = $conn->prepare($insert_sql);
                if (!$insert_stmt) {
                    throw new Exception("Insert prepare failed: " . $conn->error);
                }
                
                $insert_stmt->bind_param("issssssssssd", 
                    $employee_id, 
                    $date, 
                    $status,      // main status (for backward compatibility)
                    $status,      // status_am - use AM status
                    $pm_status,   // status_pm - use PM status
                    $time_in_am, 
                    $time_out_am, 
                    $time_in_pm, 
                    $time_out_pm, 
                    $remarks, 
                    $leave_type,
                    $total_hours
                );
            } else {
                // Use old table structure
                $insert_sql = "INSERT INTO attendance (
                              employee_id, 
                              date, 
                              status, 
                              time_in_am, 
                              time_out_am, 
                              time_in_pm, 
                              time_out_pm, 
                              remarks, 
                              leave_type,
                              total_hours,
                              created_at
                              ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)";
                
                error_log("Insert SQL (old structure): " . $insert_sql);
                
                $insert_stmt = $conn->prepare($insert_sql);
                if (!$insert_stmt) {
                    throw new Exception("Insert prepare failed: " . $conn->error);
                }
                
                $insert_stmt->bind_param("issssssssd", 
                    $employee_id, 
                    $date, 
                    $status, 
                    $time_in_am, 
                    $time_out_am, 
                    $time_in_pm, 
                    $time_out_pm, 
                    $remarks, 
                    $leave_type,
                    $total_hours
                );
            }
            
            if ($insert_stmt->execute()) {
                $new_id = $insert_stmt->insert_id;
                $_SESSION['success'] = "✅ Attendance record added successfully for Employee ID: $employee_id";
                error_log("INSERT SUCCESSFUL - New ID: " . $new_id);
            } else {
                throw new Exception("Insert execute failed: " . $insert_stmt->error);
            }
            
            $insert_stmt->close();
        }
        
        $check_stmt->close();
        
    } catch (Exception $e) {
        error_log("DATABASE ERROR: " . $e->getMessage());
        $_SESSION['error'] = "Database error: " . $e->getMessage();
    }
    
    // Check for database errors
    if ($conn->error) {
        error_log("MySQL Error: " . $conn->error);
        $_SESSION['error'] = "MySQL Error: " . $conn->error;
    }
    
    // Get employee name for enhanced success message
    if (isset($_SESSION['success'])) {
        $name_sql = "SELECT CONCAT(first_name, ' ', last_name) as full_name FROM employees WHERE id = ?";
        $name_stmt = $conn->prepare($name_sql);
        if ($name_stmt) {
            $name_stmt->bind_param("i", $employee_id);
            $name_stmt->execute();
            $name_result = $name_stmt->get_result();
            if ($name_row = $name_result->fetch_assoc()) {
                $_SESSION['success'] = "✅ Attendance record for " . $name_row['full_name'] . " on " . date('F j, Y', strtotime($date)) . " has been saved successfully.";
            }
            $name_stmt->close();
        }
    }
    
    // Redirect back to attendance page
    $redirect_url = "attendance.php?date=" . urlencode($date);
    error_log("Redirecting to: " . $redirect_url);
    
    header("Location: " . $redirect_url);
    exit;
    
} else {
    error_log("INVALID REQUEST METHOD: " . $_SERVER["REQUEST_METHOD"]);
    $_SESSION['error'] = "Invalid request method";
    header("Location: attendance.php");
    exit;
}
?>