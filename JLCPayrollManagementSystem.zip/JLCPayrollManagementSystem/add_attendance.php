<?php
session_start();

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (!isset($_SESSION['Admin_User'])) {
    header("Location: login.php");
    exit;
}

include_once("connection.php");

// Debug: Log POST data
error_log("========================================");
error_log("ADD_ATTENDANCE.PHP ACCESSED");
error_log("POST Data: " . print_r($_POST, true));
error_log("Session: " . print_r($_SESSION, true));
error_log("========================================");

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data with validation - UPDATED: Added AM/PM time fields
    $employee_id = isset($_POST['employee_id']) ? trim($_POST['employee_id']) : '';
    $date = isset($_POST['date']) ? trim($_POST['date']) : '';
    $status = isset($_POST['status']) ? trim($_POST['status']) : '';
    $remarks = isset($_POST['remarks']) ? trim($_POST['remarks']) : '';
    
    // UPDATED: AM/PM Time fields
    $time_in_am = isset($_POST['time_in_am']) && !empty($_POST['time_in_am']) ? trim($_POST['time_in_am']) : NULL;
    $time_out_am = isset($_POST['time_out_am']) && !empty($_POST['time_out_am']) ? trim($_POST['time_out_am']) : NULL;
    $time_in_pm = isset($_POST['time_in_pm']) && !empty($_POST['time_in_pm']) ? trim($_POST['time_in_pm']) : NULL;
    $time_out_pm = isset($_POST['time_out_pm']) && !empty($_POST['time_out_pm']) ? trim($_POST['time_out_pm']) : NULL;
    
    error_log("Processing attendance for:");
    error_log("- Employee ID: " . $employee_id);
    error_log("- Date: " . $date);
    error_log("- Status: " . $status);
    error_log("- Time In AM: " . ($time_in_am ? $time_in_am : 'NULL'));
    error_log("- Time Out AM: " . ($time_out_am ? $time_out_am : 'NULL'));
    error_log("- Time In PM: " . ($time_in_pm ? $time_in_pm : 'NULL'));
    error_log("- Time Out PM: " . ($time_out_pm ? $time_out_pm : 'NULL'));
    error_log("- Remarks: " . $remarks);
    
    // Validate required fields
    if (empty($employee_id) || empty($date) || empty($status)) {
        $_SESSION['error'] = "Please fill all required fields";
        error_log("VALIDATION FAILED: Missing required fields");
        header("Location: attendance.php?date=" . urlencode($date));
        exit;
    }
    
    try {
        // Check if attendance already exists for this employee on this date
        $check_sql = "SELECT id, time_in_am, time_out_am, time_in_pm, time_out_pm 
                     FROM attendance 
                     WHERE employee_id = ? AND DATE(date) = DATE(?)";
        error_log("Checking existing record: " . $check_sql);
        error_log("Params: employee_id=$employee_id, date=$date");
        
        $check_stmt = $conn->prepare($check_sql);
        if (!$check_stmt) {
            throw new Exception("Prepare failed: " . $conn->error);
        }
        
        $check_stmt->bind_param("is", $employee_id, $date);
        if (!$check_stmt->execute()) {
            throw new Exception("Execute failed: " . $check_stmt->error);
        }
        
        $check_result = $check_stmt->get_result();
        $existing_record = $check_result->fetch_assoc();
        
        if ($existing_record) {
            // Update existing record - UPDATED: With AM/PM fields
            $attendance_id = $existing_record['id'];
            error_log("Updating existing record ID: " . $attendance_id);
            
            // Preserve existing AM time-in if it exists and new time-in is empty
            if ($existing_record['time_in_am'] && $existing_record['time_in_am'] != '00:00:00' && empty($time_in_am)) {
                $time_in_am = $existing_record['time_in_am'];
                error_log("Preserving existing AM time-in: " . $time_in_am);
            }
            
            // Preserve existing AM time-out if it exists and new time-out is empty
            if ($existing_record['time_out_am'] && $existing_record['time_out_am'] != '00:00:00' && empty($time_out_am)) {
                $time_out_am = $existing_record['time_out_am'];
                error_log("Preserving existing AM time-out: " . $time_out_am);
            }
            
            // Preserve existing PM time-in if it exists and new time-in is empty
            if ($existing_record['time_in_pm'] && $existing_record['time_in_pm'] != '00:00:00' && empty($time_in_pm)) {
                $time_in_pm = $existing_record['time_in_pm'];
                error_log("Preserving existing PM time-in: " . $time_in_pm);
            }
            
            // Preserve existing PM time-out if it exists and new time-out is empty
            if ($existing_record['time_out_pm'] && $existing_record['time_out_pm'] != '00:00:00' && empty($time_out_pm)) {
                $time_out_pm = $existing_record['time_out_pm'];
                error_log("Preserving existing PM time-out: " . $time_out_pm);
            }
            
            // UPDATED: SQL with AM/PM fields
            $update_sql = "UPDATE attendance SET 
                          status = ?, 
                          time_in_am = ?, 
                          time_out_am = ?, 
                          time_in_pm = ?,
                          time_out_pm = ?,
                          remarks = ?,
                          updated_at = CURRENT_TIMESTAMP
                          WHERE id = ?";
            
            error_log("Update SQL: " . $update_sql);
            error_log("Params: status=$status, time_in_am=" . ($time_in_am ?: 'NULL') . 
                     ", time_out_am=" . ($time_out_am ?: 'NULL') . 
                     ", time_in_pm=" . ($time_in_pm ?: 'NULL') . 
                     ", time_out_pm=" . ($time_out_pm ?: 'NULL') . 
                     ", remarks=$remarks, id=$attendance_id");
            
            $update_stmt = $conn->prepare($update_sql);
            if (!$update_stmt) {
                throw new Exception("Update prepare failed: " . $conn->error);
            }
            
            $update_stmt->bind_param("ssssssi", 
                $status, 
                $time_in_am, 
                $time_out_am, 
                $time_in_pm, 
                $time_out_pm, 
                $remarks, 
                $attendance_id
            );
            
            if ($update_stmt->execute()) {
                $_SESSION['success'] = "✅ Attendance record updated successfully for Employee ID: $employee_id";
                error_log("UPDATE SUCCESSFUL");
            } else {
                throw new Exception("Update execute failed: " . $update_stmt->error);
            }
            
            $update_stmt->close();
        } else {
            // Insert new record - UPDATED: With AM/PM fields
            $insert_sql = "INSERT INTO attendance (
                          employee_id, 
                          date, 
                          status, 
                          time_in_am, 
                          time_out_am, 
                          time_in_pm, 
                          time_out_pm, 
                          remarks, 
                          created_at
                          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)";
            
            error_log("Insert SQL: " . $insert_sql);
            error_log("Params: employee_id=$employee_id, date=$date, status=$status, " .
                     "time_in_am=" . ($time_in_am ?: 'NULL') . 
                     ", time_out_am=" . ($time_out_am ?: 'NULL') . 
                     ", time_in_pm=" . ($time_in_pm ?: 'NULL') . 
                     ", time_out_pm=" . ($time_out_pm ?: 'NULL') . 
                     ", remarks=$remarks");
            
            $insert_stmt = $conn->prepare($insert_sql);
            if (!$insert_stmt) {
                throw new Exception("Insert prepare failed: " . $conn->error);
            }
            
            $insert_stmt->bind_param("isssssss", 
                $employee_id, 
                $date, 
                $status, 
                $time_in_am, 
                $time_out_am, 
                $time_in_pm, 
                $time_out_pm, 
                $remarks
            );
            
            if ($insert_stmt->execute()) {
                $new_id = $insert_stmt->insert_id;
                $_SESSION['success'] = "✅ Attendance record added successfully for Employee ID: $employee_id";
                error_log("INSERT SUCCESSFUL - New ID: " . $new_id);
            } else {
                throw new Exception("Insert execute failed: " . $insert_stmt->error);
            }
            
            $insert_stmt->close();
        }
        
        $check_stmt->close();
        
    } catch (Exception $e) {
        error_log("DATABASE ERROR: " . $e->getMessage());
        $_SESSION['error'] = "Database error: " . $e->getMessage();
    }
    
    // Check for database errors
    if ($conn->error) {
        error_log("MySQL Error: " . $conn->error);
        $_SESSION['error'] = "MySQL Error: " . $conn->error;
    }
    
    // Redirect back to attendance page
    $redirect_url = "attendance.php?date=" . urlencode($date);
    error_log("Redirecting to: " . $redirect_url);
    
    header("Location: " . $redirect_url);
    exit;
    
} else {
    error_log("INVALID REQUEST METHOD: " . $_SERVER["REQUEST_METHOD"]);
    $_SESSION['error'] = "Invalid request method";
    header("Location: attendance.php");
    exit;
}
?>