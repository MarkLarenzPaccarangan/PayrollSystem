<?php
session_start();

if (!isset($_SESSION['Admin_User'])) {
    header("Location: login.php");
    exit;
}

include_once("connection.php");

// Get parameters from URL
$employee_id = isset($_GET['employee_id']) ? intval($_GET['employee_id']) : 0;
$selected_month = isset($_GET['month']) ? intval($_GET['month']) : intval(date('m'));
$selected_year = isset($_GET['year']) ? intval($_GET['year']) : intval(date('Y'));

if ($employee_id == 0) {
    header("Location: attendance.php?error=invalid_employee");
    exit;
}

// Get month name
$month_name = date('F', mktime(0, 0, 0, $selected_month, 1));

// Get employee details
$emp_sql = "SELECT id, first_name, middle_name, last_name, position FROM employees WHERE id = ?";
$emp_stmt = $conn->prepare($emp_sql);
$emp_stmt->bind_param("i", $employee_id);
$emp_stmt->execute();
$emp_result = $emp_stmt->get_result();
$employee = $emp_result->fetch_assoc();

if (!$employee) {
    header("Location: attendance.php?error=employee_not_found");
    exit;
}

$full_name = $employee['first_name'] . ' ' . 
            (!empty($employee['middle_name']) ? $employee['middle_name'] . ' ' : '') . 
            $employee['last_name'];
$position = $employee['position'] ?? 'N/A';

// Get all attendance records for the selected month and year
$att_sql = "SELECT * FROM attendance 
            WHERE employee_id = ? 
            AND MONTH(date) = ? 
            AND YEAR(date) = ? 
            ORDER BY date ASC";
$att_stmt = $conn->prepare($att_sql);
$att_stmt->bind_param("iii", $employee_id, $selected_month, $selected_year);
$att_stmt->execute();
$att_result = $att_stmt->get_result();

// Get all dates in the month
$days_in_month = cal_days_in_month(CAL_GREGORIAN, $selected_month, $selected_year);
$all_dates = [];
for ($day = 1; $day <= $days_in_month; $day++) {
    $date = sprintf("%04d-%02d-%02d", $selected_year, $selected_month, $day);
    $all_dates[$date] = [
        'date' => $date,
        'day' => $day,
        'day_name' => date('l', strtotime($date)),
        'is_weekend' => (date('N', strtotime($date)) >= 6),
        'attendance' => null
    ];
}

// Organize attendance data
$attendance_records = [];
while ($row = $att_result->fetch_assoc()) {
    $date = $row['date'];
    $attendance_records[$date] = $row;
    
    if (isset($all_dates[$date])) {
        $all_dates[$date]['attendance'] = $row;
    }
}

// Function to format time
function formatTimeForMonthDownload($time) {
    if (empty($time) || $time == '00:00:00') {
        return '-';
    }
    return date('h:i A', strtotime($time));
}

// Function to calculate hours
function calculateHoursForMonthDownload($time_in, $time_out) {
    if (empty($time_in) || empty($time_out) || $time_in == '00:00:00' || $time_out == '00:00:00') {
        return 0;
    }
    
    $time_in_ts = strtotime($time_in);
    $time_out_ts = strtotime($time_out);
    
    if ($time_out_ts < $time_in_ts) {
        $time_out_ts += 86400;
    }
    
    return round(($time_out_ts - $time_in_ts) / 3600, 2);
}

function calculateDailyHoursForMonthDownload($time_in_am, $time_out_am, $time_in_pm, $time_out_pm) {
    $total = 0;
    $total += calculateHoursForMonthDownload($time_in_am, $time_out_am);
    $total += calculateHoursForMonthDownload($time_in_pm, $time_out_pm);
    return $total;
}

// Calculate monthly totals
$total_present_days = 0;
$total_absent_days = 0;
$total_leave_days = 0;
$total_hours = 0;
$total_working_days = 0;

foreach ($all_dates as $date => $data) {
    if ($data['attendance']) {
        $att = $data['attendance'];
        $daily_hours = calculateDailyHoursForMonthDownload(
            $att['time_in_am'], $att['time_out_am'],
            $att['time_in_pm'], $att['time_out_pm']
        );
        
        $has_time = (!empty($att['time_in_am']) && $att['time_in_am'] != '00:00:00') ||
                    (!empty($att['time_out_am']) && $att['time_out_am'] != '00:00:00') ||
                    (!empty($att['time_in_pm']) && $att['time_in_pm'] != '00:00:00') ||
                    (!empty($att['time_out_pm']) && $att['time_out_pm'] != '00:00:00');
        
        if ($has_time) {
            $total_present_days++;
            $total_hours += $daily_hours;
        } elseif ($att['status'] == 'On Leave') {
            $total_leave_days++;
        } elseif ($att['status'] == 'Absent') {
            $total_absent_days++;
        }
        
        $total_working_days++;
    }
}

// Set headers for Excel download
header('Content-Type: application/vnd.ms-excel');
header('Content-Disposition: attachment; filename="monthly_attendance_' . $employee_id . '_' . $month_name . '_' . $selected_year . '.xls"');
header('Cache-Control: max-age=0');
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Monthly Attendance - <?= htmlspecialchars($full_name) ?> - <?= $month_name ?> <?= $selected_year ?></title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 30px;
            color: #333;
        }
        
        /* Header Styles */
        .header {
            text-align: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 3px solid #2E7D32;
        }
        
        .header h1 {
            color: #2E7D32;
            font-size: 28px;
            margin: 0 0 10px 0;
        }
        
        .header h2 {
            color: #1B5E20;
            font-size: 24px;
            margin: 5px 0;
        }
        
        .header h3 {
            color: #2E7D32;
            font-size: 20px;
            margin: 5px 0;
        }
        
        .header p {
            color: #666;
            font-size: 14px;
            margin: 5px 0;
        }
        
        /* Employee Info Section */
        .info-section {
            background: #f5f5f5;
            padding: 25px;
            margin-bottom: 30px;
            border-left: 6px solid #2E7D32;
            border-radius: 8px;
        }
        
        .info-grid {
            display: flex;
            flex-wrap: wrap;
            gap: 40px;
        }
        
        .info-item {
            flex: 1;
            min-width: 200px;
        }
        
        .info-label {
            font-size: 13px;
            color: #666;
            margin-bottom: 8px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .info-value {
            font-size: 20px;
            font-weight: 700;
            color: #2E7D32;
        }
        
        /* Summary Cards */
        .summary-cards {
            display: flex;
            flex-wrap: wrap;
            gap: 25px;
            margin-bottom: 40px;
        }
        
        .summary-card {
            flex: 1;
            min-width: 150px;
            background: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            border-left: 6px solid #2E7D32;
            transition: transform 0.3s;
        }
        
        .summary-card:hover {
            transform: translateY(-5px);
        }
        
        .summary-card.present { border-left-color: #28a745; }
        .summary-card.absent { border-left-color: #dc3545; }
        .summary-card.leave { border-left-color: #ffc107; }
        .summary-card.hours { border-left-color: #17a2b8; }
        
        .summary-label {
            font-size: 14px;
            color: #666;
            margin-bottom: 10px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .summary-value {
            font-size: 32px;
            font-weight: 700;
            color: #333;
        }
        
        .summary-value small {
            font-size: 16px;
            color: #999;
            font-weight: normal;
            margin-left: 5px;
        }
        
        /* Table Styles */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 30px;
            font-size: 13px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        th {
            background: #2E7D32;
            color: white;
            font-weight: 600;
            padding: 15px 10px;
            text-align: center;
            border: 1px solid #1B5E20;
            font-size: 14px;
        }
        
        td {
            padding: 12px 8px;
            border: 1px solid #ddd;
            text-align: center;
            vertical-align: middle;
        }
        
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        
        tr:hover {
            background-color: #f1f8e9;
        }
        
        /* Status Styles */
        .status-present {
            color: #28a745;
            font-weight: 700;
            background-color: #e8f5e9;
            padding: 5px 10px;
            border-radius: 20px;
            display: inline-block;
        }
        
        .status-absent {
            color: #dc3545;
            font-weight: 700;
            background-color: #fef5f5;
            padding: 5px 10px;
            border-radius: 20px;
            display: inline-block;
        }
        
        .status-leave {
            color: #ffc107;
            font-weight: 700;
            background-color: #fff9e6;
            padding: 5px 10px;
            border-radius: 20px;
            display: inline-block;
        }
        
        .status-no-record {
            color: #6c757d;
            font-weight: 700;
            background-color: #f0f0f0;
            padding: 5px 10px;
            border-radius: 20px;
            display: inline-block;
        }
        
        /* Weekend Style */
        .weekend {
            background-color: #fff3cd;
        }
        
        .weekend td {
            background-color: #fff3cd;
        }
        
        /* Total Row */
        .total-row {
            background: #e8f5e9 !important;
            font-weight: 700;
        }
        
        .total-row td {
            background: #e8f5e9;
            border-top: 2px solid #2E7D32;
            border-bottom: 2px solid #2E7D32;
        }
        
        /* Time Display */
        .time-display {
            font-family: 'Courier New', monospace;
            font-weight: 600;
        }
        
        /* Leave Type Badge */
        .leave-type-badge {
            display: inline-block;
            padding: 3px 8px;
            border-radius: 12px;
            font-size: 11px;
            font-weight: 600;
        }
        
        .leave-type-badge.sick {
            background-color: #f8d7da;
            color: #721c24;
        }
        
        .leave-type-badge.vacation {
            background-color: #d4edda;
            color: #155724;
        }
        
        .leave-type-badge.emergency {
            background-color: #fff3cd;
            color: #856404;
        }
        
        /* Footer */
        .footer {
            margin-top: 50px;
            padding-top: 25px;
            border-top: 2px solid #2E7D32;
            font-size: 13px;
            color: #666;
            text-align: center;
        }
        
        .footer p {
            margin: 5px 0;
        }
        
        .footer .generated-date {
            color: #2E7D32;
            font-weight: 600;
        }
        
        /* Text Alignment */
        .text-center {
            text-align: center;
        }
        
        .text-left {
            text-align: left;
        }
        
        .text-right {
            text-align: right;
        }
        
        /* Column Widths */
        .col-date { width: 12%; }
        .col-day { width: 8%; }
        .col-status { width: 10%; }
        .col-time { width: 8%; }
        .col-leave { width: 12%; }
        .col-hours { width: 8%; }
        .col-remarks { width: 18%; }
    </style>
</head>
<body>
    <!-- Header -->
    <div class="header">
        <h1>MONTHLY ATTENDANCE RECORD</h1>
        <h2><?= htmlspecialchars($full_name) ?></h2>
        <h3><?= $month_name ?> <?= $selected_year ?></h3>
        <p>Generated on: <?= date('F j, Y \a\t h:i A') ?></p>
    </div>
    
    <!-- Employee Information -->
    <div class="info-section">
        <div class="info-grid">
            <div class="info-item">
                <div class="info-label">Employee ID</div>
                <div class="info-value"><?= str_pad($employee_id, 5, '0', STR_PAD_LEFT) ?></div>
            </div>
            <div class="info-item">
                <div class="info-label">Full Name</div>
                <div class="info-value"><?= htmlspecialchars($full_name) ?></div>
            </div>
            <div class="info-item">
                <div class="info-label">Position</div>
                <div class="info-value"><?= htmlspecialchars($position) ?></div>
            </div>
            <div class="info-item">
                <div class="info-label">Report Period</div>
                <div class="info-value"><?= $month_name ?> 1 - <?= $days_in_month ?>, <?= $selected_year ?></div>
            </div>
        </div>
    </div>
    
    <!-- Summary Cards -->
    <div class="summary-cards">
        <div class="summary-card present">
            <div class="summary-label">Present Days</div>
            <div class="summary-value"><?= $total_present_days ?> <small>/ <?= $days_in_month ?></small></div>
        </div>
        <div class="summary-card absent">
            <div class="summary-label">Absent Days</div>
            <div class="summary-value"><?= $total_absent_days ?></div>
        </div>
        <div class="summary-card leave">
            <div class="summary-label">Leave Days</div>
            <div class="summary-value"><?= $total_leave_days ?></div>
        </div>
        <div class="summary-card hours">
            <div class="summary-label">Total Hours Worked</div>
            <div class="summary-value"><?= number_format($total_hours, 2) ?> <small>hrs</small></div>
        </div>
    </div>
    
    <!-- Attendance Table -->
    <table>
        <thead>
            <tr>
                <th class="col-date">Date</th>
                <th class="col-day">Day</th>
                <th class="col-status">Status</th>
                <th class="col-time">AM In</th>
                <th class="col-time">AM Out</th>
                <th class="col-time">PM In</th>
                <th class="col-time">PM Out</th>
                <th class="col-hours">Hours</th>
                <th class="col-leave">Leave Type</th>
                <th class="col-remarks">Remarks</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $monthly_total_hours = 0;
            
            foreach ($all_dates as $date => $data): 
                $att = $data['attendance'];
                $row_class = $data['is_weekend'] ? 'weekend' : '';
                
                if ($att):
                    $daily_hours = calculateDailyHoursForMonthDownload(
                        $att['time_in_am'], $att['time_out_am'],
                        $att['time_in_pm'], $att['time_out_pm']
                    );
                    $monthly_total_hours += $daily_hours;
                    
                    $has_time = (!empty($att['time_in_am']) && $att['time_in_am'] != '00:00:00') ||
                                (!empty($att['time_out_am']) && $att['time_out_am'] != '00:00:00') ||
                                (!empty($att['time_in_pm']) && $att['time_in_pm'] != '00:00:00') ||
                                (!empty($att['time_out_pm']) && $att['time_out_pm'] != '00:00:00');
                    
                    if ($has_time) {
                        $status_display = 'Present';
                        $status_class = 'status-present';
                    } elseif ($att['status'] == 'On Leave') {
                        $status_display = 'On Leave';
                        $status_class = 'status-leave';
                        
                        // Determine leave type class
                        $leave_type_class = '';
                        if (strpos(strtolower($att['leave_type'] ?? ''), 'sick') !== false) {
                            $leave_type_class = 'sick';
                        } elseif (strpos(strtolower($att['leave_type'] ?? ''), 'vacation') !== false) {
                            $leave_type_class = 'vacation';
                        } elseif (strpos(strtolower($att['leave_type'] ?? ''), 'emergency') !== false) {
                            $leave_type_class = 'emergency';
                        }
                    } elseif ($att['status'] == 'Absent') {
                        $status_display = 'Absent';
                        $status_class = 'status-absent';
                    } else {
                        $status_display = 'No Record';
                        $status_class = 'status-no-record';
                    }
            ?>
            <tr class="<?= $row_class ?>">
                <td class="text-center"><strong><?= date('M d, Y', strtotime($date)) ?></strong></td>
                <td class="text-center"><?= substr($data['day_name'], 0, 3) ?></td>
                <td class="text-center"><span class="<?= $status_class ?>"><?= $status_display ?></span></td>
                <td class="text-center time-display"><?= formatTimeForMonthDownload($att['time_in_am']) ?></td>
                <td class="text-center time-display"><?= formatTimeForMonthDownload($att['time_out_am']) ?></td>
                <td class="text-center time-display"><?= formatTimeForMonthDownload($att['time_in_pm']) ?></td>
                <td class="text-center time-display"><?= formatTimeForMonthDownload($att['time_out_pm']) ?></td>
                <td class="text-center"><strong><?= number_format($daily_hours, 2) ?></strong></td>
                <td class="text-center">
                    <?php if (!empty($att['leave_type'])): ?>
                        <span class="leave-type-badge <?= $leave_type_class ?? '' ?>">
                            <?= htmlspecialchars($att['leave_type']) ?>
                        </span>
                    <?php else: ?>
                        -
                    <?php endif; ?>
                </td>
                <td class="text-left"><?= !empty($att['remarks']) ? htmlspecialchars($att['remarks']) : '-' ?></td>
            </tr>
            <?php else: ?>
            <tr class="<?= $row_class ?>">
                <td class="text-center"><strong><?= date('M d, Y', strtotime($date)) ?></strong></td>
                <td class="text-center"><?= substr($data['day_name'], 0, 3) ?></td>
                <td class="text-center"><span class="status-no-record">No Record</span></td>
                <td class="text-center">-</td>
                <td class="text-center">-</td>
                <td class="text-center">-</td>
                <td class="text-center">-</td>
                <td class="text-center">0.00</td>
                <td class="text-center">-</td>
                <td class="text-left">-</td>
            </tr>
            <?php endif; ?>
            <?php endforeach; ?>
            
            <!-- Monthly Total Row -->
            <tr class="total-row">
                <td colspan="7" class="text-right"><strong>MONTHLY TOTAL:</strong></td>
                <td class="text-center"><strong><?= number_format($monthly_total_hours, 2) ?> hrs</strong></td>
                <td colspan="2"></td>
            </tr>
        </tbody>
    </table>
    
    <!-- Summary Information -->
    <div style="margin-top: 30px; padding: 20px; background: #f8f9fa; border-radius: 8px;">
        <div style="display: flex; flex-wrap: wrap; gap: 30px;">
            <div style="flex: 1; min-width: 200px;">
                <h4 style="color: #2E7D32; margin-bottom: 15px;">Attendance Summary</h4>
                <table style="width: 100%; border: none; margin: 0;">
                    <tr>
                        <td style="border: none; padding: 5px;"><strong>Total Working Days:</strong></td>
                        <td style="border: none; padding: 5px;"><?= $days_in_month ?></td>
                    </tr>
                    <tr>
                        <td style="border: none; padding: 5px;"><strong>Present Days:</strong></td>
                        <td style="border: none; padding: 5px; color: #28a745;"><?= $total_present_days ?></td>
                    </tr>
                    <tr>
                        <td style="border: none; padding: 5px;"><strong>Absent Days:</strong></td>
                        <td style="border: none; padding: 5px; color: #dc3545;"><?= $total_absent_days ?></td>
                    </tr>
                    <tr>
                        <td style="border: none; padding: 5px;"><strong>Leave Days:</strong></td>
                        <td style="border: none; padding: 5px; color: #ffc107;"><?= $total_leave_days ?></td>
                    </tr>
                    <tr>
                        <td style="border: none; padding: 5px;"><strong>Total Hours Worked:</strong></td>
                        <td style="border: none; padding: 5px; color: #17a2b8;"><?= number_format($monthly_total_hours, 2) ?> hrs</td>
                    </tr>
                </table>
            </div>
            
            <div style="flex: 1; min-width: 200px;">
                <h4 style="color: #2E7D32; margin-bottom: 15px;">Attendance Rate</h4>
                <?php 
                $attendance_rate = ($days_in_month > 0) ? round(($total_present_days / $days_in_month) * 100, 2) : 0;
                $absent_rate = ($days_in_month > 0) ? round(($total_absent_days / $days_in_month) * 100, 2) : 0;
                $leave_rate = ($days_in_month > 0) ? round(($total_leave_days / $days_in_month) * 100, 2) : 0;
                ?>
                <table style="width: 100%; border: none; margin: 0;">
                    <tr>
                        <td style="border: none; padding: 5px;"><strong>Attendance Rate:</strong></td>
                        <td style="border: none; padding: 5px; color: #28a745;"><?= $attendance_rate ?>%</td>
                    </tr>
                    <tr>
                        <td style="border: none; padding: 5px;"><strong>Absent Rate:</strong></td>
                        <td style="border: none; padding: 5px; color: #dc3545;"><?= $absent_rate ?>%</td>
                    </tr>
                    <tr>
                        <td style="border: none; padding: 5px;"><strong>Leave Rate:</strong></td>
                        <td style="border: none; padding: 5px; color: #ffc107;"><?= $leave_rate ?>%</td>
                    </tr>
                </table>
            </div>
            
            <div style="flex: 1; min-width: 200px;">
                <h4 style="color: #2E7D32; margin-bottom: 15px;">Average per Day</h4>
                <?php 
                $avg_hours_per_day = ($total_present_days > 0) ? round($monthly_total_hours / $total_present_days, 2) : 0;
                ?>
                <table style="width: 100%; border: none; margin: 0;">
                    <tr>
                        <td style="border: none; padding: 5px;"><strong>Average Hours/Day:</strong></td>
                        <td style="border: none; padding: 5px;"><?= number_format($avg_hours_per_day, 2) ?> hrs</td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
    
    <!-- Footer -->
    <div class="footer">
        <p class="generated-date">This report was generated on <?= date('F j, Y \a\t h:i A') ?></p>
        <p>Attendance Management System - Monthly Employee Report</p>
        <p>For official use only</p>
    </div>
</body>
</html>
<?php
$conn->close();
?>