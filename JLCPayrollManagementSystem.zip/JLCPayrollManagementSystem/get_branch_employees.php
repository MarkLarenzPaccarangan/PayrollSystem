<?php
session_start();
include 'connection.php';

header('Content-Type: application/json');

if (!isset($_SESSION['Admin_User'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$branch_id = isset($_GET['branch_id']) ? (int)$_GET['branch_id'] : 0;

if ($branch_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid branch ID']);
    exit;
}

try {
    // First, check what columns exist in the employees table
    $columns = ['id', 'first_name', 'last_name', 'position'];
    
    // Check if email column exists
    $email_check = $conn->query("SHOW COLUMNS FROM employees LIKE 'email'");
    if ($email_check->num_rows > 0) {
        $columns[] = 'email';
    }
    
    // Build query with only existing columns
    $columns_str = implode(', ', $columns);
    $query = "SELECT $columns_str 
              FROM employees e 
              INNER JOIN branch_employee be ON e.id = be.employee_id 
              WHERE be.branch_id = ?
              ORDER BY e.first_name, e.last_name";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $branch_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $employees = [];
    while ($row = $result->fetch_assoc()) {
        $employees[] = $row;
    }
    
    echo json_encode([
        'success' => true,
        'employees' => $employees,
        'count' => count($employees)
    ]);
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Database error: ' . $e->getMessage()
    ]);
}
?>