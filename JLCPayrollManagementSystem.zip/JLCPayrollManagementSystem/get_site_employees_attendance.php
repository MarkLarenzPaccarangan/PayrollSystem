<?php
session_start();
include 'connection.php';

header('Content-Type: application/json');

if (!isset($_SESSION['Admin_User'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$site_id = isset($_GET['site_id']) ? (int)$_GET['site_id'] : 0;
$date = isset($_GET['date']) ? $_GET['date'] : date('Y-m-d');

if ($site_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid site ID']);
    exit;
}

// Validate date format
if (!preg_match("/^\d{4}-\d{2}-\d{2}$/", $date)) {
    $date = date('Y-m-d');
}

try {
    // Get site details
    $site_query = "SELECT s.*, so.assignment_type, so.person_group 
                   FROM site_monitoring s 
                   LEFT JOIN site_others so ON s.others_id = so.id 
                   WHERE s.id = ?";
    $site_stmt = $conn->prepare($site_query);
    $site_stmt->bind_param("i", $site_id);
    $site_stmt->execute();
    $site_result = $site_stmt->get_result();
    $site = $site_result->fetch_assoc();
    
    if (!$site) {
        echo json_encode(['success' => false, 'message' => 'Site not found']);
        exit;
    }
    
    // Get employees with attendance
    $employees = [];
    
    $emp_query = "SELECT 
                    e.id,
                    e.first_name,
                    e.last_name,
                    e.position,
                    e.email,
                    se.assigned_date,
                    COALESCE(a.status, 'Absent') as attendance_status,
                    a.time_in_am,
                    a.time_out_am,
                    a.time_in_pm,
                    a.time_out_pm,
                    a.remarks
                  FROM employees e
                  INNER JOIN site_employee se ON e.id = se.employee_id
                  LEFT JOIN attendance a ON e.id = a.employee_id AND a.date = ?
                  WHERE se.site_id = ? AND se.status = 'active'
                  AND e.status = 'active' AND e.is_active = 1
                  ORDER BY e.first_name, e.last_name";
    
    $emp_stmt = $conn->prepare($emp_query);
    $emp_stmt->bind_param("si", $date, $site_id);
    $emp_stmt->execute();
    $emp_result = $emp_stmt->get_result();
    
    while ($row = $emp_result->fetch_assoc()) {
        $employees[] = $row;
    }
    
    // Get site name display
    $site_name = ($site['is_others'] == 1 && !empty($site['assignment_type'])) 
        ? $site['assignment_type'] 
        : $site['site_name'];
    
    echo json_encode([
        'success' => true,
        'site_id' => $site_id,
        'site_name' => $site_name,
        'site_manager' => $site['site_manager'],
        'site_address' => $site['site_address'],
        'is_others' => $site['is_others'],
        'assignment_type' => $site['assignment_type'],
        'person_group' => $site['person_group'],
        'date' => $date,
        'employees' => $employees,
        'count' => count($employees)
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Database error: ' . $e->getMessage()
    ]);
}
?>