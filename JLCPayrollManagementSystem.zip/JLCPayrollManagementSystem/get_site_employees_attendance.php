<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['Admin_User'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

include_once("connection.php");

// Get parameters
$site_id = isset($_GET['site_id']) ? intval($_GET['site_id']) : 0;
$date = isset($_GET['date']) ? $_GET['date'] : date('Y-m-d');

if ($site_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid site ID']);
    exit;
}

// Get site details
$site_query = "SELECT s.*, so.assignment_type, so.person_group 
               FROM site_monitoring s 
               LEFT JOIN site_others so ON s.id = so.site_id 
               WHERE s.id = ?";
$site_stmt = $conn->prepare($site_query);
$site_stmt->bind_param("i", $site_id);
$site_stmt->execute();
$site_result = $site_stmt->get_result();
$site = $site_result->fetch_assoc();

if (!$site) {
    echo json_encode(['success' => false, 'message' => 'Site not found']);
    exit;
}

// Get employees with attendance for this site and date
$query = "SELECT 
            e.id,
            e.first_name,
            e.last_name,
            e.position,
            e.email,
            se.assigned_date,
            a.status_am,
            a.status_pm,
            a.time_in_am,
            a.time_out_am,
            a.time_in_pm,
            a.time_out_pm,
            a.remarks,
            a.total_hours,
            a.leave_type,
            a.status
          FROM employees e
          INNER JOIN site_employee se ON e.id = se.employee_id
          LEFT JOIN attendance a ON e.id = a.employee_id AND a.date = ?
          WHERE se.site_id = ? AND se.status = 'active'
          AND e.status = 'active' AND e.is_active = 1
          ORDER BY e.first_name, e.last_name";

$stmt = $conn->prepare($query);
if (!$stmt) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $conn->error]);
    exit;
}

$stmt->bind_param("si", $date, $site_id);
$stmt->execute();
$result = $stmt->get_result();

$employees = [];
while ($row = $result->fetch_assoc()) {
    // Set default values if NULL
    $row['status_am'] = $row['status_am'] ?? 'Absent';
    $row['status_pm'] = $row['status_pm'] ?? 'Absent';
    $row['time_in_am'] = $row['time_in_am'] ?? null;
    $row['time_out_am'] = $row['time_out_am'] ?? null;
    $row['time_in_pm'] = $row['time_in_pm'] ?? null;
    $row['time_out_pm'] = $row['time_out_pm'] ?? null;
    $row['total_hours'] = $row['total_hours'] ?? 0.00;
    $row['remarks'] = $row['remarks'] ?? '';
    $row['leave_type'] = $row['leave_type'] ?? '';
    
    // Format times for display (remove seconds)
    if ($row['time_in_am'] && $row['time_in_am'] != '00:00:00') {
        $row['time_in_am'] = substr($row['time_in_am'], 0, 5);
    }
    if ($row['time_out_am'] && $row['time_out_am'] != '00:00:00') {
        $row['time_out_am'] = substr($row['time_out_am'], 0, 5);
    }
    if ($row['time_in_pm'] && $row['time_in_pm'] != '00:00:00') {
        $row['time_in_pm'] = substr($row['time_in_pm'], 0, 5);
    }
    if ($row['time_out_pm'] && $row['time_out_pm'] != '00:00:00') {
        $row['time_out_pm'] = substr($row['time_out_pm'], 0, 5);
    }
    
    $employees[] = $row;
}

$response = [
    'success' => true,
    'site_id' => $site_id,
    'site_name' => $site['site_name'] ?? 'Unknown',
    'site_manager' => $site['site_manager'] ?? 'N/A',
    'site_address' => $site['site_address'] ?? 'N/A',
    'date' => $date,
    'employees' => $employees
];

echo json_encode($response);

$site_stmt->close();
$stmt->close();
$conn->close();
?>