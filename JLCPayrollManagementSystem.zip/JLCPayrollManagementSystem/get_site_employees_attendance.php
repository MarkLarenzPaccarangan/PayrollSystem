<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['Admin_User'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

include_once("connection.php");

// Get parameters
$site_id = isset($_GET['site_id']) ? intval($_GET['site_id']) : 0;
$date = isset($_GET['date']) ? $_GET['date'] : date('Y-m-d');

// Validate date format
if (!preg_match("/^\d{4}-\d{2}-\d{2}$/", $date)) {
    $date = date('Y-m-d');
}

if ($site_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid site ID']);
    exit;
}

// Get site details
$site_query = "SELECT s.*, so.assignment_type, so.person_group 
               FROM site_monitoring s 
               LEFT JOIN site_others so ON s.id = so.site_id 
               WHERE s.id = ?";
$site_stmt = $conn->prepare($site_query);
if (!$site_stmt) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $conn->error]);
    exit;
}
$site_stmt->bind_param("i", $site_id);
$site_stmt->execute();
$site_result = $site_stmt->get_result();
$site = $site_result->fetch_assoc();

if (!$site) {
    echo json_encode(['success' => false, 'message' => 'Site not found']);
    exit;
}

// Get total employees count for this site
$total_employees_query = "SELECT COUNT(*) as total 
                          FROM site_employee 
                          WHERE site_id = ? AND status = 'active'";
$total_stmt = $conn->prepare($total_employees_query);
$total_stmt->bind_param("i", $site_id);
$total_stmt->execute();
$total_result = $total_stmt->get_result();
$total_row = $total_result->fetch_assoc();
$total_employees_count = $total_row['total'] ?? 0;

// UPDATED: Include workday_type and leave_type in the query
$query = "SELECT 
            e.id,
            e.first_name,
            e.middle_name,
            e.last_name,
            e.position,
            e.email,
            se.assigned_date,
            a.id as attendance_id,
            a.status,              /* AM status */
            a.pm_status,            /* PM status */
            a.night_status,         /* Night status */
            a.time_in_am,
            a.time_out_am,
            a.time_in_pm,
            a.time_out_pm,
            a.time_in_night,        /* Night time in */
            a.time_out_night,       /* Night time out */
            a.remarks,
            a.total_hours,
            a.leave_type,
            a.workday_type
          FROM employees e
          INNER JOIN site_employee se ON e.id = se.employee_id
          LEFT JOIN attendance a ON e.id = a.employee_id AND DATE(a.date) = DATE(?)
          WHERE se.site_id = ? AND se.status = 'active'
          AND e.status = 'active'
          ORDER BY e.first_name, e.last_name";

$stmt = $conn->prepare($query);
if (!$stmt) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $conn->error]);
    exit;
}

$stmt->bind_param("si", $date, $site_id);
$stmt->execute();
$result = $stmt->get_result();

$employees = [];
$present_count = 0;
$absent_count = 0;
$leave_count = 0;

while ($row = $result->fetch_assoc()) {
    // FIXED: Check if employee is on leave based on leave_type column FIRST
    $is_on_leave = !empty($row['leave_type']);
    
    // Set status values - OVERRIDE if on leave
    if ($is_on_leave) {
        // If on leave, all sessions show as 'On Leave' regardless of actual status
        $row['status_am'] = 'On Leave';
        $row['status_pm'] = 'On Leave';
        $row['status_night'] = 'On Leave';
    } else {
        // Not on leave - use actual status values
        $row['status_am'] = $row['status'] ?? 'Absent';
        $row['status_pm'] = $row['pm_status'] ?? 'Absent';
        $row['status_night'] = $row['night_status'] ?? 'Absent';
    }
    
    $row['time_in_am'] = $row['time_in_am'] ?? null;
    $row['time_out_am'] = $row['time_out_am'] ?? null;
    $row['time_in_pm'] = $row['time_in_pm'] ?? null;
    $row['time_out_pm'] = $row['time_out_pm'] ?? null;
    $row['time_in_night'] = $row['time_in_night'] ?? null;
    $row['time_out_night'] = $row['time_out_night'] ?? null;
    $row['total_hours'] = $row['total_hours'] ?? 0.00;
    $row['remarks'] = $row['remarks'] ?? '';
    $row['leave_type'] = $row['leave_type'] ?? '';
    $row['workday_type'] = $row['workday_type'] ?? '';
    
    // Format full name with middle name
    $full_name = $row['first_name'];
    if (!empty($row['middle_name'])) {
        $full_name .= ' ' . substr($row['middle_name'], 0, 1) . '.';
    }
    $full_name .= ' ' . $row['last_name'];
    $row['full_name'] = $full_name;
    
    // Determine overall status for the day
    if ($is_on_leave) {
        $row['overall_status'] = 'On Leave';
        $leave_count++;
    } elseif ($row['status_am'] == 'Present' || $row['status_pm'] == 'Present' || $row['status_night'] == 'Present') {
        $row['overall_status'] = 'Present';
        $present_count++;
    } else {
        $row['overall_status'] = 'Absent';
        $absent_count++;
    }
    
    // Check if employee has any time logged
    $has_time = (
        (!empty($row['time_in_am']) && $row['time_in_am'] != '00:00:00' && $row['time_in_am'] != '--:--') ||
        (!empty($row['time_out_am']) && $row['time_out_am'] != '00:00:00' && $row['time_out_am'] != '--:--') ||
        (!empty($row['time_in_pm']) && $row['time_in_pm'] != '00:00:00' && $row['time_in_pm'] != '--:--') ||
        (!empty($row['time_out_pm']) && $row['time_out_pm'] != '00:00:00' && $row['time_out_pm'] != '--:--') ||
        (!empty($row['time_in_night']) && $row['time_in_night'] != '00:00:00' && $row['time_in_night'] != '--:--') ||
        (!empty($row['time_out_night']) && $row['time_out_night'] != '00:00:00' && $row['time_out_night'] != '--:--')
    );
    $row['has_time'] = $has_time;
    
    // Format times for display (remove seconds) - KEEP ORIGINAL FOR REFERENCE
    $row['time_in_am_raw'] = $row['time_in_am'];
    $row['time_out_am_raw'] = $row['time_out_am'];
    $row['time_in_pm_raw'] = $row['time_in_pm'];
    $row['time_out_pm_raw'] = $row['time_out_pm'];
    $row['time_in_night_raw'] = $row['time_in_night'];
    $row['time_out_night_raw'] = $row['time_out_night'];
    
    // Format for display
    if ($row['time_in_am'] && $row['time_in_am'] != '00:00:00') {
        $row['time_in_am_display'] = substr($row['time_in_am'], 0, 5);
    } else {
        $row['time_in_am_display'] = '--:--';
    }
    
    if ($row['time_out_am'] && $row['time_out_am'] != '00:00:00') {
        $row['time_out_am_display'] = substr($row['time_out_am'], 0, 5);
    } else {
        $row['time_out_am_display'] = '--:--';
    }
    
    if ($row['time_in_pm'] && $row['time_in_pm'] != '00:00:00') {
        $row['time_in_pm_display'] = substr($row['time_in_pm'], 0, 5);
    } else {
        $row['time_in_pm_display'] = '--:--';
    }
    
    if ($row['time_out_pm'] && $row['time_out_pm'] != '00:00:00') {
        $row['time_out_pm_display'] = substr($row['time_out_pm'], 0, 5);
    } else {
        $row['time_out_pm_display'] = '--:--';
    }
    
    if ($row['time_in_night'] && $row['time_in_night'] != '00:00:00') {
        $row['time_in_night_display'] = substr($row['time_in_night'], 0, 5);
    } else {
        $row['time_in_night_display'] = '--:--';
    }
    
    if ($row['time_out_night'] && $row['time_out_night'] != '00:00:00') {
        $row['time_out_night_display'] = substr($row['time_out_night'], 0, 5);
    } else {
        $row['time_out_night_display'] = '--:--';
    }
    
    // Create combined time string for display
    $time_details = [];
    if ($row['time_in_am_display'] != '--:--' || $row['time_out_am_display'] != '--:--') {
        $time_details[] = "AM: {$row['time_in_am_display']}-{$row['time_out_am_display']}";
    }
    if ($row['time_in_pm_display'] != '--:--' || $row['time_out_pm_display'] != '--:--') {
        $time_details[] = "PM: {$row['time_in_pm_display']}-{$row['time_out_pm_display']}";
    }
    if ($row['time_in_night_display'] != '--:--' || $row['time_out_night_display'] != '--:--') {
        $time_details[] = "Night: {$row['time_in_night_display']}-{$row['time_out_night_display']}";
    }
    $row['time_display'] = implode(' | ', $time_details);
    
    $employees[] = $row;
}

// Recalculate absent count based on total employees
$absent_count = max(0, $total_employees_count - $present_count - $leave_count);

$response = [
    'success' => true,
    'site_id' => $site_id,
    'site_name' => $site['site_name'] ?? 'Unknown',
    'site_manager' => $site['site_manager'] ?? 'N/A',
    'site_address' => $site['site_address'] ?? 'N/A',
    'date' => $date,
    'employees' => $employees,
    'summary' => [
        'total' => $total_employees_count,
        'present' => $present_count,
        'absent' => $absent_count,
        'leave' => $leave_count
    ],
    'debug' => [
        'employees_found' => count($employees),
        'date_used' => $date
    ]
];

echo json_encode($response);

$site_stmt->close();
$total_stmt->close();
$stmt->close();
$conn->close();
?>