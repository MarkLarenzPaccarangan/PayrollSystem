<?php
session_start();

if (!isset($_SESSION['Admin_User'])) {
    header("Location: login.php");
    exit;
}

// Include access control
include_once("check_access.php");

// Check if user has access to this page
$current_page = basename($_SERVER['PHP_SELF']);
if (!checkPageAccess($current_page)) {
    header("Location: home.php?error=access_denied");
    exit;
}

include_once("connection.php");
$username = $_SESSION['Admin_User'];
$error_message = '';
$success_message = '';

// Fetch user data from super_user table
$stmt = $conn->prepare("SELECT username, password, security_answer1, security_answer2, security_answer3 FROM super_user WHERE username = ?");
$stmt->bind_param("s", $username);
$stmt->execute();
$stmt->bind_result($currentUsername, $currentPassword, $security1, $security2, $security3);
$stmt->fetch();
$stmt->close();

// Handle NULL values
$security1 = $security1 ?? '';
$security2 = $security2 ?? '';
$security3 = $security3 ?? '';

// Get user role from session
$role = $_SESSION['role'] ?? 'admin';
$full_name = $_SESSION['full_name'] ?? $currentUsername;

// Handle form submission for updates
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $newUsername = trim($_POST['username']);
    $newPassword = trim($_POST['password']);
    $newAnswer1 = trim($_POST['security_answer1']);
    $newAnswer2 = trim($_POST['security_answer2']);
    $newAnswer3 = trim($_POST['security_answer3']);

    // Update user data
    $updateStmt = $conn->prepare("UPDATE super_user SET username = ?, password = ?, security_answer1 = ?, security_answer2 = ?, security_answer3 = ? WHERE username = ?");
    $updateStmt->bind_param("ssssss", $newUsername, $newPassword, $newAnswer1, $newAnswer2, $newAnswer3, $username);

    if ($updateStmt->execute()) {
        $_SESSION['Admin_User'] = $newUsername; // Update session username
        $_SESSION['full_name'] = $newUsername; // Update full name if needed
        $success_message = "Profile updated successfully.";
        
        // Update local variables for display
        $currentUsername = $newUsername;
        $currentPassword = $newPassword;
        $security1 = $newAnswer1;
        $security2 = $newAnswer2;
        $security3 = $newAnswer3;
    } else {
        $error_message = "Failed to update profile. Please try again.";
    }

    $updateStmt->close();
}
$conn->close();

// Get first letter for avatar
$firstLetter = !empty($currentUsername) ? strtoupper(substr($currentUsername, 0, 1)) : 'A';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
    <link rel="stylesheet" href="./assets/css/user2.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .content-wrapper {
            min-height: calc(100vh - var(--header-height) - 40px);
            padding: 20px;
        }
        
        .profile-header {
            display: flex;
            align-items: center;
            gap: 20px;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 2px solid #e0e0e0;
        }
        
        .profile-stats {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 15px;
            margin-top: 20px;
        }
        
        .stat-card {
            background: white;
            padding: 15px;
            border-radius: var(--border-radius);
            text-align: center;
            box-shadow: var(--box-shadow);
            border: 1px solid #e0e0e0;
            transition: var(--transition);
        }
        
        .stat-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 12px rgba(0,0,0,0.1);
            border-color: var(--accent-green);
        }
        
        .stat-card i {
            font-size: 2rem;
            color: var(--sidebar-green);
            margin-bottom: 10px;
        }
        
        .stat-card h4 {
            color: var(--sidebar-dark-green);
            margin: 5px 0;
            font-size: 0.9rem;
        }
        
        .stat-card p {
            font-size: 1.2rem;
            font-weight: 700;
            color: #333;
        }
        
        .form-section {
            margin-bottom: 25px;
            padding-bottom: 20px;
            border-bottom: 1px solid #e0e0e0;
        }
        
        .form-section h3 {
            color: var(--sidebar-dark-green);
            margin-bottom: 15px;
            font-size: 1.1rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .form-row {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
        }
        
        .password-group {
            position: relative;
        }
        
        .password-toggle {
            position: absolute;
            right: 10px;
            top: 38px;
            background: none;
            border: none;
            color: #95a5a6;
            cursor: pointer;
            font-size: 1rem;
            padding: 5px;
        }
        
        .password-toggle:hover {
            color: var(--sidebar-green);
        }
        
        .action-buttons {
            display: flex;
            gap: 15px;
            margin-top: 20px;
            justify-content: flex-end;
        }
        
        .btn-save, .btn-cancel {
            padding: 12px 30px;
            border: none;
            border-radius: var(--border-radius);
            font-size: 0.95rem;
            font-weight: 600;
            cursor: pointer;
            transition: var(--transition);
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        
        .btn-save {
            background: linear-gradient(135deg, var(--sidebar-green), var(--sidebar-dark-green));
            color: white;
        }
        
        .btn-save:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(46, 125, 50, 0.3);
        }
        
        .btn-cancel {
            background-color: #f8f9fa;
            color: #7f8c8d;
            border: 1px solid #bdc3c7;
        }
        
        .btn-cancel:hover {
            background-color: #e74c3c;
            color: white;
            border-color: #e74c3c;
            transform: translateY(-2px);
        }
        
        .message {
            padding: 15px 20px;
            border-radius: var(--border-radius);
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 0.95rem;
            animation: slideIn 0.3s ease;
        }
        
        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .message.success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .message.error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        .text-success {
            color: #28a745;
        }
        
        .profile-info {
            display: grid;
            gap: 15px;
            background: #f8f9fa;
            padding: 20px;
            border-radius: var(--border-radius);
        }
        
        .profile-info-item {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 10px 15px;
            background: white;
            border-radius: var(--border-radius);
            border: 1px solid #e0e0e0;
        }
        
        .profile-info-item label {
            min-width: 150px;
            font-weight: 600;
            color: var(--sidebar-dark-green);
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .profile-info-item label i {
            color: var(--sidebar-green);
            width: 20px;
        }
        
        .profile-info-item span {
            color: #2c3e50;
            font-weight: 500;
            flex: 1;
        }
        
        .security-question-item {
            margin-bottom: 15px;
        }
        
        .security-question-item label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: var(--sidebar-dark-green);
            font-size: 0.95rem;
        }
        
        .security-question-item label i {
            color: var(--sidebar-green);
            margin-right: 8px;
        }
        
        .security-question-item input {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e0e0e0;
            border-radius: var(--border-radius);
            font-size: 0.95rem;
            transition: var(--transition);
        }
        
        .security-question-item input:focus {
            border-color: var(--accent-green);
            box-shadow: 0 0 0 3px rgba(41, 148, 82, 0.1);
            outline: none;
        }
        
        .success-pulse {
            animation: successPulse 0.5s ease;
        }
        
        @keyframes successPulse {
            0% {
                transform: scale(1);
            }
            50% {
                transform: scale(1.05);
                box-shadow: 0 0 0 3px rgba(46, 125, 50, 0.3);
            }
            100% {
                transform: scale(1);
            }
        }
        
        /* Role-based styling */
        .avatar-circle.admin {
            background: linear-gradient(135deg, #667eea, #764ba2);
        }
        
        .avatar-circle.ceo {
            background: linear-gradient(135deg, #f093fb, #f5576c);
        }
        
        .avatar-circle.user {
            background: linear-gradient(135deg, #4facfe, #00f2fe);
        }
        
        .role-badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
            text-transform: uppercase;
            margin-left: 10px;
        }
        
        .role-badge.admin {
            background: #667eea;
            color: white;
        }
        
        .role-badge.ceo {
            background: #f093fb;
            color: white;
        }
        
        .role-badge.user {
            background: #4facfe;
            color: white;
        }
        
        @media (max-width: 768px) {
            .form-row {
                grid-template-columns: 1fr;
            }
            
            .profile-stats {
                grid-template-columns: 1fr;
            }
            
            .profile-info-item {
                flex-direction: column;
                align-items: flex-start;
                gap: 5px;
            }
            
            .profile-info-item label {
                min-width: auto;
            }
            
            .action-buttons {
                flex-direction: column;
            }
            
            .btn-save, .btn-cancel {
                width: 100%;
                justify-content: center;
            }
            
            .password-toggle {
                top: 35px;
            }
        }
    </style>
</head>
<body>
    
<!-- Header -->
<?php include_once("./includes/header.php"); ?>

<main class="content">
    <div class="content-wrapper">
        <!-- Profile Header -->
        <div class="welcome-box2">
            <i class="fas fa-user-cog"></i> USER PROFILE
        </div>

        <div class="profile-container">
            <!-- Profile Avatar -->
            <div class="profile-avatar">
                <div class="avatar-circle <?php echo $role; ?>">
                    <?php echo $firstLetter; ?>
                </div>
                <h3><?php echo htmlspecialchars($currentUsername); ?></h3>
                <p>
                    <i class="fas fa-user-shield"></i> 
                    <?php echo ucfirst($role); ?> Account
                    <span class="role-badge <?php echo $role; ?>"><?php echo strtoupper($role); ?></span>
                </p>
            </div>

            <!-- Messages -->
            <?php if (!empty($error_message)): ?>
                <div class="message error">
                    <i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($error_message); ?>
                </div>
            <?php endif; ?>
            <?php if (!empty($success_message)): ?>
                <div class="message success">
                    <i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($success_message); ?>
                </div>
            <?php endif; ?>

            <!-- Account Information -->
            <div class="form-section">
                <h3><i class="fas fa-user-circle"></i> Account Information</h3>
                <div class="profile-info">
                    <div class="profile-info-item">
                        <label><i class="fas fa-user"></i> Username</label>
                        <span><?php echo htmlspecialchars($currentUsername); ?></span>
                    </div>
                    <div class="profile-info-item">
                        <label><i class="fas fa-user-tag"></i> Full Name</label>
                        <span><?php echo htmlspecialchars($full_name); ?></span>
                    </div>
                    <div class="profile-info-item">
                        <label><i class="fas fa-calendar-alt"></i> Account Created</label>
                        <span><?php echo date('F d, Y'); ?></span>
                    </div>
                    <div class="profile-info-item">
                        <label><i class="fas fa-key"></i> Password Status</label>
                        <span><i class="fas fa-check text-success"></i> Password Set</span>
                    </div>
                    <div class="profile-info-item">
                        <label><i class="fas fa-shield-alt"></i> Security Level</label>
                        <span><?php echo ucfirst($role); ?></span>
                    </div>
                </div>
            </div>

            <!-- Update Profile Form -->
            <form method="POST" action="" id="profileForm">
                <div class="form-section">
                    <h3><i class="fas fa-edit"></i> Update Profile</h3>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="username">
                                <i class="fas fa-user"></i> New Username
                            </label>
                            <input type="text" id="username" name="username" 
                                   value="<?php echo htmlspecialchars($currentUsername); ?>" 
                                   required
                                   placeholder="Enter new username">
                        </div>
                        
                        <div class="form-group password-group">
                            <label for="password">
                                <i class="fas fa-lock"></i> New Password
                            </label>
                            <input type="password" id="password" name="password" 
                                   value="<?php echo htmlspecialchars($currentPassword); ?>" 
                                   required
                                   placeholder="Enter new password">
                            <button type="button" class="password-toggle" onclick="togglePassword()">
                                <i class="fas fa-eye"></i>
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Security Questions -->
                <div class="form-section">
                    <h3><i class="fas fa-question-circle"></i> Security Questions</h3>
                    
                    <div class="security-question-item">
                        <label for="security_answer1">
                            <i class="fas fa-question"></i> What is your Middle Name?
                        </label>
                        <input type="text" id="security_answer1" name="security_answer1" 
                               value="<?php echo htmlspecialchars($security1); ?>" 
                               required
                               placeholder="Enter your middle name">
                    </div>
                    
                    <div class="security-question-item">
                        <label for="security_answer2">
                            <i class="fas fa-question"></i> What is your First Name?
                        </label>
                        <input type="text" id="security_answer2" name="security_answer2" 
                               value="<?php echo htmlspecialchars($security2); ?>" 
                               required
                               placeholder="Enter your first name">
                    </div>
                    
                    <div class="security-question-item">
                        <label for="security_answer3">
                            <i class="fas fa-question"></i> What is your Last Name?
                        </label>
                        <input type="text" id="security_answer3" name="security_answer3" 
                               value="<?php echo htmlspecialchars($security3); ?>" 
                               required
                               placeholder="Enter your last name">
                    </div>
                </div>

                <!-- Action Buttons -->
                <div class="action-buttons">
                    <button type="submit" class="btn-save">
                        <i class="fas fa-save"></i> Update Profile
                    </button>
                    <button type="button" class="btn-cancel" onclick="resetForm()">
                        <i class="fas fa-undo"></i> Reset
                    </button>
                </div>
            </form>
        </div>
    </div>
</main>

<!-- Footer -->
<?php include_once("./includes/footer.php"); ?>

<?php include_once("./modal/logout-modal.php"); ?>

<script>
    // Toggle password visibility
    function togglePassword() {
        const passwordInput = document.getElementById('password');
        const toggleIcon = document.querySelector('.password-toggle i');
        
        if (passwordInput.type === 'password') {
            passwordInput.type = 'text';
            toggleIcon.classList.remove('fa-eye');
            toggleIcon.classList.add('fa-eye-slash');
        } else {
            passwordInput.type = 'password';
            toggleIcon.classList.remove('fa-eye-slash');
            toggleIcon.classList.add('fa-eye');
        }
    }

    // Reset form to original values
    function resetForm() {
        if (confirm('Are you sure you want to reset all changes?')) {
            document.getElementById('profileForm').reset();
            // Reset password toggle
            const passwordInput = document.getElementById('password');
            const toggleIcon = document.querySelector('.password-toggle i');
            passwordInput.type = 'password';
            toggleIcon.classList.remove('fa-eye-slash');
            toggleIcon.classList.add('fa-eye');
        }
    }

    // Form validation
    document.getElementById('profileForm').addEventListener('submit', function(e) {
        const username = document.getElementById('username').value.trim();
        const password = document.getElementById('password').value.trim();
        const answer1 = document.getElementById('security_answer1').value.trim();
        const answer2 = document.getElementById('security_answer2').value.trim();
        const answer3 = document.getElementById('security_answer3').value.trim();
        
        if (!username || !password || !answer1 || !answer2 || !answer3) {
            e.preventDefault();
            alert('Please fill in all fields before updating your profile.');
            return false;
        }
        
        if (password.length < 6) {
            e.preventDefault();
            alert('Password must be at least 6 characters long.');
            return false;
        }
        
        // Add success animation to button
        const submitBtn = document.querySelector('.btn-save');
        submitBtn.classList.add('success-pulse');
        setTimeout(() => {
            submitBtn.classList.remove('success-pulse');
        }, 500);
        
        return true;
    });

    // Auto-hide messages after 5 seconds
    document.addEventListener('DOMContentLoaded', function() {
        const successMessage = document.querySelector('.message.success');
        if (successMessage) {
            setTimeout(() => {
                successMessage.style.animation = 'slideOut 0.3s ease';
                setTimeout(() => {
                    if (successMessage.parentNode) {
                        successMessage.remove();
                    }
                }, 300);
            }, 5000);
        }
        
        const errorMessage = document.querySelector('.message.error');
        if (errorMessage) {
            setTimeout(() => {
                errorMessage.style.animation = 'slideOut 0.3s ease';
                setTimeout(() => {
                    if (errorMessage.parentNode) {
                        errorMessage.remove();
                    }
                }, 300);
            }, 5000);
        }
    });

    // Add slideOut animation
    const style = document.createElement('style');
    style.textContent = `
        @keyframes slideOut {
            from {
                opacity: 1;
                transform: translateY(0);
            }
            to {
                opacity: 0;
                transform: translateY(-10px);
            }
        }
    `;
    document.head.appendChild(style);
</script>

</body>
</html>