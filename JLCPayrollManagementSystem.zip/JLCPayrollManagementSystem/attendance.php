<?php
session_start();

// Debug: Check if we have success/error messages
if (isset($_SESSION['success'])) {
    error_log("SUCCESS MESSAGE: " . $_SESSION['success']);
}
if (isset($_SESSION['error'])) {
    error_log("ERROR MESSAGE: " . $_SESSION['error']);
}

if (!isset($_SESSION['Admin_User'])) {
    header("Location: login.php");
    exit;
}

include_once("connection.php");

// Date filter - default to current date
$selected_date = isset($_GET['date']) ? $_GET['date'] : date('Y-m-d');
$search = isset($_GET['search']) ? trim($_GET['search']) : "";

// Extract month, year, and day from selected date
$month = date('m', strtotime($selected_date));
$year = date('Y', strtotime($selected_date));
$day = date('d', strtotime($selected_date));

// BASE QUERY (LEFT JOIN = important)
$sql = "SELECT 
            e.id AS employee_id,
            e.first_name,
            e.middle_name,
            e.last_name,
            a.date,
            a.status,
            a.time_in,
            a.time_out,
            a.remarks
        FROM employees e
        LEFT JOIN attendance a 
            ON a.employee_id = e.id 
            AND DATE(a.date) = ?";

$params = [$selected_date];
$param_types = "s";

// Search
if (!empty($search)) {
    $sql .= " WHERE (e.first_name LIKE ? 
              OR e.middle_name LIKE ? 
              OR e.last_name LIKE ? 
              OR e.id LIKE ?)";
    $search_param = "%$search%";
    $params = array_merge($params, [$search_param, $search_param, $search_param, $search_param]);
    $param_types .= "ssss";
}

$sql .= " ORDER BY e.last_name ASC, a.date DESC";

$stmt = $conn->prepare($sql);

if ($stmt === false) {
    die("Error preparing query: " . $conn->error);
}

// Bind parameters dynamically
$stmt->bind_param($param_types, ...$params);
$stmt->execute();
$result = $stmt->get_result();

// Get month name
$month_name = date('F', strtotime($selected_date));

// Get number of days in selected month
$days_in_month = date('t', strtotime($selected_date));

// Get first day of month (0=Sunday, 1=Monday, etc.)
$first_day_of_month = date('w', strtotime("$year-$month-01"));

// Get employees for modal dropdown
$employee_sql = "SELECT id, first_name, middle_name, last_name FROM employees ORDER BY last_name, first_name";
$employee_result = $conn->query($employee_sql);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Attendance</title>
    <link rel="stylesheet" href="./assets/css/attendance.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* Additional inline styles to ensure full payroll UI compatibility */
        .content-wrapper {
            min-height: calc(100vh - var(--header-height) - 40px);
            margin-top: 0;
            padding: 0;
        }
        
        .payroll-info {
            display: grid;
            gap: 4px;
        }
        
        .payroll-info strong {
            color: var(--sidebar-dark-green);
            font-weight: 600;
        }
        
        .controls-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin: 20px 0;
            padding: 15px 20px;
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
        }
        
        .search-section {
            display: flex;
            align-items: center;
            gap: 15px;
            flex: 1;
        }
        
        .generate-payroll-btn {
            background-color: var(--sidebar-green);
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 25px;
            font-size: 0.95rem;
            font-weight: 600;
            cursor: pointer;
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 8px;
            box-shadow: var(--box-shadow);
            white-space: nowrap;
            text-decoration: none;
        }
        
        .generate-payroll-btn:hover {
            background-color: var(--sidebar-dark-green);
            transform: translateY(-2px);
            box-shadow: 0 6px 8px rgba(0, 0, 0, 0.15);
        }
        
        .date-range {
            color: #666;
            font-size: 0.9rem;
            font-style: italic;
        }
        
        /* Status badge styles */
        .status-badge {
            padding: 4px 10px;
            border-radius: 15px;
            font-size: 0.8rem;
            font-weight: 600;
            text-transform: uppercase;
            display: inline-block;
        }
        
        .status-paid {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .status-pending {
            background-color: #fff3cd;
            color: #856404;
            border: 1px solid #ffeaa7;
        }
        
        /* Ensure proper table styling */
        .payroll-table td {
            vertical-align: middle;
        }
        
        .btn-edit {
            background-color: var(--info-color);
            color: white;
            padding: 8px 16px;
            border: none;
            cursor: pointer;
            text-align: center;
            font-weight: 600;
            border-radius: var(--border-radius);
            text-decoration: none;
            transition: var(--transition);
            font-size: 0.85rem;
            min-width: 80px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 5px;
        }
        
        .btn-edit:hover {
            background-color: #0b7dda;
            transform: translateY(-1px);
            color: white;
        }
        
        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: #7f8c8d;
        }
        
        .empty-state i {
            font-size: 2.5rem;
            color: #d1f0eb;
            margin-bottom: 10px;
        }
        
        .empty-state p {
            font-size: 1rem;
        }
        
        .month-highlight {
            font-weight: 600;
            color: var(--sidebar-dark-green);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .time-container {
            display: flex;
            flex-direction: column;
            gap: 4px;
            align-items: center;
            justify-content: center;
        }
        
        .time-label {
            font-size: 0.7rem;
            font-weight: 600;
            color: #6c757d;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .am-time {
            color: var(--info-color);
            font-weight: 700;
            font-size: 0.9rem;
            font-family: 'Courier New', monospace;
        }
        
        .pm-time {
            color: var(--warning-color);
            font-weight: 700;
            font-size: 0.9rem;
            font-family: 'Courier New', monospace;
        }
    </style>
</head>
<body>

<?php 
// Include header with session check removed (already done above)
include("./includes/header.php"); 
?>

<main class="content">
    <div class="content-wrapper">
        <!-- Welcome Box - Updated to match payroll UI -->
       
        
        <!-- Display success/error messages -->
        <?php if(isset($_SESSION['success'])): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i> <?= $_SESSION['success']; unset($_SESSION['success']); ?>
            </div>
        <?php endif; ?>
        
        <?php if(isset($_SESSION['error'])): ?>
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle"></i> <?= $_SESSION['error']; unset($_SESSION['error']); ?>
            </div>
        <?php endif; ?>
        
        <!-- Controls Container - Matching payrollList2.php UI -->
        <div class="controls-container">
            <div class="search-section">
                <form method="GET" action="attendance.php" style="display: flex; align-items: center; gap: 15px; flex-wrap: wrap; width: 100%;">
                    <div style="display: flex; align-items: center; gap: 10px;">
                        <span class="filter-label"><i class="fas fa-calendar-alt"></i> Date:</span>
                        <div class="calendar-container">
                            <input type="text" id="dateInput" class="date-input" 
                                   onclick="toggleCalendar()" readonly value="<?= date('M d, Y', strtotime($selected_date)) ?>">
                            <input type="hidden" id="selectedDate" name="date" value="<?= $selected_date ?>">
                            
                            <!-- Calendar Dropdown -->
                            <div class="calendar-wrapper" id="calendarWrapper">
                                <div class="calendar-box">
                                    <div class="calendar-header">
                                        <div class="calendar-month-year">
                                            <?= $month_name ?> <?= $year ?> ▼
                                        </div>
                                        <div class="calendar-nav">
                                            <button type="button" class="calendar-nav-btn" onclick="navigateMonth(-1)">‹</button>
                                            <button type="button" class="calendar-nav-btn" onclick="navigateMonth(1)">›</button>
                                        </div>
                                    </div>
                                    
                                    <div class="calendar-weekdays">
                                        <div class="weekday">Su</div>
                                        <div class="weekday">Mo</div>
                                        <div class="weekday">Tu</div>
                                        <div class="weekday">We</div>
                                        <div class="weekday">Th</div>
                                        <div class="weekday">Fr</div>
                                        <div class="weekday">Sa</div>
                                    </div>
                                    
                                    <div class="calendar-days-grid">
                                        <?php
                                        // Fill in days from previous month
                                        for ($i = 0; $i < $first_day_of_month; $i++) {
                                            $prev_month_day = date('j', strtotime("-$i days", strtotime("$year-$month-01")));
                                            echo '<div class="calendar-day other-month">' . $prev_month_day . '</div>';
                                        }
                                        
                                        // Current month days
                                        $today = date('Y-m-d');
                                        for ($day_num = 1; $day_num <= $days_in_month; $day_num++) {
                                            $current_date = date('Y-m-d', strtotime("$year-$month-" . str_pad($day_num, 2, '0', STR_PAD_LEFT)));
                                            $is_today = ($current_date == $today);
                                            $is_selected = ($current_date == $selected_date);
                                            $weekday = date('w', strtotime($current_date));
                                            $is_weekend = ($weekday == 0 || $weekday == 6);
                                            
                                            $classes = 'calendar-day';
                                            if ($is_today) $classes .= ' today';
                                            if ($is_selected) $classes .= ' selected';
                                            if ($is_weekend) $classes .= ' weekend';
                                            
                                            echo '<a href="javascript:void(0)" class="' . $classes . '" onclick="selectDate(\'' . $current_date . '\')">';
                                            echo $day_num;
                                            echo '</a>';
                                        }
                                        
                                        // Fill remaining cells
                                        $total_cells = 42;
                                        $cells_used = $first_day_of_month + $days_in_month;
                                        $cells_remaining = $total_cells - $cells_used;
                                        
                                        for ($i = 1; $i <= $cells_remaining; $i++) {
                                            echo '<div class="calendar-day other-month">' . $i . '</div>';
                                        }
                                        ?>
                                    </div>
                                    
                                    <div class="calendar-footer">
                                        <a href="javascript:void(0)" class="calendar-action-btn clear" onclick="selectDate('')">Clear</a>
                                        <a href="javascript:void(0)" class="calendar-action-btn today" 
                                           onclick="selectDate('<?= date('Y-m-d') ?>')">Today</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div style="display: flex; align-items: center; gap: 10px; flex: 1;">
                        <input type="text" id="searchInput" name="search" placeholder="Search by name or ID" 
                               class="search-bar" value="<?= htmlspecialchars($search) ?>">
                    </div>

                    <button type="submit" class="search-btn">
                        <i class="fas fa-search"></i> Search
                    </button>

                    <a href="attendance.php" class="clear-btn">
                        <i class="fas fa-times"></i> Clear
                    </a>

                    <button type="button" class="add-attendance-btn" onclick="window.openAddAttendanceModal()">
                        <i class="fas fa-plus"></i> Add Attendance
                    </button>
                </form>
            </div>
        </div>

        <!-- Table Container - Matching payrollList2.php -->
        <div class="table-responsive">
            <div class="payroll-table-container">
                <table class="payroll-table">
                    <thead>
                        <tr>
                            <th><i class="fas fa-id-badge"></i> ID</th>
                            <th><i class="fas fa-user"></i> Employee</th>
                            <th><i class="fas fa-calendar"></i> Date</th>
                            <th><i class="fas fa-clipboard-check"></i> Status</th>
                            <th><i class="fas fa-sign-in-alt"></i> Time In</th>
                            <th><i class="fas fa-sign-out-alt"></i> Time Out</th>
                            <th><i class="fas fa-comment"></i> Remarks</th>
                            <th><i class="fas fa-cogs"></i> Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if($result && $result->num_rows > 0): ?>
                        <?php while($row = $result->fetch_assoc()): ?>
                            <?php
                            // Handle NULL values
                            $row['middle_name'] = $row['middle_name'] ?? '';
                            $row['time_in'] = $row['time_in'] ?? '';
                            $row['time_out'] = $row['time_out'] ?? '';
                            $row['remarks'] = $row['remarks'] ?? '';
                            
                            // Format times for display
                            $time_in_display = "-";
                            $time_out_display = "-";
                            
                            if (!empty($row['time_in']) && $row['time_in'] != '00:00:00') {
                                $time_in = strtotime($row['time_in']);
                                $time_in_display = date('h:i A', $time_in);
                            }
                            
                            if (!empty($row['time_out']) && $row['time_out'] != '00:00:00') {
                                $time_out = strtotime($row['time_out']);
                                $time_out_display = date('h:i A', $time_out);
                            }
                            
                            // Determine AM/PM
                            $time_in_ampm = (!empty($row['time_in']) && $row['time_in'] != '00:00:00') ? date('A', strtotime($row['time_in'])) : '';
                            $time_out_ampm = (!empty($row['time_out']) && $row['time_out'] != '00:00:00') ? date('A', strtotime($row['time_out'])) : '';
                            
                            // Determine status class
                            $status_class = 'status-no-record';
                            $status_text = 'No Record';
                            if (!empty($row['status'])) {
                                $status_class = $row['status'] == 'Present' ? 'status-present' : 'status-absent';
                                $status_text = htmlspecialchars($row['status']);
                            }
                            ?>
                            <tr>
                                <td data-label="ID" style="text-align: center; font-weight: 700;"><?= htmlspecialchars($row['employee_id']) ?></td>
                                <td data-label="Employee">
                                    <div class="payroll-info">
                                        <div><strong>Name:</strong> <?= htmlspecialchars($row['first_name'] . " " . 
                                           (!empty($row['middle_name']) ? $row['middle_name'] . " " : "") . 
                                           $row['last_name']) ?></div>
                                        <div><strong>ID:</strong> <?= $row['employee_id'] ?></div>
                                    </div>
                                </td>
                                <td data-label="Date" style="text-align: center;">
                                    <div class="payroll-info">
                                        <div><strong>Date:</strong> <?= !empty($row['date']) ? date('M d, Y', strtotime($row['date'])) : '-' ?></div>
                                        <div class="date-range">
                                            <?= date('l', strtotime($row['date'])) ?>
                                        </div>
                                    </div>
                                </td>
                                <td data-label="Status" style="text-align: center;">
                                    <span class="<?= $status_class ?>">
                                        <?php if($status_text == 'Present'): ?>
                                            <i class="fas fa-check-circle"></i>
                                        <?php elseif($status_text == 'Absent'): ?>
                                            <i class="fas fa-times-circle"></i>
                                        <?php else: ?>
                                            <i class="fas fa-question-circle"></i>
                                        <?php endif; ?>
                                        <?= $status_text ?>
                                    </span>
                                </td>
                                <td data-label="Time In" style="text-align: center;">
                                    <?php if (!empty($row['time_in']) && $row['time_in'] != '00:00:00'): ?>
                                        <div class="time-container">
                                            <span class="time-label"><?= $time_in_ampm ?></span>
                                            <span class="<?= strtolower($time_in_ampm) == 'am' ? 'am-time' : 'pm-time' ?>">
                                                <?= $time_in_display ?>
                                            </span>
                                        </div>
                                    <?php else: ?>
                                        <span style="color:#adb5bd;"><i class="fas fa-minus"></i></span>
                                    <?php endif; ?>
                                </td>
                                <td data-label="Time Out" style="text-align: center;">
                                    <?php if (!empty($row['time_out']) && $row['time_out'] != '00:00:00'): ?>
                                        <div class="time-container">
                                            <span class="time-label"><?= $time_out_ampm ?></span>
                                            <span class="<?= strtolower($time_out_ampm) == 'am' ? 'am-time' : 'pm-time' ?>">
                                                <?= $time_out_display ?>
                                            </span>
                                        </div>
                                    <?php else: ?>
                                        <span style="color:#adb5bd;"><i class="fas fa-minus"></i></span>
                                    <?php endif; ?>
                                </td>
                                <td data-label="Remarks" style="text-align: center;">
                                    <?= !empty($row['remarks']) ? htmlspecialchars($row['remarks']) : '-' ?>
                                </td>
                                <td data-label="Actions" style="text-align: center;">
                                    <div class="action-buttons">
                                        <button type="button" class="btn-edit" 
                                                onclick="editAttendance(<?= $row['employee_id'] ?>, '<?= $selected_date ?>', '<?= htmlspecialchars($row['first_name'] . ' ' . $row['last_name']) ?>')">
                                            <i class="fas fa-edit"></i> Edit
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="8">
                                <div class="empty-state">
                                    <?php if (!empty($search)): ?>
                                        <i class="fas fa-search"></i>
                                        <p>No employees found matching <strong>'<?= htmlspecialchars($search) ?>'</strong> for <?= date('F j, Y', strtotime($selected_date)) ?>.</p>
                                        <p style="font-size: 0.9rem; margin-top: 10px;">Try a different search term or date.</p>
                                    <?php else: ?>
                                        <i class="fas fa-calendar-times"></i>
                                        <p>No attendance records found for <?= date('l, F j, Y', strtotime($selected_date)) ?>.</p>
                                        <p style="font-size: 0.9rem; margin-top: 10px;">Try selecting a different date or add new attendance records.</p>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <!-- Add/Edit Attendance Modal -->
    <div class="modal" id="addAttendanceModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title" id="modalTitle"><i class="fas fa-calendar-plus"></i> Add Attendance Record</h3>
                <button type="button" class="modal-close" onclick="closeAddAttendanceModal()">×</button>
            </div>
            <div class="modal-body">
                <div id="notificationArea"></div>
                
                <form id="addAttendanceForm" method="POST" action="add_attendance.php">
                    <input type="hidden" id="attendanceId" name="attendance_id" value="">
                    
                    <!-- EMPLOYEE SELECTION -->
                    <div class="form-group">
                        <label class="form-label required"><i class="fas fa-user"></i> Employee</label>
                        
                        <!-- Search Input - Hidden by default, shown only in Add mode -->
                        <div class="employee-search-container" id="employeeSearchContainer" style="display: none;">
                            <div class="search-input-wrapper">
                                <i class="fas fa-search search-icon"></i>
                                <input type="text" 
                                       id="employeeSearchInput" 
                                       class="form-control employee-search-input" 
                                       placeholder="Type to search employee by name or ID..."
                                       autocomplete="off">
                                <i class="fas fa-times clear-search" id="clearSearch" onclick="clearEmployeeSearch()" style="display: none;"></i>
                            </div>
                        </div>
                        
                        <!-- Hidden select for form submission -->
                        <select id="employeeSelect" name="employee_id" class="hidden-select" required>
                            <option value="">Select Employee</option>
                            <?php 
                            // Get all employees for the hidden select
                            $all_employees = $conn->query("SELECT id, first_name, middle_name, last_name FROM employees ORDER BY last_name, first_name");
                            if ($all_employees && $all_employees->num_rows > 0) {
                                while($emp = $all_employees->fetch_assoc()): 
                                    $emp['middle_name'] = $emp['middle_name'] ?? '';
                                    $full_name = htmlspecialchars($emp['first_name'] . ' ' . 
                                                (!empty($emp['middle_name']) ? $emp['middle_name'] . ' ' : '') . 
                                                $emp['last_name']);
                            ?>
                                <option value="<?= $emp['id'] ?>" data-name="<?= strtolower($full_name) ?>" data-id="<?= $emp['id'] ?>">
                                    <?= $full_name ?> (ID: <?= $emp['id'] ?>)
                                </option>
                            <?php 
                                endwhile;
                            }
                            ?>
                        </select>
                        
                        <!-- Search Results Dropdown -->
                        <div class="employee-results-dropdown" id="employeeResultsDropdown" style="display: none;">
                            <div class="results-header">
                                <span id="resultsCount">0 employees found</span>
                            </div>
                            <div class="results-list" id="employeeResultsList">
                                <!-- Results will be populated here -->
                            </div>
                            <div class="results-footer">
                                <span class="text-muted">Type at least 2 characters to search</span>
                            </div>
                        </div>
                        
                        <!-- SELECTED EMPLOYEE CARD - WITHOUT CHANGE BUTTON -->
                        <div class="selected-employee-card" id="selectedEmployeeCard" style="display: none;">
                            <div class="selected-employee-info">
                                <div class="selected-employee-avatar">
                                    <i class="fas fa-user-circle"></i>
                                </div>
                                <div class="selected-employee-details">
                                    <span class="selected-employee-name" id="selectedEmployeeName"></span>
                                    <span class="selected-employee-id" id="selectedEmployeeIdDisplay">ID: <span id="selectedEmployeeId">--</span></span>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Employee Name Display (for edit mode) -->
                        <div id="employeeNameDisplay" style="display: none;"></div>
                    </div>
                    
                    <!-- Date and ID Row -->
                    <div class="form-row">
                        <div class="form-col">
                            <label class="form-label"><i class="fas fa-calendar"></i> Date</label>
                            <div class="date-display" id="attendanceDateDisplay">
                                <?= date('m/d/Y', strtotime($selected_date)) ?>
                            </div>
                            <input type="hidden" id="attendanceDate" name="date" value="<?= $selected_date ?>">
                        </div>
                        
                        <div class="form-col">
                            <label class="form-label"><i class="fas fa-id-badge"></i> ID</label>
                            <div class="date-display" id="employeeIdDisplay2">--</div>
                        </div>
                    </div>
                    
                    <!-- Status Selection -->
                    <div class="form-group">
                        <label class="form-label required"><i class="fas fa-clipboard-check"></i> Status</label>
                        <div class="status-options">
                            <div class="status-option">
                                <input type="radio" id="statusPresent" name="status" value="Present" class="status-radio" checked>
                                <label for="statusPresent" class="status-label">
                                    <span class="status-dot present"></span>
                                    <span><i class="fas fa-check-circle"></i> Present</span>
                                </label>
                            </div>
                            
                            <div class="status-option">
                                <input type="radio" id="statusAbsent" name="status" value="Absent" class="status-radio">
                                <label for="statusAbsent" class="status-label">
                                    <span class="status-dot absent"></span>
                                    <span><i class="fas fa-times-circle"></i> Absent</span>
                                </label>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Time In -->
                    <div class="form-group">
                        <label class="form-label"><i class="fas fa-sign-in-alt"></i> Time In</label>
                        <div class="time-input-container">
                            <div class="time-display-wrapper">
                                <div class="time-display-box empty" id="timeInDisplay">
                                    <div class="time-display-content"><i class="far fa-clock"></i> --:-- --</div>
                                </div>
                                <input type="hidden" id="timeIn" name="time_in">
                            </div>
                            <button type="button" class="time-manual-btn" onclick="openTimeModal('time_in')">
                                <i class="fas fa-clock"></i> Set Time
                            </button>
                        </div>
                    </div>
                    
                    <!-- Time Out -->
                    <div class="form-group">
                        <label class="form-label"><i class="fas fa-sign-out-alt"></i> Time Out</label>
                        <div class="time-input-container">
                            <div class="time-display-wrapper">
                                <div class="time-display-box empty" id="timeOutDisplay">
                                    <div class="time-display-content"><i class="far fa-clock"></i> --:-- --</div>
                                </div>
                                <input type="hidden" id="timeOut" name="time_out">
                            </div>
                            <button type="button" class="time-manual-btn" onclick="openTimeModal('time_out')">
                                <i class="fas fa-clock"></i> Set Time
                            </button>
                        </div>
                    </div>
                    
                    <!-- Remarks -->
                    <div class="form-group">
                        <label class="form-label"><i class="fas fa-comment"></i> Remarks (Optional)</label>
                        <textarea name="remarks" id="remarks" class="form-control" rows="3" placeholder="Add any remarks or notes..."></textarea>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeAddAttendanceModal()">
                    <i class="fas fa-times"></i> Cancel
                </button>
                <button type="button" class="btn btn-success" onclick="submitAttendanceForm()">
                    <i class="fas fa-save"></i> Save Attendance
                </button>
            </div>
        </div>
    </div>
    
    <!-- Time Input Modal -->
    <div class="time-modal" id="timeModal">
        <div class="time-modal-content">
            <div class="time-modal-header">
                <h3 class="time-modal-title" id="timeModalTitle"><i class="fas fa-clock"></i> Set Time</h3>
                <button type="button" class="modal-close" onclick="closeTimeModal()">×</button>
            </div>
            <div class="time-modal-body">
                <div class="time-input-group">
                    <select id="timeHour" class="time-input-select"></select>
                    <span class="time-input-separator">:</span>
                    <select id="timeMinute" class="time-input-select"></select>
                    <select id="timePeriod" class="time-period-select"></select>
                </div>
            </div>
            <div class="time-modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeTimeModal()">
                    <i class="fas fa-times"></i> Cancel
                </button>
                <button type="button" class="btn btn-primary" onclick="saveTime()">
                    <i class="fas fa-check"></i> Set Time
                </button>
            </div>
        </div>
    </div>
</main>

<?php include("./includes/footer.php"); ?>

<!-- Load calendar.js -->
<script src="./assets/js/calendar.js"></script>

<script>
// ============================================
// GLOBAL VARIABLES
// ============================================
let currentTimeField = null;
let isEditMode = false;
let currentEmployeeId = null;
let employeeData = [];
let searchTimeout;

// ============================================
// SEARCHABLE EMPLOYEE DROPDOWN FUNCTIONS
// ============================================

// Initialize employee search
function initEmployeeSearch() {
    const select = document.getElementById('employeeSelect');
    if (!select) return;
    
    employeeData = [];
    const options = select.options;
    
    for (let i = 1; i < options.length; i++) {
        const option = options[i];
        employeeData.push({
            id: option.value,
            name: option.textContent.replace(/\(ID:.*\)/, '').trim(),
            fullText: option.textContent,
            searchText: option.getAttribute('data-name') || option.textContent.toLowerCase()
        });
    }
    console.log('Employee data loaded:', employeeData.length, 'employees');
}

// Search employees
function searchEmployees(query) {
    const resultsList = document.getElementById('employeeResultsList');
    const resultsCount = document.getElementById('resultsCount');
    const dropdown = document.getElementById('employeeResultsDropdown');
    const clearBtn = document.getElementById('clearSearch');
    
    if (!query || query.length < 2) {
        dropdown.style.display = 'none';
        if (clearBtn) clearBtn.style.display = 'none';
        return;
    }
    
    if (clearBtn) clearBtn.style.display = 'block';
    
    const searchLower = query.toLowerCase();
    const results = employeeData.filter(emp => 
        emp.searchText.includes(searchLower) || 
        emp.id.includes(searchLower)
    ).slice(0, 10);
    
    resultsCount.textContent = `${results.length} employee${results.length !== 1 ? 's' : ''} found`;
    
    if (results.length > 0) {
        let html = '';
        results.forEach(emp => {
            let displayName = emp.name;
            if (searchLower) {
                const regex = new RegExp(`(${searchLower})`, 'gi');
                displayName = emp.name.replace(regex, '<strong>$1</strong>');
            }
            
            html += `
                <div class="employee-result-item" onclick="selectEmployee('${emp.id}', '${emp.name.replace(/'/g, "\\'")}')">
                    <div class="employee-result-avatar">
                        <i class="fas fa-user"></i>
                    </div>
                    <div class="employee-result-info">
                        <div class="employee-result-name">${displayName}</div>
                        <div class="employee-result-details">
                            <span class="employee-result-id"><i class="fas fa-id-badge"></i> ID: ${emp.id}</span>
                        </div>
                    </div>
                </div>
            `;
        });
        resultsList.innerHTML = html;
        dropdown.style.display = 'block';
    } else {
        resultsList.innerHTML = `
            <div class="no-results">
                <i class="fas fa-user-slash"></i>
                <h4>No employees found</h4>
                <p>Try different search terms</p>
            </div>
        `;
        dropdown.style.display = 'block';
    }
}

// Select employee
function selectEmployee(id, name) {
    const select = document.getElementById('employeeSelect');
    if (select) {
        select.value = id;
    }
    
    // Update selected employee card
    const selectedCard = document.getElementById('selectedEmployeeCard');
    const selectedName = document.getElementById('selectedEmployeeName');
    const selectedId = document.getElementById('selectedEmployeeId');
    const searchContainer = document.getElementById('employeeSearchContainer');
    const dropdown = document.getElementById('employeeResultsDropdown');
    const clearBtn = document.getElementById('clearSearch');
    const employeeIdDisplay = document.getElementById('employeeIdDisplay2');
    
    if (selectedCard) {
        selectedCard.style.display = 'block';
        selectedName.textContent = name;
        selectedId.textContent = id;
    }
    
    // Hide search container
    if (searchContainer) {
        searchContainer.style.display = 'none';
    }
    
    // Hide dropdown and clear button
    if (dropdown) dropdown.style.display = 'none';
    if (clearBtn) clearBtn.style.display = 'none';
    
    // Update ID display
    if (employeeIdDisplay) {
        employeeIdDisplay.textContent = id;
    }
    
    // Trigger change event
    updateEmployeeId();
    
    // Check for existing attendance
    setTimeout(() => {
        checkExistingAttendance();
    }, 300);
}

// Clear employee selection
function clearEmployeeSelection() {
    const select = document.getElementById('employeeSelect');
    const selectedCard = document.getElementById('selectedEmployeeCard');
    const searchContainer = document.getElementById('employeeSearchContainer');
    const searchInput = document.getElementById('employeeSearchInput');
    const dropdown = document.getElementById('employeeResultsDropdown');
    const employeeIdDisplay = document.getElementById('employeeIdDisplay2');
    
    if (select) {
        select.value = '';
    }
    
    if (selectedCard) {
        selectedCard.style.display = 'none';
    }
    
    if (searchContainer) {
        searchContainer.style.display = 'block';
    }
    
    if (searchInput) {
        searchInput.style.display = 'block';
        searchInput.value = '';
        searchInput.focus();
    }
    
    if (dropdown) {
        dropdown.style.display = 'none';
    }
    
    if (employeeIdDisplay) {
        employeeIdDisplay.textContent = '--';
    }
    
    isEditMode = false;
    updateEmployeeId();
}

// Switch to Add mode
function switchToAddMode() {
    clearEmployeeSelection();
    
    const modalTitle = document.getElementById('modalTitle');
    if (modalTitle) {
        modalTitle.innerHTML = '<i class="fas fa-calendar-plus"></i> Add Attendance Record';
    }
    
    const date = document.getElementById('attendanceDate').value;
    resetAttendanceForm();
    document.getElementById('attendanceDate').value = date;
    
    const dateDisplay = document.getElementById('attendanceDateDisplay');
    if (dateDisplay) {
        dateDisplay.textContent = formatDateForDisplay(date);
    }
}

// Clear search
function clearEmployeeSearch() {
    const searchInput = document.getElementById('employeeSearchInput');
    const dropdown = document.getElementById('employeeResultsDropdown');
    const clearBtn = document.getElementById('clearSearch');
    
    if (searchInput) {
        searchInput.value = '';
        searchInput.focus();
    }
    
    if (dropdown) {
        dropdown.style.display = 'none';
    }
    
    if (clearBtn) {
        clearBtn.style.display = 'none';
    }
}

// ============================================
// MODAL FUNCTIONS
// ============================================

function openAddAttendanceModal() {
    console.log('Opening Add Attendance Modal');
    const modal = document.getElementById('addAttendanceModal');
    if (modal) {
        modal.style.display = 'flex';
        modal.classList.add('show');
        document.body.style.overflow = 'hidden';
        
        isEditMode = false;
        
        const modalTitle = document.getElementById('modalTitle');
        if (modalTitle) {
            modalTitle.innerHTML = '<i class="fas fa-calendar-plus"></i> Add Attendance Record';
        }
        
        resetAttendanceForm();
        
        const notificationArea = document.getElementById('notificationArea');
        if (notificationArea) {
            notificationArea.innerHTML = '';
        }
        
        const searchContainer = document.getElementById('employeeSearchContainer');
        if (searchContainer) {
            searchContainer.style.display = 'block';
        }
        
        setTimeout(() => {
            const searchInput = document.getElementById('employeeSearchInput');
            if (searchInput) {
                searchInput.style.display = 'block';
                searchInput.focus();
            }
        }, 300);
    }
}

function closeAddAttendanceModal() {
    console.log('Closing Add Attendance Modal');
    const modal = document.getElementById('addAttendanceModal');
    if (modal) {
        modal.style.display = 'none';
        modal.classList.remove('show');
        document.body.style.overflow = 'auto';
    }
}

function closeTimeModal() {
    const modal = document.getElementById('timeModal');
    if (modal) {
        modal.style.display = 'none';
        modal.classList.remove('show');
        currentTimeField = null;
    }
}

// ============================================
// EDIT ATTENDANCE FUNCTION
// ============================================

function editAttendance(employeeId, date, employeeName) {
    console.log('Edit button clicked - Employee:', employeeId, 'Name:', employeeName, 'Date:', date);
    
    // Reset form first
    resetAttendanceForm();
    
    // Set edit mode
    currentEmployeeId = employeeId;
    isEditMode = true;
    
    // Open modal
    const modal = document.getElementById('addAttendanceModal');
    if (modal) {
        modal.style.display = 'flex';
        modal.classList.add('show');
        document.body.style.overflow = 'hidden';
        
        // Update modal title
        const modalTitle = document.getElementById('modalTitle');
        if (modalTitle) {
            modalTitle.innerHTML = '<i class="fas fa-edit"></i> Edit Attendance Record';
        }
        
        // Set the date
        document.getElementById('attendanceDate').value = date;
        
        const dateDisplay = document.getElementById('attendanceDateDisplay');
        if (dateDisplay) {
            dateDisplay.textContent = formatDateForDisplay(date);
        }
        
        // Hide search container in edit mode
        const searchContainer = document.getElementById('employeeSearchContainer');
        if (searchContainer) {
            searchContainer.style.display = 'none';
        }
        
        // Set the hidden select value
        const select = document.getElementById('employeeSelect');
        if (select) {
            select.value = employeeId;
        }
        
        // Update selected employee display - WITHOUT CHANGE BUTTON
        const selectedCard = document.getElementById('selectedEmployeeCard');
        const selectedName = document.getElementById('selectedEmployeeName');
        const selectedId = document.getElementById('selectedEmployeeId');
        const employeeIdDisplay = document.getElementById('employeeIdDisplay2');
        
        if (selectedCard) {
            selectedCard.style.display = 'block';
            selectedName.textContent = employeeName;
            selectedId.textContent = employeeId;
        }
        
        // Update ID display
        if (employeeIdDisplay) {
            employeeIdDisplay.textContent = employeeId;
        }
        
        // Update employee select for backward compatibility
        updateEmployeeId();
        
        // Show loading notification
        showNotification('Loading attendance data...', 'info');
        
        // Fetch attendance data
        fetchAttendanceData(employeeId, date);
    }
}

// ============================================
// FETCH ATTENDANCE DATA
// ============================================

async function fetchAttendanceData(employeeId, date) {
    try {
        const response = await fetch(`get_attendance.php?employee_id=${employeeId}&date=${date}`);
        const data = await response.json();
        
        console.log('Fetched attendance data:', data);
        
        if (data.success) {
            clearNotification();
            
            // Set status
            if (data.status) {
                if (data.status === 'Absent') {
                    document.getElementById('statusAbsent').checked = true;
                } else {
                    document.getElementById('statusPresent').checked = true;
                }
            }
            
            // Set attendance ID
            if (data.id) {
                document.getElementById('attendanceId').value = data.id;
            }
            
            // Set time in
            if (data.time_in && data.time_in !== '00:00:00' && data.time_in !== null) {
                const timeInDisplay = formatTimeForDisplay(data.time_in);
                const timeInElement = document.getElementById('timeIn');
                const timeInDisplayElement = document.getElementById('timeInDisplay');
                
                if (timeInElement) timeInElement.value = data.time_in;
                if (timeInDisplayElement) {
                    timeInDisplayElement.innerHTML = `<div class="time-display-content"><i class="far fa-clock"></i> ${timeInDisplay}</div>`;
                    timeInDisplayElement.classList.remove('empty');
                }
                
                const timeInBtn = document.querySelector('button[onclick*="time_in"]');
                if (timeInBtn) {
                    timeInBtn.innerHTML = '<i class="fas fa-check"></i> Time In (Set)';
                    timeInBtn.style.background = '#28a745';
                }
            }
            
            // Set time out
            if (data.time_out && data.time_out !== '00:00:00' && data.time_out !== null) {
                const timeOutDisplay = formatTimeForDisplay(data.time_out);
                const timeOutElement = document.getElementById('timeOut');
                const timeOutDisplayElement = document.getElementById('timeOutDisplay');
                
                if (timeOutElement) timeOutElement.value = data.time_out;
                if (timeOutDisplayElement) {
                    timeOutDisplayElement.innerHTML = `<div class="time-display-content"><i class="far fa-clock"></i> ${timeOutDisplay}</div>`;
                    timeOutDisplayElement.classList.remove('empty');
                }
                
                const timeOutBtn = document.querySelectorAll('button[onclick*="time_out"]')[0];
                if (timeOutBtn) {
                    timeOutBtn.innerHTML = '<i class="fas fa-check"></i> Time Out (Set)';
                    timeOutBtn.style.background = '#28a745';
                }
            }
            
            // Set remarks
            if (data.remarks) {
                document.getElementById('remarks').value = data.remarks;
            }
            
            showNotification('✅ Attendance data loaded successfully', 'success');
        } else {
            showNotification('Error loading attendance data: ' + (data.message || 'Unknown error'), 'error');
        }
    } catch (error) {
        console.error('Error fetching attendance data:', error);
        showNotification('Error loading attendance data. Please try again.', 'error');
    }
}

// ============================================
// FORM FUNCTIONS
// ============================================

function updateEmployeeId() {
    const select = document.getElementById('employeeSelect');
    const display = document.getElementById('employeeIdDisplay2');
    if (select && display) {
        if (select.value) {
            display.textContent = select.value;
        } else {
            display.textContent = '--';
        }
    }
}

function resetAttendanceForm() {
    const form = document.getElementById('addAttendanceForm');
    if (form) form.reset();
    
    // Clear employee selection but keep search container hidden in edit mode
    if (!isEditMode) {
        clearEmployeeSelection();
    }
    
    const idDisplay = document.getElementById('employeeIdDisplay2');
    if (idDisplay) idDisplay.textContent = '--';
    
    // Reset time displays
    const timeInDisplay = document.getElementById('timeInDisplay');
    const timeOutDisplay = document.getElementById('timeOutDisplay');
    const timeIn = document.getElementById('timeIn');
    const timeOut = document.getElementById('timeOut');
    
    if (timeInDisplay) {
        timeInDisplay.innerHTML = '<div class="time-display-content"><i class="far fa-clock"></i> --:-- --</div>';
        timeInDisplay.classList.add('empty');
    }
    if (timeOutDisplay) {
        timeOutDisplay.innerHTML = '<div class="time-display-content"><i class="far fa-clock"></i> --:-- --</div>';
        timeOutDisplay.classList.add('empty');
    }
    if (timeIn) timeIn.value = '';
    if (timeOut) timeOut.value = '';
    
    // Reset buttons
    const timeInBtn = document.querySelector('button[onclick*="time_in"]');
    const timeOutBtn = document.querySelectorAll('button[onclick*="time_out"]')[0];
    
    if (timeInBtn) {
        timeInBtn.innerHTML = '<i class="fas fa-clock"></i> Set Time';
        timeInBtn.style.background = '';
        timeInBtn.disabled = false;
    }
    if (timeOutBtn) {
        timeOutBtn.innerHTML = '<i class="fas fa-clock"></i> Set Time';
        timeOutBtn.style.background = '';
        timeOutBtn.disabled = false;
    }
    
    const attendanceId = document.getElementById('attendanceId');
    if (attendanceId) attendanceId.value = '';
}

// ============================================
// CHECK EXISTING ATTENDANCE
// ============================================

async function checkExistingAttendance() {
    const employeeSelect = document.getElementById('employeeSelect');
    const dateInput = document.getElementById('attendanceDate');
    
    if (!employeeSelect || !employeeSelect.value || !dateInput || !dateInput.value) {
        return;
    }
    
    try {
        const employeeId = employeeSelect.value;
        const date = dateInput.value;
        
        const formData = new FormData();
        formData.append('employee_id', employeeId);
        formData.append('date', date);
        
        const response = await fetch('check_attendance.php', {
            method: 'POST',
            body: formData
        });
        
        const data = await response.json();
        
        if (data.exists) {
            showNotification('📝 Existing record found. You can edit it.', 'info');
        }
    } catch (error) {
        console.error('Error checking existing attendance:', error);
    }
}

// ============================================
// TIME MODAL FUNCTIONS
// ============================================

function openTimeModal(field) {
    currentTimeField = field;
    const modal = document.getElementById('timeModal');
    const title = document.getElementById('timeModalTitle');
    
    if (modal) {
        title.innerHTML = `<i class="fas fa-clock"></i> Set ${field === 'time_in' ? 'Time In' : 'Time Out'}`;
        modal.style.display = 'flex';
        modal.classList.add('show');
        populateTimeDropdowns();
    }
}

function populateTimeDropdowns() {
    const hourSelect = document.getElementById('timeHour');
    const minuteSelect = document.getElementById('timeMinute');
    const periodSelect = document.getElementById('timePeriod');
    
    if (!hourSelect || !minuteSelect || !periodSelect) return;
    
    hourSelect.innerHTML = '';
    minuteSelect.innerHTML = '';
    periodSelect.innerHTML = '';
    
    for (let i = 1; i <= 12; i++) {
        const option = document.createElement('option');
        option.value = i.toString().padStart(2, '0');
        option.textContent = i.toString().padStart(2, '0');
        hourSelect.appendChild(option);
    }
    
    for (let i = 0; i < 60; i += 5) {
        const option = document.createElement('option');
        option.value = i.toString().padStart(2, '0');
        option.textContent = i.toString().padStart(2, '0');
        minuteSelect.appendChild(option);
    }
    
    ['AM', 'PM'].forEach(period => {
        const option = document.createElement('option');
        option.value = period;
        option.textContent = period;
        periodSelect.appendChild(option);
    });
    
    setCurrentTime();
}

function setCurrentTime() {
    const hourSelect = document.getElementById('timeHour');
    const minuteSelect = document.getElementById('timeMinute');
    const periodSelect = document.getElementById('timePeriod');
    
    if (!hourSelect || !minuteSelect || !periodSelect) return;
    
    const now = new Date();
    let hours = now.getHours();
    const minutes = now.getMinutes();
    const period = hours >= 12 ? 'PM' : 'AM';
    
    hours = hours % 12 || 12;
    
    let roundedMinutes = Math.round(minutes / 5) * 5;
    if (roundedMinutes === 60) {
        roundedMinutes = 0;
        hours = (hours % 12) + 1;
        if (hours === 13) hours = 1;
    }
    
    hourSelect.value = hours.toString().padStart(2, '0');
    minuteSelect.value = roundedMinutes.toString().padStart(2, '0');
    periodSelect.value = period;
}

function saveTime() {
    if (!currentTimeField) return;
    
    const hour = document.getElementById('timeHour').value;
    const minute = document.getElementById('timeMinute').value;
    const period = document.getElementById('timePeriod').value;
    
    if (!hour || !minute || !period) {
        alert('Please select a valid time');
        return;
    }
    
    const displayHour = parseInt(hour);
    const timeDisplay = `${displayHour}:${minute} ${period}`;
    const time24 = convertTo24Hour(hour, minute, period);
    
    if (currentTimeField === 'time_in') {
        const display = document.getElementById('timeInDisplay');
        const input = document.getElementById('timeIn');
        const btn = document.querySelector('button[onclick*="time_in"]');
        
        if (display) {
            display.innerHTML = `<div class="time-display-content"><i class="far fa-clock"></i> ${timeDisplay}</div>`;
            display.classList.remove('empty');
        }
        if (input) input.value = time24;
        if (btn) {
            btn.innerHTML = '<i class="fas fa-check"></i> Time In (Set)';
            btn.style.background = '#28a745';
        }
        
        showTimeAnimation('timeInDisplay');
    } else {
        const display = document.getElementById('timeOutDisplay');
        const input = document.getElementById('timeOut');
        const btn = document.querySelectorAll('button[onclick*="time_out"]')[0];
        
        if (display) {
            display.innerHTML = `<div class="time-display-content"><i class="far fa-clock"></i> ${timeDisplay}</div>`;
            display.classList.remove('empty');
        }
        if (input) input.value = time24;
        if (btn) {
            btn.innerHTML = '<i class="fas fa-check"></i> Time Out (Set)';
            btn.style.background = '#28a745';
        }
        
        showTimeAnimation('timeOutDisplay');
    }
    
    closeTimeModal();
}

function convertTo24Hour(hour, minute, period) {
    let hour24 = parseInt(hour);
    const minuteVal = parseInt(minute);
    
    if (period === 'PM' && hour24 !== 12) {
        hour24 += 12;
    }
    if (period === 'AM' && hour24 === 12) {
        hour24 = 0;
    }
    
    return `${hour24.toString().padStart(2, '0')}:${minuteVal.toString().padStart(2, '0')}:00`;
}

function showTimeAnimation(elementId) {
    const element = document.getElementById(elementId);
    if (!element) return;
    
    const confirmation = document.createElement('div');
    confirmation.className = 'time-set-confirmation';
    confirmation.textContent = '✓ Time Set';
    
    const existing = element.querySelector('.time-set-confirmation');
    if (existing) existing.remove();
    
    element.appendChild(confirmation);
    
    setTimeout(() => {
        if (confirmation.parentNode === element) {
            element.removeChild(confirmation);
        }
    }, 3000);
}

// ============================================
// FORM SUBMISSION
// ============================================

function submitAttendanceForm() {
    const form = document.getElementById('addAttendanceForm');
    const employeeSelect = document.getElementById('employeeSelect');
    const statusPresent = document.getElementById('statusPresent');
    const statusAbsent = document.getElementById('statusAbsent');
    const timeIn = document.getElementById('timeIn').value;
    const timeOut = document.getElementById('timeOut').value;
    
    if (!employeeSelect.value) {
        alert('Please select an employee');
        if (isEditMode) {
            alert('Employee cannot be changed in edit mode. Please delete and create a new record if needed.');
        } else {
            document.getElementById('employeeSearchInput').focus();
        }
        return false;
    }
    
    if (!statusPresent.checked && !statusAbsent.checked) {
        alert('Please select attendance status');
        return false;
    }
    
    if (timeOut && !timeIn) {
        if (!confirm('Time Out is set but Time In is not set. Are you sure you want to continue?')) {
            return false;
        }
    }
    
    if (timeIn && timeOut) {
        const timeInParts = timeIn.split(':');
        const timeOutParts = timeOut.split(':');
        
        const timeInDate = new Date(2000, 0, 1, parseInt(timeInParts[0]), parseInt(timeInParts[1]), 0);
        const timeOutDate = new Date(2000, 0, 1, parseInt(timeOutParts[0]), parseInt(timeOutParts[1]), 0);
        
        if (timeOutDate < timeInDate) {
            alert('Time Out cannot be before Time In');
            return false;
        }
    }
    
    form.submit();
    return true;
}

// ============================================
// UTILITY FUNCTIONS
// ============================================

function formatDateForDisplay(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
        month: '2-digit',
        day: '2-digit',
        year: 'numeric'
    });
}

function formatTimeForDisplay(timeString) {
    if (!timeString || timeString === '00:00:00' || timeString === null) return '--:-- --';
    
    const [hours, minutes] = timeString.split(':');
    const hour = parseInt(hours);
    const period = hour >= 12 ? 'PM' : 'AM';
    const hour12 = hour % 12 || 12;
    
    return `${hour12.toString().padStart(2, '0')}:${minutes} ${period}`;
}

function showNotification(message, type = 'info') {
    const notificationArea = document.getElementById('notificationArea');
    if (!notificationArea) return;
    
    const notification = document.createElement('div');
    notification.className = `attendance-notification ${type}`;
    
    let icon = '';
    if (type === 'success') icon = '✅ ';
    else if (type === 'error') icon = '❌ ';
    else if (type === 'info') icon = 'ℹ️ ';
    else if (type === 'warning') icon = '⚠️ ';
    
    notification.textContent = icon + message;
    
    notificationArea.innerHTML = '';
    notificationArea.appendChild(notification);
    
    setTimeout(() => {
        if (notification.parentNode) {
            notification.remove();
        }
    }, 5000);
}

function clearNotification() {
    const notificationArea = document.getElementById('notificationArea');
    if (notificationArea) {
        notificationArea.innerHTML = '';
    }
}

// ============================================
// CALENDAR FUNCTIONS
// ============================================

function toggleCalendar() {
    if (typeof window.toggleCalendar === 'function') {
        window.toggleCalendar();
    }
}

function selectDate(date) {
    if (typeof window.selectDate === 'function') {
        window.selectDate(date);
    }
}

function navigateMonth(direction) {
    if (typeof window.navigateMonth === 'function') {
        window.navigateMonth(direction);
    }
}

// ============================================
// EVENT LISTENERS
// ============================================

document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM loaded - attendance.php inline script initialized');
    
    initEmployeeSearch();
    
    const searchInput = document.getElementById('employeeSearchInput');
    if (searchInput) {
        searchInput.addEventListener('input', function(e) {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(() => {
                searchEmployees(e.target.value);
            }, 300);
        });
        
        searchInput.addEventListener('focus', function(e) {
            if (this.value.length >= 2) {
                searchEmployees(this.value);
            }
        });
        
        document.addEventListener('click', function(e) {
            const container = document.querySelector('.employee-search-container');
            const dropdown = document.getElementById('employeeResultsDropdown');
            
            if (container && dropdown && !container.contains(e.target)) {
                dropdown.style.display = 'none';
            }
        });
        
        searchInput.addEventListener('keydown', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                if (this.value.length >= 2) {
                    searchEmployees(this.value);
                }
            }
        });
    }
    
    window.addEventListener('click', function(event) {
        const addModal = document.getElementById('addAttendanceModal');
        const timeModal = document.getElementById('timeModal');
        const calendar = document.getElementById('calendarWrapper');
        
        if (event.target === addModal) {
            closeAddAttendanceModal();
        }
        
        if (event.target === timeModal) {
            closeTimeModal();
        }
        
        if (calendar && calendar.classList.contains('show') && 
            !calendar.contains(event.target) && 
            event.target !== document.getElementById('dateInput')) {
            calendar.classList.remove('show');
        }
    });
    
    document.addEventListener('keydown', function(event) {
        if (event.key === 'Escape') {
            const addModal = document.getElementById('addAttendanceModal');
            const timeModal = document.getElementById('timeModal');
            const calendar = document.getElementById('calendarWrapper');
            
            if (addModal && addModal.style.display === 'flex') {
                closeAddAttendanceModal();
            }
            
            if (timeModal && timeModal.style.display === 'flex') {
                closeTimeModal();
            }
            
            if (calendar && calendar.classList.contains('show')) {
                calendar.classList.remove('show');
            }
        }
    });
    
    setTimeout(() => {
        const alerts = document.querySelectorAll('.alert');
        alerts.forEach(alert => {
            alert.style.transition = 'opacity 0.5s';
            alert.style.opacity = '0';
            setTimeout(() => {
                if (alert.parentNode) {
                    alert.parentNode.removeChild(alert);
                }
            }, 500);
        });
    }, 5000);
});

// Make functions globally accessible
window.openAddAttendanceModal = openAddAttendanceModal;
window.closeAddAttendanceModal = closeAddAttendanceModal;
window.editAttendance = editAttendance;
window.updateEmployeeId = updateEmployeeId;
window.openTimeModal = openTimeModal;
window.closeTimeModal = closeTimeModal;
window.saveTime = saveTime;
window.submitAttendanceForm = submitAttendanceForm;
window.formatDateForDisplay = formatDateForDisplay;
window.formatTimeForDisplay = formatTimeForDisplay;
window.showNotification = showNotification;
window.selectEmployee = selectEmployee;
window.clearEmployeeSelection = clearEmployeeSelection;
window.clearEmployeeSearch = clearEmployeeSearch;
window.switchToAddMode = switchToAddMode;
</script>

<?php
// Close statements
if (isset($stmt)) {
    $stmt->close();
}
if (isset($employee_result)) {
    $employee_result->close();
}
$conn->close();
?>
</body>
</html>