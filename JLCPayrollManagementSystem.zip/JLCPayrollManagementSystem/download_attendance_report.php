<?php
session_start();

if (!isset($_SESSION['Admin_User'])) {
    header("Location: login.php");
    exit;
}

include_once("connection.php");

// Get parameters
$date_from = isset($_GET['date_from']) ? $_GET['date_from'] : '';
$date_to = isset($_GET['date_to']) ? $_GET['date_to'] : '';
$employee_id = isset($_GET['employee_id']) ? intval($_GET['employee_id']) : 0;

if (empty($date_from) || empty($date_to)) {
    header("Location: attendance.php?error=missing_dates");
    exit;
}

// Build query
$sql = "SELECT 
            e.id AS employee_id,
            e.first_name,
            e.middle_name,
            e.last_name,
            e.position,
            a.id as attendance_id,
            a.date,
            a.status,
            a.pm_status,
            a.night_status,
            a.time_in_am,
            a.time_out_am,
            a.time_in_pm,
            a.time_out_pm,
            a.time_in_night,
            a.time_out_night,
            a.remarks,
            a.leave_type,
            a.workday_type
        FROM employees e
        LEFT JOIN attendance a ON a.employee_id = e.id 
        WHERE a.date BETWEEN ? AND ?";

$params = [$date_from, $date_to];
$param_types = "ss";

if ($employee_id > 0) {
    $sql .= " AND e.id = ?";
    $params[] = $employee_id;
    $param_types .= "i";
}

$sql .= " ORDER BY e.last_name ASC, a.date ASC";

$stmt = $conn->prepare($sql);
if ($stmt === false) {
    die("Database error");
}

$stmt->bind_param($param_types, ...$params);
$stmt->execute();
$result = $stmt->get_result();

// Get employee name if filtered
$employee_name = "All Employees";
if ($employee_id > 0) {
    $name_query = "SELECT CONCAT(first_name, ' ', last_name) as full_name FROM employees WHERE id = ?";
    $name_stmt = $conn->prepare($name_query);
    $name_stmt->bind_param("i", $employee_id);
    $name_stmt->execute();
    $name_result = $name_stmt->get_result();
    if ($name_row = $name_result->fetch_assoc()) {
        $employee_name = $name_row['full_name'];
    }
    $name_stmt->close();
}

// Calculate totals
$total_hours = 0;
$present_count = 0;
$absent_count = 0;
$leave_count = 0;
$rows = [];

while ($row = $result->fetch_assoc()) {
    $rows[] = $row;
    
    // Count status
    if ($row['status'] == 'Present') $present_count++;
    elseif ($row['status'] == 'On Leave') $leave_count++;
    else $absent_count++;
    
    // Calculate hours
    $total = calculateTotalHoursForDownload(
        $row['time_in_am'], $row['time_out_am'],
        $row['time_in_pm'], $row['time_out_pm'],
        $row['time_in_night'], $row['time_out_night']
    );
    $total_hours += floatval($total);
}

// Set headers for Excel download
header('Content-Type: application/vnd.ms-excel');
header('Content-Disposition: attachment; filename="Attendance_Report_' . $date_from . 'to' . $date_to . '.xls"');
header('Cache-Control: max-age=0');

// Generate Excel file
echo '<html>';
echo '<head>';
echo '<meta charset="UTF-8">';
echo '<title>Attendance Report - ' . $date_from . ' to ' . $date_to . '</title>';
echo '<style>
    @page { size: landscape; margin: 0.5in; }
    table { border-collapse: collapse; width: 100%; font-family: Arial, sans-serif; font-size: 10px; }
    td, th { padding: 3px 4px; border: 1px solid #000000; white-space: nowrap; }
    th { background-color: #2E7D32; color: white; font-weight: bold; text-align: center; }
    .present { color: #2E7D32; font-weight: bold; }
    .absent { color: #dc2626; font-weight: bold; }
    .leave { color: #856404; font-weight: bold; }
    .total-row { font-weight: bold; background-color: #f0f7f0; }
    .header-text { font-weight: bold; font-size: 16px; text-align: center; background-color: #2E7D32; color: white; }
    .subheader-text { text-align: center; font-size: 11px; background-color: #f5f5f5; }
    .info-row { background-color: #f5f5f5; font-size: 9px; }
</style>';
echo '</head>';
echo '<body>';

echo '<table>';

// Header
echo '<tr>';
echo '<td colspan="14" class="header-text">ATTENDANCE REPORT - ' . date('F d, Y', strtotime($date_from)) . ' to ' . date('F d, Y', strtotime($date_to)) . '</td>';
echo '</tr>';

echo '<tr>';
echo '<td colspan="14" class="subheader-text">Payroll Management System • Official Document</td>';
echo '</tr>';

// Info row
echo '<tr class="info-row">';
echo '<td colspan="14">';
echo 'Period: ' . date('M d, Y', strtotime($date_from)) . ' - ' . date('M d, Y', strtotime($date_to)) . ' | ';
echo 'Employee: ' . htmlspecialchars($employee_name) . ' | ';
echo 'Generated: ' . date('m/d/Y h:i A') . ' | ';
echo 'Total Records: ' . count($rows) . ' | ';
echo 'Total Hours: ' . number_format($total_hours, 2);
echo '</td>';
echo '</tr>';

echo '<tr><td colspan="14">&nbsp;</td></tr>';

// Summary row
echo '<tr>';
echo '<th colspan="2">Summary</th>';
echo '<th>Present</th>';
echo '<th>Absent</th>';
echo '<th>Leave</th>';
echo '<th>Total Hrs</th>';
echo '<th colspan="8"></th>';
echo '</tr>';

echo '<tr>';
echo '<td colspan="2"></td>';
echo '<td class="present">' . $present_count . '</td>';
echo '<td class="absent">' . $absent_count . '</td>';
echo '<td class="leave">' . $leave_count . '</td>';
echo '<td>' . number_format($total_hours, 2) . '</td>';
echo '<td colspan="8"></td>';
echo '</tr>';

echo '<tr><td colspan="14">&nbsp;</td></tr>';

// Main table headers
echo '<tr>';
echo '<th>ID</th>';
echo '<th>Employee</th>';
echo '<th>Date</th>';
echo '<th>AM Status</th>';
echo '<th>AM In</th>';
echo '<th>AM Out</th>';
echo '<th>PM Status</th>';
echo '<th>PM/Night In</th>';
echo '<th>PM/Night Out</th>';
echo '<th>Night Status</th>';
echo '<th>Leave</th>';
echo '<th>Workday Type</th>';
echo '<th>Total Hrs</th>';
echo '<th>Remarks</th>';
echo '</tr>';

// Data rows
if (!empty($rows)) {
    foreach ($rows as $row) {
        $full_name = trim($row['first_name'] . ' ' . ($row['middle_name'] ?? '') . ' ' . $row['last_name']);
        
        // Format status classes
        $am_status_class = '';
        $am_status_text = $row['status'] ?? 'No Record';
        if ($row['status'] == 'Present') $am_status_class = 'present';
        elseif ($row['status'] == 'Absent') $am_status_class = 'absent';
        elseif ($row['status'] == 'On Leave') $am_status_class = 'leave';
        
        $pm_status_class = '';
        $pm_status_text = $row['pm_status'] ?? 'No Record';
        if ($row['pm_status'] == 'Present') $pm_status_class = 'present';
        elseif ($row['pm_status'] == 'Absent') $pm_status_class = 'absent';
        elseif ($row['pm_status'] == 'On Leave') $pm_status_class = 'leave';
        
        $night_status_class = '';
        $night_status_text = $row['night_status'] ?? 'No Record';
        if ($row['night_status'] == 'Present') $night_status_class = 'present';
        elseif ($row['night_status'] == 'Absent') $night_status_class = 'absent';
        elseif ($row['night_status'] == 'On Leave') $night_status_class = 'leave';
        
        // Format times
        $time_in_am = formatTimeForDownload($row['time_in_am']);
        $time_out_am = formatTimeForDownload($row['time_out_am']);
        $time_in_pm = formatTimeForDownload($row['time_in_pm']);
        $time_out_pm = formatTimeForDownload($row['time_out_pm']);
        $time_in_night = formatTimeForDownload($row['time_in_night']);
        $time_out_night = formatTimeForDownload($row['time_out_night']);
        
        $total = calculateTotalHoursForDownload(
            $row['time_in_am'], $row['time_out_am'],
            $row['time_in_pm'], $row['time_out_pm'],
            $row['time_in_night'], $row['time_out_night']
        );
        
        echo '<tr>';
        echo '<td>' . $row['employee_id'] . '</td>';
        echo '<td>' . htmlspecialchars($full_name) . '</td>';
        echo '<td>' . date('M d, Y', strtotime($row['date'])) . '</td>';
        echo '<td class="' . $am_status_class . '">' . htmlspecialchars($am_status_text) . '</td>';
        echo '<td>' . $time_in_am . '</td>';
        echo '<td>' . $time_out_am . '</td>';
        echo '<td class="' . $pm_status_class . '">' . htmlspecialchars($pm_status_text) . '</td>';
        echo '<td>';
        if ($time_in_pm != '-') echo 'PM: ' . $time_in_pm . '<br>';
        if ($time_in_night != '-') echo 'Night: ' . $time_in_night;
        if ($time_in_pm == '-' && $time_in_night == '-') echo '-';
        echo '</td>';
        echo '<td>';
        if ($time_out_pm != '-') echo 'PM: ' . $time_out_pm . '<br>';
        if ($time_out_night != '-') echo 'Night: ' . $time_out_night;
        if ($time_out_pm == '-' && $time_out_night == '-') echo '-';
        echo '</td>';
        echo '<td class="' . $night_status_class . '">' . htmlspecialchars($night_status_text) . '</td>';
        echo '<td>' . htmlspecialchars($row['leave_type'] ?? '-') . '</td>';
        echo '<td>' . htmlspecialchars($row['workday_type'] ?? '-') . '</td>';
        echo '<td><strong>' . $total . '</strong></td>';
        echo '<td>' . htmlspecialchars($row['remarks'] ?? '-') . '</td>';
        echo '</tr>';
    }
    
    // Total row
    echo '<tr class="total-row">';
    echo '<td colspan="12" style="text-align: right;"><strong>TOTAL HOURS:</strong></td>';
    echo '<td><strong>' . number_format($total_hours, 2) . '</strong></td>';
    echo '<td></td>';
    echo '</tr>';
    
} else {
    echo '<tr><td colspan="14" style="text-align: center; padding: 20px;">No attendance records found for the selected period</td></tr>';
}

echo '</table>';
echo '</body>';
echo '</html>';

$stmt->close();
$conn->close();

// Helper functions
function formatTimeForDownload($time) {
    if (empty($time) || $time == '00:00:00') {
        return '-';
    }
    return date('h:i A', strtotime($time));
}

function calculateTotalHoursForDownload($time_in_am, $time_out_am, $time_in_pm, $time_out_pm, $time_in_night, $time_out_night) {
    $total = 0;
    
    if (!empty($time_in_am) && !empty($time_out_am) && $time_in_am != '00:00:00' && $time_out_am != '00:00:00') {
        $am_hours = calculateHoursForDownload($time_in_am, $time_out_am);
        $total += floatval($am_hours);
    }
    
    if (!empty($time_in_pm) && !empty($time_out_pm) && $time_in_pm != '00:00:00' && $time_out_pm != '00:00:00') {
        $pm_hours = calculateHoursForDownload($time_in_pm, $time_out_pm);
        $total += floatval($pm_hours);
    }
    
    if (!empty($time_in_night) && !empty($time_out_night) && $time_in_night != '00:00:00' && $time_out_night != '00:00:00') {
        $night_hours = calculateHoursForDownload($time_in_night, $time_out_night);
        $total += floatval($night_hours);
    }
    
    return number_format($total, 2);
}

function calculateHoursForDownload($time_in, $time_out) {
    $time_in_ts = strtotime($time_in);
    $time_out_ts = strtotime($time_out);
    
    if ($time_out_ts < $time_in_ts) {
        $time_out_ts += 86400;
    }
    
    $hours = round(($time_out_ts - $time_in_ts) / 3600, 2);
    return $hours;
}
?>