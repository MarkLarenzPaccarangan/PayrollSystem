<?php 
session_start();

if (!isset($_SESSION['Admin_User'])) {
    header("Location: login.php"); 
    exit;
}

include 'connection.php';

// Function to get employee count for dashboard (add this after connection)
function getSiteEmployeeCount($conn, $site_id) {
    $query = "SELECT COUNT(*) as count FROM site_employee WHERE site_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $site_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $data = $result->fetch_assoc();
    return $data ? $data['count'] : 0;
}

// Save site to database
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Add new site
    if (isset($_POST['save_site'])) {
        $site_name = $_POST['site_name'];
        $manager = $_POST['site_manager'];
        $address = $_POST['site_address'];

        $query = "INSERT INTO site_monitoring (site_name, site_manager, site_address) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("sss", $site_name, $manager, $address);

        if ($stmt->execute()) {
            echo "<script>alert('Site added successfully!'); window.location.href='site_monitoring.php';</script>";
        } else {
            echo "<script>alert('Error adding site: " . $conn->error . "');</script>";
        }
    }
    
    // Update site information
    if (isset($_POST['update_site'])) {
        $site_id = $_POST['site_id'];
        $site_name = $_POST['edit_site_name'];
        $manager = $_POST['edit_site_manager'];
        $address = $_POST['edit_site_address'];
        
        // Update site details
        $query = "UPDATE site_monitoring SET site_name = ?, site_manager = ?, site_address = ? WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("sssi", $site_name, $manager, $address, $site_id);
        
        if ($stmt->execute()) {
            // Remove selected employees if any
            if (isset($_POST['remove_employees']) && !empty($_POST['remove_employees'])) {
                foreach ($_POST['remove_employees'] as $employee_id) {
                    $delete_query = "DELETE FROM site_employee WHERE site_id = ? AND employee_id = ?";
                    $delete_stmt = $conn->prepare($delete_query);
                    $delete_stmt->bind_param("ii", $site_id, $employee_id);
                    $delete_stmt->execute();
                }
            }
            echo "<script>alert('Site updated successfully!'); window.location.href='site_monitoring.php';</script>";
        } else {
            echo "<script>alert('Error updating site: " . $conn->error . "');</script>";
        }
    }
    
    // Add employees to site (Modified: 1 employee = 1 site)
    if (isset($_POST['add_employees_to_site'])) {
        $site_id = $_POST['add_site_id'];
        
        if (isset($_POST['selected_employees']) && !empty($_POST['selected_employees'])) {
            $success_count = 0;
            $error_count = 0;
            $already_assigned = [];
            
            foreach ($_POST['selected_employees'] as $employee_id) {
                // Check if employee is already assigned to ANY site
                $check_any_site_query = "SELECT se.*, s.site_name 
                                        FROM site_employee se 
                                        LEFT JOIN site_monitoring s ON se.site_id = s.id 
                                        WHERE se.employee_id = ?";
                $check_any_site_stmt = $conn->prepare($check_any_site_query);
                $check_any_site_stmt->bind_param("i", $employee_id);
                $check_any_site_stmt->execute();
                $check_any_site_result = $check_any_site_stmt->get_result();
                
                if ($check_any_site_result->num_rows > 0) {
                    // Employee is already assigned to a site
                    $assigned_data = $check_any_site_result->fetch_assoc();
                    $already_assigned[] = [
                        'employee_id' => $employee_id,
                        'site_name' => $assigned_data['site_name'] ?? 'another site'
                    ];
                } else {
                    // Employee is not assigned to any site, proceed with assignment
                    // Check if assigned_date column exists
                    $table_check = $conn->query("SHOW COLUMNS FROM site_employee LIKE 'assigned_date'");
                    
                    if ($table_check->num_rows > 0) {
                        $insert_query = "INSERT INTO site_employee (site_id, employee_id, assigned_date) VALUES (?, ?, NOW())";
                    } else {
                        $insert_query = "INSERT INTO site_employee (site_id, employee_id) VALUES (?, ?)";
                    }
                    
                    $insert_stmt = $conn->prepare($insert_query);
                    $insert_stmt->bind_param("ii", $site_id, $employee_id);
                    
                    if ($insert_stmt->execute()) {
                        $success_count++;
                    } else {
                        $error_count++;
                    }
                }
            }
            
            // Build response message
            if ($success_count > 0) {
                $message = "Successfully added " . $success_count . " employee(s) to site!";
                if (!empty($already_assigned)) {
                    $assigned_names = [];
                    foreach ($already_assigned as $assigned) {
                        // Get employee name
                        $name_query = "SELECT CONCAT(first_name, ' ', last_name) as name FROM employees WHERE id = ?";
                        $name_stmt = $conn->prepare($name_query);
                        $name_stmt->bind_param("i", $assigned['employee_id']);
                        $name_stmt->execute();
                        $name_result = $name_stmt->get_result();
                        $name_data = $name_result->fetch_assoc();
                        $assigned_names[] = $name_data['name'] . " (already assigned to " . $assigned['site_name'] . ")";
                    }
                    $message .= "\n\nCannot assign: " . implode("\n", $assigned_names);
                }
                echo "<script>alert('" . addslashes($message) . "'); window.location.href='site_monitoring.php';</script>";
            } else {
                if (!empty($already_assigned)) {
                    $assigned_names = [];
                    foreach ($already_assigned as $assigned) {
                        $name_query = "SELECT CONCAT(first_name, ' ', last_name) as name FROM employees WHERE id = ?";
                        $name_stmt = $conn->prepare($name_query);
                        $name_stmt->bind_param("i", $assigned['employee_id']);
                        $name_stmt->execute();
                        $name_result = $name_stmt->get_result();
                        $name_data = $name_result->fetch_assoc();
                        $assigned_names[] = $name_data['name'] . " (already assigned to " . $assigned['site_name'] . ")";
                    }
                    $message = "No employees were added.\n\n" . implode("\n", $assigned_names);
                    echo "<script>alert('" . addslashes($message) . "'); window.location.href='site_monitoring.php';</script>";
                } else {
                    echo "<script>alert('No employees were added. Please try again.'); window.location.href='site_monitoring.php';</script>";
                }
            }
        } else {
            echo "<script>alert('Please select at least one employee to add.');</script>";
        }
    }
}

// Delete site
if (isset($_GET['delete'])) {
    $site_id = (int)$_GET['delete'];

    $delete_site_employee = "DELETE FROM site_employee WHERE site_id = ?";
    $stmt1 = $conn->prepare($delete_site_employee);
    $stmt1->bind_param("i", $site_id);

    if ($stmt1->execute()) {
        $delete_site = "DELETE FROM site_monitoring WHERE id = ?";
        $stmt2 = $conn->prepare($delete_site);
        $stmt2->bind_param("i", $site_id);

        if ($stmt2->execute()) {
            echo "<script>alert('Site deleted successfully!'); window.location.href='site_monitoring.php';</script>";
        } else {
            echo "<script>alert('Error deleting site: " . $conn->error . "');</script>";
        }
    } else {
        echo "<script>alert('Error deleting associated records: " . $conn->error . "');</script>";
    }
}

// Function to get site employees for view modal
function getSiteEmployees($conn, $site_id) {
    $employees = [];
    
    // First, check what columns exist in the employees table
    $columns = ['id', 'first_name', 'last_name', 'position'];
    
    // Check if email column exists
    $email_check = $conn->query("SHOW COLUMNS FROM employees LIKE 'email'");
    if ($email_check->num_rows > 0) {
        $columns[] = 'email';
    }
    
    // Build query with only existing columns
    $columns_str = implode(', ', $columns);
    $query = "SELECT $columns_str 
              FROM employees e 
              INNER JOIN site_employee se ON e.id = se.employee_id 
              WHERE se.site_id = ?
              ORDER BY e.first_name, e.last_name";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $site_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while ($row = $result->fetch_assoc()) {
        $employees[] = $row;
    }
    
    return $employees;
}

// Function to get available employees for modal (Modified: Only employees NOT assigned to ANY site)
function getAvailableEmployees($conn, $site_id) {
    $available_employees = [];
    
    $query = "SELECT e.id, e.first_name, e.last_name, e.position 
              FROM employees e 
              WHERE e.id NOT IN (
                  SELECT employee_id 
                  FROM site_employee 
                  WHERE employee_id IS NOT NULL
              )
              AND e.status = 'active'
              ORDER BY e.first_name, e.last_name";
    
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while ($row = $result->fetch_assoc()) {
        $available_employees[] = $row;
    }
    
    return $available_employees;
}

// Get site details for editing
$site_details = null;
$site_employees = [];
if (isset($_GET['edit'])) {
    $site_id = (int)$_GET['edit'];
    
    // Get site details
    $query = "SELECT * FROM site_monitoring WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $site_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $site_details = $result->fetch_assoc();
    
    // Get employees assigned to this site
    $site_employees = getSiteEmployees($conn, $site_id);
    
    // Get available employees for add employee modal (only unassigned employees)
    $available_employees = getAvailableEmployees($conn, $site_id);
}

// Search functionality for sites
$search_query = '';
if (isset($_GET['search']) && !empty($_GET['search'])) {
    $search_query = $_GET['search'];
    $query = "SELECT id, site_name, site_manager, site_address FROM site_monitoring 
              WHERE site_name LIKE ? OR site_manager LIKE ? OR site_address LIKE ?";
    $stmt = $conn->prepare($query);
    $search_term = '%' . $search_query . '%';
    $stmt->bind_param("sss", $search_term, $search_term, $search_term);
} else {
    $query = "SELECT id, site_name, site_manager, site_address FROM site_monitoring";
    $stmt = $conn->prepare($query);
}
$stmt->execute();
$result = $stmt->get_result();

// Get all sites for add employee modal
$all_sites = [];
$sites_query = "SELECT id, site_name FROM site_monitoring ORDER BY site_name";
$sites_result = $conn->query($sites_query);
while ($row = $sites_result->fetch_assoc()) {
    $all_sites[] = $row;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Site Monitoring</title>
    <link rel="stylesheet" href="./assets/css/site_monitoring2.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .content-wrapper {
            min-height: calc(100vh - 100px);
        }
        
        .table-responsive {
            overflow-x: auto;
        }
        
        .modal-open {
            overflow: hidden;
        }
        
        .selected-count {
            background-color: var(--info-color);
            color: white;
            padding: 2px 8px;
            border-radius: 10px;
            font-size: 0.8rem;
            margin-left: 10px;
        }
        
        .select-all-btn {
            background-color: var(--accent-green);
            color: white;
            border: none;
            padding: 6px 12px;
            border-radius: var(--border-radius);
            font-size: 0.85rem;
            cursor: pointer;
            margin-bottom: 10px;
            display: inline-flex;
            align-items: center;
            gap: 5px;
        }
        
        .select-all-btn:hover {
            background-color: var(--sidebar-dark-green);
        }
        
        .view-modal-header {
            display: flex;
            flex-direction: column;
            gap: 5px;
            margin-top: 5px;
        }
        
        .view-modal-header p {
            margin: 0;
            font-size: 0.9rem;
            color: rgba(255, 255, 255, 0.9);
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .view-modal-header p i {
            width: 16px;
        }
        
        .employee-search-container {
            position: relative;
            margin-bottom: 15px;
        }
        
        .employee-search-input {
            width: 100%;
            padding: 8px 35px 8px 12px;
            border: 2px solid #e0e0e0;
            border-radius: var(--border-radius);
            font-size: 0.9rem;
            transition: var(--transition);
        }
        
        .employee-search-input:focus {
            outline: none;
            border-color: var(--accent-green);
            box-shadow: 0 0 0 3px rgba(41, 148, 82, 0.1);
        }
        
        .employee-search-btn {
            position: absolute;
            right: 8px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            color: var(--sidebar-green);
            font-size: 1rem;
            cursor: pointer;
            padding: 5px;
        }
        
        .no-results {
            text-align: center;
            padding: 20px;
            color: #7f8c8d;
            font-style: italic;
            font-size: 0.9rem;
        }
        
        .employee-checkbox-list.searchable {
            max-height: 150px;
            overflow-y: auto;
        }
        
        .employee-item.hidden {
            display: none;
        }
        
        .site-header {
            background: linear-gradient(135deg, var(--sidebar-green) 0%, var(--sidebar-dark-green) 100%);
            color: white;
            padding: 20px;
            border-radius: var(--border-radius);
            margin-bottom: 20px;
            text-align: center;
            font-size: 1.8rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 1px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 15px;
        }
        
        .site-header i {
            font-size: 2rem;
        }
        
        /* Warning message for already assigned employees */
        .assignment-warning {
            background-color: #fff3cd;
            border: 1px solid #ffeaa7;
            color: #856404;
            padding: 10px;
            border-radius: var(--border-radius);
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 0.9rem;
        }
        
        .assignment-warning i {
            color: #f39c12;
            font-size: 1.2rem;
        }
        
        /* Employee status badge */
        .employee-status {
            display: inline-block;
            padding: 3px 8px;
            border-radius: 12px;
            font-size: 0.75rem;
            font-weight: 600;
            margin-left: 8px;
        }
        
        .status-unassigned {
            background-color: #d4edda;
            color: #155724;
        }
        
        .status-assigned {
            background-color: #fff3cd;
            color: #856404;
        }
        
        /* NEW: Search bar styles for add employee modal */
        .employee-search-section {
            margin-bottom: 15px;
        }
        
        .employee-search-section .search-container {
            display: flex;
            align-items: center;
            border: 2px solid var(--sidebar-dark-green);
            border-radius: 25px;
            padding: 5px 15px;
            background-color: white;
            transition: var(--transition);
            width: 100%;
        }
        
        .employee-search-section .search-container:focus-within {
            border-color: var(--accent-green);
            box-shadow: 0 0 0 3px rgba(41, 148, 82, 0.1);
        }
        
        .employee-search-section .search-bar {
            border: none;
            outline: none;
            width: 100%;
            font-size: 0.95rem;
            background-color: transparent;
            padding: 8px;
        }
        
        .employee-search-section .search-btn {
            background: none;
            border: none;
            color: var(--sidebar-green);
            font-size: 1.1rem;
            cursor: pointer;
            padding: 5px;
            flex-shrink: 0;
        }
        
        .employee-select-item.hidden {
            display: none;
        }
    </style>
</head>
<body>
    <!-- Header -->
    <?php include_once("./includes/header.php"); ?>
     
    <main class="content">
        <div class="content-wrapper">
            <!-- Site Header -->
            <!-- Controls Container with Search and Add Button -->
            <div class="controls-container">
                <div class="search-section">
                    <div class="search-container">
                        <form method="GET" action="site_monitoring.php" style="display: flex; align-items: center; width: 100%;">
                            <input type="text" name="search" 
                                   value="<?php echo htmlspecialchars($search_query); ?>" 
                                   placeholder="Search Site..." 
                                   class="search-bar">
                            <button type="submit" class="search-btn">
                                <i class="fas fa-search"></i>
                            </button>
                        </form>
                    </div>
                </div>
                
                <button class="add-site-btn" onclick="showAddSiteModal()">
                    <i class="fas fa-plus-circle"></i>
                    Add Site
                </button>
            </div>

            <!-- Site Table -->
            <div class="table-responsive">
                <div class="site-table-container">
                    <table class="site-table">
                        <thead>
                            <tr>
                                <th>Site Information</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php if ($result->num_rows > 0): ?>
                            <?php while ($row = $result->fetch_assoc()): 
                                // Get employee count for this site
                                $employee_count_query = "SELECT COUNT(*) as count FROM site_employee WHERE site_id = ?";
                                $count_stmt = $conn->prepare($employee_count_query);
                                $count_stmt->bind_param("i", $row['id']);
                                $count_stmt->execute();
                                $count_result = $count_stmt->get_result();
                                $count_data = $count_result->fetch_assoc();
                                $employee_count = $count_data ? $count_data['count'] : 0;
                            ?>
                            <tr>
                                <td>
                                    <div class="site-info">
                                        <div><strong>Site Name:</strong> <?php echo htmlspecialchars($row['site_name']); ?></div>
                                        <div><strong>Manager:</strong> <?php echo htmlspecialchars($row['site_manager']); ?></div>
                                        <div><strong>Address:</strong> <?php echo htmlspecialchars($row['site_address']); ?></div>
                                        <div><strong>Employees:</strong> <span style="color: var(--info-color); font-weight: 600;"><?php echo $employee_count; ?> assigned</span></div>
                                    </div>
                                </td>
                                <td>
                                    <div class="action-buttons">
                                        <button class='action-btn view-btn' 
                                                onclick='showViewEmployeesModal(<?php echo $row['id']; ?>, "<?php echo htmlspecialchars(addslashes($row['site_name'])); ?>", "<?php echo htmlspecialchars(addslashes($row['site_manager'])); ?>", "<?php echo htmlspecialchars(addslashes($row['site_address'])); ?>")'
                                                title="View Employees">
                                            <i class="fas fa-eye"></i>
                                        </button>

                                        <a href='site_monitoring.php?edit=<?php echo $row['id']; ?>' 
                                           class='action-btn edit-btn' 
                                           title="Edit">
                                            <i class="fas fa-edit"></i>
                                        </a>

                                        <a href='site_monitoring.php?delete=<?php echo $row['id']; ?>' 
                                           class='action-btn delete-btn' 
                                           title="Delete"
                                           onclick='return confirm("Are you sure you want to delete this site? This will unassign all employees from this site.");'>
                                            <i class="fas fa-trash-alt"></i>
                                        </a>

                                        <button class='add-employee-btn' 
                                                onclick='showAddEmployeeModal(<?php echo $row['id']; ?>, "<?php echo htmlspecialchars(addslashes($row['site_name'])); ?>")'
                                                title="Add Employee">
                                            <i class="fas fa-user-plus"></i>
                                            Add Employee
                                        </button>
                                    </div>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="2">
                                    <div class="empty-state">
                                        <i class="fas fa-map-marked-alt"></i>
                                        <p>No sites found</p>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>

    <!-- Footer -->
    <?php include_once("./includes/footer.php"); ?>
    
    <?php include_once("./modal/logout-modal.php"); ?>

    <!-- Add Site Modal -->
    <div id="addSiteModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-map-marked-alt"></i> Add New Site</h3>
                <button class="modal-close" onclick="closeAddSiteModal()">&times;</button>
            </div>
            <form method="POST" action="site_monitoring.php">
                <div class="modal-body">
                    <div class="site-form">
                        <div class="form-group">
                            <label for="site-name">Site Name *</label>
                            <input type="text" id="site-name" name="site_name" 
                                   required placeholder="Enter site name" 
                                   autocomplete="off">
                        </div>
                        <div class="form-group">
                            <label for="site-manager">Manager *</label>
                            <input type="text" id="site-manager" name="site_manager" 
                                   required placeholder="Enter manager name" 
                                   autocomplete="off">
                        </div>
                        <div class="form-group">
                            <label for="site-address">Address *</label>
                            <input type="text" id="site-address" name="site_address" 
                                   required placeholder="Enter address" 
                                   autocomplete="off">
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-cancel" onclick="closeAddSiteModal()">Cancel</button>
                    <button type="submit" name="save_site" class="btn btn-save">Save Site</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Add Employee Modal (Modified: Added search bar, removed note) -->
    <div id="addEmployeeModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-user-plus"></i> Add Employees to Site</h3>
                <button class="modal-close" onclick="closeAddEmployeeModal()">&times;</button>
            </div>
            <form method="POST" action="site_monitoring.php" id="addEmployeeForm">
                <input type="hidden" id="add_site_id" name="add_site_id" value="">
                
                <div class="modal-body">
                    <div class="site-form">
                        <div class="form-group">
                            <label for="site-select">Select Site</label>
                            <select id="site-select" class="form-control" required>
                                <option value="">-- Select a Site --</option>
                                <?php foreach ($all_sites as $site): ?>
                                <option value="<?php echo $site['id']; ?>"><?php echo htmlspecialchars($site['site_name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="employee-select-section">
                            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                                <h4 style="margin: 0;">
                                    <i class="fas fa-users"></i> Available Employees
                                </h4>
                                <div style="display: flex; align-items: center; gap: 10px;">
                                    <span id="selectedCount" class="selected-count">0 selected</span>
                                    <button type="button" class="select-all-btn" id="selectAllBtn" onclick="selectAllEmployees()">
                                        <i class="fas fa-check"></i> Select All
                                    </button>
                                </div>
                            </div>
                            
                            <!-- NEW: Search bar for employees -->
                            <div class="employee-search-section">
                                <div class="search-container">
                                    <input type="text" 
                                           id="employeeSearchInput" 
                                           placeholder="Search employees by name or ID..." 
                                           class="search-bar"
                                           onkeyup="searchAvailableEmployees()">
                                    <button type="button" class="search-btn" onclick="searchAvailableEmployees()">
                                        <i class="fas fa-search"></i>
                                    </button>
                                </div>
                            </div>
                            
                            <div id="employeeSelectList" class="employee-select-list" style="max-height: 300px;">
                                <div class="no-employees-available">
                                    <i class="fas fa-user-slash"></i>
                                    <p>Select a site first to see available employees</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-cancel" onclick="closeAddEmployeeModal()">Cancel</button>
                    <button type="submit" name="add_employees_to_site" class="btn btn-add" id="addEmployeesBtn" disabled>
                        <i class="fas fa-user-plus"></i> Add Selected Employees
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- View Employees Modal -->
    <div id="viewEmployeesModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <div>
                    <h3><i class="fas fa-users"></i> Site Employees</h3>
                    <div class="view-modal-header">
                        <p id="viewSiteName"></p>
                        <p><i class="fas fa-user-tie"></i> <span id="viewSiteManager"></span></p>
                        <p><i class="fas fa-map-marker-alt"></i> <span id="viewSiteAddress"></span></p>
                    </div>
                </div>
                <button class="modal-close" onclick="closeViewEmployeesModal()">&times;</button>
            </div>
            <div class="modal-body">
                <div id="employeesListContainer">
                    <div class="no-assigned-employees">
                        <i class="fas fa-user-clock"></i>
                        <p>Loading employees...</p>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-cancel" onclick="closeViewEmployeesModal()">Close</button>
            </div>
        </div>
    </div>

    <!-- Edit Site Modal -->
    <?php if ($site_details): ?>
    <div id="editSiteModal" class="modal" style="display: flex;">
        <div class="modal-content" style="max-width: 500px;">
            <div class="modal-header">
                <h3><i class="fas fa-edit"></i> Edit Site</h3>
                <button class="modal-close" onclick="closeEditSiteModal()">&times;</button>
            </div>
            <form method="POST" action="site_monitoring.php">
                <input type="hidden" name="site_id" value="<?php echo $site_details['id']; ?>">
                
                <div class="modal-body">
                    <div class="site-form">
                        <div class="form-group">
                            <label for="edit-site-name">Site Name *</label>
                            <input type="text" id="edit-site-name" name="edit_site_name" 
                                   value="<?php echo htmlspecialchars($site_details['site_name']); ?>"
                                   required placeholder="Enter site name" 
                                   autocomplete="off">
                        </div>
                        <div class="form-group">
                            <label for="edit-site-manager">Manager *</label>
                            <input type="text" id="edit-site-manager" name="edit_site_manager" 
                                   value="<?php echo htmlspecialchars($site_details['site_manager']); ?>"
                                   required placeholder="Enter manager name" 
                                   autocomplete="off">
                        </div>
                        <div class="form-group">
                            <label for="edit-site-address">Address *</label>
                            <input type="text" id="edit-site-address" name="edit_site_address" 
                                   value="<?php echo htmlspecialchars($site_details['site_address']); ?>"
                                   required placeholder="Enter address" 
                                   autocomplete="off">
                        </div>
                        
                        <!-- Employee Management Section -->
                        <?php if (!empty($site_employees)): ?>
                        <div class="employee-list-section">
                            <h4><i class="fas fa-users"></i> Assigned Employees (<?php echo count($site_employees); ?>)</h4>
                            <p style="color: #666; font-size: 0.85rem; margin-bottom: 10px;">
                                <i class="fas fa-info-circle"></i> Removing an employee will make them available for assignment to other sites.
                            </p>
                            
                            <div class="remove-employees-section">
                                <h5><i class="fas fa-user-minus"></i> Remove Employees</h5>
                                <p>Select employees to remove from this site:</p>
                                
                                <div class="employee-search-container">
                                    <input type="text" 
                                           id="employeeSearch" 
                                           class="employee-search-input" 
                                           placeholder="Search employees by name or ID..." 
                                           onkeyup="searchEmployees()">
                                    <button type="button" class="employee-search-btn">
                                        <i class="fas fa-search"></i>
                                    </button>
                                </div>
                                
                                <div id="employeeCheckboxList" class="employee-checkbox-list searchable">
                                    <?php foreach ($site_employees as $employee): ?>
                                    <div class="employee-item" data-name="<?php echo strtolower(htmlspecialchars($employee['first_name'] . ' ' . $employee['last_name'])); ?>" data-id="<?php echo $employee['id']; ?>">
                                        <input type="checkbox" 
                                               id="employee_<?php echo $employee['id']; ?>" 
                                               name="remove_employees[]" 
                                               value="<?php echo $employee['id']; ?>">
                                        <label for="employee_<?php echo $employee['id']; ?>">
                                            <div class="employee-info">
                                                <span class="name"><?php echo htmlspecialchars($employee['first_name'] . ' ' . $employee['last_name']); ?></span>
                                                <span class="id">ID: <?php echo $employee['id']; ?> | <?php echo htmlspecialchars($employee['position']); ?></span>
                                            </div>
                                        </label>
                                    </div>
                                    <?php endforeach; ?>
                                </div>
                                <div id="noResultsMessage" class="no-results" style="display: none;">
                                    <i class="fas fa-search"></i>
                                    <p>No employees found matching your search</p>
                                </div>
                            </div>
                        </div>
                        <?php else: ?>
                        <div class="employee-list-section">
                            <h4><i class="fas fa-users"></i> Assigned Employees (0)</h4>
                            <div class="no-employees">
                                <i class="fas fa-user-slash"></i>
                                <p>No employees assigned to this site yet.</p>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-cancel" onclick="closeEditSiteModal()">Cancel</button>
                    <button type="submit" name="update_site" class="btn btn-save">Update Site</button>
                </div>
            </form>
        </div>
    </div>
    <?php endif; ?>

    <script>
        // Add Site Modal functions
        function showAddSiteModal() {
            document.getElementById('addSiteModal').style.display = 'flex';
            document.body.classList.add('modal-open');
            document.getElementById('site-name').focus();
        }

        function closeAddSiteModal() {
            document.getElementById('addSiteModal').style.display = 'none';
            document.body.classList.remove('modal-open');
            document.getElementById('site-name').value = '';
            document.getElementById('site-manager').value = '';
            document.getElementById('site-address').value = '';
        }

        // Add Employee Modal functions
        function showAddEmployeeModal(siteId, siteName) {
            document.getElementById('addEmployeeModal').style.display = 'flex';
            document.body.classList.add('modal-open');
            
            document.getElementById('add_site_id').value = siteId;
            const siteSelect = document.getElementById('site-select');
            siteSelect.value = siteId;
            
            document.querySelector('#addEmployeeModal .modal-header h3').innerHTML = 
                `<i class="fas fa-user-plus"></i> Add Employees to ${siteName}`;
            
            loadAvailableEmployees(siteId);
            
            // Clear search input
            const searchInput = document.getElementById('employeeSearchInput');
            if (searchInput) {
                searchInput.value = '';
            }
        }

        function closeAddEmployeeModal() {
            document.getElementById('addEmployeeModal').style.display = 'none';
            document.body.classList.remove('modal-open');
            document.getElementById('add_site_id').value = '';
            document.getElementById('site-select').value = '';
            document.getElementById('employeeSelectList').innerHTML = 
                '<div class="no-employees-available"><i class="fas fa-user-slash"></i><p>Select a site first to see available employees</p></div>';
            document.getElementById('selectedCount').textContent = '0 selected';
            document.getElementById('addEmployeesBtn').disabled = true;
            document.getElementById('selectAllBtn').innerHTML = '<i class="fas fa-check"></i> Select All';
        }

        // View Employees Modal functions
        function showViewEmployeesModal(siteId, siteName, siteManager, siteAddress) {
            document.getElementById('viewEmployeesModal').style.display = 'flex';
            document.body.classList.add('modal-open');
            
            document.getElementById('viewSiteName').innerHTML = `<i class="fas fa-building"></i> ${siteName}`;
            document.getElementById('viewSiteManager').textContent = siteManager;
            document.getElementById('viewSiteAddress').textContent = siteAddress;
            
            loadSiteEmployees(siteId, siteName);
        }

        function closeViewEmployeesModal() {
            document.getElementById('viewEmployeesModal').style.display = 'none';
            document.body.classList.remove('modal-open');
            document.getElementById('employeesListContainer').innerHTML = 
                '<div class="no-assigned-employees"><i class="fas fa-user-clock"></i><p>Loading employees...</p></div>';
        }

        // Edit Site Modal functions
        function closeEditSiteModal() {
            window.location.href = 'site_monitoring.php';
        }

        // Search employees in edit modal
        function searchEmployees() {
            const searchTerm = document.getElementById('employeeSearch').value.toLowerCase();
            const employeeItems = document.querySelectorAll('.employee-item');
            const noResultsMessage = document.getElementById('noResultsMessage');
            let visibleCount = 0;
            
            employeeItems.forEach(item => {
                const employeeName = item.getAttribute('data-name');
                const employeeId = item.getAttribute('data-id');
                
                if (employeeName.includes(searchTerm) || employeeId.includes(searchTerm)) {
                    item.classList.remove('hidden');
                    visibleCount++;
                } else {
                    item.classList.add('hidden');
                }
            });
            
            if (visibleCount === 0 && searchTerm !== '') {
                noResultsMessage.style.display = 'block';
            } else {
                noResultsMessage.style.display = 'none';
            }
        }

        // NEW: Search available employees in add employee modal
        function searchAvailableEmployees() {
            const searchTerm = document.getElementById('employeeSearchInput').value.toLowerCase();
            const employeeItems = document.querySelectorAll('#employeeSelectList .employee-select-item');
            let visibleCount = 0;
            
            employeeItems.forEach(item => {
                const employeeName = item.querySelector('.employee-name').textContent.toLowerCase();
                const employeeId = item.querySelector('input[type="checkbox"]').value;
                
                if (employeeName.includes(searchTerm) || employeeId.includes(searchTerm)) {
                    item.classList.remove('hidden');
                    visibleCount++;
                } else {
                    item.classList.add('hidden');
                }
            });
            
            // Show no results message if needed
            const noResultsElement = document.getElementById('searchNoResults');
            if (!noResultsElement) {
                const noResultsDiv = document.createElement('div');
                noResultsDiv.id = 'searchNoResults';
                noResultsDiv.className = 'no-results';
                noResultsDiv.innerHTML = '<i class="fas fa-search"></i><p>No employees found matching your search</p>';
                
                if (visibleCount === 0 && searchTerm !== '' && employeeItems.length > 0) {
                    document.getElementById('employeeSelectList').appendChild(noResultsDiv);
                }
            } else {
                if (visibleCount === 0 && searchTerm !== '' && employeeItems.length > 0) {
                    noResultsElement.style.display = 'block';
                } else {
                    noResultsElement.style.display = 'none';
                }
            }
        }

        // Load site employees for view modal
        async function loadSiteEmployees(siteId, siteName) {
            const container = document.getElementById('employeesListContainer');
            
            container.innerHTML = '<div class="spinner"></div>';
            
            try {
                const response = await fetch(`get_site_employees.php?site_id=${siteId}`);
                const data = await response.json();
                
                if (data.success && data.employees && data.employees.length > 0) {
                    let html = '';
                    data.employees.forEach(employee => {
                        html += `
                            <div class="view-employee-item">
                                <div class="view-employee-details">
                                    <div class="view-employee-name">${employee.first_name} ${employee.last_name}</div>
                                    <div class="view-employee-info">
                                        <span><i class="fas fa-id-badge"></i> ID: ${employee.id}</span>
                                        <span><i class="fas fa-briefcase"></i> ${employee.position || 'No position'}</span>
                                        ${employee.email ? `<span><i class="fas fa-envelope"></i> ${employee.email}</span>` : ''}
                                    </div>
                                </div>
                            </div>
                        `;
                    });
                    
                    const titleElement = document.querySelector('#viewEmployeesModal .modal-header h3');
                    titleElement.innerHTML = `<i class="fas fa-users"></i> Site Employees <span class="employee-count-badge">${data.employees.length} employees</span>`;
                    
                    container.innerHTML = html;
                } else {
                    container.innerHTML = `
                        <div class="no-assigned-employees">
                            <i class="fas fa-user-slash"></i>
                            <p>No employees assigned to this site yet.</p>
                        </div>
                    `;
                    
                    const titleElement = document.querySelector('#viewEmployeesModal .modal-header h3');
                    titleElement.innerHTML = `<i class="fas fa-users"></i> Site Employees`;
                }
            } catch (error) {
                console.error('Error loading site employees:', error);
                container.innerHTML = `
                    <div class="no-assigned-employees">
                        <i class="fas fa-exclamation-triangle"></i>
                        <p>Error loading employees. Please try again.</p>
                    </div>
                `;
            }
        }

        // Load available employees via AJAX
        function loadAvailableEmployees(siteId) {
            const employeeSelectList = document.getElementById('employeeSelectList');
            
            employeeSelectList.innerHTML = '<div class="spinner"></div>';
            
            fetch(`get_available_employees.php?site_id=${siteId}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success && data.employees && data.employees.length > 0) {
                        let html = '';
                        data.employees.forEach(employee => {
                            html += `
                                <div class="employee-select-item">
                                    <input type="checkbox" 
                                           id="emp_${employee.id}" 
                                           name="selected_employees[]" 
                                           value="${employee.id}"
                                           onchange="updateSelectedCount()">
                                    <label for="emp_${employee.id}">
                                        <div class="employee-details">
                                            <span class="employee-name">${employee.first_name} ${employee.last_name}</span>
                                            <span class="employee-position">${employee.position || 'No position specified'}</span>
                                            <span class="employee-status status-unassigned">Unassigned</span>
                                        </div>
                                    </label>
                                </div>
                            `;
                        });
                        employeeSelectList.innerHTML = html;
                        document.getElementById('selectAllBtn').style.display = 'inline-flex';
                        
                        // Clear and show search bar
                        document.getElementById('employeeSearchInput').value = '';
                        document.getElementById('employeeSearchInput').disabled = false;
                    } else {
                        employeeSelectList.innerHTML = `
                            <div class="no-employees-available">
                                <i class="fas fa-user-check"></i>
                                <p>No available employees. All active employees are already assigned to sites.</p>
                            </div>
                        `;
                        document.getElementById('selectAllBtn').style.display = 'none';
                        document.getElementById('employeeSearchInput').disabled = true;
                    }
                    updateSelectedCount();
                    
                    // Remove any existing no results message
                    const existingNoResults = document.getElementById('searchNoResults');
                    if (existingNoResults) {
                        existingNoResults.remove();
                    }
                })
                .catch(error => {
                    console.error('Error loading employees:', error);
                    employeeSelectList.innerHTML = `
                        <div class="no-employees-available">
                            <i class="fas fa-exclamation-triangle"></i>
                            <p>Error loading employees. Please try again.</p>
                        </div>
                    `;
                    document.getElementById('selectAllBtn').style.display = 'none';
                    document.getElementById('employeeSearchInput').disabled = true;
                });
        }

        // Update selected count
        function updateSelectedCount() {
            const checkboxes = document.querySelectorAll('#employeeSelectList input[type="checkbox"]');
            const selected = document.querySelectorAll('#employeeSelectList input[type="checkbox"]:checked');
            const selectedCount = document.getElementById('selectedCount');
            const addEmployeesBtn = document.getElementById('addEmployeesBtn');
            const selectAllBtn = document.getElementById('selectAllBtn');
            
            selectedCount.textContent = `${selected.length} selected`;
            
            if (checkboxes.length > 0 && selected.length === checkboxes.length) {
                selectAllBtn.innerHTML = '<i class="fas fa-times"></i> Deselect All';
            } else {
                selectAllBtn.innerHTML = '<i class="fas fa-check"></i> Select All';
            }
            
            addEmployeesBtn.disabled = selected.length === 0;
        }

        // Select all employees
        function selectAllEmployees() {
            const checkboxes = document.querySelectorAll('#employeeSelectList input[type="checkbox"]');
            const selectAllBtn = document.getElementById('selectAllBtn');
            const isSelectingAll = selectAllBtn.innerHTML.includes('Select All');
            
            checkboxes.forEach(checkbox => {
                checkbox.checked = isSelectingAll;
            });
            
            updateSelectedCount();
        }

        // Site select change handler
        document.getElementById('site-select').addEventListener('change', function() {
            const siteId = this.value;
            const addSiteIdField = document.getElementById('add_site_id');
            
            if (siteId) {
                addSiteIdField.value = siteId;
                loadAvailableEmployees(siteId);
                
                const selectedOption = this.options[this.selectedIndex];
                document.querySelector('#addEmployeeModal .modal-header h3').innerHTML = 
                    `<i class="fas fa-user-plus"></i> Add Employees to ${selectedOption.text}`;
                
                // Enable and focus search input
                const searchInput = document.getElementById('employeeSearchInput');
                searchInput.disabled = false;
                searchInput.focus();
            } else {
                addSiteIdField.value = '';
                document.getElementById('employeeSelectList').innerHTML = 
                    '<div class="no-employees-available"><i class="fas fa-user-slash"></i><p>Select a site first to see available employees</p></div>';
                document.getElementById('selectedCount').textContent = '0 selected';
                document.getElementById('addEmployeesBtn').disabled = true;
                document.getElementById('selectAllBtn').style.display = 'none';
                document.getElementById('employeeSearchInput').disabled = true;
                document.getElementById('employeeSearchInput').value = '';
            }
        });

        // Close modal when clicking outside
        window.onclick = function(event) {
            const addModal = document.getElementById('addSiteModal');
            const editModal = document.getElementById('editSiteModal');
            const addEmployeeModal = document.getElementById('addEmployeeModal');
            const viewEmployeesModal = document.getElementById('viewEmployeesModal');
            
            if (event.target === addModal) closeAddSiteModal();
            if (event.target === editModal) closeEditSiteModal();
            if (event.target === addEmployeeModal) closeAddEmployeeModal();
            if (event.target === viewEmployeesModal) closeViewEmployeesModal();
        }

        // Close modal with Escape key
        document.addEventListener('keydown', function(event) {
            if (event.key === 'Escape') {
                closeAddSiteModal();
                closeAddEmployeeModal();
                closeViewEmployeesModal();
                if (document.getElementById('editSiteModal')) {
                    closeEditSiteModal();
                }
            }
        });

        // Form validation
        document.getElementById('addEmployeeForm').addEventListener('submit', function(e) {
            const selected = document.querySelectorAll('#employeeSelectList input[type="checkbox"]:checked');
            if (selected.length === 0) {
                e.preventDefault();
                alert('Please select at least one employee to add.');
                return false;
            }
            return true;
        });

        <?php if ($site_details): ?>
        document.addEventListener('DOMContentLoaded', function() {
            document.body.classList.add('modal-open');
            const searchInput = document.getElementById('employeeSearch');
            if (searchInput) {
                setTimeout(() => {
                    searchInput.focus();
                }, 300);
            }
        });
        <?php endif; ?>
        
        // Enter key for search
        document.addEventListener('keypress', function(e) {
            if (e.key === 'Enter' && e.target.id === 'employeeSearchInput') {
                e.preventDefault();
                searchAvailableEmployees();
            }
        });
    </script>
</body>
</html>