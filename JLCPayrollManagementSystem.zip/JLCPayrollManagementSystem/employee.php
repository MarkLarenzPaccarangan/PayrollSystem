<?php
session_start();

if (!isset($_SESSION['Admin_User'])) {
    header("Location: login.php"); 
    exit;
}
// Connection to the database
include_once("connection.php");

// Set MySQL to accept dates in a more flexible format
$conn->query("SET SESSION sql_mode = 'ALLOW_INVALID_DATES'");

// Function to safely format date for display
function formatDateForDisplay($date) {
    if (empty($date) || $date == '0000-00-00' || $date == '0000-00-00 00:00:00') {
        return '';
    }
    // Check if it's a valid date
    $timestamp = strtotime($date);
    if ($timestamp === false || $timestamp === -1) {
        return '';
    }
    return date('m/d/Y', $timestamp);
}

// Handle Add Employee
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['save_employee'])) {
    $first_name = $_POST['first_name'];
    $middle_name = $_POST['middle_name'];
    $last_name = $_POST['last_name'];
    $address = $_POST['address'];
    $contact_num = $_POST['contact_num'];
    $position = $_POST['position'];
    $email = $_POST['email'];
    $gender = $_POST['gender'];
    $civil_status = $_POST['civil_status'];
    $date_hired = !empty($_POST['date_hired']) ? $_POST['date_hired'] : null;
    $monthly_salary = $_POST['monthly_salary'];
    $dob = !empty($_POST['dob']) ? $_POST['dob'] : null;
    $sss_number = $_POST['sss_number'] ?? '';
    $pagibig_number = $_POST['pagibig_number'] ?? '';
    $tin_number = $_POST['tin_number'] ?? '';
    $philhealth_number = $_POST['philhealth_number'] ?? '';

    // Use prepared statement to prevent SQL injection
    $sql = "INSERT INTO employees (first_name, middle_name, last_name, address, contact_num, position, email, gender, civil_status, date_hired, monthly_salary, dob, sss_number, pagibig_number, tin_number, philhealth_number) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssssssssssssss", 
        $first_name, $middle_name, $last_name, $address, $contact_num, $position, $email, 
        $gender, $civil_status, $date_hired, $monthly_salary, $dob, 
        $sss_number, $pagibig_number, $tin_number, $philhealth_number
    );
    
    if ($stmt->execute()) {
        echo "<script>
            localStorage.setItem('toastMessage', 'Employee added successfully!');
            localStorage.setItem('toastType', 'success');
            window.location.href='employee.php';
        </script>";
    } else {
        echo "<script>
            localStorage.setItem('toastMessage', 'Error adding employee: " . addslashes($conn->error) . "');
            localStorage.setItem('toastType', 'error');
            window.location.href='employee.php';
        </script>";
    }
    exit();
}

// Handle Delete Employee
if (isset($_GET['delete']) && isset($_GET['employee_id'])) {
    $employee_id = $_GET['employee_id'];
    
    // Start transaction
    $conn->begin_transaction();
    
    try {
        // First delete from site_employee if exists
        $table_check = $conn->query("SHOW TABLES LIKE 'site_employee'");
        if ($table_check && $table_check->num_rows > 0) {
            $stmt1 = $conn->prepare("DELETE FROM site_employee WHERE employee_id = ?");
            $stmt1->bind_param("i", $employee_id);
            $stmt1->execute();
        }
        
        // Delete from deduction if exists
        $table_check = $conn->query("SHOW TABLES LIKE 'deduction'");
        if ($table_check && $table_check->num_rows > 0) {
            $stmt2 = $conn->prepare("DELETE FROM deduction WHERE employee_id = ?");
            $stmt2->bind_param("i", $employee_id);
            $stmt2->execute();
        }
        
        // Finally delete the employee
        $stmt3 = $conn->prepare("DELETE FROM employees WHERE id = ?");
        $stmt3->bind_param("i", $employee_id);
        $stmt3->execute();
        
        $conn->commit();
        
        echo "<script>
            localStorage.setItem('toastMessage', 'Employee deleted successfully!');
            localStorage.setItem('toastType', 'success');
            window.location.href='employee.php';
        </script>";
        
    } catch (Exception $e) {
        $conn->rollback();
        echo "<script>
            localStorage.setItem('toastMessage', 'Error deleting employee: " . addslashes($e->getMessage()) . "');
            localStorage.setItem('toastType', 'error');
            window.location.href='employee.php';
        </script>";
    }
    exit();
}

// Handle Toggle Status (Enable/Disable Employee)
if (isset($_GET['toggle_status']) && isset($_GET['employee_id'])) {
    $employee_id = $_GET['employee_id'];
    $current_status = $_GET['status'];

    // Toggle the employee status between active and inactive
    $new_status = ($current_status === 'active') ? 'inactive' : 'active';

    // Start transaction
    $conn->begin_transaction();
    
    try {
        // Update the employee's status
        $stmt = $conn->prepare("UPDATE employees SET status = ? WHERE id = ?");
        $stmt->bind_param("si", $new_status, $employee_id);
        $stmt->execute();
        
        // If the employee is disabled, disable all their deductions
        if ($new_status === 'inactive') {
            // Check if deduction table exists
            $table_check = $conn->query("SHOW TABLES LIKE 'deduction'");
            if ($table_check && $table_check->num_rows > 0) {
                $stmt2 = $conn->prepare("UPDATE deduction SET status = 'disabled' WHERE employee_id = ?");
                $stmt2->bind_param("i", $employee_id);
                $stmt2->execute();
            }
            
            // Check if site_employee table exists and remove employee from site assignments
            $table_check = $conn->query("SHOW TABLES LIKE 'site_employee'");
            if ($table_check && $table_check->num_rows > 0) {
                $stmt3 = $conn->prepare("DELETE FROM site_employee WHERE employee_id = ?");
                $stmt3->bind_param("i", $employee_id);
                $stmt3->execute();
            }
        }
        
        $conn->commit();
        
        $action = $new_status === 'active' ? 'enabled' : 'disabled';
        echo "<script>
            localStorage.setItem('toastMessage', 'Employee " . $action . " successfully!');
            localStorage.setItem('toastType', 'success');
            window.location.href='employee.php';
        </script>";
        
    } catch (Exception $e) {
        $conn->rollback();
        echo "<script>
            localStorage.setItem('toastMessage', 'Error updating employee status: " . addslashes($e->getMessage()) . "');
            localStorage.setItem('toastType', 'error');
            window.location.href='employee.php';
        </script>";
    }
    exit();
}

// Fetch Employee Details for View
if (isset($_GET['view'])) {
    $id = $_GET['view'];
    $stmt = $conn->prepare("SELECT * FROM employees WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $view_result = $stmt->get_result();
    $employee = $view_result->fetch_assoc();
}

// Fetch Employee Details for Edit
if (isset($_GET['edit'])) {
    $id = $_GET['edit'];
    $stmt = $conn->prepare("SELECT * FROM employees WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $edit_result = $stmt->get_result();
    $employee_edit = $edit_result->fetch_assoc();
}

// Handle Update Employee
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_employee'])) {
    $id = $_POST['id'];
    $first_name = $_POST['first_name'];
    $middle_name = $_POST['middle_name'];
    $last_name = $_POST['last_name'];
    $address = $_POST['address'];
    $contact_num = $_POST['contact_num'];
    $position = $_POST['position'];
    $email = $_POST['email'];
    $gender = $_POST['gender'];
    $civil_status = $_POST['civil_status'];
    $date_hired = !empty($_POST['date_hired']) ? $_POST['date_hired'] : null;
    $monthly_salary = $_POST['monthly_salary'];
    $dob = !empty($_POST['dob']) ? $_POST['dob'] : null;
    $sss_number = $_POST['sss_number'] ?? '';
    $pagibig_number = $_POST['pagibig_number'] ?? '';
    $tin_number = $_POST['tin_number'] ?? '';
    $philhealth_number = $_POST['philhealth_number'] ?? '';

    $sql = "UPDATE employees SET 
            first_name=?, middle_name=?, last_name=?, address=?, 
            contact_num=?, position=?, email=?, gender=?, civil_status=?, 
            date_hired=?, monthly_salary=?, dob=?, sss_number=?, 
            pagibig_number=?, tin_number=?, philhealth_number=? 
            WHERE id=?";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssssssssssssssi", 
        $first_name, $middle_name, $last_name, $address, 
        $contact_num, $position, $email, $gender, $civil_status, 
        $date_hired, $monthly_salary, $dob, $sss_number, 
        $pagibig_number, $tin_number, $philhealth_number, $id
    );

    if ($stmt->execute()) {
        echo "<script>
            localStorage.setItem('toastMessage', 'Employee updated successfully!');
            localStorage.setItem('toastType', 'success');
            window.location.href='employee.php';
        </script>";
    } else {
        echo "<script>
            localStorage.setItem('toastMessage', 'Error updating employee: " . addslashes($conn->error) . "');
            localStorage.setItem('toastType', 'error');
            window.location.href='employee.php';
        </script>";
    }
    exit();
}

// First, check if the new columns exist in the table, if not add them
$check_columns = $conn->query("SHOW COLUMNS FROM employees LIKE 'sss_number'");
if ($check_columns && $check_columns->num_rows == 0) {
    $alter_sql = "ALTER TABLE employees 
                  ADD COLUMN sss_number VARCHAR(50) NULL,
                  ADD COLUMN pagibig_number VARCHAR(50) NULL,
                  ADD COLUMN tin_number VARCHAR(50) NULL,
                  ADD COLUMN philhealth_number VARCHAR(50) NULL";
    $conn->query($alter_sql);
}

// Check if status column exists, if not add it
$check_status = $conn->query("SHOW COLUMNS FROM employees LIKE 'status'");
if ($check_status && $check_status->num_rows == 0) {
    $conn->query("ALTER TABLE employees ADD COLUMN status ENUM('active','inactive','disabled') DEFAULT 'active'");
}

// Fetch employees based on search query
$search_query = "";
if (isset($_GET['search'])) {
    $search_query = $conn->real_escape_string($_GET['search']);
    $result = $conn->query("SELECT * FROM employees WHERE 
                            first_name LIKE '%$search_query%' OR 
                            middle_name LIKE '%$search_query%' OR 
                            last_name LIKE '%$search_query%' OR
                            id LIKE '%$search_query%' OR
                            position LIKE '%$search_query%'
                            ORDER BY id DESC");
} else {
    $result = $conn->query("SELECT * FROM employees ORDER BY id DESC");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Management</title>
    <link rel="stylesheet" href="./assets/css/employee2.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* Your existing styles remain exactly the same */
        .govt-id-badge {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 6px 12px;
            background-color: #e3f2fd;
            border-radius: var(--border-radius);
            font-size: 0.85rem;
            margin: 3px;
        }
        
        .govt-id-badge i {
            color: var(--info-color);
        }
        
        .govt-id-container {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-top: 10px;
        }
        
        /* Adjust for footer */
        .content {
            padding-bottom: 80px;
        }
        
        /* Ensure proper header height on page load */
        body {
            padding-top: var(--header-height) !important;
        }
        
        /* Toggle status button styles */
        .toggle-status-btn {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            padding: 6px 12px;
            border-radius: var(--border-radius);
            font-size: 0.85rem;
            font-weight: 500;
            cursor: pointer;
            transition: var(--transition);
            text-decoration: none;
            border: none;
            background-color: #fb0202;
            color: white;
        }
        
        .toggle-status-btn:hover {
            background-color: #781c1c;
            transform: translateY(-1px);
        }
        
        .toggle-status-btn.inactive {
            background-color: #27ae60;
        }
        
        .toggle-status-btn.inactive:hover {
            background-color: #219a52;
        }
        
        /* Delete button styles */
        .delete-btn {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            padding: 6px 12px;
            border-radius: var(--border-radius);
            font-size: 0.85rem;
            font-weight: 500;
            cursor: pointer;
            transition: var(--transition);
            text-decoration: none;
            border: none;
            background-color: #dc3545;
            color: white;
        }
        
        .delete-btn:hover {
            background-color: #c82333;
            transform: translateY(-1px);
        }
        
        .delete-btn i {
            font-size: 0.9rem;
        }
        
        /* Status badge styles */
        .status-badge {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
        }
        
        .status-active {
            background-color: #e8f5e9;
            color: #2e7d32;
        }
        
        .status-inactive {
            background-color: #ffebee;
            color: #c62828;
        }
        
        /* Government ID section in form */
        .govt-id-section {
            grid-column: 1 / -1;
            background: #f8fff8;
            border-radius: var(--border-radius);
            padding: 20px;
            margin-top: 15px;
            border-left: 4px solid var(--accent-green);
        }
        
        .govt-id-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 15px;
        }
        
        .govt-id-section h4 {
            color: var(--accent-green);
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .govt-id-section small {
            display: block;
            margin-top: 4px;
        }
        
        /* Form sections */
        .form-section {
            background: white;
            border-radius: var(--border-radius);
            padding: 20px;
            margin-bottom: 15px;
            border: 1px solid #e0e0e0;
        }
        
        .form-section h4 {
            color: var(--sidebar-dark-green);
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .employee-details {
            display: grid;
            gap: 15px;
        }
        
        .employee-details .form-group {
            display: grid;
            grid-template-columns: 150px 1fr;
            align-items: baseline;
            padding: 8px 0;
            border-bottom: 1px solid #f0f0f0;
        }
        
        .employee-details .form-group label {
            font-weight: 600;
            color: var(--sidebar-dark-green);
        }
        
        .employee-details .form-group p {
            margin: 0;
            color: #333;
        }

        /* ============ CALENDAR DATE PICKER STYLES ============ */
        .date-picker-wrapper {
            position: relative;
            width: 100%;
        }
        
        .date-input-group {
            display: flex;
            align-items: center;
            position: relative;
            width: 100%;
        }
        
        .date-field {
            width: 100%;
            padding: 10px 15px 10px 12px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 0.95rem;
            transition: all 0.3s;
            background: white;
            cursor: pointer;
            color: #2c3e50;
            font-weight: 500;
            height: 42px;
        }
        
        .date-field:hover {
            border-color: #75e6da;
        }
        
        .date-field:focus {
            border-color: #75e6da;
            box-shadow: 0 0 0 3px rgba(46, 125, 139, 0.1);
            outline: none;
        }
        
        .calendar-dropdown-btn {
            position: absolute;
            right: 12px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            color: #95a5a6;
            cursor: pointer;
            font-size: 0.9rem;
            padding: 5px;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s;
        }
        
        .calendar-dropdown-btn:hover {
            color: #75e6da;
        }
        
        /* Calendar Dropdown Styles */
        .calendar-wrapper {
            position: absolute;
            top: calc(100% + 5px);
            left: 0;
            right: 0;
            background: white;
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
            z-index: 2000;
            display: none;
            width: 100%;
            min-width: 300px;
        }
        
        .calendar-wrapper.show {
            display: block;
        }
        
        .calendar-box {
            width: 100%;
            background: white;
            border-radius: 8px;
            overflow: hidden;
        }
        
        .calendar-header {
            background: linear-gradient(135deg, #75e6da, #62d4c8);
            color: white;
            padding: 15px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .calendar-month-year {
            font-weight: 600;
            font-size: 1rem;
        }
        
        .calendar-nav {
            display: flex;
            gap: 10px;
        }
        
        .calendar-nav-btn {
            background: rgba(255, 255, 255, 0.2);
            border: none;
            color: white;
            width: 30px;
            height: 30px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s;
            font-size: 1.2rem;
        }
        
        .calendar-nav-btn:hover {
            background: rgba(255, 255, 255, 0.3);
            transform: scale(1.1);
        }
        
        .calendar-selectors {
            display: flex;
            gap: 10px;
            padding: 15px 15px 5px 15px;
            background: white;
        }
        
        .calendar-select {
            flex: 1;
            padding: 8px 12px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 0.9rem;
            font-weight: 600;
            color: #2c3e50;
            background: white;
            cursor: pointer;
            transition: all 0.3s;
            outline: none;
        }
        
        .calendar-select:hover {
            border-color: #75e6da;
        }
        
        .calendar-select:focus {
            border-color: #75e6da;
            box-shadow: 0 0 0 3px rgba(46, 125, 139, 0.1);
        }
        
        .calendar-weekdays {
            display: grid;
            grid-template-columns: repeat(7, 1fr);
            background: #f8f9fa;
            padding: 10px;
            text-align: center;
            font-weight: 600;
            font-size: 0.85rem;
            color: #2c3e50;
        }
        
        .calendar-days-grid {
            display: grid;
            grid-template-columns: repeat(7, 1fr);
            gap: 2px;
            padding: 10px;
            background: white;
        }
        
        .calendar-day {
            aspect-ratio: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 8px;
            cursor: pointer;
            border-radius: 50%;
            transition: all 0.2s;
            font-size: 0.9rem;
            color: #2c3e50;
            text-decoration: none;
            border: none;
            background: none;
            width: 100%;
        }
        
        .calendar-day:hover {
            background: #e8f5e9;
            color: #62d4c8;
        }
        
        .calendar-day.selected {
            background: #75e6da;
            color: white;
            font-weight: 600;
        }
        
        .calendar-day.today {
            border: 2px solid #75e6da;
            font-weight: 600;
        }
        
        .calendar-day.weekend {
            color: #e74c3c;
        }
        
        .calendar-day.other-month {
            color: #bdc3c7;
        }
        
        .calendar-footer {
            padding: 10px;
            background: #f8f9fa;
            border-top: 1px solid #e0e0e0;
            display: flex;
            justify-content: space-between;
        }
        
        .calendar-action-btn {
            padding: 8px 16px;
            border-radius: 6px;
            font-size: 0.85rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 5px;
            border: none;
        }
        
        .calendar-action-btn.clear {
            background: #f8f9fa;
            color: #7f8c8d;
            border: 1px solid #bdc3c7;
        }
        
        .calendar-action-btn.clear:hover {
            background: #e74c3c;
            color: white;
            border-color: #e74c3c;
        }
        
        .calendar-action-btn.today {
            background: #75e6da;
            color: white;
            border: 1px solid #75e6da;
        }
        
        .calendar-action-btn.today:hover {
            background: #62d4c8;
        }

        /* Toast Notification Styles */
        .toast-container {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 9999;
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        .toast {
            min-width: 300px;
            max-width: 400px;
            background: white;
            border-radius: 8px;
            padding: 16px 20px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            display: flex;
            align-items: center;
            gap: 12px;
            animation: slideIn 0.3s ease;
            border-left: 4px solid;
        }

        .toast.success {
            border-left-color: #28a745;
        }

        .toast.success i {
            color: #28a745;
        }

        .toast.error {
            border-left-color: #dc3545;
        }

        .toast.error i {
            color: #dc3545;
        }

        .toast.warning {
            border-left-color: #ffc107;
        }

        .toast.warning i {
            color: #ffc107;
        }

        .toast.info {
            border-left-color: #17a2b8;
        }

        .toast.info i {
            color: #17a2b8;
        }

        .toast i {
            font-size: 1.2rem;
        }

        .toast-content {
            flex: 1;
            font-size: 0.95rem;
            color: #333;
        }

        .toast-close {
            background: none;
            border: none;
            color: #999;
            cursor: pointer;
            font-size: 1rem;
            padding: 0;
            transition: color 0.3s;
        }

        .toast-close:hover {
            color: #333;
        }

        @keyframes slideIn {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }

        @keyframes slideOut {
            from {
                transform: translateX(0);
                opacity: 1;
            }
            to {
                transform: translateX(100%);
                opacity: 0;
            }
        }

        /* New Position Selection Styles - Enhanced */
        .position-selection-container {
            margin-top: 10px;
            border: 1px solid #e0e0e0;
            border-radius: var(--border-radius);
            overflow: hidden;
            background: white;
        }

        .select-position-btn {
            background: linear-gradient(135deg, var(--sidebar-green), var(--sidebar-dark-green));
            color: white;
            border: none;
            padding: 12px 15px;
            border-radius: var(--border-radius);
            font-size: 0.95rem;
            font-weight: 600;
            cursor: pointer;
            transition: var(--transition);
            display: inline-flex;
            align-items: center;
            gap: 8px;
            width: 100%;
            justify-content: center;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .select-position-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.15);
        }

        .select-position-btn i {
            font-size: 1rem;
        }

        .position-tag {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            padding: 8px 15px;
            background: linear-gradient(135deg, #e8f5e9, #c8e6c9);
            border-radius: 30px;
            font-size: 0.9rem;
            color: #2e7d32;
            margin: 4px;
            border: 1px solid #a5d6a7;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
            transition: var(--transition);
            max-width: 100%;
            word-break: break-word;
            line-height: 1.4;
            white-space: normal;
            text-align: left;
        }

        .position-tag:hover {
            transform: translateY(-1px);
            box-shadow: 0 3px 6px rgba(0,0,0,0.1);
        }

        .position-tag i {
            color: #2e7d32;
            cursor: pointer;
            font-size: 0.9rem;
            opacity: 0.7;
            transition: var(--transition);
        }

        .position-tag i:hover {
            opacity: 1;
            color: #c62828;
            transform: scale(1.1);
        }

        .position-tag .delete-position {
            color: #c62828;
        }

        .selected-positions {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            margin-top: 10px;
            padding: 15px;
            background-color: #f8fff8;
            border-radius: var(--border-radius);
            min-height: 60px;
            border: 2px dashed #c8e6c9;
            max-height: 300px;
            overflow-y: auto;
        }

        .category-buttons {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }

        .category-btn {
            flex: 1;
            padding: 12px 15px;
            border: none;
            border-radius: var(--border-radius);
            font-size: 0.95rem;
            font-weight: 600;
            cursor: pointer;
            transition: var(--transition);
            background-color: #f0f0f0;
            color: #333;
            min-width: 100px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
        }

        .category-btn.active {
            background: linear-gradient(135deg, var(--sidebar-green), var(--sidebar-dark-green));
            color: white;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }

        .category-btn:hover:not(.active) {
            background-color: #e0e0e0;
            transform: translateY(-1px);
        }

        .positions-container {
            padding: 20px;
            background: linear-gradient(135deg, #f8fff8, #f0f9f0);
            border-radius: var(--border-radius);
            min-height: 250px;
            max-height: 350px;
            overflow-y: auto;
            border: 1px solid #e0e0e0;
            margin-bottom: 15px;
        }

        .position-checkbox-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px;
            border-bottom: 1px solid #e0e0e0;
            background: white;
            margin-bottom: 2px;
            border-radius: 4px;
            transition: var(--transition);
        }

        .position-checkbox-item:hover {
            background-color: #f0f9f0;
            transform: translateX(5px);
        }

        .position-checkbox-item input[type="checkbox"] {
            width: 20px;
            height: 20px;
            cursor: pointer;
            accent-color: var(--sidebar-green);
        }

        .position-checkbox-item label {
            font-size: 0.95rem;
            color: #333;
            cursor: pointer;
            flex: 1;
            font-weight: 500;
            word-break: break-word;
        }

        .add-position-small-btn {
            background: linear-gradient(135deg, #75e6da, #62d4c8);
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 25px;
            font-size: 0.85rem;
            font-weight: 600;
            cursor: pointer;
            transition: var(--transition);
            display: inline-flex;
            align-items: center;
            gap: 8px;
            margin-top: 15px;
            box-shadow: 0 2px 4px rgba(117, 230, 218, 0.3);
        }

        .add-position-small-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(117, 230, 218, 0.4);
        }

        .custom-position-input {
            display: flex;
            gap: 10px;
            margin-top: 15px;
            padding: 15px;
            background: white;
            border-radius: var(--border-radius);
            border: 1px solid #e0e0e0;
        }

        .custom-position-input input {
            flex: 1;
            padding: 10px 12px;
            border: 2px solid #e0e0e0;
            border-radius: var(--border-radius);
            font-size: 0.95rem;
            transition: var(--transition);
        }

        .custom-position-input input:focus {
            outline: none;
            border-color: var(--sidebar-green);
            box-shadow: 0 0 0 3px rgba(117, 230, 218, 0.1);
        }

        .custom-position-input button {
            background: linear-gradient(135deg, var(--sidebar-green), var(--sidebar-dark-green));
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: var(--border-radius);
            font-size: 0.95rem;
            font-weight: 600;
            cursor: pointer;
            transition: var(--transition);
            white-space: nowrap;
        }

        .custom-position-input button:hover {
            transform: translateY(-1px);
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .position-group {
            border: 1px solid #e0e0e0;
            border-radius: var(--border-radius);
            margin-bottom: 20px;
            background: white;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
        }

        .position-group-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px 20px;
            background: linear-gradient(135deg, var(--sidebar-green), var(--sidebar-dark-green));
            color: white;
            border-radius: var(--border-radius) var(--border-radius) 0 0;
        }

        .position-group-header h5 {
            margin: 0;
            font-size: 1rem;
            font-weight: 600;
            letter-spacing: 0.5px;
        }

        .position-group-header button {
            background: rgba(255, 255, 255, 0.2);
            border: none;
            color: white;
            width: 30px;
            height: 30px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: var(--transition);
        }

        .position-group-header button:hover {
            background: rgba(255, 255, 255, 0.3);
            transform: rotate(90deg);
        }

        .position-group-content {
            padding: 15px;
            background: white;
            border-radius: 0 0 var(--border-radius) var(--border-radius);
        }

        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: #7f8c8d;
        }

        .empty-state i {
            font-size: 3rem;
            color: #d1f0eb;
            margin-bottom: 15px;
        }

        .empty-state p {
            font-size: 1rem;
            color: #95a5a6;
        }

        .modal {
            z-index: 10000;
        }
        
        #positionModal, #editPositionModal {
            z-index: 10001;
        }

        /* Custom Positions Section */
        .custom-positions-section {
            margin-top: 20px;
            padding: 15px;
            background: #f8fff8;
            border-radius: var(--border-radius);
            border: 1px solid #e0e0e0;
        }

        .custom-positions-section h6 {
            color: var(--sidebar-dark-green);
            margin-bottom: 10px;
            font-size: 0.9rem;
            font-weight: 600;
        }

        .custom-positions-list {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            margin-top: 10px;
            max-height: 150px;
            overflow-y: auto;
            padding: 10px;
            background: white;
            border-radius: var(--border-radius);
            border: 1px solid #e0e0e0;
        }

        .custom-position-tag {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 6px 12px;
            background: linear-gradient(135deg, #e1f5fe, #b3e5fc);
            border-radius: 20px;
            font-size: 0.85rem;
            color: #0277bd;
            border: 1px solid #81d4fa;
            word-break: break-word;
            max-width: 100%;
        }

        .custom-position-tag i {
            cursor: pointer;
            color: #0277bd;
            opacity: 0.7;
        }

        .custom-position-tag i:hover {
            opacity: 1;
            color: #c62828;
        }

        /* Employee Info in Table */
        .employee-info {
            display: grid;
            gap: 6px;
        }

        .employee-info div {
            font-size: 0.9rem;
            line-height: 1.4;
            word-break: break-word;
        }

        .employee-info strong {
            color: var(--sidebar-dark-green);
            font-weight: 600;
            min-width: 100px;
            display: inline-block;
        }

        .position-display {
            white-space: normal;
            word-break: break-word;
            line-height: 1.5;
        }
    </style>
</head>
<body>
    <!-- Toast Container -->
    <div id="toastContainer" class="toast-container"></div>

    <!-- Header with Navigation -->
    <?php include_once("./includes/header.php"); ?>

    <main class="content">
        <div class="content-wrapper">
            <!-- Controls Container with Search and Add Button -->
            <div class="controls-container">
                <div class="search-section">
                    <div class="search-container">
                        <form method="GET" action="employee.php" style="display: flex; align-items: center; width: 100%;">
                            <input type="text" name="search" 
                                   value="<?php echo htmlspecialchars($search_query); ?>" 
                                   placeholder="Search employees by name, ID, or position..." 
                                   class="search-bar">
                            <button type="submit" class="search-btn">
                                <i class="fas fa-search"></i>
                            </button>
                        </form>
                    </div>
                </div>
                
                <button class="add-employee-btn" onclick="showAddEmployeeModal()">
                    <i class="fas fa-user-plus"></i>
                    Add Employee
                </button>
            </div>

            <!-- Employee Table -->
            <div class="table-responsive">
                <div class="employee-table-container">
                    <table class="employee-table">
                        <thead>
                            <tr>
                                <th>Employee Information</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php if ($result && $result->num_rows > 0): ?>
                            <?php while ($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td>
                                    <div class="employee-info">
                                        <div><strong>Name:</strong> <?php echo htmlspecialchars($row['first_name'] . ' ' . $row['last_name']); ?></div>
                                        <div><strong>ID:</strong> <?php echo $row['id']; ?></div>
                                        <div><strong>Position:</strong> <span class="position-display"><?php echo str_replace(', ', ' / ', htmlspecialchars($row['position'])); ?></span></div>
                                        <div><strong>Contact:</strong> <?php echo htmlspecialchars($row['contact_num']); ?></div>
                                        <div><strong>Email:</strong> <?php echo htmlspecialchars($row['email']); ?></div>
                                        <?php if (!empty($row['sss_number']) || !empty($row['pagibig_number']) || !empty($row['tin_number']) || !empty($row['philhealth_number'])): ?>
                                        <div><strong>Gov't IDs:</strong> 
                                            <?php 
                                            $govt_ids = [];
                                            if (!empty($row['sss_number'])) $govt_ids[] = 'SSS';
                                            if (!empty($row['pagibig_number'])) $govt_ids[] = 'PAG-IBIG';
                                            if (!empty($row['tin_number'])) $govt_ids[] = 'TIN';
                                            if (!empty($row['philhealth_number'])) $govt_ids[] = 'PhilHealth';
                                            echo implode(', ', $govt_ids);
                                            ?>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                </td>
                                <td>
                                    <span class="status-badge <?php echo ($row['status'] ?? 'active') == 'active' ? 'status-active' : 'status-inactive'; ?>">
                                        <i class="fas fa-circle" style="font-size: 0.6rem;"></i>
                                        <?php echo ucfirst($row['status'] ?? 'active'); ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="action-buttons">
                                        <button class='action-btn view-btn' 
                                                onclick='showViewEmployeeModal(<?php echo $row['id']; ?>)'
                                                title="View Details">
                                            <i class="fas fa-eye"></i>
                                        </button>

                                        <button class='action-btn edit-btn' 
                                                onclick='showEditEmployeeModal(<?php echo $row['id']; ?>)'
                                                title="Edit">
                                            <i class="fas fa-edit"></i>
                                        </button>

                                        <a href='employee.php?delete=1&employee_id=<?php echo $row['id']; ?>' 
                                           class='delete-btn' 
                                           onclick='return confirmDelete(event, "<?php echo htmlspecialchars($row['first_name'] . ' ' . $row['last_name']); ?>")'
                                           title="Delete Employee">
                                            <i class="fas fa-trash"></i>
                                            Delete
                                        </a>

                                        <a href='employee.php?toggle_status=1&employee_id=<?php echo $row['id']; ?>&status=<?php echo $row['status'] ?? 'active'; ?>' 
                                           class='toggle-status-btn <?php echo ($row['status'] ?? 'active') == 'active' ? '' : 'inactive'; ?>' 
                                           onclick='return confirmToggleStatus(event, "<?php echo htmlspecialchars($row['first_name'] . ' ' . $row['last_name']); ?>", "<?php echo $row['status'] ?? 'active'; ?>")'
                                           title="<?php echo ($row['status'] ?? 'active') == 'active' ? 'Disable' : 'Enable'; ?> Employee">
                                            <i class="fas <?php echo ($row['status'] ?? 'active') == 'active' ? 'fa-user-slash' : 'fa-user-check'; ?>"></i>
                                            <?php echo ($row['status'] ?? 'active') == 'active' ? 'Disable' : 'Enable'; ?>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="3">
                                    <div class="empty-state">
                                        <i class="fas fa-users"></i>
                                        <p>No employees found</p>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>

    <!-- Footer -->
    <?php include_once("./includes/footer.php"); ?>
    
    <?php include_once("./modal/logout-modal.php"); ?>

    <!-- Add Employee Modal -->
    <div id="addEmployeeModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-user-plus"></i> Add New Employee</h3>
                <button class="modal-close" onclick="closeAddEmployeeModal()">&times;</button>
            </div>
            <form method="POST" action="employee.php">
                <div class="modal-body">
                    <div class="employee-form">
                        <div class="form-section">
                            <h4><i class="fas fa-user"></i> Personal Information</h4>
                            <div class="form-group">
                                <label for="first_name">First Name *</label>
                                <input type="text" id="first_name" name="first_name" 
                                       required placeholder="Enter first name" 
                                       autocomplete="off">
                            </div>
                            <div class="form-group">
                                <label for="middle_name">Middle Name</label>
                                <input type="text" id="middle_name" name="middle_name" 
                                       placeholder="Enter middle name" 
                                       autocomplete="off">
                            </div>
                            <div class="form-group">
                                <label for="last_name">Last Name *</label>
                                <input type="text" id="last_name" name="last_name" 
                                       required placeholder="Enter last name" 
                                       autocomplete="off">
                            </div>
                            <div class="form-group">
                                <label for="dob">Date of Birth *</label>
                                <div class="date-picker-wrapper">
                                    <div class="date-input-group">
                                        <input type="text" 
                                               id="dobField" 
                                               class="date-field" 
                                               placeholder="MM/DD/YYYY"
                                               autocomplete="off"
                                               readonly
                                               onclick="toggleCalendar('dob')">
                                        <input type="hidden" id="dob" name="dob" value="">
                                        <button type="button" class="calendar-dropdown-btn" onclick="toggleCalendar('dob')">
                                            <i class="fas fa-chevron-down"></i>
                                        </button>
                                    </div>
                                    
                                    <!-- Calendar Dropdown -->
                                    <div class="calendar-wrapper" id="dobCalendar">
                                        <div class="calendar-box">
                                            <div class="calendar-header">
                                                <div class="calendar-month-year" id="dobMonthYear"></div>
                                                <div class="calendar-nav">
                                                    <button type="button" class="calendar-nav-btn" onclick="navigateMonth('dob', -1)">‹</button>
                                                    <button type="button" class="calendar-nav-btn" onclick="navigateMonth('dob', 1)">›</button>
                                                </div>
                                            </div>
                                            
                                            <div class="calendar-selectors">
                                                <select id="dobMonthSelect" class="calendar-select" onchange="changeMonthYear('dob')">
                                                    <option value="0">January</option>
                                                    <option value="1">February</option>
                                                    <option value="2">March</option>
                                                    <option value="3">April</option>
                                                    <option value="4">May</option>
                                                    <option value="5">June</option>
                                                    <option value="6">July</option>
                                                    <option value="7">August</option>
                                                    <option value="8">September</option>
                                                    <option value="9">October</option>
                                                    <option value="10">November</option>
                                                    <option value="11">December</option>
                                                </select>
                                                
                                                <select id="dobYearSelect" class="calendar-select" onchange="changeMonthYear('dob')">
                                                </select>
                                            </div>
                                            
                                            <div class="calendar-weekdays">
                                                <div>Su</div>
                                                <div>Mo</div>
                                                <div>Tu</div>
                                                <div>We</div>
                                                <div>Th</div>
                                                <div>Fr</div>
                                                <div>Sa</div>
                                            </div>
                                            
                                            <div class="calendar-days-grid" id="dobDaysGrid">
                                            </div>
                                            
                                            <div class="calendar-footer">
                                                <button type="button" class="calendar-action-btn clear" onclick="clearDate('dob')">
                                                    <i class="fas fa-times"></i> Clear
                                                </button>
                                                <button type="button" class="calendar-action-btn today" onclick="setToday('dob')">
                                                    <i class="fas fa-calendar-check"></i> Today
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <small style="color: #666;">Select a valid date</small>
                            </div>
                            <div class="form-group">
                                <label for="gender">Gender *</label>
                                <select id="gender" name="gender" required>
                                    <option value="" disabled selected>Select gender</option>
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="civil_status">Civil Status *</label>
                                <select id="civil_status" name="civil_status" required>
                                    <option value="" disabled selected>Select civil status</option>
                                    <option value="Single">Single</option>
                                    <option value="Married">Married</option>
                                    <option value="Widowed">Widowed</option>
                                    <option value="Separated">Separated</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="form-section">
                            <h4><i class="fas fa-briefcase"></i> Employment Details</h4>
                            <div class="form-group">
                                <label for="position">Position *</label>
                                <input type="text" id="position" name="position" 
                                       required placeholder="Select position below" 
                                       autocomplete="off" readonly>
                            </div>
                            
                            <!-- Position Selection Area -->
                            <div class="position-selection-container">
                                <button type="button" class="select-position-btn" onclick="showPositionModal()">
                                    <i class="fas fa-tasks"></i> Select Position(s)
                                </button>
                                <div class="selected-positions" id="selectedPositionsDisplay">
                                    <!-- Selected positions will appear here -->
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="date_hired">Date Hired *</label>
                                <div class="date-picker-wrapper">
                                    <div class="date-input-group">
                                        <input type="text" 
                                               id="dateHiredField" 
                                               class="date-field" 
                                               placeholder="MM/DD/YYYY"
                                               autocomplete="off"
                                               readonly
                                               onclick="toggleCalendar('hired')">
                                        <input type="hidden" id="date_hired" name="date_hired" value="">
                                        <button type="button" class="calendar-dropdown-btn" onclick="toggleCalendar('hired')">
                                            <i class="fas fa-chevron-down"></i>
                                        </button>
                                    </div>
                                    
                                    <div class="calendar-wrapper" id="hiredCalendar">
                                        <div class="calendar-box">
                                            <div class="calendar-header">
                                                <div class="calendar-month-year" id="hiredMonthYear"></div>
                                                <div class="calendar-nav">
                                                    <button type="button" class="calendar-nav-btn" onclick="navigateMonth('hired', -1)">‹</button>
                                                    <button type="button" class="calendar-nav-btn" onclick="navigateMonth('hired', 1)">›</button>
                                                </div>
                                            </div>
                                            
                                            <div class="calendar-selectors">
                                                <select id="hiredMonthSelect" class="calendar-select" onchange="changeMonthYear('hired')">
                                                    <option value="0">January</option>
                                                    <option value="1">February</option>
                                                    <option value="2">March</option>
                                                    <option value="3">April</option>
                                                    <option value="4">May</option>
                                                    <option value="5">June</option>
                                                    <option value="6">July</option>
                                                    <option value="7">August</option>
                                                    <option value="8">September</option>
                                                    <option value="9">October</option>
                                                    <option value="10">November</option>
                                                    <option value="11">December</option>
                                                </select>
                                                
                                                <select id="hiredYearSelect" class="calendar-select" onchange="changeMonthYear('hired')">
                                                </select>
                                            </div>
                                            
                                            <div class="calendar-weekdays">
                                                <div>Su</div>
                                                <div>Mo</div>
                                                <div>Tu</div>
                                                <div>We</div>
                                                <div>Th</div>
                                                <div>Fr</div>
                                                <div>Sa</div>
                                            </div>
                                            
                                            <div class="calendar-days-grid" id="hiredDaysGrid">
                                            </div>
                                            
                                            <div class="calendar-footer">
                                                <button type="button" class="calendar-action-btn clear" onclick="clearDate('hired')">
                                                    <i class="fas fa-times"></i> Clear
                                                </button>
                                                <button type="button" class="calendar-action-btn today" onclick="setToday('hired')">
                                                    <i class="fas fa-calendar-check"></i> Today
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <small style="color: #666;">Select a valid date</small>
                            </div>
                            <div class="form-group">
                                <label for="monthly_salary">Monthly Salary *</label>
                                <input type="number" id="monthly_salary" name="monthly_salary" 
                                       required placeholder="Enter monthly salary" 
                                       autocomplete="off" step="0.01" min="0">
                            </div>
                            <div class="form-group">
                                <label for="email">Email Address *</label>
                                <input type="email" id="email" name="email" 
                                       required placeholder="Enter email address" 
                                       autocomplete="off">
                            </div>
                            <div class="form-group">
                                <label for="contact_num">Contact Number *</label>
                                <input type="text" id="contact_num" name="contact_num" 
                                       required placeholder="Enter contact number" 
                                       autocomplete="off">
                            </div>
                            <div class="form-group">
                                <label for="address">Address *</label>
                                <input type="text" id="address" name="address" 
                                       required placeholder="Enter address" 
                                       autocomplete="off">
                            </div>
                        </div>
                        
                        <div class="govt-id-section">
                            <h4><i class="fas fa-id-card"></i> Government Identification Numbers</h4>
                            <p style="color: #666; font-size: 0.9rem; margin-bottom: 15px;">Optional: Provide government identification numbers for payroll processing</p>
                            <div class="govt-id-grid">
                                <div class="form-group">
                                    <label for="sss_number">SSS Number</label>
                                    <input type="text" id="sss_number" name="sss_number" 
                                           placeholder="XX-XXXXXXX-X" 
                                           pattern="[0-9]{2}-[0-9]{7}-[0-9]{1}"
                                           title="Format: XX-XXXXXXX-X"
                                           autocomplete="off">
                                    <small style="color: #888; font-size: 0.8rem;">Format: XX-XXXXXXX-X</small>
                                </div>
                                <div class="form-group">
                                    <label for="pagibig_number">PAG-IBIG Number</label>
                                    <input type="text" id="pagibig_number" name="pagibig_number" 
                                           placeholder="XXXX-XXXX-XXXX" 
                                           pattern="[0-9]{4}-[0-9]{4}-[0-9]{4}"
                                           title="Format: XXXX-XXXX-XXXX"
                                           autocomplete="off">
                                    <small style="color: #888; font-size: 0.8rem;">Format: XXXX-XXXX-XXXX</small>
                                </div>
                                <div class="form-group">
                                    <label for="tin_number">TIN Number</label>
                                    <input type="text" id="tin_number" name="tin_number" 
                                           placeholder="XXX-XXX-XXX-XXX" 
                                           pattern="[0-9]{3}-[0-9]{3}-[0-9]{3}-[0-9]{3}"
                                           title="Format: XXX-XXX-XXX-XXX"
                                           autocomplete="off">
                                    <small style="color: #888; font-size: 0.8rem;">Format: XXX-XXX-XXX-XXX</small>
                                </div>
                                <div class="form-group">
                                    <label for="philhealth_number">PhilHealth Number</label>
                                    <input type="text" id="philhealth_number" name="philhealth_number" 
                                           placeholder="XX-XXXXXXXXX-X" 
                                           pattern="[0-9]{2}-[0-9]{9}-[0-9]{1}"
                                           title="Format: XX-XXXXXXXXX-X"
                                           autocomplete="off">
                                    <small style="color: #888; font-size: 0.8rem;">Format: XX-XXXXXXXXX-X</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-cancel" onclick="closeAddEmployeeModal()">Cancel</button>
                    <button type="submit" name="save_employee" class="btn btn-save">Save Employee</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Position Selection Modal -->
    <div id="positionModal" class="modal">
        <div class="modal-content" style="max-width: 500px;">
            <div class="modal-header">
                <h3><i class="fas fa-tasks"></i> Select Position(s)</h3>
                <button class="modal-close" onclick="closePositionModal()">&times;</button>
            </div>
            <div class="modal-body">
                <div class="category-buttons">
                    <button type="button" class="category-btn active" onclick="showPositionCategory('executive')" id="catExecutive">Executive</button>
                    <button type="button" class="category-btn" onclick="showPositionCategory('technical')" id="catTechnical">Technical</button>
                    <button type="button" class="category-btn" onclick="showPositionCategory('admin')" id="catAdmin">Admin</button>
                </div>

                <div id="positionChecklist" class="positions-container">
                    <!-- Positions will be loaded here dynamically -->
                </div>

                <div class="custom-position-input" id="customPositionInput" style="display: none;">
                    <input type="text" id="newPositionName" placeholder="Enter new position name">
                    <button type="button" onclick="addCustomPosition()">Add</button>
                </div>

                <button type="button" class="add-position-small-btn" id="addPositionBtn" onclick="toggleCustomPositionInput()">
                    <i class="fas fa-plus"></i> Add Custom Position
                </button>

                <div class="custom-positions-section" id="customPositionsSection" style="display: none;">
                    <h6>Custom Positions Added:</h6>
                    <div class="custom-positions-list" id="customPositionsList"></div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-cancel" onclick="closePositionModal()">Cancel</button>
                <button type="button" class="btn btn-save" onclick="savePositions()">Save Positions</button>
            </div>
        </div>
    </div>

    <!-- Edit Position Selection Modal -->
    <div id="editPositionModal" class="modal">
        <div class="modal-content" style="max-width: 500px;">
            <div class="modal-header">
                <h3><i class="fas fa-tasks"></i> Select Position(s)</h3>
                <button class="modal-close" onclick="closeEditPositionModal()">&times;</button>
            </div>
            <div class="modal-body">
                <div class="category-buttons">
                    <button type="button" class="category-btn active" onclick="showEditPositionCategory('executive')" id="editCatExecutive">Executive</button>
                    <button type="button" class="category-btn" onclick="showEditPositionCategory('technical')" id="editCatTechnical">Technical</button>
                    <button type="button" class="category-btn" onclick="showEditPositionCategory('admin')" id="editCatAdmin">Admin</button>
                </div>

                <div id="editPositionChecklist" class="positions-container">
                    <!-- Positions will be loaded here dynamically -->
                </div>

                <div class="custom-position-input" id="editCustomPositionInput" style="display: none;">
                    <input type="text" id="editNewPositionName" placeholder="Enter new position name">
                    <button type="button" onclick="addEditCustomPosition()">Add</button>
                </div>

                <button type="button" class="add-position-small-btn" id="editAddPositionBtn" onclick="toggleEditCustomPositionInput()">
                    <i class="fas fa-plus"></i> Add Custom Position
                </button>

                <div class="custom-positions-section" id="editCustomPositionsSection" style="display: none;">
                    <h6>Custom Positions Added:</h6>
                    <div class="custom-positions-list" id="editCustomPositionsList"></div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-cancel" onclick="closeEditPositionModal()">Cancel</button>
                <button type="button" class="btn btn-save" onclick="saveEditPositions()">Save Positions</button>
            </div>
        </div>
    </div>

    <!-- View Employee Modal -->
    <div id="viewEmployeeModal" class="modal" style="<?= isset($_GET['view']) ? 'display: flex;' : 'display: none;' ?>">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-user"></i> Employee Details</h3>
                <button class="modal-close" onclick="closeViewEmployeeModal()">&times;</button>
            </div>
            <div class="modal-body">
                <?php if (isset($employee)): ?>
                <div class="employee-details">
                    <div class="form-section">
                        <h4><i class="fas fa-id-card"></i> Personal Information</h4>
                        <div class="form-group">
                            <label>Full Name:</label>
                            <p><?= htmlspecialchars($employee['first_name'] . ' ' . ($employee['middle_name'] ? $employee['middle_name'] . ' ' : '') . $employee['last_name']) ?></p>
                        </div>
                        <div class="form-group">
                            <label>Date of Birth:</label>
                            <?php 
                            $dob_display = formatDateForDisplay($employee['dob'] ?? '');
                            echo '<p>' . ($dob_display ?: 'Not specified') . '</p>';
                            ?>
                        </div>
                        <div class="form-group">
                            <label>Gender:</label>
                            <p><?= htmlspecialchars($employee['gender']) ?></p>
                        </div>
                        <div class="form-group">
                            <label>Civil Status:</label>
                            <p><?= htmlspecialchars($employee['civil_status']) ?></p>
                        </div>
                        <div class="form-group">
                            <label>Address:</label>
                            <p><?= htmlspecialchars($employee['address']) ?></p>
                        </div>
                    </div>
                    
                    <div class="form-section">
                        <h4><i class="fas fa-briefcase"></i> Employment Details</h4>
                        <div class="form-group">
                            <label>Employee ID:</label>
                            <p><?= $employee['id'] ?></p>
                        </div>
                        <div class="form-group">
                            <label>Position:</label>
                            <p class="position-display"><?= str_replace(', ', ' / ', htmlspecialchars($employee['position'])) ?></p>
                        </div>
                        <div class="form-group">
                            <label>Date Hired:</label>
                            <?php 
                            $hired_display = formatDateForDisplay($employee['date_hired'] ?? '');
                            echo '<p>' . ($hired_display ?: 'Not specified') . '</p>';
                            ?>
                        </div>
                        <div class="form-group">
                            <label>Monthly Salary:</label>
                            <p>₱<?= number_format($employee['monthly_salary'], 2) ?></p>
                        </div>
                        <div class="form-group">
                            <label>Email:</label>
                            <p><?= htmlspecialchars($employee['email']) ?></p>
                        </div>
                        <div class="form-group">
                            <label>Contact Number:</label>
                            <p><?= htmlspecialchars($employee['contact_num']) ?></p>
                        </div>
                        <div class="form-group">
                            <label>Status:</label>
                            <p>
                                <span class="status-badge <?php echo ($employee['status'] ?? 'active') == 'active' ? 'status-active' : 'status-inactive'; ?>">
                                    <i class="fas fa-circle" style="font-size: 0.6rem;"></i>
                                    <?php echo ucfirst($employee['status'] ?? 'active'); ?>
                                </span>
                            </p>
                        </div>
                    </div>
                    
                    <!-- Government IDs Section -->
                    <?php if (!empty($employee['sss_number']) || !empty($employee['pagibig_number']) || !empty($employee['tin_number']) || !empty($employee['philhealth_number'])): ?>
                    <div class="form-section" style="grid-column: 1 / -1;">
                        <h4><i class="fas fa-id-card"></i> Government Identification Numbers</h4>
                        <div class="govt-id-container">
                            <?php if (!empty($employee['sss_number'])): ?>
                            <div class="govt-id-badge">
                                <i class="fas fa-shield-alt"></i>
                                <div>
                                    <strong>SSS:</strong> <?= htmlspecialchars($employee['sss_number']) ?>
                                </div>
                            </div>
                            <?php endif; ?>
                            
                            <?php if (!empty($employee['pagibig_number'])): ?>
                            <div class="govt-id-badge">
                                <i class="fas fa-home"></i>
                                <div>
                                    <strong>PAG-IBIG:</strong> <?= htmlspecialchars($employee['pagibig_number']) ?>
                                </div>
                            </div>
                            <?php endif; ?>
                            
                            <?php if (!empty($employee['tin_number'])): ?>
                            <div class="govt-id-badge">
                                <i class="fas fa-file-invoice-dollar"></i>
                                <div>
                                    <strong>TIN:</strong> <?= htmlspecialchars($employee['tin_number']) ?>
                                </div>
                            </div>
                            <?php endif; ?>
                            
                            <?php if (!empty($employee['philhealth_number'])): ?>
                            <div class="govt-id-badge">
                                <i class="fas fa-heartbeat"></i>
                                <div>
                                    <strong>PhilHealth:</strong> <?= htmlspecialchars($employee['philhealth_number']) ?>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-cancel" onclick="closeViewEmployeeModal()">Close</button>
            </div>
        </div>
    </div>

    <!-- Edit Employee Modal -->
    <div id="editEmployeeModal" class="modal" style="<?= isset($_GET['edit']) ? 'display: flex;' : 'display: none;' ?>">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-edit"></i> Edit Employee</h3>
                <button class="modal-close" onclick="closeEditEmployeeModal()">&times;</button>
            </div>
            <form method="POST" action="employee.php">
                <input type="hidden" name="id" value="<?= isset($employee_edit['id']) ? htmlspecialchars($employee_edit['id']) : '' ?>">
                
                <div class="modal-body">
                    <div class="employee-form">
                        <div class="form-section">
                            <h4><i class="fas fa-user"></i> Personal Information</h4>
                            <div class="form-group">
                                <label for="edit_first_name">First Name *</label>
                                <input type="text" id="edit_first_name" name="first_name" 
                                       value="<?= htmlspecialchars($employee_edit['first_name'] ?? '') ?>" 
                                       required placeholder="Enter first name" 
                                       autocomplete="off">
                            </div>
                            <div class="form-group">
                                <label for="edit_middle_name">Middle Name</label>
                                <input type="text" id="edit_middle_name" name="middle_name" 
                                       value="<?= htmlspecialchars($employee_edit['middle_name'] ?? '') ?>" 
                                       placeholder="Enter middle name" 
                                       autocomplete="off">
                            </div>
                            <div class="form-group">
                                <label for="edit_last_name">Last Name *</label>
                                <input type="text" id="edit_last_name" name="last_name" 
                                       value="<?= htmlspecialchars($employee_edit['last_name'] ?? '') ?>" 
                                       required placeholder="Enter last name" 
                                       autocomplete="off">
                            </div>
                            <div class="form-group">
                                <label for="edit_dob">Date of Birth *</label>
                                <div class="date-picker-wrapper">
                                    <div class="date-input-group">
                                        <input type="text" 
                                               id="editDobField" 
                                               class="date-field" 
                                               value="<?= formatDateForDisplay($employee_edit['dob'] ?? '') ?>"
                                               placeholder="MM/DD/YYYY"
                                               autocomplete="off"
                                               readonly
                                               onclick="toggleCalendar('editDob')">
                                        <input type="hidden" id="edit_dob" name="dob" value="<?= htmlspecialchars($employee_edit['dob'] ?? '') ?>">
                                        <button type="button" class="calendar-dropdown-btn" onclick="toggleCalendar('editDob')">
                                            <i class="fas fa-chevron-down"></i>
                                        </button>
                                    </div>
                                    
                                    <div class="calendar-wrapper" id="editDobCalendar">
                                        <div class="calendar-box">
                                            <div class="calendar-header">
                                                <div class="calendar-month-year" id="editDobMonthYear"></div>
                                                <div class="calendar-nav">
                                                    <button type="button" class="calendar-nav-btn" onclick="navigateMonth('editDob', -1)">‹</button>
                                                    <button type="button" class="calendar-nav-btn" onclick="navigateMonth('editDob', 1)">›</button>
                                                </div>
                                            </div>
                                            
                                            <div class="calendar-selectors">
                                                <select id="editDobMonthSelect" class="calendar-select" onchange="changeMonthYear('editDob')">
                                                    <option value="0">January</option>
                                                    <option value="1">February</option>
                                                    <option value="2">March</option>
                                                    <option value="3">April</option>
                                                    <option value="4">May</option>
                                                    <option value="5">June</option>
                                                    <option value="6">July</option>
                                                    <option value="7">August</option>
                                                    <option value="8">September</option>
                                                    <option value="9">October</option>
                                                    <option value="10">November</option>
                                                    <option value="11">December</option>
                                                </select>
                                                
                                                <select id="editDobYearSelect" class="calendar-select" onchange="changeMonthYear('editDob')">
                                                </select>
                                            </div>
                                            
                                            <div class="calendar-weekdays">
                                                <div>Su</div>
                                                <div>Mo</div>
                                                <div>Tu</div>
                                                <div>We</div>
                                                <div>Th</div>
                                                <div>Fr</div>
                                                <div>Sa</div>
                                            </div>
                                            
                                            <div class="calendar-days-grid" id="editDobDaysGrid">
                                            </div>
                                            
                                            <div class="calendar-footer">
                                                <button type="button" class="calendar-action-btn clear" onclick="clearDate('editDob')">
                                                    <i class="fas fa-times"></i> Clear
                                                </button>
                                                <button type="button" class="calendar-action-btn today" onclick="setToday('editDob')">
                                                    <i class="fas fa-calendar-check"></i> Today
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <small style="color: #666;">Select a valid date</small>
                            </div>
                            <div class="form-group">
                                <label for="edit_gender">Gender *</label>
                                <select id="edit_gender" name="gender" required>
                                    <option value="Male" <?= (isset($employee_edit['gender']) && $employee_edit['gender'] == 'Male') ? 'selected' : '' ?>>Male</option>
                                    <option value="Female" <?= (isset($employee_edit['gender']) && $employee_edit['gender'] == 'Female') ? 'selected' : '' ?>>Female</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="edit_civil_status">Civil Status *</label>
                                <select id="edit_civil_status" name="civil_status" required>
                                    <option value="Single" <?= (isset($employee_edit['civil_status']) && $employee_edit['civil_status'] == 'Single') ? 'selected' : '' ?>>Single</option>
                                    <option value="Married" <?= (isset($employee_edit['civil_status']) && $employee_edit['civil_status'] == 'Married') ? 'selected' : '' ?>>Married</option>
                                    <option value="Widowed" <?= (isset($employee_edit['civil_status']) && $employee_edit['civil_status'] == 'Widowed') ? 'selected' : '' ?>>Widowed</option>
                                    <option value="Separated" <?= (isset($employee_edit['civil_status']) && $employee_edit['civil_status'] == 'Separated') ? 'selected' : '' ?>>Separated</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="form-section">
                            <h4><i class="fas fa-briefcase"></i> Employment Details</h4>
                            <div class="form-group">
                                <label for="edit_position">Position *</label>
                                <input type="text" id="edit_position" name="position" 
                                       value="<?= htmlspecialchars($employee_edit['position'] ?? '') ?>" 
                                       required placeholder="Select position below" 
                                       autocomplete="off" readonly>
                            </div>
                            
                            <!-- Position Selection Area for Edit -->
                            <div class="position-selection-container">
                                <button type="button" class="select-position-btn" onclick="showEditPositionModal()">
                                    <i class="fas fa-tasks"></i> Select Position(s)
                                </button>
                                <div class="selected-positions" id="editSelectedPositionsDisplay">
                                    <!-- Selected positions will appear here -->
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="edit_date_hired">Date Hired *</label>
                                <div class="date-picker-wrapper">
                                    <div class="date-input-group">
                                        <input type="text" 
                                               id="editHiredField" 
                                               class="date-field" 
                                               value="<?= formatDateForDisplay($employee_edit['date_hired'] ?? '') ?>"
                                               placeholder="MM/DD/YYYY"
                                               autocomplete="off"
                                               readonly
                                               onclick="toggleCalendar('editHired')">
                                        <input type="hidden" id="edit_date_hired" name="date_hired" value="<?= htmlspecialchars($employee_edit['date_hired'] ?? '') ?>">
                                        <button type="button" class="calendar-dropdown-btn" onclick="toggleCalendar('editHired')">
                                            <i class="fas fa-chevron-down"></i>
                                        </button>
                                    </div>
                                    
                                    <div class="calendar-wrapper" id="editHiredCalendar">
                                        <div class="calendar-box">
                                            <div class="calendar-header">
                                                <div class="calendar-month-year" id="editHiredMonthYear"></div>
                                                <div class="calendar-nav">
                                                    <button type="button" class="calendar-nav-btn" onclick="navigateMonth('editHired', -1)">‹</button>
                                                    <button type="button" class="calendar-nav-btn" onclick="navigateMonth('editHired', 1)">›</button>
                                                </div>
                                            </div>
                                            
                                            <div class="calendar-selectors">
                                                <select id="editHiredMonthSelect" class="calendar-select" onchange="changeMonthYear('editHired')">
                                                    <option value="0">January</option>
                                                    <option value="1">February</option>
                                                    <option value="2">March</option>
                                                    <option value="3">April</option>
                                                    <option value="4">May</option>
                                                    <option value="5">June</option>
                                                    <option value="6">July</option>
                                                    <option value="7">August</option>
                                                    <option value="8">September</option>
                                                    <option value="9">October</option>
                                                    <option value="10">November</option>
                                                    <option value="11">December</option>
                                                </select>
                                                
                                                <select id="editHiredYearSelect" class="calendar-select" onchange="changeMonthYear('editHired')">
                                                </select>
                                            </div>
                                            
                                            <div class="calendar-weekdays">
                                                <div>Su</div>
                                                <div>Mo</div>
                                                <div>Tu</div>
                                                <div>We</div>
                                                <div>Th</div>
                                                <div>Fr</div>
                                                <div>Sa</div>
                                            </div>
                                            
                                            <div class="calendar-days-grid" id="editHiredDaysGrid">
                                            </div>
                                            
                                            <div class="calendar-footer">
                                                <button type="button" class="calendar-action-btn clear" onclick="clearDate('editHired')">
                                                    <i class="fas fa-times"></i> Clear
                                                </button>
                                                <button type="button" class="calendar-action-btn today" onclick="setToday('editHired')">
                                                    <i class="fas fa-calendar-check"></i> Today
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <small style="color: #666;">Select a valid date</small>
                            </div>
                            <div class="form-group">
                                <label for="edit_monthly_salary">Monthly Salary *</label>
                                <input type="number" id="edit_monthly_salary" name="monthly_salary" 
                                       value="<?= htmlspecialchars($employee_edit['monthly_salary'] ?? '') ?>" 
                                       required placeholder="Enter monthly salary" 
                                       autocomplete="off" step="0.01" min="0">
                            </div>
                            <div class="form-group">
                                <label for="edit_email">Email Address *</label>
                                <input type="email" id="edit_email" name="email" 
                                       value="<?= htmlspecialchars($employee_edit['email'] ?? '') ?>" 
                                       required placeholder="Enter email address" 
                                       autocomplete="off">
                            </div>
                            <div class="form-group">
                                <label for="edit_contact_num">Contact Number *</label>
                                <input type="text" id="edit_contact_num" name="contact_num" 
                                       value="<?= htmlspecialchars($employee_edit['contact_num'] ?? '') ?>" 
                                       required placeholder="Enter contact number" 
                                       autocomplete="off">
                            </div>
                            <div class="form-group">
                                <label for="edit_address">Address *</label>
                                <input type="text" id="edit_address" name="address" 
                                       value="<?= htmlspecialchars($employee_edit['address'] ?? '') ?>" 
                                       required placeholder="Enter address" 
                                       autocomplete="off">
                            </div>
                        </div>
                        
                        <div class="govt-id-section">
                            <h4><i class="fas fa-id-card"></i> Government Identification Numbers</h4>
                            <p style="color: #666; font-size: 0.9rem; margin-bottom: 15px;">Optional: Provide government identification numbers for payroll processing</p>
                            <div class="govt-id-grid">
                                <div class="form-group">
                                    <label for="edit_sss_number">SSS Number</label>
                                    <input type="text" id="edit_sss_number" name="sss_number" 
                                           value="<?= htmlspecialchars($employee_edit['sss_number'] ?? '') ?>" 
                                           placeholder="XX-XXXXXXX-X" 
                                           pattern="[0-9]{2}-[0-9]{7}-[0-9]{1}"
                                           title="Format: XX-XXXXXXX-X"
                                           autocomplete="off">
                                    <small style="color: #888; font-size: 0.8rem;">Format: XX-XXXXXXX-X</small>
                                </div>
                                <div class="form-group">
                                    <label for="edit_pagibig_number">PAG-IBIG Number</label>
                                    <input type="text" id="edit_pagibig_number" name="pagibig_number" 
                                           value="<?= htmlspecialchars($employee_edit['pagibig_number'] ?? '') ?>" 
                                           placeholder="XXXX-XXXX-XXXX" 
                                           pattern="[0-9]{4}-[0-9]{4}-[0-9]{4}"
                                           title="Format: XXXX-XXXX-XXXX"
                                           autocomplete="off">
                                    <small style="color: #888; font-size: 0.8rem;">Format: XXXX-XXXX-XXXX</small>
                                </div>
                                <div class="form-group">
                                    <label for="edit_tin_number">TIN Number</label>
                                    <input type="text" id="edit_tin_number" name="tin_number" 
                                           value="<?= htmlspecialchars($employee_edit['tin_number'] ?? '') ?>" 
                                           placeholder="XXX-XXX-XXX-XXX" 
                                           pattern="[0-9]{3}-[0-9]{3}-[0-9]{3}-[0-9]{3}"
                                           title="Format: XXX-XXX-XXX-XXX"
                                           autocomplete="off">
                                    <small style="color: #888; font-size: 0.8rem;">Format: XXX-XXX-XXX-XXX</small>
                                </div>
                                <div class="form-group">
                                    <label for="edit_philhealth_number">PhilHealth Number</label>
                                    <input type="text" id="edit_philhealth_number" name="philhealth_number" 
                                           value="<?= htmlspecialchars($employee_edit['philhealth_number'] ?? '') ?>" 
                                           placeholder="XX-XXXXXXXXX-X" 
                                           pattern="[0-9]{2}-[0-9]{9}-[0-9]{1}"
                                           title="Format: XX-XXXXXXXXX-X"
                                           autocomplete="off">
                                    <small style="color: #888; font-size: 0.8rem;">Format: XX-XXXXXXXXX-X</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-cancel" onclick="closeEditEmployeeModal()">Cancel</button>
                    <button type="submit" name="update_employee" class="btn btn-save">Update Employee</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        // Calendar state
        let activeCalendar = null;
        let calendarDates = {
            dob: { currentDate: new Date(), selectedDate: null },
            hired: { currentDate: new Date(), selectedDate: null },
            editDob: { currentDate: new Date(), selectedDate: null },
            editHired: { currentDate: new Date(), selectedDate: null }
        };

        // Position selection state
        let selectedPositions = [];
        let editSelectedPositions = [];
        let currentCategory = 'executive';
        let editCurrentCategory = 'executive';
        let customPositions = [];
        let editCustomPositions = [];

        // Position data by category
        const positionsByCategory = {
            executive: [
                'Chief Executive Officer',
                'General Manager',
                'Sales and Marketing Manager'
            ],
            technical: [
                'Technical Director',
                'Design Department Head',
                'Design Engineer',
                'Design Technical Engineer',
                'CAD operator',
                'Implementation',
                'Technical Department Head',
                'Site Engineer',
                'Safety Officer 2',
                'Lead man',
                'Electrician',
                'carpenter',
                'welder',
                'Electronics',
                'Painter',
                'Scaffolder',
                'Safety Officer Department Head'
            ],
            admin: [
                'Admin',
                'Purchasing',
                'HR Manager',
                'Finance and Administrative Officer',
                'Maintenance'
            ]
        };

        // Toast notification function
        function showToast(message, type = 'success', duration = 5000) {
            const container = document.getElementById('toastContainer');
            if (!container) return;
            
            const toast = document.createElement('div');
            toast.className = `toast ${type}`;
            
            let icon = '';
            switch(type) {
                case 'success':
                    icon = '<i class="fas fa-check-circle"></i>';
                    break;
                case 'error':
                    icon = '<i class="fas fa-exclamation-circle"></i>';
                    break;
                case 'warning':
                    icon = '<i class="fas fa-exclamation-triangle"></i>';
                    break;
                default:
                    icon = '<i class="fas fa-info-circle"></i>';
            }
            
            toast.innerHTML = `
                ${icon}
                <div class="toast-content">${message}</div>
                <button class="toast-close" onclick="this.parentElement.remove()">&times;</button>
            `;
            
            container.appendChild(toast);
            
            setTimeout(() => {
                toast.style.animation = 'slideOut 0.3s ease';
                setTimeout(() => {
                    if (toast.parentElement) {
                        toast.remove();
                    }
                }, 300);
            }, duration);
        }

        // Check for stored toast messages
        document.addEventListener('DOMContentLoaded', function() {
            const toastMessage = localStorage.getItem('toastMessage');
            const toastType = localStorage.getItem('toastType');
            
            if (toastMessage) {
                showToast(toastMessage, toastType || 'success');
                localStorage.removeItem('toastMessage');
                localStorage.removeItem('toastType');
            }
            
            // Set initial selected dates from hidden inputs
            const dobHidden = document.getElementById('dob');
            const hiredHidden = document.getElementById('date_hired');
            const editDobHidden = document.getElementById('edit_dob');
            const editHiredHidden = document.getElementById('edit_date_hired');
            
            if (dobHidden && dobHidden.value) {
                calendarDates.dob.selectedDate = dobHidden.value;
                const dobField = document.getElementById('dobField');
                if (dobField && dobHidden.value) {
                    const date = new Date(dobHidden.value);
                    dobField.value = date.toLocaleDateString('en-US', {
                        month: '2-digit',
                        day: '2-digit',
                        year: 'numeric'
                    });
                }
            }
            
            if (hiredHidden && hiredHidden.value) {
                calendarDates.hired.selectedDate = hiredHidden.value;
                const hiredField = document.getElementById('dateHiredField');
                if (hiredField && hiredHidden.value) {
                    const date = new Date(hiredHidden.value);
                    hiredField.value = date.toLocaleDateString('en-US', {
                        month: '2-digit',
                        day: '2-digit',
                        year: 'numeric'
                    });
                }
            }
            
            if (editDobHidden && editDobHidden.value) {
                calendarDates.editDob.selectedDate = editDobHidden.value;
                const editDobField = document.getElementById('editDobField');
                if (editDobField && editDobHidden.value) {
                    const date = new Date(editDobHidden.value);
                    editDobField.value = date.toLocaleDateString('en-US', {
                        month: '2-digit',
                        day: '2-digit',
                        year: 'numeric'
                    });
                }
            }
            
            if (editHiredHidden && editHiredHidden.value) {
                calendarDates.editHired.selectedDate = editHiredHidden.value;
                const editHiredField = document.getElementById('editHiredField');
                if (editHiredField && editHiredHidden.value) {
                    const date = new Date(editHiredHidden.value);
                    editHiredField.value = date.toLocaleDateString('en-US', {
                        month: '2-digit',
                        day: '2-digit',
                        year: 'numeric'
                    });
                }
            }

            // Initialize edit positions if in edit mode
            <?php if (isset($employee_edit['position'])): ?>
            editSelectedPositions = <?= json_encode(explode(', ', $employee_edit['position'])) ?>;
            updateEditPositionsDisplay();
            <?php endif; ?>
        });

        // Initialize year dropdowns
        function initializeYearSelects() {
            const yearSelects = ['dobYearSelect', 'hiredYearSelect', 'editDobYearSelect', 'editHiredYearSelect'];
            const currentYear = new Date().getFullYear();
            
            yearSelects.forEach(selectId => {
                const select = document.getElementById(selectId);
                if (select) {
                    select.innerHTML = '';
                    for (let year = 1900; year <= 2100; year++) {
                        const option = document.createElement('option');
                        option.value = year;
                        option.textContent = year;
                        if (year === currentYear) {
                            option.selected = true;
                        }
                        select.appendChild(option);
                    }
                }
            });
        }

        // Toggle calendar
        function toggleCalendar(calendarId) {
            const calendar = document.getElementById(calendarId + 'Calendar');
            if (calendar) {
                document.querySelectorAll('.calendar-wrapper').forEach(cal => {
                    if (cal.id !== calendarId + 'Calendar') {
                        cal.style.display = 'none';
                    }
                });
                
                if (calendar.style.display === 'block') {
                    calendar.style.display = 'none';
                    activeCalendar = null;
                } else {
                    updateCalendar(calendarId);
                    calendar.style.display = 'block';
                    activeCalendar = calendarId;
                }
            }
        }

        // Update calendar display
        function updateCalendar(calendarId) {
            const date = calendarDates[calendarId].currentDate || new Date();
            const year = date.getFullYear();
            const month = date.getMonth();
            
            const monthYearElement = document.getElementById(calendarId + 'MonthYear');
            if (monthYearElement) {
                monthYearElement.textContent = date.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
            }
            
            const monthSelect = document.getElementById(calendarId + 'MonthSelect');
            const yearSelect = document.getElementById(calendarId + 'YearSelect');
            
            if (monthSelect) monthSelect.value = month;
            if (yearSelect) yearSelect.value = year;
            
            generateCalendarDays(calendarId);
        }

        // Generate calendar days
        function generateCalendarDays(calendarId) {
            const date = calendarDates[calendarId].currentDate || new Date();
            const year = date.getFullYear();
            const month = date.getMonth();
            const daysGrid = document.getElementById(calendarId + 'DaysGrid');
            
            if (!daysGrid) return;
            
            const firstDay = new Date(year, month, 1).getDay();
            const daysInMonth = new Date(year, month + 1, 0).getDate();
            const today = new Date();
            const selectedDate = calendarDates[calendarId].selectedDate;
            
            let html = '';
            
            // Previous month days
            const prevMonthDays = new Date(year, month, 0).getDate();
            for (let i = firstDay - 1; i >= 0; i--) {
                const day = prevMonthDays - i;
                const dateStr = `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
                html += `<div class="calendar-day other-month" onclick="selectDate('${calendarId}', '${dateStr}')">${day}</div>`;
            }
            
            // Current month days
            for (let day = 1; day <= daysInMonth; day++) {
                const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
                const isToday = today.getFullYear() === year && today.getMonth() === month && today.getDate() === day;
                const isSelected = selectedDate === dateStr;
                const isWeekend = new Date(year, month, day).getDay() === 0 || new Date(year, month, day).getDay() === 6;
                
                let classes = 'calendar-day';
                if (isToday) classes += ' today';
                if (isSelected) classes += ' selected';
                if (isWeekend) classes += ' weekend';
                
                html += `<div class="${classes}" onclick="selectDate('${calendarId}', '${dateStr}')">${day}</div>`;
            }
            
            // Next month days
            const totalCells = 42;
            const cellsUsed = firstDay + daysInMonth;
            const nextMonthDays = totalCells - cellsUsed;
            for (let day = 1; day <= nextMonthDays; day++) {
                const dateStr = `${year}-${String(month + 2).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
                html += `<div class="calendar-day other-month" onclick="selectDate('${calendarId}', '${dateStr}')">${day}</div>`;
            }
            
            daysGrid.innerHTML = html;
        }

        // Navigate months
        function navigateMonth(calendarId, direction) {
            const date = calendarDates[calendarId].currentDate;
            date.setMonth(date.getMonth() + direction);
            updateCalendar(calendarId);
        }

        // Change month/year from selects
        function changeMonthYear(calendarId) {
            const monthSelect = document.getElementById(calendarId + 'MonthSelect');
            const yearSelect = document.getElementById(calendarId + 'YearSelect');
            
            if (monthSelect && yearSelect) {
                const newMonth = parseInt(monthSelect.value);
                const newYear = parseInt(yearSelect.value);
                
                calendarDates[calendarId].currentDate = new Date(newYear, newMonth, 1);
                updateCalendar(calendarId);
            }
        }

        // Select a date
        function selectDate(calendarId, dateStr) {
            const date = new Date(dateStr);
            const formattedDisplay = date.toLocaleDateString('en-US', {
                month: '2-digit',
                day: '2-digit',
                year: 'numeric'
            });
            
            let fieldId = '';
            let hiddenId = '';
            
            switch(calendarId) {
                case 'dob':
                    fieldId = 'dobField';
                    hiddenId = 'dob';
                    break;
                case 'hired':
                    fieldId = 'dateHiredField';
                    hiddenId = 'date_hired';
                    break;
                case 'editDob':
                    fieldId = 'editDobField';
                    hiddenId = 'edit_dob';
                    break;
                case 'editHired':
                    fieldId = 'editHiredField';
                    hiddenId = 'edit_date_hired';
                    break;
            }
            
            const field = document.getElementById(fieldId);
            const hidden = document.getElementById(hiddenId);
            
            if (field) {
                field.value = formattedDisplay;
            }
            
            if (hidden) {
                hidden.value = dateStr;
            }
            
            calendarDates[calendarId].selectedDate = dateStr;
            
            const calendar = document.getElementById(calendarId + 'Calendar');
            if (calendar) calendar.style.display = 'none';
            activeCalendar = null;
            
            updateCalendar(calendarId);
        }

        // Clear date
        function clearDate(calendarId) {
            let fieldId = '';
            let hiddenId = '';
            
            switch(calendarId) {
                case 'dob':
                    fieldId = 'dobField';
                    hiddenId = 'dob';
                    break;
                case 'hired':
                    fieldId = 'dateHiredField';
                    hiddenId = 'date_hired';
                    break;
                case 'editDob':
                    fieldId = 'editDobField';
                    hiddenId = 'edit_dob';
                    break;
                case 'editHired':
                    fieldId = 'editHiredField';
                    hiddenId = 'edit_date_hired';
                    break;
            }
            
            const field = document.getElementById(fieldId);
            const hidden = document.getElementById(hiddenId);
            
            if (field) field.value = '';
            if (hidden) hidden.value = '';
            
            calendarDates[calendarId].selectedDate = null;
            
            const calendar = document.getElementById(calendarId + 'Calendar');
            if (calendar) calendar.style.display = 'none';
            activeCalendar = null;
            
            updateCalendar(calendarId);
        }

        // Set today's date
        function setToday(calendarId) {
            const today = new Date();
            const year = today.getFullYear();
            const month = String(today.getMonth() + 1).padStart(2, '0');
            const day = String(today.getDate()).padStart(2, '0');
            const dateStr = `${year}-${month}-${day}`;
            
            calendarDates[calendarId].currentDate = new Date(dateStr);
            selectDate(calendarId, dateStr);
        }

        // Position Modal Functions
        function showPositionModal() {
            document.getElementById('positionModal').style.display = 'flex';
            document.body.classList.add('modal-open');
            currentCategory = 'executive';
            updateCategoryButtons('positionModal', currentCategory);
            loadPositions(currentCategory);
            loadCustomPositionsSection();
        }

        function closePositionModal() {
            document.getElementById('positionModal').style.display = 'none';
            document.body.classList.remove('modal-open');
        }

        function showEditPositionModal() {
            document.getElementById('editPositionModal').style.display = 'flex';
            document.body.classList.add('modal-open');
            editCurrentCategory = 'executive';
            updateCategoryButtons('editPositionModal', editCurrentCategory);
            loadEditPositions(editCurrentCategory);
            loadEditCustomPositionsSection();
        }

        function closeEditPositionModal() {
            document.getElementById('editPositionModal').style.display = 'none';
            document.body.classList.remove('modal-open');
        }

        function updateCategoryButtons(modalId, activeCategory) {
            const modal = document.getElementById(modalId);
            const btns = modal.querySelectorAll('.category-btn');
            btns.forEach(btn => btn.classList.remove('active'));
            const activeBtn = modal.querySelector(`#${modalId === 'positionModal' ? 'cat' : 'editCat'}${activeCategory.charAt(0).toUpperCase() + activeCategory.slice(1)}`);
            if (activeBtn) activeBtn.classList.add('active');
        }

        function loadPositions(category) {
            const container = document.getElementById('positionChecklist');
            container.innerHTML = '';
            
            let html = '';
            positionsByCategory[category].forEach(position => {
                const isChecked = selectedPositions.includes(position) ? 'checked' : '';
                html += `
                    <div class="position-checkbox-item">
                        <input type="checkbox" value="${position}" ${isChecked} onchange="updatePositionCheckboxes()">
                        <label>${position}</label>
                    </div>
                `;
            });
            
            container.innerHTML = html;
        }

        function loadEditPositions(category) {
            const container = document.getElementById('editPositionChecklist');
            container.innerHTML = '';
            
            let html = '';
            positionsByCategory[category].forEach(position => {
                const isChecked = editSelectedPositions.includes(position) ? 'checked' : '';
                html += `
                    <div class="position-checkbox-item">
                        <input type="checkbox" value="${position}" ${isChecked} onchange="updateEditPositionCheckboxes()">
                        <label>${position}</label>
                    </div>
                `;
            });
            
            container.innerHTML = html;
        }

        function showPositionCategory(category) {
            currentCategory = category;
            updateCategoryButtons('positionModal', category);
            loadPositions(category);
            document.getElementById('customPositionInput').style.display = 'none';
            document.getElementById('addPositionBtn').style.display = 'block';
        }

        function showEditPositionCategory(category) {
            editCurrentCategory = category;
            updateCategoryButtons('editPositionModal', category);
            loadEditPositions(category);
            document.getElementById('editCustomPositionInput').style.display = 'none';
            document.getElementById('editAddPositionBtn').style.display = 'block';
        }

        function toggleCustomPositionInput() {
            const input = document.getElementById('customPositionInput');
            if (input.style.display === 'none' || input.style.display === '') {
                input.style.display = 'flex';
                document.getElementById('addPositionBtn').style.display = 'none';
            } else {
                input.style.display = 'none';
                document.getElementById('addPositionBtn').style.display = 'block';
            }
        }

        function toggleEditCustomPositionInput() {
            const input = document.getElementById('editCustomPositionInput');
            if (input.style.display === 'none' || input.style.display === '') {
                input.style.display = 'flex';
                document.getElementById('editAddPositionBtn').style.display = 'none';
            } else {
                input.style.display = 'none';
                document.getElementById('editAddPositionBtn').style.display = 'block';
            }
        }

        function addCustomPosition() {
            const input = document.getElementById('newPositionName');
            const positionName = input.value.trim();
            
            if (positionName === '') {
                showToast('Please enter a position name', 'warning');
                return;
            }

            if (!customPositions.includes(positionName) && !selectedPositions.includes(positionName)) {
                customPositions.push(positionName);
                selectedPositions.push(positionName);
                loadCustomPositionsSection();
                input.value = '';
                document.getElementById('customPositionInput').style.display = 'none';
                document.getElementById('addPositionBtn').style.display = 'block';
                showToast('Custom position added successfully', 'success');
            } else {
                showToast('This position already exists', 'warning');
            }
        }

        function addEditCustomPosition() {
            const input = document.getElementById('editNewPositionName');
            const positionName = input.value.trim();
            
            if (positionName === '') {
                showToast('Please enter a position name', 'warning');
                return;
            }

            if (!editCustomPositions.includes(positionName) && !editSelectedPositions.includes(positionName)) {
                editCustomPositions.push(positionName);
                editSelectedPositions.push(positionName);
                loadEditCustomPositionsSection();
                input.value = '';
                document.getElementById('editCustomPositionInput').style.display = 'none';
                document.getElementById('editAddPositionBtn').style.display = 'block';
                showToast('Custom position added successfully', 'success');
            } else {
                showToast('This position already exists', 'warning');
            }
        }

        function removeCustomPosition(position) {
            customPositions = customPositions.filter(p => p !== position);
            selectedPositions = selectedPositions.filter(p => p !== position);
            loadCustomPositionsSection();
            updatePositionsDisplay();
        }

        function removeEditCustomPosition(position) {
            editCustomPositions = editCustomPositions.filter(p => p !== position);
            editSelectedPositions = editSelectedPositions.filter(p => p !== position);
            loadEditCustomPositionsSection();
            updateEditPositionsDisplay();
        }

        function loadCustomPositionsSection() {
            const section = document.getElementById('customPositionsSection');
            const list = document.getElementById('customPositionsList');
            
            if (customPositions.length > 0) {
                section.style.display = 'block';
                list.innerHTML = '';
                customPositions.forEach(position => {
                    const tag = document.createElement('span');
                    tag.className = 'custom-position-tag';
                    tag.innerHTML = `${position} <i class="fas fa-times" onclick="removeCustomPosition('${position}')"></i>`;
                    list.appendChild(tag);
                });
            } else {
                section.style.display = 'none';
            }
        }

        function loadEditCustomPositionsSection() {
            const section = document.getElementById('editCustomPositionsSection');
            const list = document.getElementById('editCustomPositionsList');
            
            if (editCustomPositions.length > 0) {
                section.style.display = 'block';
                list.innerHTML = '';
                editCustomPositions.forEach(position => {
                    const tag = document.createElement('span');
                    tag.className = 'custom-position-tag';
                    tag.innerHTML = `${position} <i class="fas fa-times" onclick="removeEditCustomPosition('${position}')"></i>`;
                    list.appendChild(tag);
                });
            } else {
                section.style.display = 'none';
            }
        }

        function updatePositionCheckboxes() {
            // This function can be used for any additional logic when checkboxes change
        }

        function updateEditPositionCheckboxes() {
            // This function can be used for any additional logic when checkboxes change
        }

        function savePositions() {
            const checkboxes = document.querySelectorAll('#positionModal .position-checkbox-item input[type="checkbox"]:checked');
            checkboxes.forEach(cb => {
                if (!selectedPositions.includes(cb.value)) {
                    selectedPositions.push(cb.value);
                }
            });
            
            // Update display
            updatePositionsDisplay();
            closePositionModal();
        }

        function saveEditPositions() {
            const checkboxes = document.querySelectorAll('#editPositionModal .position-checkbox-item input[type="checkbox"]:checked');
            checkboxes.forEach(cb => {
                if (!editSelectedPositions.includes(cb.value)) {
                    editSelectedPositions.push(cb.value);
                }
            });
            
            // Add custom positions to editSelectedPositions
            editCustomPositions.forEach(position => {
                if (!editSelectedPositions.includes(position)) {
                    editSelectedPositions.push(position);
                }
            });
            
            // Update display
            updateEditPositionsDisplay();
            closeEditPositionModal();
        }

        function updatePositionsDisplay() {
            const displayArea = document.getElementById('selectedPositionsDisplay');
            const positionInput = document.getElementById('position');
            
            if (displayArea && positionInput) {
                displayArea.innerHTML = '';
                selectedPositions.forEach(position => {
                    const tag = document.createElement('span');
                    tag.className = 'position-tag';
                    tag.innerHTML = `${position} <i class="fas fa-times delete-position" onclick="removeSelectedPosition('${position}')"></i>`;
                    displayArea.appendChild(tag);
                });
                
                positionInput.value = selectedPositions.join(', ');
            }
        }

        function updateEditPositionsDisplay() {
            const displayArea = document.getElementById('editSelectedPositionsDisplay');
            const positionInput = document.getElementById('edit_position');
            
            if (displayArea && positionInput) {
                displayArea.innerHTML = '';
                editSelectedPositions.forEach(position => {
                    const tag = document.createElement('span');
                    tag.className = 'position-tag';
                    tag.innerHTML = `${position} <i class="fas fa-times delete-position" onclick="removeEditSelectedPosition('${position}')"></i>`;
                    displayArea.appendChild(tag);
                });
                
                positionInput.value = editSelectedPositions.join(', ');
            }
        }

        function removeSelectedPosition(position) {
            selectedPositions = selectedPositions.filter(p => p !== position);
            customPositions = customPositions.filter(p => p !== position);
            updatePositionsDisplay();
        }

        function removeEditSelectedPosition(position) {
            editSelectedPositions = editSelectedPositions.filter(p => p !== position);
            editCustomPositions = editCustomPositions.filter(p => p !== position);
            updateEditPositionsDisplay();
        }

        // Close calendar when clicking outside
        document.addEventListener('click', function(e) {
            const isCalendarClick = e.target.closest('.calendar-wrapper') || e.target.closest('.date-input-group');
            if (!isCalendarClick && activeCalendar) {
                const calendar = document.getElementById(activeCalendar + 'Calendar');
                if (calendar) calendar.style.display = 'none';
                activeCalendar = null;
            }
        });

        // Close modal with Escape key
        document.addEventListener('keydown', function(event) {
            if (event.key === 'Escape') {
                if (activeCalendar) {
                    const calendar = document.getElementById(activeCalendar + 'Calendar');
                    if (calendar) calendar.style.display = 'none';
                    activeCalendar = null;
                } else {
                    closeAddEmployeeModal();
                    closeViewEmployeeModal();
                    closeEditEmployeeModal();
                    closePositionModal();
                    closeEditPositionModal();
                }
            }
        });

        // Initialize on page load
        document.addEventListener('DOMContentLoaded', function() {
            initializeYearSelects();
            
            ['dob', 'hired', 'editDob', 'editHired'].forEach(calId => {
                updateCalendar(calId);
            });
            
            const urlParams = new URLSearchParams(window.location.search);
            if (urlParams.has('view') || urlParams.has('edit')) {
                document.body.classList.add('modal-open');
            }
            
            // Format input masks for government IDs
            const sssInput = document.getElementById('sss_number');
            const pagibigInput = document.getElementById('pagibig_number');
            const tinInput = document.getElementById('tin_number');
            const philhealthInput = document.getElementById('philhealth_number');
            
            const editSssInput = document.getElementById('edit_sss_number');
            const editPagibigInput = document.getElementById('edit_pagibig_number');
            const editTinInput = document.getElementById('edit_tin_number');
            const editPhilhealthInput = document.getElementById('edit_philhealth_number');
            
            function formatSSS(input) {
                let value = input.value.replace(/\D/g, '');
                if (value.length > 0) {
                    value = value.substring(0, 2) + (value.length > 2 ? '-' + value.substring(2, 9) : '') + 
                           (value.length > 9 ? '-' + value.substring(9, 10) : '');
                }
                input.value = value;
            }
            
            function formatPagibig(input) {
                let value = input.value.replace(/\D/g, '');
                if (value.length > 0) {
                    value = value.substring(0, 4) + (value.length > 4 ? '-' + value.substring(4, 8) : '') + 
                           (value.length > 8 ? '-' + value.substring(8, 12) : '');
                }
                input.value = value;
            }
            
            function formatTIN(input) {
                let value = input.value.replace(/\D/g, '');
                if (value.length > 0) {
                    value = value.substring(0, 3) + (value.length > 3 ? '-' + value.substring(3, 6) : '') + 
                           (value.length > 6 ? '-' + value.substring(6, 9) : '') + 
                           (value.length > 9 ? '-' + value.substring(9, 12) : '');
                }
                input.value = value;
            }
            
            function formatPhilhealth(input) {
                let value = input.value.replace(/\D/g, '');
                if (value.length > 0) {
                    value = value.substring(0, 2) + (value.length > 2 ? '-' + value.substring(2, 11) : '') + 
                           (value.length > 11 ? '-' + value.substring(11, 12) : '');
                }
                input.value = value;
            }
            
            if (sssInput) sssInput.addEventListener('input', function() { formatSSS(this); });
            if (pagibigInput) pagibigInput.addEventListener('input', function() { formatPagibig(this); });
            if (tinInput) tinInput.addEventListener('input', function() { formatTIN(this); });
            if (philhealthInput) philhealthInput.addEventListener('input', function() { formatPhilhealth(this); });
            
            if (editSssInput) editSssInput.addEventListener('input', function() { formatSSS(this); });
            if (editPagibigInput) editPagibigInput.addEventListener('input', function() { formatPagibig(this); });
            if (editTinInput) editTinInput.addEventListener('input', function() { formatTIN(this); });
            if (editPhilhealthInput) editPhilhealthInput.addEventListener('input', function() { formatPhilhealth(this); });
        });

        // Modal functions
        function showAddEmployeeModal() {
            document.getElementById('addEmployeeModal').style.display = 'flex';
            document.body.classList.add('modal-open');
            document.getElementById('first_name').focus();
        }

        function closeAddEmployeeModal() {
            document.getElementById('addEmployeeModal').style.display = 'none';
            document.body.classList.remove('modal-open');
            const form = document.querySelector('#addEmployeeModal form');
            if (form) form.reset();
            clearDate('dob');
            clearDate('hired');
            selectedPositions = [];
            customPositions = [];
            updatePositionsDisplay();
        }

        function showViewEmployeeModal(employeeId) {
            window.location.href = 'employee.php?view=' + employeeId;
        }

        function closeViewEmployeeModal() {
            window.location.href = 'employee.php';
        }

        function showEditEmployeeModal(employeeId) {
            window.location.href = 'employee.php?edit=' + employeeId;
        }

        function closeEditEmployeeModal() {
            window.location.href = 'employee.php';
        }
        
        function confirmToggleStatus(event, employeeName, currentStatus) {
            const action = currentStatus === 'active' ? 'disable' : 'enable';
            const message = `Are you sure you want to ${action} employee "${employeeName}"?\n\n` +
                           `This will ${action} their account and remove them from any assigned sites.`;
            
            if (!confirm(message)) {
                event.preventDefault();
                return false;
            }
            return true;
        }

        function confirmDelete(event, employeeName) {
            const message = `Are you sure you want to permanently delete employee "${employeeName}"?\n\n` +
                           `This action cannot be undone and will remove all associated records.`;
            
            if (!confirm(message)) {
                event.preventDefault();
                return false;
            }
            return true;
        }

        window.onclick = function(event) {
            const addModal = document.getElementById('addEmployeeModal');
            const viewModal = document.getElementById('viewEmployeeModal');
            const editModal = document.getElementById('editEmployeeModal');
            const positionModal = document.getElementById('positionModal');
            const editPositionModal = document.getElementById('editPositionModal');
            
            if (event.target === addModal) closeAddEmployeeModal();
            if (event.target === viewModal) closeViewEmployeeModal();
            if (event.target === editModal) closeEditEmployeeModal();
            if (event.target === positionModal) closePositionModal();
            if (event.target === editPositionModal) closeEditPositionModal();
        }
    </script>
</body>
</html>