<?php 
session_start();

if (!isset($_SESSION['Admin_User'])) {
    header("Location: login.php");
    exit;
}

include_once("connection.php");

$month = isset($_GET['month']) ? $_GET['month'] : date('m');
$year = isset($_GET['year']) ? $_GET['year'] : date('Y');

if (isset($_GET['delete_id'])) {
    $payrollId = $_GET['delete_id'];
    $stmt = $conn->prepare("DELETE FROM payroll WHERE id = ?");
    $stmt->bind_param("i", $payrollId);
    if ($stmt->execute()) {
        echo "<script>alert('Payroll record deleted successfully'); window.location.href='payrollList.php';</script>";
    } else {
        echo "<script>alert('Error deleting payroll record');</script>";
    }
}

$sql = "
    SELECT p.id, p.date_from, p.date_to, 
           CONCAT(e.first_name, ' ', e.last_name) AS employee_name, 
           e.position, e.id as employee_id,
           e.monthly_salary,
           (e.monthly_salary - COALESCE(SUM(d.amount), 0)) AS net_pay,
           p.status
    FROM payroll p
    LEFT JOIN employees e ON e.id = p.employee_id
    LEFT JOIN deduction d ON d.employee_id = e.id 
        AND d.status = 'active'
        AND (d.start_date <= p.date_to AND d.end_date >= p.date_from)
    WHERE MONTH(p.date_from) = ? AND YEAR(p.date_from) = ?
    GROUP BY p.id, e.id, e.monthly_salary, p.status
    ORDER BY p.date_from DESC
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $month, $year);
$stmt->execute();
$result = $stmt->get_result();

$searchTerm = isset($_POST['search']) ? $_POST['search'] : '';
$searchSql = "SELECT id, first_name, last_name FROM employees WHERE CONCAT(first_name, ' ', last_name) LIKE ?";
$searchStmt = $conn->prepare($searchSql);
$searchTerm = '%' . $searchTerm . '%';
$searchStmt->bind_param("s", $searchTerm);
$searchStmt->execute();
$employeesResult = $searchStmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Payroll List</title>
<link rel="stylesheet" href="./assets/css/payrollList2.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
    .content-wrapper {
        min-height: calc(100vh - var(--header-height) - 40px);
    }
    
    .payroll-info {
        display: grid;
        gap: 4px;
    }
    
    .payroll-info strong {
        color: var(--sidebar-dark-green);
        font-weight: 600;
    }
    
    .controls-container {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin: 20px 0;
        padding: 15px 20px;
        background: white;
        border-radius: var(--border-radius);
        box-shadow: var(--box-shadow);
    }
    
    .search-section {
        display: flex;
        align-items: center;
        gap: 15px;
        flex: 1;
    }
    
    .generate-payroll-btn {
        background-color: var(--sidebar-green);
        color: white;
        border: none;
        padding: 10px 20px;
        border-radius: 25px;
        font-size: 0.95rem;
        font-weight: 600;
        cursor: pointer;
        transition: var(--transition);
        display: flex;
        align-items: center;
        gap: 8px;
        box-shadow: var(--box-shadow);
        white-space: nowrap;
        text-decoration: none;
    }
    
    .generate-payroll-btn:hover {
        background-color: var(--sidebar-dark-green);
        transform: translateY(-2px);
        box-shadow: 0 6px 8px rgba(0, 0, 0, 0.15);
    }
    
    .date-range {
        color: #666;
        font-size: 0.9rem;
        font-style: italic;
    }
</style>
</head>
<body>

<?php include_once("./includes/header.php"); ?>

<main class="content">
    <div class="content-wrapper">
        <!-- Payroll Header -->
        

        <!-- Controls -->
        <div class="controls">
            <form method="GET" action="payrollList.php" style="display: flex; align-items: center; gap: 15px; flex-wrap: wrap;">
                <div style="display: flex; align-items: center; gap: 10px;">
                    <label for="month"><i class="fas fa-calendar-alt"></i> Month:</label>
                    <select name="month" id="month" class="form-control">
                        <?php for ($m=1; $m<=12; $m++): ?>
                            <option value="<?= $m ?>" <?= $month == $m ? 'selected' : '' ?>>
                                <?= date('F', mktime(0,0,0,$m,10)) ?>
                            </option>
                        <?php endfor; ?>
                    </select>
                </div>

                <div style="display: flex; align-items: center; gap: 10px;">
                    <label for="year"><i class="fas fa-calendar"></i> Year:</label>
                    <input type="number" name="year" id="year" value="<?= $year ?>" required 
                           min="2000" max="2100" class="form-control">
                </div>

                <button type="submit" class="filter-btn">
                    <i class="fas fa-filter"></i> Filter
                </button>
            </form>
        </div>

        <!-- Generate Payroll Button -->
        <a href="generate_payroll.php" class="generate-payroll-btn">
            <i class="fas fa-calculator"></i> Generate Payroll
        </a>

        <!-- Payroll Table -->
        <div class="table-responsive">
            <div class="payroll-table-container">
                <table class="payroll-table">
                    <thead>
                        <tr>
                            <th>Payroll ID</th>
                            <th>Employee Information</th>
                            <th>Base Salary</th>
                            <th>Net Pay</th>
                            <th>Pay Period</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($result->num_rows > 0): ?>
                            <?php while ($row = $result->fetch_assoc()): 
                                $date_from = date('M d, Y', strtotime($row['date_from']));
                                $date_to = date('M d, Y', strtotime($row['date_to']));
                                $status = $row['status'] ?? 'pending';
                            ?>
                                <tr>
                                    <td><strong><?= $row['id'] ?></strong></td>
                                    <td>
                                        <div class="payroll-info">
                                            <div><strong>Name:</strong> <?= htmlspecialchars($row['employee_name']) ?></div>
                                            <div><strong>Position:</strong> <?= htmlspecialchars($row['position']) ?></div>
                                            <div><strong>ID:</strong> <?= $row['employee_id'] ?></div>
                                        </div>
                                    </td>
                                    <td>₱<?= number_format($row['monthly_salary'], 2) ?></td>
                                    <td class="net-pay-highlight">₱<?= number_format($row['net_pay'], 2) ?></td>
                                    <td>
                                        <div class="payroll-info">
                                            <div><strong>From:</strong> <?= $date_from ?></div>
                                            <div><strong>To:</strong> <?= $date_to ?></div>
                                            <div class="date-range">
                                                <?= date('F', mktime(0,0,0,$month,10)) . ' ' . $year ?>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="status-badge <?= $status == 'paid' ? 'status-paid' : 'status-pending' ?>">
                                            <i class="fas <?= $status == 'paid' ? 'fa-check-circle' : 'fa-clock' ?>"></i>
                                            <?= ucfirst($status) ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div class="action-buttons">
                                            <a href="generate_payslip.php?payroll_id=<?= $row['id'] ?>" 
                                               class="generate-btn" title="Generate Payslip">
                                                <i class="fas fa-file-invoice"></i> Payslip
                                            </a>
                                            <a href="payrollList.php?delete_id=<?= $row['id'] ?>" 
                                               class="delete" 
                                               title="Delete"
                                               onclick="return confirm('Are you sure you want to delete this payroll record?');">
                                                <i class="fas fa-trash-alt"></i> Delete
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="7">
                                    <div class="empty-state">
                                        <i class="fas fa-money-bill-wave"></i>
                                        <p>No payroll records found for the selected period</p>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</main>

<?php include_once("./modal/logout-modal.php"); ?>
<?php include_once("./includes/footer.php"); ?>

<script>
    // Update year input constraints
    document.addEventListener('DOMContentLoaded', function() {
        const yearInput = document.getElementById('year');
        const currentYear = new Date().getFullYear();
        
        // Set min to 2000 and max to current year + 5
        yearInput.min = 2000;
        yearInput.max = currentYear + 5;
        
        // Ensure year is within range
        yearInput.addEventListener('change', function() {
            if (this.value < 2000) this.value = 2000;
            if (this.value > currentYear + 5) this.value = currentYear + 5;
        });
    });
</script>

</body>
</html>