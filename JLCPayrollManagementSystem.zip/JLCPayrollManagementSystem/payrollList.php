<?php 
session_start();

// TURN ON ERROR DISPLAY FOR DEBUGGING - REMOVE AFTER FIXING
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Log all errors to a file
ini_set('log_errors', 1);
ini_set('error_log', './payroll_errors.log');

if (!isset($_SESSION['Admin_User'])) {
    header("Location: login.php");
    exit;
}

include_once("connection.php");

$month = isset($_GET['month']) ? $_GET['month'] : date('m');
$year = isset($_GET['year']) ? $_GET['year'] : date('Y');

// Handle Delete Payroll
if (isset($_GET['delete_id'])) {
    $payrollId = $_GET['delete_id'];
    
    // Start transaction
    $conn->begin_transaction();
    
    try {
        // Delete from payroll_deductions first
        $stmt1 = $conn->prepare("DELETE FROM payroll_deductions WHERE payroll_id = ?");
        $stmt1->bind_param("i", $payrollId);
        $stmt1->execute();
        $stmt1->close();
        
        // Then delete payroll
        $stmt2 = $conn->prepare("DELETE FROM payroll WHERE id = ?");
        $stmt2->bind_param("i", $payrollId);
        $stmt2->execute();
        $stmt2->close();
        
        $conn->commit();
        
        echo "<script>alert('Payroll record deleted successfully'); window.location.href='payrollList.php';</script>";
    } catch (Exception $e) {
        $conn->rollback();
        error_log("Delete error: " . $e->getMessage());
        echo "<script>alert('Error deleting payroll record');</script>";
    }
    exit;
}

// Handle Generate Payroll via AJAX
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['generate_payroll_ajax'])) {
    header('Content-Type: application/json');
    
    $response = ['success' => false, 'message' => '', 'payroll' => null];
    
    try {
        $date_from = $_POST['date_from'];
        $date_to = $_POST['date_to'];
        $employee_id = $_POST['employee_id'];
        
        if (empty($employee_id)) {
            $response['message'] = "Please select an employee.";
            echo json_encode($response);
            exit;
        }
        
        // Check if payroll already exists for this employee and date range
        $check_payroll_query = "SELECT id FROM payroll WHERE employee_id = ? AND date_from = ? AND date_to = ?";
        $check_payroll_stmt = $conn->prepare($check_payroll_query);
        $check_payroll_stmt->bind_param("iss", $employee_id, $date_from, $date_to);
        $check_payroll_stmt->execute();
        $check_payroll_result = $check_payroll_stmt->get_result();
        
        if ($check_payroll_result->num_rows > 0) {
            $response['message'] = "Payroll already exists for this employee and date range.";
            $response['exists'] = true;
            echo json_encode($response);
            exit;
        }
        
        // Get employee daily salary and details
        $salary_query = "SELECT id, first_name, last_name, position, address, contact_num, daily_salary FROM employees WHERE id = ?";
        $salary_stmt = $conn->prepare($salary_query);
        if (!$salary_stmt) {
            throw new Exception("Database error: " . $conn->error);
        }
        $salary_stmt->bind_param("i", $employee_id);
        $salary_stmt->execute();
        $salary_result = $salary_stmt->get_result();
        $employee = $salary_result->fetch_assoc();
        
        if (!$employee) {
            $response['message'] = "Employee not found";
            echo json_encode($response);
            exit;
        }
        
        // Calculate days between dates
        $start = new DateTime($date_from);
        $end = new DateTime($date_to);
        $end->modify('+1 day');
        $interval = new DateInterval('P1D');
        $period = new DatePeriod($start, $interval, $end);
        
        $total_days = 0;
        $total_work_hours = 0;
        $regular_hours = 0;
        $overtime_hours = 0;
        $days_present = 0;
        $days_on_leave = 0;
        $attendance_records = [];
        
        // Get attendance records for the period
        $attendance_query = "SELECT date, status, leave_type, time_in_am, time_out_am, time_in_pm, time_out_pm 
                             FROM attendance 
                             WHERE employee_id = ? AND date BETWEEN ? AND ?";
        $attendance_stmt = $conn->prepare($attendance_query);
        $attendance_stmt->bind_param("iss", $employee_id, $date_from, $date_to);
        $attendance_stmt->execute();
        $attendance_result = $attendance_stmt->get_result();
        
        while ($row = $attendance_result->fetch_assoc()) {
            $attendance_records[$row['date']] = $row;
        }
        
        // Calculate hourly rate (daily salary / 8 hours)
        $hourly_rate = $employee['daily_salary'] / 8;
        
        foreach ($period as $date) {
            $date_str = $date->format('Y-m-d');
            $total_days++;
            
            if (isset($attendance_records[$date_str])) {
                $record = $attendance_records[$date_str];
                
                if ($record['status'] == 'On Leave') {
                    // On leave - still get daily salary (8 hours)
                    $days_on_leave++;
                    $regular_hours += 8;
                    $total_work_hours += 8;
                } else if ($record['status'] == 'Present') {
                    $days_present++;
                    
                    // Calculate AM hours
                    $am_hours = 0;
                    if (!empty($record['time_in_am']) && !empty($record['time_out_am']) && 
                        $record['time_in_am'] != '00:00:00' && $record['time_out_am'] != '00:00:00') {
                        
                        $am_in = strtotime($record['time_in_am']);
                        $am_out = strtotime($record['time_out_am']);
                        if ($am_out < $am_in) $am_out += 86400;
                        $am_hours = ($am_out - $am_in) / 3600;
                    }
                    
                    // Calculate PM hours
                    $pm_hours = 0;
                    if (!empty($record['time_in_pm']) && !empty($record['time_out_pm']) && 
                        $record['time_in_pm'] != '00:00:00' && $record['time_out_pm'] != '00:00:00') {
                        
                        $pm_in = strtotime($record['time_in_pm']);
                        $pm_out = strtotime($record['time_out_pm']);
                        if ($pm_out < $pm_in) $pm_out += 86400;
                        $pm_hours = ($pm_out - $pm_in) / 3600;
                    }
                    
                    $daily_hours = $am_hours + $pm_hours;
                    
                    // Calculate regular and overtime hours (8 hours is regular, beyond is OT at 1.25x)
                    if ($daily_hours <= 8) {
                        $regular_hours += $daily_hours;
                    } else {
                        $regular_hours += 8;
                        $overtime_hours += ($daily_hours - 8);
                    }
                    
                    $total_work_hours += $daily_hours;
                }
            }
        }
        
        // Calculate base salary (regular hours at normal rate + overtime hours at 1.25x)
        $regular_pay = $regular_hours * $hourly_rate;
        $overtime_pay = $overtime_hours * $hourly_rate * 1.25;
        $base_salary = $regular_pay + $overtime_pay;
        
        // Get deductions for the period
        $deduction_query = "SELECT id, deduction_name, amount 
                            FROM deduction 
                            WHERE employee_id = ? 
                            AND status = 'active'
                            AND start_date <= ? 
                            AND end_date >= ?";
        $deduction_stmt = $conn->prepare($deduction_query);
        $deduction_stmt->bind_param("iss", $employee_id, $date_to, $date_from);
        $deduction_stmt->execute();
        $deduction_result = $deduction_stmt->get_result();
        
        $deductions = [];
        $total_deductions = 0;
        while ($row = $deduction_result->fetch_assoc()) {
            $deductions[] = $row;
            $total_deductions += $row['amount'];
        }
        
        $net_pay = $base_salary - $total_deductions;
        
        $response['success'] = true;
        $response['payroll'] = [
            'employee' => $employee,
            'date_from' => $date_from,
            'date_to' => $date_to,
            'total_days' => $total_days,
            'days_present' => $days_present,
            'days_on_leave' => $days_on_leave,
            'total_work_hours' => round($total_work_hours, 2),
            'regular_hours' => round($regular_hours, 2),
            'overtime_hours' => round($overtime_hours, 2),
            'hourly_rate' => $hourly_rate,
            'regular_pay' => round($regular_pay, 2),
            'overtime_pay' => round($overtime_pay, 2),
            'base_salary' => round($base_salary, 2),
            'deductions' => $deductions,
            'total_deductions' => $total_deductions,
            'net_pay' => round($net_pay, 2)
        ];
        
    } catch (Exception $e) {
        $response['message'] = 'Error: ' . $e->getMessage();
        error_log("Generate payroll error: " . $e->getMessage());
    }
    
    echo json_encode($response);
    exit;
}

// Handle Save Payroll
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_payroll'])) {
    header('Content-Type: application/json');
    
    $response = ['success' => false, 'message' => ''];
    
    try {
        // Log received data for debugging
        error_log("=== SAVE PAYROLL START ===");
        error_log("POST data: " . print_r($_POST, true));
        
        $employee_id = $_POST['employee_id'];
        $date_from = $_POST['date_from'];
        $date_to = $_POST['date_to'];
        $base_salary = $_POST['base_salary'];
        $total_deductions = $_POST['total_deductions'];
        $net_pay = $_POST['net_pay'];
        $total_work_hours = $_POST['total_work_hours'];
        $deductions_json = $_POST['deductions'];
        
        error_log("Employee ID: $employee_id");
        error_log("Date From: $date_from");
        error_log("Date To: $date_to");
        error_log("Base Salary: $base_salary");
        error_log("Total Deductions: $total_deductions");
        error_log("Net Pay: $net_pay");
        error_log("Work Hours: $total_work_hours");
        error_log("Deductions JSON: $deductions_json");
        
        if (!$employee_id || !$date_from || !$date_to || !$base_salary || !$net_pay) {
            $response['message'] = 'All fields are required';
            echo json_encode($response);
            exit;
        }
        
        // Check if payroll already exists
        $check_query = "SELECT id FROM payroll WHERE employee_id = ? AND date_from = ? AND date_to = ?";
        $check_stmt = $conn->prepare($check_query);
        if (!$check_stmt) {
            throw new Exception("Prepare check failed: " . $conn->error);
        }
        $check_stmt->bind_param("iss", $employee_id, $date_from, $date_to);
        $check_stmt->execute();
        $check_result = $check_stmt->get_result();
        
        $payroll_id = null;
        
        if ($check_result->num_rows > 0) {
            // Update existing
            $row = $check_result->fetch_assoc();
            $payroll_id = $row['id'];
            error_log("Updating existing payroll ID: $payroll_id");
            
            $update_query = "UPDATE payroll SET base_salary = ?, total_deductions = ?, net_pay = ?, total_work_hours = ?, status = 'pending' WHERE id = ?";
            $update_stmt = $conn->prepare($update_query);
            if (!$update_stmt) {
                throw new Exception("Prepare update failed: " . $conn->error);
            }
            $update_stmt->bind_param("ddddsi", $base_salary, $total_deductions, $net_pay, $total_work_hours, $payroll_id);
            if (!$update_stmt->execute()) {
                throw new Exception('Error updating payroll: ' . $update_stmt->error);
            }
            $update_stmt->close();
            error_log("Update successful");
        } else {
            // Insert new - let's first check what columns actually exist
            $columns_query = "SHOW COLUMNS FROM payroll";
            $columns_result = $conn->query($columns_query);
            $existing_columns = [];
            while ($col = $columns_result->fetch_assoc()) {
                $existing_columns[] = $col['Field'];
            }
            error_log("Existing columns: " . implode(", ", $existing_columns));
            
            // Build dynamic INSERT query based on existing columns
            $insert_columns = ['employee_id', 'date_from', 'date_to', 'base_salary', 'total_deductions', 'net_pay', 'total_work_hours'];
            $insert_values = ['?', '?', '?', '?', '?', '?', '?'];
            $bind_types = "issdddd";
            $bind_params = [$employee_id, $date_from, $date_to, $base_salary, $total_deductions, $net_pay, $total_work_hours];
            
            // Add optional columns if they exist
            if (in_array('payroll_type', $existing_columns)) {
                $insert_columns[] = 'payroll_type';
                $insert_values[] = '?';
                $bind_types .= "s";
                $bind_params[] = 'regular';
            }
            
            if (in_array('status', $existing_columns)) {
                $insert_columns[] = 'status';
                $insert_values[] = '?';
                $bind_types .= "s";
                $bind_params[] = 'pending';
            }
            
            if (in_array('date', $existing_columns)) {
                $insert_columns[] = 'date';
                $insert_values[] = 'NOW()';
                // NOW() doesn't need a parameter
            }
            
            if (in_array('pay_period', $existing_columns)) {
                $insert_columns[] = 'pay_period';
                $insert_values[] = '?';
                $bind_types .= "s";
                $pay_period = date('Y-m-01', strtotime($date_from));
                $bind_params[] = $pay_period;
            }
            
            // Build the query
            $insert_query = "INSERT INTO payroll (" . implode(", ", $insert_columns) . ") 
                             VALUES (" . implode(", ", $insert_values) . ")";
            
            error_log("Dynamic insert query: " . $insert_query);
            error_log("Bind types: " . $bind_types);
            error_log("Bind params: " . print_r($bind_params, true));
            
            $insert_stmt = $conn->prepare($insert_query);
            if (!$insert_stmt) {
                throw new Exception("Prepare insert failed: " . $conn->error);
            }
            
            // Dynamically bind parameters
            if (!empty($bind_params)) {
                $insert_stmt->bind_param($bind_types, ...$bind_params);
            }
            
            if ($insert_stmt->execute()) {
                $payroll_id = $conn->insert_id;
                error_log("Insert successful, new ID: $payroll_id");
            } else {
                throw new Exception('Error saving payroll: ' . $insert_stmt->error);
            }
            $insert_stmt->close();
        }
        
        // Save the deductions used for this payroll
        $deductions = json_decode($deductions_json, true);
        error_log("Deductions decoded: " . print_r($deductions, true));
        
        if (!empty($deductions) && is_array($deductions)) {
            // Check if payroll_deductions table exists
            $table_check = $conn->query("SHOW TABLES LIKE 'payroll_deductions'");
            if ($table_check->num_rows > 0) {
                // Clear old payroll_deductions
                $clear_stmt = $conn->prepare("DELETE FROM payroll_deductions WHERE payroll_id = ?");
                if (!$clear_stmt) {
                    throw new Exception("Prepare clear deductions failed: " . $conn->error);
                }
                $clear_stmt->bind_param("i", $payroll_id);
                $clear_stmt->execute();
                $clear_stmt->close();
                error_log("Cleared old deductions");
                
                // Insert new payroll_deductions
                $insert_deduction_stmt = $conn->prepare("INSERT INTO payroll_deductions (payroll_id, deduction_id, deduction_name, amount) VALUES (?, ?, ?, ?)");
                if (!$insert_deduction_stmt) {
                    throw new Exception("Prepare insert deductions failed: " . $conn->error);
                }
                
                foreach ($deductions as $deduction) {
                    $deduction_id = isset($deduction['id']) ? $deduction['id'] : 0;
                    $deduction_name = $deduction['deduction_name'];
                    $amount = $deduction['amount'];
                    $insert_deduction_stmt->bind_param("issd", $payroll_id, $deduction_id, $deduction_name, $amount);
                    if (!$insert_deduction_stmt->execute()) {
                        throw new Exception("Error inserting deduction: " . $insert_deduction_stmt->error);
                    }
                    error_log("Inserted deduction: $deduction_name - $amount");
                }
                $insert_deduction_stmt->close();
            } else {
                error_log("payroll_deductions table does not exist");
            }
        }
        
        $response['success'] = true;
        $response['message'] = 'Payroll saved successfully';
        $response['payroll_id'] = $payroll_id;
        error_log("=== SAVE PAYROLL SUCCESS ===");
        
    } catch (Exception $e) {
        $response['message'] = 'Error: ' . $e->getMessage();
        error_log("=== SAVE PAYROLL ERROR: " . $e->getMessage() . " ===");
        error_log("Stack trace: " . $e->getTraceAsString());
    }
    
    echo json_encode($response);
    exit;
}

// Handle Recalculate Payroll for Edit
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['recalculate_payroll'])) {
    header('Content-Type: application/json');
    
    $response = ['success' => false, 'message' => '', 'payroll' => null];
    
    try {
        $employee_id = $_POST['employee_id'];
        $date_from = $_POST['date_from'];
        $date_to = $_POST['date_to'];
        $current_deductions_json = isset($_POST['current_deductions']) ? $_POST['current_deductions'] : '[]';
        
        if (empty($employee_id) || empty($date_from) || empty($date_to)) {
            $response['message'] = "Missing required parameters";
            echo json_encode($response);
            exit;
        }
        
        // Get employee daily salary
        $salary_query = "SELECT id, daily_salary FROM employees WHERE id = ?";
        $salary_stmt = $conn->prepare($salary_query);
        $salary_stmt->bind_param("i", $employee_id);
        $salary_stmt->execute();
        $salary_result = $salary_stmt->get_result();
        $employee = $salary_result->fetch_assoc();
        
        if (!$employee) {
            $response['message'] = "Employee not found";
            echo json_encode($response);
            exit;
        }
        
        // Calculate days between dates
        $start = new DateTime($date_from);
        $end = new DateTime($date_to);
        $end->modify('+1 day');
        $interval = new DateInterval('P1D');
        $period = new DatePeriod($start, $interval, $end);
        
        $total_days = 0;
        $total_work_hours = 0;
        $regular_hours = 0;
        $overtime_hours = 0;
        $days_present = 0;
        $days_on_leave = 0;
        $attendance_records = [];
        
        // Get attendance records for the period
        $attendance_query = "SELECT date, status, leave_type, time_in_am, time_out_am, time_in_pm, time_out_pm 
                             FROM attendance 
                             WHERE employee_id = ? AND date BETWEEN ? AND ?";
        $attendance_stmt = $conn->prepare($attendance_query);
        $attendance_stmt->bind_param("iss", $employee_id, $date_from, $date_to);
        $attendance_stmt->execute();
        $attendance_result = $attendance_stmt->get_result();
        
        while ($row = $attendance_result->fetch_assoc()) {
            $attendance_records[$row['date']] = $row;
        }
        
        // Calculate hourly rate (daily salary / 8 hours)
        $hourly_rate = $employee['daily_salary'] / 8;
        
        foreach ($period as $date) {
            $date_str = $date->format('Y-m-d');
            $total_days++;
            
            if (isset($attendance_records[$date_str])) {
                $record = $attendance_records[$date_str];
                
                if ($record['status'] == 'On Leave') {
                    // On leave - still get daily salary (8 hours)
                    $days_on_leave++;
                    $regular_hours += 8;
                    $total_work_hours += 8;
                } else if ($record['status'] == 'Present') {
                    $days_present++;
                    
                    // Calculate AM hours
                    $am_hours = 0;
                    if (!empty($record['time_in_am']) && !empty($record['time_out_am']) && 
                        $record['time_in_am'] != '00:00:00' && $record['time_out_am'] != '00:00:00') {
                        
                        $am_in = strtotime($record['time_in_am']);
                        $am_out = strtotime($record['time_out_am']);
                        if ($am_out < $am_in) $am_out += 86400;
                        $am_hours = ($am_out - $am_in) / 3600;
                    }
                    
                    // Calculate PM hours
                    $pm_hours = 0;
                    if (!empty($record['time_in_pm']) && !empty($record['time_out_pm']) && 
                        $record['time_in_pm'] != '00:00:00' && $record['time_out_pm'] != '00:00:00') {
                        
                        $pm_in = strtotime($record['time_in_pm']);
                        $pm_out = strtotime($record['time_out_pm']);
                        if ($pm_out < $pm_in) $pm_out += 86400;
                        $pm_hours = ($pm_out - $pm_in) / 3600;
                    }
                    
                    $daily_hours = $am_hours + $pm_hours;
                    
                    // Calculate regular and overtime hours (8 hours is regular, beyond is OT at 1.25x)
                    if ($daily_hours <= 8) {
                        $regular_hours += $daily_hours;
                    } else {
                        $regular_hours += 8;
                        $overtime_hours += ($daily_hours - 8);
                    }
                    
                    $total_work_hours += $daily_hours;
                }
            }
        }
        
        // Calculate base salary (regular hours at normal rate + overtime hours at 1.25x)
        $regular_pay = $regular_hours * $hourly_rate;
        $overtime_pay = $overtime_hours * $hourly_rate * 1.25;
        $base_salary = $regular_pay + $overtime_pay;
        
        // Parse current deductions
        $current_deductions = json_decode($current_deductions_json, true);
        $total_deductions = 0;
        if (!empty($current_deductions) && is_array($current_deductions)) {
            foreach ($current_deductions as $deduction) {
                $total_deductions += floatval($deduction['amount']);
            }
        }
        
        $net_pay = $base_salary - $total_deductions;
        
        $response['success'] = true;
        $response['payroll'] = [
            'total_days' => $total_days,
            'days_present' => $days_present,
            'days_on_leave' => $days_on_leave,
            'total_work_hours' => round($total_work_hours, 2),
            'regular_hours' => round($regular_hours, 2),
            'overtime_hours' => round($overtime_hours, 2),
            'hourly_rate' => $hourly_rate,
            'regular_pay' => round($regular_pay, 2),
            'overtime_pay' => round($overtime_pay, 2),
            'base_salary' => round($base_salary, 2),
            'total_deductions' => $total_deductions,
            'net_pay' => round($net_pay, 2)
        ];
        
    } catch (Exception $e) {
        $response['message'] = 'Error: ' . $e->getMessage();
        error_log("Recalculate payroll error: " . $e->getMessage());
    }
    
    echo json_encode($response);
    exit;
}

// Handle Add Custom Deduction
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_custom_deduction'])) {
    header('Content-Type: application/json');
    
    $response = ['success' => false, 'message' => ''];
    
    try {
        $employee_id = $_POST['employee_id'];
        $deduction_name = $_POST['deduction_name'];
        $amount = $_POST['amount'];
        $start_date = $_POST['start_date'];
        $end_date = $_POST['end_date'];
        
        if (!$employee_id || !$deduction_name || !$amount || !$start_date || !$end_date) {
            $response['message'] = 'All fields are required';
            echo json_encode($response);
            exit;
        }
        
        if (!is_numeric($amount) || $amount <= 0) {
            $response['message'] = 'Amount must be a positive number';
            echo json_encode($response);
            exit;
        }
        
        $query = "INSERT INTO deduction (employee_id, deduction_name, amount, start_date, end_date, status, description) 
                  VALUES (?, ?, ?, ?, ?, 'active', ?)";
        $stmt = $conn->prepare($query);
        $description = "Custom deduction: " . $deduction_name;
        $stmt->bind_param("isdsss", $employee_id, $deduction_name, $amount, $start_date, $end_date, $description);
        
        if ($stmt->execute()) {
            $deduction_id = $conn->insert_id;
            $response['success'] = true;
            $response['message'] = 'Deduction added successfully';
            $response['deduction'] = [
                'id' => $deduction_id,
                'deduction_name' => $deduction_name,
                'amount' => $amount,
                'start_date' => $start_date,
                'end_date' => $end_date
            ];
        } else {
            throw new Exception('Error adding deduction: ' . $conn->error);
        }
        
        $stmt->close();
        
    } catch (Exception $e) {
        $response['message'] = $e->getMessage();
        error_log("Add deduction error: " . $e->getMessage());
    }
    
    echo json_encode($response);
    exit;
}

// Handle Delete Deduction
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_deduction'])) {
    header('Content-Type: application/json');
    
    $response = ['success' => false, 'message' => ''];
    
    try {
        $deduction_id = $_POST['deduction_id'];
        
        if (!$deduction_id) {
            $response['message'] = 'Invalid deduction ID';
            echo json_encode($response);
            exit;
        }
        
        $query = "DELETE FROM deduction WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $deduction_id);
        
        if ($stmt->execute()) {
            $response['success'] = true;
            $response['message'] = 'Deduction deleted successfully';
        } else {
            throw new Exception('Error deleting deduction: ' . $conn->error);
        }
        
        $stmt->close();
        
    } catch (Exception $e) {
        $response['message'] = $e->getMessage();
        error_log("Delete deduction error: " . $e->getMessage());
    }
    
    echo json_encode($response);
    exit;
}

// Handle Get Single Payroll for Edit
if (isset($_GET['get_payroll'])) {
    header('Content-Type: application/json');
    
    $response = ['success' => false, 'message' => ''];
    
    try {
        $payroll_id = $_GET['get_payroll'];
        
        if (!$payroll_id) {
            $response['message'] = 'Invalid payroll ID';
            echo json_encode($response);
            exit;
        }
        
        $query = "SELECT p.*, e.first_name, e.last_name, e.position, e.daily_salary, e.contact_num
                  FROM payroll p 
                  JOIN employees e ON e.id = p.employee_id 
                  WHERE p.id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $payroll_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $payroll = $result->fetch_assoc();
            
            // Check if payroll_deductions table exists
            $table_check = $conn->query("SHOW TABLES LIKE 'payroll_deductions'");
            if ($table_check->num_rows > 0) {
                // Get deductions for this payroll
                $deduction_query = "SELECT deduction_name, amount FROM payroll_deductions WHERE payroll_id = ?";
                $deduction_stmt = $conn->prepare($deduction_query);
                $deduction_stmt->bind_param("i", $payroll_id);
                $deduction_stmt->execute();
                $deduction_result = $deduction_stmt->get_result();
                
                $deductions = [];
                while ($row = $deduction_result->fetch_assoc()) {
                    $deductions[] = $row;
                }
                
                $payroll['deductions'] = $deductions;
            }
            
            $response['success'] = true;
            $response['data'] = $payroll;
        } else {
            $response['message'] = 'Payroll not found';
        }
        
        $stmt->close();
        
    } catch (Exception $e) {
        $response['message'] = 'Error: ' . $e->getMessage();
        error_log("Get payroll error: " . $e->getMessage());
    }
    
    echo json_encode($response);
    exit;
}

// Handle Update Payroll - Only status can be edited manually
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_payroll_status'])) {
    header('Content-Type: application/json');
    
    $response = ['success' => false, 'message' => ''];
    
    try {
        $payroll_id = $_POST['payroll_id'];
        $status = $_POST['status'];
        
        if (!$payroll_id || !$status) {
            $response['message'] = 'All fields are required';
            echo json_encode($response);
            exit;
        }
        
        $update_query = "UPDATE payroll SET status = ? WHERE id = ?";
        $update_stmt = $conn->prepare($update_query);
        $update_stmt->bind_param("si", $status, $payroll_id);
        
        if ($update_stmt->execute()) {
            $response['success'] = true;
            $response['message'] = 'Payroll status updated successfully';
        } else {
            throw new Exception('Error updating payroll: ' . $conn->error);
        }
        
        $update_stmt->close();
        
    } catch (Exception $e) {
        $response['message'] = 'Error: ' . $e->getMessage();
        error_log("Update payroll error: " . $e->getMessage());
    }
    
    echo json_encode($response);
    exit;
}

// Handle Main Page Payroll Search
if (isset($_GET['search_payroll'])) {
    header('Content-Type: application/json');
    
    $search_term = isset($_GET['term']) ? $_GET['term'] : '';
    $response = ['success' => true, 'payrolls' => []];
    
    if (!empty($search_term)) {
        $search_term = '%' . $conn->real_escape_string($search_term) . '%';
        $query = "SELECT p.id, p.date_from, p.date_to, p.base_salary, p.total_deductions, p.net_pay, p.status,
                         CONCAT(e.first_name, ' ', e.last_name) AS employee_name, 
                         e.position, e.id as employee_id, e.daily_salary
                  FROM payroll p
                  LEFT JOIN employees e ON e.id = p.employee_id
                  WHERE CONCAT(e.first_name, ' ', e.last_name) LIKE ? 
                     OR e.position LIKE ? 
                     OR e.id LIKE ?
                     OR p.date_from LIKE ?
                     OR p.date_to LIKE ?
                  ORDER BY p.date_from DESC
                  LIMIT 20";
        
        $stmt = $conn->prepare($query);
        $stmt->bind_param("sssss", $search_term, $search_term, $search_term, $search_term, $search_term);
        $stmt->execute();
        $result = $stmt->get_result();
        
        while ($row = $result->fetch_assoc()) {
            $response['payrolls'][] = [
                'id' => $row['id'],
                'employee_name' => $row['employee_name'],
                'employee_id' => $row['employee_id'],
                'position' => $row['position'],
                'date_from' => date('M d, Y', strtotime($row['date_from'])),
                'date_to' => date('M d, Y', strtotime($row['date_to'])),
                'net_pay' => $row['net_pay'],
                'status' => $row['status']
            ];
        }
    }
    
    echo json_encode($response);
    exit;
}

// Get custom deductions for dropdown
$custom_deductions_query = "SELECT name FROM custom_deductions ORDER BY name";
$custom_deductions_result = $conn->query($custom_deductions_query);

// Main query to fetch payroll records
$sql = "
    SELECT p.id, p.date_from, p.date_to, 
           COALESCE(p.base_salary, 0) as base_salary, 
           COALESCE(p.total_deductions, 0) as total_deductions, 
           COALESCE(p.net_pay, 0) as net_pay, 
           COALESCE(p.total_work_hours, 0) as total_work_hours, 
           p.status,
           CONCAT(e.first_name, ' ', e.last_name) AS employee_name, 
           e.position, e.id as employee_id, 
           COALESCE(e.daily_salary, 0) as daily_salary,
           e.contact_num
    FROM payroll p
    LEFT JOIN employees e ON e.id = p.employee_id
    WHERE MONTH(p.date_from) = ? AND YEAR(p.date_from) = ?
    ORDER BY p.date_from DESC
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $month, $year);
$stmt->execute();
$result = $stmt->get_result();

// Fetch all active employees for the generate modal
$employees_query = "SELECT id, first_name, last_name, position, COALESCE(daily_salary, 0) as daily_salary, address, contact_num FROM employees WHERE status = 'active' ORDER BY first_name, last_name";
$employees_result = $conn->query($employees_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, height=device-height">
<title>Payroll List</title>
<link rel="stylesheet" href="./assets/css/payrollList2.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
    /* Full height layout fix */
    html, body {
        height: 100%;
        margin: 0;
        padding: 0;
        overflow: hidden;
    }
    
    body {
        display: flex;
        flex-direction: column;
        padding-top: var(--header-height, 60px) !important;
    }
    
    .content {
        flex: 1;
        overflow-y: auto;
        padding: 20px;
        padding-bottom: 80px;
        height: calc(100vh - var(--header-height, 60px));
    }
    
    .content-wrapper {
        min-height: 100%;
        padding-bottom: 20px;
    }
    
    .payroll-info {
        display: grid;
        gap: 4px;
    }
    
    .payroll-info strong {
        color: var(--sidebar-dark-green);
        font-weight: 600;
    }
    
    .controls-container {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin: 20px 0;
        padding: 15px 20px;
        background: white;
        border-radius: var(--border-radius);
        box-shadow: var(--box-shadow);
    }
    
    .search-section {
        display: flex;
        align-items: center;
        gap: 15px;
        flex: 1;
    }
    
    .main-search-container {
        position: relative;
        flex: 1;
        max-width: 400px;
    }
    
    .main-search-input {
        width: 100%;
        padding: 10px 40px 10px 15px;
        border: 2px solid #e0e0e0;
        border-radius: 30px;
        font-size: 0.95rem;
        transition: all 0.3s;
        background: white;
    }
    
    .main-search-input:focus {
        border-color: var(--sidebar-green);
        box-shadow: 0 0 0 3px rgba(46, 125, 139, 0.1);
        outline: none;
    }
    
    .main-search-icon {
        position: absolute;
        right: 15px;
        top: 50%;
        transform: translateY(-50%);
        color: #95a5a6;
        cursor: pointer;
    }
    
    .main-search-icon:hover {
        color: var(--sidebar-green);
    }
    
    .main-search-results {
        position: absolute;
        top: 100%;
        left: 0;
        right: 0;
        background: white;
        border: 1px solid #e0e0e0;
        border-radius: 12px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        z-index: 1000;
        max-height: 300px;
        overflow-y: auto;
        display: none;
        margin-top: 5px;
    }
    
    .main-search-results.show {
        display: block;
    }
    
    .main-search-result-item {
        padding: 12px 15px;
        cursor: pointer;
        border-bottom: 1px solid #f0f0f0;
        transition: all 0.2s;
    }
    
    .main-search-result-item:hover {
        background: #e8f5e9;
    }
    
    .main-search-result-item:last-child {
        border-bottom: none;
    }
    
    .main-search-result-name {
        font-weight: 600;
        color: #2c3e50;
        margin-bottom: 4px;
    }
    
    .main-search-result-details {
        font-size: 0.85rem;
        color: #7f8c8d;
        display: flex;
        gap: 15px;
    }
    
    .generate-payroll-btn {
        background-color: var(--sidebar-green);
        color: white;
        border: none;
        padding: 10px 20px;
        border-radius: 25px;
        font-size: 0.95rem;
        font-weight: 600;
        cursor: pointer;
        transition: var(--transition);
        display: inline-flex;
        align-items: center;
        gap: 8px;
        box-shadow: var(--box-shadow);
        white-space: nowrap;
        text-decoration: none;
        margin: 20px 0;
    }
    
    .generate-payroll-btn:hover {
        background-color: var(--sidebar-dark-green);
        transform: translateY(-2px);
        box-shadow: 0 6px 8px rgba(0, 0, 0, 0.15);
    }
    
    .date-range {
        color: #666;
        font-size: 0.9rem;
        font-style: italic;
    }
    
    /* CRUD Button Styles */
    .edit-btn {
        background-color: #007bff;
        color: white;
        padding: 6px 12px;
        border-radius: 20px;
        font-size: 0.85rem;
        text-decoration: none;
        display: inline-flex;
        align-items: center;
        gap: 5px;
        transition: var(--transition);
        border: none;
        cursor: pointer;
    }
    
    .edit-btn:hover {
        background-color: #0056b3;
        transform: translateY(-2px);
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
    }
    
    .view-btn {
        background-color: #17a2b8;
        color: white;
        padding: 6px 12px;
        border-radius: 20px;
        font-size: 0.85rem;
        text-decoration: none;
        display: inline-flex;
        align-items: center;
        gap: 5px;
        transition: var(--transition);
        border: none;
        cursor: pointer;
    }
    
    .view-btn:hover {
        background-color: #138496;
        transform: translateY(-2px);
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
    }
    
    .delete-btn {
        background-color: #dc3545;
        color: white;
        padding: 6px 12px;
        border-radius: 20px;
        font-size: 0.85rem;
        text-decoration: none;
        display: inline-flex;
        align-items: center;
        gap: 5px;
        transition: var(--transition);
        border: none;
        cursor: pointer;
    }
    
    .delete-btn:hover {
        background-color: #c82333;
        transform: translateY(-2px);
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
    }
    
    .action-buttons {
        display: flex;
        gap: 8px;
        flex-wrap: wrap;
        align-items: center;
    }

    /* Status Badge Styles */
    .status-badge {
        display: inline-block;
        padding: 6px 12px;
        border-radius: 20px;
        font-size: 0.85rem;
        font-weight: 600;
        text-align: center;
        min-width: 80px;
    }
    
    .status-paid {
        background-color: #d4edda;
        color: #155724;
        border: 1px solid #c3e6cb;
    }
    
    .status-pending {
        background-color: #fff3cd;
        color: #856404;
        border: 1px solid #ffeeba;
    }

    /* Modal Styles */
    .modal {
        display: none;
        position: fixed;
        z-index: 9999;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.5);
        align-items: center;
        justify-content: center;
    }

    .modal.show {
        display: flex;
    }

    .modal-content {
        background-color: white;
        border-radius: 16px;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
        width: 90%;
        max-width: 700px;
        max-height: 90vh;
        overflow-y: auto;
        animation: modalSlideIn 0.3s ease;
    }

    .modal-content.large {
        max-width: 900px;
    }

    @keyframes modalSlideIn {
        from {
            opacity: 0;
            transform: translateY(-50px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    .modal-header {
        padding: 20px 25px;
        background: linear-gradient(135deg, #75e6da, #62d4c8);
        color: white;
        border-radius: 16px 16px 0 0;
        display: flex;
        align-items: center;
        gap: 10px;
        position: sticky;
        top: 0;
        z-index: 1;
    }

    .modal-header.info {
        background: linear-gradient(135deg, #75e6da, #62d4c8);
    }

    .modal-header.success {
        background: linear-gradient(135deg, #d4edda, #c3e6cb);
        color: #155724;
    }

    .modal-header.warning {
        background: linear-gradient(135deg, #fff3cd, #ffeaa7);
        color: #856404;
    }

    .modal-header.primary {
        background: linear-gradient(135deg, #75e6da, #62d4c8);
    }

    .modal-header i {
        font-size: 20px;
    }

    .modal-header h3 {
        margin: 0;
        font-size: 18px;
        font-weight: 600;
        flex: 1;
    }

    .close-btn {
        background: none;
        border: none;
        color: white;
        font-size: 24px;
        cursor: pointer;
        width: 30px;
        height: 30px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 50%;
        transition: all 0.3s;
    }

    .close-btn:hover {
        background: rgba(255, 255, 255, 0.2);
    }

    .modal-body {
        padding: 25px;
    }

    .modal-footer {
        padding: 15px 25px;
        background-color: #f8fafc;
        border-top: 1px solid #e9ecef;
        border-radius: 0 0 16px 16px;
        display: flex;
        justify-content: flex-end;
        gap: 10px;
    }

    .modal-btn {
        padding: 10px 24px;
        border: none;
        border-radius: 30px;
        font-size: 14px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.3s;
        display: inline-flex;
        align-items: center;
        gap: 8px;
    }

    .modal-btn.cancel {
        background: #e2e8f0;
        color: #334155;
    }

    .modal-btn.cancel:hover {
        background: #cbd5e1;
    }

    .modal-btn.confirm {
        background: #75e6da;
        color: white;
    }

    .modal-btn.confirm:hover {
        background: #62d4c8;
        transform: translateY(-2px);
        box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    }

    .modal-btn.edit {
        background: #007bff;
        color: white;
    }

    .modal-btn.edit:hover {
        background: #0056b3;
    }

    .modal-btn.delete {
        background: #dc3545;
        color: white;
    }

    .modal-btn.delete:hover {
        background: #c82333;
    }

    .modal-btn.primary {
        background: #28a745;
        color: white;
    }

    .modal-btn.primary:hover {
        background: #218838;
    }

    /* Employee Selection Grid - Without Radio Button */
    .employee-selection-grid {
        max-height: 300px;
        overflow-y: auto;
        border: 1px solid #e9ecef;
        border-radius: 12px;
        padding: 5px;
        margin-top: 10px;
    }

    .employee-grid-item {
        display: flex;
        align-items: center;
        padding: 12px 15px;
        border-bottom: 1px solid #f0f0f0;
        cursor: pointer;
        transition: all 0.2s;
        border-radius: 8px;
    }

    .employee-grid-item:hover {
        background: #e8f5e9;
    }

    .employee-grid-item.selected {
        background: #d4edda;
        border-left: 4px solid #28a745;
    }

    .employee-grid-item:last-child {
        border-bottom: none;
    }

    .employee-grid-info {
        flex: 1;
    }

    .employee-grid-name {
        font-weight: 600;
        color: #2c3e50;
        margin-bottom: 4px;
    }

    .employee-grid-details {
        font-size: 0.85rem;
        color: #7f8c8d;
        display: flex;
        gap: 15px;
        flex-wrap: wrap;
    }

    /* Enhanced Calendar Date Picker Styles - Adjusted for Modal */
    .date-picker-wrapper {
        position: relative;
        width: 100%;
    }
    
    .date-input-group {
        display: flex;
        align-items: center;
        position: relative;
        width: 100%;
    }
    
    .date-field {
        width: 100%;
        padding: 12px 45px 12px 15px;
        border: 2px solid #e0e0e0;
        border-radius: 30px;
        font-size: 0.95rem;
        transition: all 0.3s;
        background: white;
        cursor: pointer;
        color: #2c3e50;
        font-weight: 500;
    }
    
    .date-field:hover {
        border-color: #75e6da;
    }
    
    .date-field:focus {
        border-color: #75e6da;
        box-shadow: 0 0 0 3px rgba(117, 230, 218, 0.2);
        outline: none;
    }
    
    .calendar-dropdown-btn {
        position: absolute;
        right: 12px;
        top: 50%;
        transform: translateY(-50%);
        background: linear-gradient(135deg, #75e6da, #62d4c8);
        color: white;
        border: none;
        width: 32px;
        height: 32px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all 0.3s;
        font-size: 0.9rem;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    
    .calendar-dropdown-btn:hover {
        background: #62d4c8;
        transform: translateY(-50%) scale(1.1);
        box-shadow: 0 4px 8px rgba(0,0,0,0.15);
    }
    
    /* Calendar Dropdown Styles - Adjusted for Modal */
    .calendar-wrapper {
        position: absolute;
        top: calc(100% + 8px);
        left: 50%;
        transform: translateX(-50%);
        background: white;
        border: 1px solid #e0e0e0;
        border-radius: 12px;
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
        z-index: 10000;
        display: none;
        width: 280px;
    }
    
    .calendar-wrapper.show {
        display: block;
    }
    
    .calendar-box {
        width: 100%;
        background: white;
        border-radius: 12px;
        overflow: hidden;
    }
    
    .calendar-header {
        background: linear-gradient(135deg, #75e6da, #62d4c8);
        color: white;
        padding: 12px;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    
    .calendar-month-year {
        font-weight: 600;
        font-size: 0.95rem;
    }
    
    .calendar-nav {
        display: flex;
        gap: 8px;
    }
    
    .calendar-nav-btn {
        background: rgba(255, 255, 255, 0.2);
        border: none;
        color: white;
        width: 26px;
        height: 26px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all 0.3s;
        font-size: 1rem;
        line-height: 1;
    }
    
    .calendar-nav-btn:hover {
        background: rgba(255, 255, 255, 0.3);
        transform: scale(1.1);
    }
    
    .calendar-selectors {
        display: flex;
        gap: 5px;
        padding: 10px 10px 5px 10px;
        background: white;
    }
    
    .calendar-select {
        flex: 1;
        padding: 4px 6px;
        border: 1px solid #e0e0e0;
        border-radius: 4px;
        font-size: 0.8rem;
        font-weight: 500;
        color: #2c3e50;
        background: white;
        cursor: pointer;
        transition: all 0.3s;
        outline: none;
    }
    
    .calendar-select:hover {
        border-color: #75e6da;
    }
    
    .calendar-select:focus {
        border-color: #75e6da;
        box-shadow: 0 0 0 2px rgba(117, 230, 218, 0.2);
    }
    
    .calendar-weekdays {
        display: grid;
        grid-template-columns: repeat(7, 1fr);
        background: #f8f9fa;
        padding: 8px 5px;
        text-align: center;
        font-weight: 600;
        font-size: 0.7rem;
        color: #2c3e50;
        border-bottom: 1px solid #e9ecef;
    }
    
    .calendar-days-grid {
        display: grid;
        grid-template-columns: repeat(7, 1fr);
        gap: 2px;
        padding: 5px;
        background: white;
    }
    
    .calendar-day {
        aspect-ratio: 1;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 4px;
        cursor: pointer;
        border-radius: 50%;
        transition: all 0.2s;
        font-size: 0.8rem;
        color: #2c3e50;
        text-decoration: none;
        border: none;
        background: none;
        width: 100%;
        min-width: 24px;
        min-height: 24px;
    }
    
    .calendar-day:hover {
        background: #e8f5e9;
        color: #2E7D32;
    }
    
    .calendar-day.selected {
        background: #75e6da;
        color: white;
        font-weight: 600;
    }
    
    .calendar-day.today {
        border: 2px solid #75e6da;
        font-weight: 600;
    }
    
    .calendar-day.weekend {
        color: #e74c3c;
    }
    
    .calendar-day.other-month {
        color: #bdc3c7;
    }
    
    .calendar-footer {
        padding: 8px;
        background: #f8f9fa;
        border-top: 1px solid #e9ecef;
        display: flex;
        justify-content: space-between;
    }
    
    .calendar-action-btn {
        padding: 4px 10px;
        border-radius: 20px;
        font-size: 0.75rem;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.3s;
        text-decoration: none;
        display: inline-flex;
        align-items: center;
        gap: 3px;
        border: none;
    }
    
    .calendar-action-btn.clear {
        background: #f8f9fa;
        color: #7f8c8d;
        border: 1px solid #bdc3c7;
    }
    
    .calendar-action-btn.clear:hover {
        background: #e74c3c;
        color: white;
        border-color: #e74c3c;
    }
    
    .calendar-action-btn.today {
        background: #75e6da;
        color: white;
        border: 1px solid #75e6da;
    }
    
    .calendar-action-btn.today:hover {
        background: #62d4c8;
    }

    /* Form Controls */
    .form-group {
        margin-bottom: 20px;
    }

    .form-group label {
        display: block;
        margin-bottom: 8px;
        font-weight: 600;
        color: #2c3e50;
        font-size: 14px;
    }

    .form-group label i {
        margin-right: 8px;
        color: #75e6da;
    }

    .form-control {
        width: 100%;
        padding: 12px 15px;
        border: 2px solid #e0e0e0;
        border-radius: 8px;
        font-size: 0.95rem;
        transition: all 0.3s;
        box-sizing: border-box;
    }

    .form-control:focus {
        border-color: #75e6da;
        box-shadow: 0 0 0 3px rgba(117, 230, 218, 0.2);
        outline: none;
    }

    .form-control[readonly] {
        background-color: #f8f9fa;
        cursor: not-allowed;
    }

    .date-row {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 15px;
    }

    /* Employee Search in Modal */
    .employee-search-container {
        position: relative;
        margin-bottom: 15px;
    }

    .employee-search-input {
        width: 100%;
        padding: 12px 15px;
        border: 2px solid #e0e0e0;
        border-radius: 30px;
        font-size: 0.95rem;
        transition: all 0.3s;
        box-sizing: border-box;
    }

    .employee-search-input:focus {
        border-color: #75e6da;
        box-shadow: 0 0 0 3px rgba(117, 230, 218, 0.2);
        outline: none;
    }

    /* Employee Details Card */
    .employee-details-card {
        background: #f8fafc;
        border-radius: 12px;
        padding: 15px;
        margin: 15px 0;
        border-left: 4px solid #75e6da;
        position: relative;
    }

    .employee-details-grid {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 10px;
        margin-top: 10px;
    }

    .detail-item {
        padding: 8px;
        background: white;
        border-radius: 8px;
    }

    .detail-label {
        font-size: 0.8rem;
        color: #64748b;
        margin-bottom: 2px;
    }

    .detail-value {
        font-weight: 600;
        color: #2c3e50;
    }

    .change-employee-btn {
        position: absolute;
        top: -10px;
        right: -10px;
        background: #dc3545;
        color: white;
        border: none;
        width: 30px;
        height: 30px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        font-size: 1rem;
        box-shadow: 0 2px 5px rgba(0,0,0,0.2);
    }

    .change-employee-btn:hover {
        background: #c82333;
        transform: scale(1.1);
    }

    /* Attendance Summary */
    .attendance-summary {
        background: #f8fafc;
        border-radius: 12px;
        padding: 15px;
        margin: 15px 0;
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 10px;
        border: 1px solid #e9ecef;
    }

    .summary-item {
        text-align: center;
    }

    .summary-label {
        font-size: 0.8rem;
        color: #64748b;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }

    .summary-value {
        font-size: 1.5rem;
        font-weight: 700;
        color: #75e6da;
        line-height: 1.2;
    }

    .summary-value span {
        font-size: 0.9rem;
        font-weight: 400;
        color: #666;
    }

    /* Salary Computation */
    .computation-box {
        background: white;
        border: 1px solid #e9ecef;
        border-radius: 12px;
        margin: 15px 0;
        overflow: hidden;
    }

    .computation-header {
        background: linear-gradient(135deg, #f8fafc, #f1f5f9);
        padding: 12px 15px;
        border-bottom: 1px solid #e9ecef;
        font-weight: 600;
        color: #2c3e50;
    }

    .computation-row {
        display: flex;
        justify-content: space-between;
        padding: 12px 15px;
        border-bottom: 1px solid #f0f0f0;
    }

    .computation-row.total {
        background: #e8f5e9;
        font-weight: 700;
        color: #2e7d32;
        border-bottom: none;
    }

    .computation-row.net {
        background: #d4edda;
        font-weight: 700;
        font-size: 1.1rem;
        color: #155724;
    }

    .computation-label {
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .computation-value {
        font-family: 'Courier New', monospace;
        font-weight: 600;
    }

    /* Deductions Section */
    .deductions-section {
        margin: 20px 0;
    }

    .deductions-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 10px;
    }

    .deductions-header h4 {
        margin: 0;
        color: #2c3e50;
        font-size: 16px;
    }

    .add-deduction-btn {
        background: linear-gradient(135deg, #ff9800, #f57c00);
        color: white;
        border: none;
        padding: 8px 16px;
        border-radius: 30px;
        font-size: 0.85rem;
        font-weight: 600;
        cursor: pointer;
        display: flex;
        align-items: center;
        gap: 5px;
        transition: all 0.3s;
    }

    .add-deduction-btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    }

    .deductions-list {
        border: 1px solid #e9ecef;
        border-radius: 12px;
        max-height: 200px;
        overflow-y: auto;
    }

    .deduction-item {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 12px 15px;
        border-bottom: 1px solid #f0f0f0;
        position: relative;
    }

    .deduction-item:last-child {
        border-bottom: none;
    }

    .deduction-info {
        flex: 1;
    }

    .deduction-name {
        font-weight: 600;
        color: #2c3e50;
    }

    .deduction-amount {
        color: #dc3545;
        font-weight: 600;
        margin-right: 35px;
    }

    .deduction-actions {
        display: flex;
        gap: 5px;
    }

    .deduction-delete {
        background: none;
        border: none;
        color: #dc3545;
        cursor: pointer;
        font-size: 1.1rem;
        padding: 5px 10px;
        border-radius: 4px;
        transition: all 0.2s;
    }

    .deduction-delete:hover {
        background: #fee;
        color: #c82333;
        transform: scale(1.1);
    }

    .empty-deductions {
        text-align: center;
        padding: 30px 20px;
        color: #999;
    }

    .empty-deductions i {
        font-size: 2.5rem;
        margin-bottom: 10px;
        color: #ddd;
    }

    /* Add Deduction Modal */
    .deduction-modal-content {
        max-width: 500px;
    }

    .deduction-form-group {
        margin-bottom: 15px;
    }

    .deduction-form-group label {
        display: block;
        margin-bottom: 5px;
        font-weight: 600;
        color: #2c3e50;
        font-size: 13px;
    }

    .deduction-form-group label i {
        margin-right: 5px;
        color: #75e6da;
    }

    .deduction-form-control {
        width: 100%;
        padding: 10px 12px;
        border: 2px solid #e0e0e0;
        border-radius: 8px;
        font-size: 13px;
        box-sizing: border-box;
        transition: all 0.3s;
    }

    .deduction-form-control:focus {
        border-color: #75e6da;
        box-shadow: 0 0 0 3px rgba(117, 230, 218, 0.2);
        outline: none;
    }

    .deduction-form-row {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 10px;
    }

    /* Loading Overlay */
    .loading-overlay {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(255,255,255,0.9);
        z-index: 10000;
        align-items: center;
        justify-content: center;
        flex-direction: column;
    }

    .loading-spinner {
        width: 50px;
        height: 50px;
        border: 5px solid #f3f3f3;
        border-top: 5px solid #75e6da;
        border-radius: 50%;
        animation: spin 1s linear infinite;
        margin-bottom: 15px;
    }

    @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }

    /* Success Modal */
    .success-message {
        text-align: center;
        padding: 20px;
        font-size: 16px;
        color: #2e7d32;
    }

    /* Empty State */
    .empty-state {
        text-align: center;
        padding: 60px 40px;
        color: #999;
    }

    .empty-state i {
        font-size: 48px;
        margin-bottom: 15px;
        color: #ddd;
    }

    /* Delete Confirmation Modal */
    .delete-icon {
        font-size: 48px;
        color: #dc3545;
        text-align: center;
        margin-bottom: 15px;
    }

    .delete-message {
        text-align: center;
        margin-bottom: 20px;
        font-size: 16px;
        color: #333;
    }

    .delete-details {
        background: #f8fafc;
        padding: 15px;
        border-radius: 8px;
        margin: 15px 0;
        font-size: 14px;
    }

    .delete-warning {
        color: #dc3545;
        font-size: 13px;
        font-style: italic;
        margin-top: 10px;
        text-align: center;
    }

    /* Payroll Steps */
    .payroll-step {
        display: none;
    }

    .payroll-step.active {
        display: block;
    }

    .step-indicators {
        display: flex;
        margin-bottom: 25px;
        border-bottom: 2px solid #e9ecef;
        padding-bottom: 10px;
    }

    .step-indicator {
        flex: 1;
        text-align: center;
        position: relative;
    }

    .step-indicator.active .step-number {
        background: #75e6da;
        color: white;
    }

    .step-indicator.completed .step-number {
        background: #28a745;
        color: white;
    }

    .step-number {
        width: 32px;
        height: 32px;
        background: #e0e0e0;
        color: #666;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 8px;
        font-weight: 600;
    }

    .step-label {
        font-size: 0.9rem;
        color: #666;
        font-weight: 500;
    }

    .step-indicator.active .step-label {
        color: #75e6da;
        font-weight: 600;
    }

    /* Notification Modal */
    .notification-modal {
        display: none;
        position: fixed;
        z-index: 10001;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.5);
        align-items: center;
        justify-content: center;
    }

    .notification-modal.show {
        display: flex;
    }

    .notification-modal-content {
        background: white;
        border-radius: 16px;
        width: 400px;
        max-width: 90%;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
        animation: modalSlideIn 0.3s ease;
    }

    .notification-modal-header {
        padding: 20px;
        border-bottom: 1px solid #e9ecef;
        display: flex;
        align-items: center;
        gap: 10px;
        border-radius: 16px 16px 0 0;
    }

    .notification-modal-header.success {
        background: linear-gradient(135deg, #d4edda, #c3e6cb);
        color: #155724;
    }

    .notification-modal-header.error {
        background: linear-gradient(135deg, #f8d7da, #f5c6cb);
        color: #721c24;
    }

    .notification-modal-header.warning {
        background: linear-gradient(135deg, #fff3cd, #ffeaa7);
        color: #856404;
    }

    .notification-modal-header.info {
        background: linear-gradient(135deg, #e3f2fd, #bbdefb);
        color: #0c5460;
    }

    .notification-modal-header i {
        font-size: 24px;
    }

    .notification-modal-header h3 {
        margin: 0;
        font-size: 18px;
        font-weight: 600;
        flex: 1;
    }

    .notification-modal-body {
        padding: 25px;
        text-align: center;
        font-size: 15px;
    }

    .notification-modal-body p {
        margin: 0;
    }

    .notification-modal-footer {
        padding: 15px 20px;
        border-top: 1px solid #e9ecef;
        display: flex;
        justify-content: center;
    }

    .notification-modal-btn {
        padding: 10px 30px;
        border: none;
        border-radius: 30px;
        font-size: 14px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.3s;
    }

    .notification-modal-btn.success {
        background: #75e6da;
        color: white;
    }

    .notification-modal-btn.success:hover {
        background: #62d4c8;
    }

    /* Table responsive */
    .table-responsive {
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
        margin-bottom: 20px;
    }

    .payroll-table-container {
        min-width: 100%;
        display: inline-block;
    }

    .payroll-table {
        width: 100%;
        border-collapse: collapse;
    }

    .payroll-table th {
        background: linear-gradient(135deg, #f8fafc, #f1f5f9);
        padding: 15px;
        text-align: left;
        font-weight: 600;
        color: #2c3e50;
        border-bottom: 2px solid #e9ecef;
        white-space: nowrap;
    }

    .payroll-table td {
        padding: 15px;
        border-bottom: 1px solid #e9ecef;
        vertical-align: top;
    }

    .payroll-table tbody tr:hover {
        background: #f8fafc;
    }

    .net-pay-highlight {
        font-weight: 700;
        color: #28a745;
    }

    /* Filter controls */
    .controls {
        background: white;
        padding: 20px;
        border-radius: 16px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.05);
        margin: 20px 0;
        border: 1px solid #e9ecef;
    }

    .filter-btn {
        background: #6c757d;
        color: white;
        border: none;
        padding: 10px 20px;
        border-radius: 30px;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        gap: 5px;
        transition: all 0.3s;
    }

    .filter-btn:hover {
        background: #5a6268;
        transform: translateY(-2px);
    }

    /* Existing Payroll Warning Modal */
    .warning-icon {
        font-size: 48px;
        color: #ffc107;
        text-align: center;
        margin-bottom: 15px;
    }

    /* Recalculate Button */
    .recalculate-btn {
        background: #17a2b8;
        color: white;
        border: none;
        padding: 8px 16px;
        border-radius: 30px;
        font-size: 0.85rem;
        font-weight: 600;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        gap: 5px;
        transition: all 0.3s;
        margin-right: 10px;
    }

    .recalculate-btn:hover {
        background: #138496;
        transform: translateY(-2px);
        box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    }

    .recalculate-btn i {
        font-size: 0.9rem;
    }
</style>
</head>
<body>

<?php include_once("./includes/header.php"); ?>

<main class="content">
    <div class="content-wrapper">
        <!-- Controls -->
        <div class="controls">
            <form method="GET" action="payrollList.php" style="display: flex; align-items: center; gap: 15px; flex-wrap: wrap; width: 100%;">
                <div style="display: flex; align-items: center; gap: 10px;">
                    <label for="month"><i class="fas fa-calendar-alt"></i> Month:</label>
                    <select name="month" id="month" class="form-control" style="width: auto;">
                        <?php for ($m=1; $m<=12; $m++): ?>
                            <option value="<?php echo $m; ?>" <?php echo $month == $m ? 'selected' : ''; ?>>
                                <?php echo date('F', mktime(0,0,0,$m,10)); ?>
                            </option>
                        <?php endfor; ?>
                    </select>
                </div>

                <div style="display: flex; align-items: center; gap: 10px;">
                    <label for="year"><i class="fas fa-calendar"></i> Year:</label>
                    <input type="number" name="year" id="year" value="<?php echo $year; ?>" required 
                           min="2000" max="2100" class="form-control" style="width: 100px;">
                </div>

                <button type="submit" class="filter-btn">
                    <i class="fas fa-filter"></i> Filter
                </button>
            </form>
        </div>

        <!-- Main Page Payroll Search -->
        <div style="display: flex; justify-content: space-between; align-items: center; margin: 20px 0;">
            <div class="main-search-container">
                <input type="text" id="mainSearchInput" class="main-search-input" placeholder="Search payroll by employee name, position,or date...">
                <i class="fas fa-search main-search-icon" onclick="performPayrollSearch()"></i>
                <div class="main-search-results" id="mainSearchResults"></div>
            </div>
            <button onclick="openGeneratePayrollModal()" class="generate-payroll-btn">
                <i class="fas fa-calculator"></i> Generate Payroll
            </button>
        </div>

        <!-- Payroll Table -->
        <div class="table-responsive">
            <div class="payroll-table-container">
                <table class="payroll-table">
                    <thead>
                        <tr>
                            <th>Employee Information</th>
                            <th>Daily Salary</th>
                            <th>Work Hours</th>
                            <th>Base Salary</th>
                            <th>Deductions</th>
                            <th>Net Pay</th>
                            <th>Pay Period</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody id="payrollTableBody">
                        <?php if ($result && $result->num_rows > 0): ?>
                            <?php while ($row = $result->fetch_assoc()): 
                                $date_from = date('M d, Y', strtotime($row['date_from']));
                                $date_to = date('M d, Y', strtotime($row['date_to']));
                                $status = $row['status'] ?? 'pending';
                                $statusClass = $status == 'paid' ? 'status-paid' : 'status-pending';
                                $statusIcon = $status == 'paid' ? 'fa-check-circle' : 'fa-clock';
                            ?>
                                <tr class="payroll-row" data-id="<?php echo $row['id']; ?>" data-name="<?php echo htmlspecialchars(strtolower($row['employee_name'])); ?>" data-position="<?php echo htmlspecialchars(strtolower($row['position'])); ?>" data-date-from="<?php echo $row['date_from']; ?>" data-date-to="<?php echo $row['date_to']; ?>">
                                    <td>
                                        <div class="payroll-info">
                                            <div><strong>Name:</strong> <?php echo htmlspecialchars($row['employee_name']); ?></div>
                                            <div><strong>Position:</strong> <?php echo htmlspecialchars($row['position']); ?></div>
                                            <div><strong>ID:</strong> <?php echo $row['employee_id']; ?></div>
                                            <div><strong>Contact:</strong> <?php echo htmlspecialchars($row['contact_num'] ?? 'N/A'); ?></div>
                                        </div>
                                    </td>
                                    <td>₱<?php echo number_format(floatval($row['daily_salary']), 2); ?></td>
                                    <td><?php echo number_format(floatval($row['total_work_hours']), 2); ?> hrs</td>
                                    <td>₱<?php echo number_format(floatval($row['base_salary']), 2); ?></td>
                                    <td>₱<?php echo number_format(floatval($row['total_deductions']), 2); ?></td>
                                    <td class="net-pay-highlight">₱<?php echo number_format(floatval($row['net_pay']), 2); ?></td>
                                    <td>
                                        <div class="payroll-info">
                                            <div><strong>From:</strong> <?php echo $date_from; ?></div>
                                            <div><strong>To:</strong> <?php echo $date_to; ?></div>
                                            <div class="date-range">
                                                <?php echo date('F', mktime(0,0,0,$month,10)) . ' ' . $year; ?>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="status-badge <?php echo $statusClass; ?>">
                                            <i class="fas <?php echo $statusIcon; ?>"></i>
                                            <?php echo ucfirst($status); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div class="action-buttons">
                                            <button onclick="viewPayroll(<?php echo $row['id']; ?>)" class="view-btn" title="View Details">
                                                <i class="fas fa-eye"></i> View
                                            </button>
                                            <button onclick="editPayroll(<?php echo $row['id']; ?>)" class="edit-btn" title="Edit Payroll">
                                                <i class="fas fa-edit"></i> Edit
                                            </button>
                                            <button onclick="openDeletePayrollModal(<?php echo $row['id']; ?>, '<?php echo htmlspecialchars($row['employee_name']); ?>', '<?php echo $date_from; ?>', '<?php echo $date_to; ?>', '₱<?php echo number_format(floatval($row['net_pay']), 2); ?>')" 
                                               class="delete-btn" title="Delete">
                                                <i class="fas fa-trash-alt"></i> Delete
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="9">
                                    <div class="empty-state">
                                        <i class="fas fa-money-bill-wave"></i>
                                        <p>No payroll records found for the selected period</p>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</main>

<!-- Generate Payroll Modal (Step 1 - Select Date and Employee) -->
<div id="generatePayrollModal" class="modal">
    <div class="modal-content large">
        <div class="modal-header info">
            <i class="fas fa-calculator"></i>
            <h3 id="modalStepTitle">Generate Payroll - Step 1: Select Date and Employee</h3>
            <button class="close-btn" onclick="closeModal('generatePayrollModal')"><i class="fas fa-times"></i></button>
        </div>
        <div class="modal-body">
            <div class="step-indicators">
                <div class="step-indicator active" id="step1Indicator">
                    <div class="step-number">1</div>
                    <div class="step-label">Select Date & Employee</div>
                </div>
                <div class="step-indicator" id="step2Indicator">
                    <div class="step-number">2</div>
                    <div class="step-label">Review & Add Deductions</div>
                </div>
                <div class="step-indicator" id="step3Indicator">
                    <div class="step-number">3</div>
                    <div class="step-label">Save Payroll</div>
                </div>
            </div>

            <!-- Step 1 Content -->
            <div id="step1Content" class="payroll-step active">
                <div class="date-row">
                    <div class="form-group">
                        <label for="payroll_date_from">
                            <i class="fas fa-calendar-alt"></i> Date From
                        </label>
                        <div class="date-picker-wrapper">
                            <div class="date-input-group">
                                <input type="date" id="payroll_date_from" class="date-field" value="<?php echo date('Y-m-01'); ?>">
                                <button type="button" class="calendar-dropdown-btn" onclick="toggleCalendar('date_from')">
                                    <i class="fas fa-chevron-down"></i>
                                </button>
                            </div>
                            <div class="calendar-wrapper" id="calendar_date_from"></div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="payroll_date_to">
                            <i class="fas fa-calendar-alt"></i> Date To
                        </label>
                        <div class="date-picker-wrapper">
                            <div class="date-input-group">
                                <input type="date" id="payroll_date_to" class="date-field" value="<?php echo date('Y-m-t'); ?>">
                                <button type="button" class="calendar-dropdown-btn" onclick="toggleCalendar('date_to')">
                                    <i class="fas fa-chevron-down"></i>
                                </button>
                            </div>
                            <div class="calendar-wrapper" id="calendar_date_to"></div>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label><i class="fas fa-user"></i> Select Employee</label>
                    <div class="employee-search-container">
                        <input type="text" id="employeeSearch" class="employee-search-input" placeholder="Search employee by name or ID...">
                    </div>
                    
                    <!-- Employee Grid Display - Without Radio Buttons -->
                    <div class="employee-selection-grid" id="employeeGrid">
                        <?php if ($employees_result && $employees_result->num_rows > 0): ?>
                            <?php 
                            $employees_result->data_seek(0);
                            while ($emp = $employees_result->fetch_assoc()): 
                            ?>
                            <div class="employee-grid-item" onclick="selectEmployeeFromGrid(<?php echo $emp['id']; ?>)">
                                <div class="employee-grid-info">
                                    <div class="employee-grid-name"><?php echo htmlspecialchars($emp['first_name'] . ' ' . $emp['last_name']); ?></div>
                                    <div class="employee-grid-details">
                                        <span><i class="fas fa-id-badge"></i> <?php echo $emp['id']; ?></span>
                                        <span><i class="fas fa-briefcase"></i> <?php echo htmlspecialchars($emp['position']); ?></span>
                                        <span><i class="fas fa-phone"></i> <?php echo htmlspecialchars($emp['contact_num'] ?? 'N/A'); ?></span>
                                        <span><i class="fas fa-money-bill-wave"></i> ₱<?php echo number_format($emp['daily_salary'], 2); ?></span>
                                    </div>
                                </div>
                            </div>
                            <?php endwhile; ?>
                        <?php endif; ?>
                    </div>
                </div>

                <div id="selectedEmployeeInfo" style="display: none;">
                    <div class="employee-details-card">
                        <button class="change-employee-btn" onclick="changeEmployee()" title="Change Employee">
                            <i class="fas fa-times"></i>
                        </button>
                        <h4><i class="fas fa-user-circle"></i> Selected Employee</h4>
                        <div class="employee-details-grid">
                            <div class="detail-item">
                                <div class="detail-label">Name</div>
                                <div class="detail-value" id="selectedEmpName"></div>
                            </div>
                            <div class="detail-item">
                                <div class="detail-label">ID</div>
                                <div class="detail-value" id="selectedEmpId"></div>
                            </div>
                            <div class="detail-item">
                                <div class="detail-label">Position</div>
                                <div class="detail-value" id="selectedEmpPosition"></div>
                            </div>
                            <div class="detail-item">
                                <div class="detail-label">Contact</div>
                                <div class="detail-value" id="selectedEmpContact"></div>
                            </div>
                            <div class="detail-item">
                                <div class="detail-label">Address</div>
                                <div class="detail-value" id="selectedEmpAddress"></div>
                            </div>
                            <div class="detail-item">
                                <div class="detail-label">Daily Salary</div>
                                <div class="detail-value" id="selectedEmpSalary"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Step 2 Content -->
            <div id="step2Content" class="payroll-step">
                <div id="payrollSummary"></div>
                
                <div class="deductions-section">
                    <div class="deductions-header">
                        <h4><i class="fas fa-minus-circle"></i> Deductions</h4>
                        <button class="add-deduction-btn" onclick="openAddDeductionModal()">
                            <i class="fas fa-plus"></i> Add Deduction
                        </button>
                    </div>
                    <div class="deductions-list" id="deductionsList">
                        <div class="empty-deductions">
                            <i class="fas fa-receipt"></i>
                            <p>No deductions added yet</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Step 3 Content -->
            <div id="step3Content" class="payroll-step">
                <div class="form-group">
                    <label><i class="fas fa-check-circle"></i> Review and Save</label>
                    <div style="background: #e8f5e9; padding: 25px; border-radius: 12px; text-align: center;">
                        <i class="fas fa-check-circle" style="font-size: 48px; color: #28a745; margin-bottom: 15px;"></i>
                        <h4 style="color: #2e7d32; margin-bottom: 10px;">Ready to Save</h4>
                        <p style="color: #2c3e50;">Please review the payroll details above. Once saved, the payroll record will be added to the list.</p>
                    </div>
                </div>
            </div>

            <input type="hidden" id="currentEmployeeId">
            <input type="hidden" id="currentBaseSalary">
            <input type="hidden" id="currentTotalDeductions">
            <input type="hidden" id="currentNetPay">
            <input type="hidden" id="currentWorkHours">
        </div>
        <div class="modal-footer">
            <button class="modal-btn cancel" id="step1CancelBtn" onclick="closeModal('generatePayrollModal')">
                <i class="fas fa-times"></i> Cancel
            </button>
            <button class="modal-btn cancel" id="step2BackBtn" style="display: none;" onclick="goToStep(1)">
                <i class="fas fa-arrow-left"></i> Back
            </button>
            <button class="modal-btn cancel" id="step3BackBtn" style="display: none;" onclick="goToStep(2)">
                <i class="fas fa-arrow-left"></i> Back
            </button>
            <button class="modal-btn confirm" id="step1NextBtn" onclick="processPayrollStep1()">
                Next <i class="fas fa-arrow-right"></i>
            </button>
            <button class="modal-btn confirm" id="step2NextBtn" style="display: none;" onclick="goToStep(3)">
                Next <i class="fas fa-arrow-right"></i>
            </button>
            <button class="modal-btn primary" id="step3SaveBtn" style="display: none;" onclick="savePayroll()">
                <i class="fas fa-save"></i> Save Payroll
            </button>
        </div>
    </div>
</div>

<!-- Add Deduction Modal -->
<div id="addDeductionModal" class="modal">
    <div class="modal-content deduction-modal-content">
        <div class="modal-header primary">
            <i class="fas fa-plus-circle"></i>
            <h3>Add Custom Deduction</h3>
            <button class="close-btn" onclick="closeModal('addDeductionModal')"><i class="fas fa-times"></i></button>
        </div>
        <div class="modal-body">
            <input type="hidden" id="deductionEmployeeId">
            
            <div class="deduction-form-group">
                <label><i class="fas fa-tag"></i> Deduction Name</label>
                <select id="deductionName" class="deduction-form-control">
                    <option value="">Select deduction type</option>
                    <option value="Tax">Tax (Withholding)</option>
                    <option value="SSS">SSS</option>
                    <option value="Pag-IBIG">Pag-IBIG</option>
                    <option value="PhilHealth">PhilHealth</option>
                    <option value="Cash Advance">Cash Advance</option>
                    <option value="Uniform">Uniform</option>
                    <option value="Other">Other (Custom)</option>
                </select>
            </div>
            
            <div class="deduction-form-group" id="customNameGroup" style="display: none;">
                <label><i class="fas fa-pencil-alt"></i> Custom Name</label>
                <input type="text" id="customDeductionName" class="deduction-form-control" placeholder="Enter deduction name">
            </div>
            
            <div class="deduction-form-group">
                <label><i class="fas fa-dollar-sign"></i> Amount</label>
                <input type="number" id="deductionAmount" class="deduction-form-control" step="0.01" min="0" placeholder="0.00">
            </div>
            
            <div class="deduction-form-row">
                <div class="deduction-form-group">
                    <label><i class="fas fa-calendar-alt"></i> Start Date</label>
                    <div class="date-picker-wrapper">
                        <div class="date-input-group">
                            <input type="date" id="deductionStartDate" class="deduction-form-control">
                            <button type="button" class="calendar-dropdown-btn" onclick="toggleCalendar('deduction_start')">
                                <i class="fas fa-chevron-down"></i>
                            </button>
                        </div>
                        <div class="calendar-wrapper" id="calendar_deduction_start"></div>
                    </div>
                </div>
                <div class="deduction-form-group">
                    <label><i class="fas fa-calendar-alt"></i> End Date</label>
                    <div class="date-picker-wrapper">
                        <div class="date-input-group">
                            <input type="date" id="deductionEndDate" class="deduction-form-control">
                            <button type="button" class="calendar-dropdown-btn" onclick="toggleCalendar('deduction_end')">
                                <i class="fas fa-chevron-down"></i>
                            </button>
                        </div>
                        <div class="calendar-wrapper" id="calendar_deduction_end"></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button class="modal-btn cancel" onclick="closeModal('addDeductionModal')">
                <i class="fas fa-times"></i> Cancel
            </button>
            <button class="modal-btn confirm" onclick="addDeduction()">
                <i class="fas fa-plus"></i> Add Deduction
            </button>
        </div>
    </div>
</div>

<!-- Edit Payroll Modal -->
<div id="editPayrollModal" class="modal">
    <div class="modal-content">
        <div class="modal-header warning">
            <i class="fas fa-edit"></i>
            <h3>Edit Payroll</h3>
            <button class="close-btn" onclick="closeModal('editPayrollModal')"><i class="fas fa-times"></i></button>
        </div>
        <div class="modal-body">
            <input type="hidden" id="edit_payroll_id">
            <input type="hidden" id="edit_employee_id">
            
            <div class="form-group">
                <label><i class="fas fa-user"></i> Employee</label>
                <input type="text" id="edit_employee_name" class="form-control" readonly>
            </div>
            
            <div class="date-row">
                <div class="form-group">
                    <label for="edit_date_from">
                        <i class="fas fa-calendar-alt"></i> Date From
                    </label>
                    <div class="date-picker-wrapper">
                        <div class="date-input-group">
                            <input type="date" id="edit_date_from" class="date-field" onchange="recalculateEditPayroll()">
                            <button type="button" class="calendar-dropdown-btn" onclick="toggleCalendar('edit_from')">
                                <i class="fas fa-chevron-down"></i>
                            </button>
                        </div>
                        <div class="calendar-wrapper" id="calendar_edit_from"></div>
                    </div>
                </div>
                <div class="form-group">
                    <label for="edit_date_to">
                        <i class="fas fa-calendar-alt"></i> Date To
                    </label>
                    <div class="date-picker-wrapper">
                        <div class="date-input-group">
                            <input type="date" id="edit_date_to" class="date-field" onchange="recalculateEditPayroll()">
                            <button type="button" class="calendar-dropdown-btn" onclick="toggleCalendar('edit_to')">
                                <i class="fas fa-chevron-down"></i>
                            </button>
                        </div>
                        <div class="calendar-wrapper" id="calendar_edit_to"></div>
                    </div>
                </div>
            </div>
            
            <div id="editPayrollSummary"></div>
            
            <div class="deductions-section">
                <div class="deductions-header">
                    <h4><i class="fas fa-minus-circle"></i> Deductions</h4>
                    <button class="add-deduction-btn" onclick="openEditAddDeductionModal()">
                        <i class="fas fa-plus"></i> Add Deduction
                    </button>
                </div>
                <div class="deductions-list" id="editDeductionsList"></div>
            </div>
            
            <div class="form-group">
                <label for="edit_status">
                    <i class="fas fa-tag"></i> Status
                </label>
                <select id="edit_status" class="form-control">
                    <option value="pending">Pending</option>
                    <option value="paid">Paid</option>
                </select>
            </div>
        </div>
        <div class="modal-footer">
            <button class="modal-btn cancel" onclick="closeModal('editPayrollModal')">
                <i class="fas fa-times"></i> Cancel
            </button>
            <button class="modal-btn edit" onclick="updatePayrollStatus()">
                <i class="fas fa-save"></i> Update Status
            </button>
        </div>
    </div>
</div>

<!-- View Payroll Modal -->
<div id="viewPayrollModal" class="modal">
    <div class="modal-content large">
        <div class="modal-header info">
            <i class="fas fa-eye"></i>
            <h3>Payroll Details</h3>
            <button class="close-btn" onclick="closeModal('viewPayrollModal')"><i class="fas fa-times"></i></button>
        </div>
        <div class="modal-body" id="viewPayrollContent">
            <!-- Content will be populated dynamically -->
        </div>
        <div class="modal-footer">
            <button class="modal-btn confirm" onclick="closeModal('viewPayrollModal')">
                <i class="fas fa-check"></i> Close
            </button>
        </div>
    </div>
</div>

<!-- Delete Payroll Confirmation Modal -->
<div id="deletePayrollModal" class="modal">
    <div class="modal-content">
        <div class="modal-header danger">
            <i class="fas fa-exclamation-triangle"></i>
            <h3>Delete Payroll Record</h3>
            <button class="close-btn" onclick="closeModal('deletePayrollModal')"><i class="fas fa-times"></i></button>
        </div>
        <div class="modal-body">
            <div class="delete-icon">
                <i class="fas fa-trash-alt"></i>
            </div>
            <div class="delete-message">
                Are you sure you want to delete this payroll record?
            </div>
            <div class="delete-details" id="deletePayrollDetails">
                <!-- Payroll details will be displayed here -->
            </div>
            <div class="delete-warning">
                <i class="fas fa-info-circle"></i> This action cannot be undone.
            </div>
        </div>
        <div class="modal-footer">
            <button class="modal-btn cancel" onclick="closeModal('deletePayrollModal')">
                <i class="fas fa-times"></i> Cancel
            </button>
            <button class="modal-btn delete" onclick="confirmDeletePayroll()">
                <i class="fas fa-trash-alt"></i> Delete
            </button>
        </div>
    </div>
</div>

<!-- Generate Payroll Success Modal -->
<div id="generateSuccessModal" class="modal">
    <div class="modal-content">
        <div class="modal-header success">
            <i class="fas fa-check-circle"></i>
            <h3>Payroll Generated Successfully</h3>
            <button class="close-btn" onclick="closeModal('generateSuccessModal')"><i class="fas fa-times"></i></button>
        </div>
        <div class="modal-body">
            <p id="successMessage" class="success-message"></p>
        </div>
        <div class="modal-footer">
            <button class="modal-btn confirm" onclick="closeModalAndRefresh()">
                <i class="fas fa-check"></i> OK
            </button>
        </div>
    </div>
</div>

<!-- Existing Payroll Warning Modal -->
<div id="existingPayrollModal" class="modal">
    <div class="modal-content">
        <div class="modal-header warning">
            <i class="fas fa-exclamation-triangle"></i>
            <h3>Payroll Already Exists</h3>
            <button class="close-btn" onclick="closeModal('existingPayrollModal')"><i class="fas fa-times"></i></button>
        </div>
        <div class="modal-body">
            <div class="warning-icon">
                <i class="fas fa-clock"></i>
            </div>
            <p style="text-align: center; font-size: 16px; margin-bottom: 20px;">The payroll is existing.</p>
            <p style="text-align: center; color: #666;">A payroll record already exists for this employee and date range.</p>
        </div>
        <div class="modal-footer">
            <button class="modal-btn confirm" onclick="closeModal('existingPayrollModal')">
                <i class="fas fa-check"></i> OK
            </button>
        </div>
    </div>
</div>

<!-- Edit Add Deduction Modal -->
<div id="editAddDeductionModal" class="modal">
    <div class="modal-content deduction-modal-content">
        <div class="modal-header primary">
            <i class="fas fa-plus-circle"></i>
            <h3>Add Deduction to Edit</h3>
            <button class="close-btn" onclick="closeModal('editAddDeductionModal')"><i class="fas fa-times"></i></button>
        </div>
        <div class="modal-body">
            <input type="hidden" id="editDeductionEmployeeId">
            
            <div class="deduction-form-group">
                <label><i class="fas fa-tag"></i> Deduction Name</label>
                <select id="editDeductionName" class="deduction-form-control">
                    <option value="">Select deduction type</option>
                    <option value="Tax">Tax (Withholding)</option>
                    <option value="SSS">SSS</option>
                    <option value="Pag-IBIG">Pag-IBIG</option>
                    <option value="PhilHealth">PhilHealth</option>
                    <option value="Cash Advance">Cash Advance</option>
                    <option value="Uniform">Uniform</option>
                    <option value="Other">Other (Custom)</option>
                </select>
            </div>
            
            <div class="deduction-form-group" id="editCustomNameGroup" style="display: none;">
                <label><i class="fas fa-pencil-alt"></i> Custom Name</label>
                <input type="text" id="editCustomDeductionName" class="deduction-form-control" placeholder="Enter deduction name">
            </div>
            
            <div class="deduction-form-group">
                <label><i class="fas fa-dollar-sign"></i> Amount</label>
                <input type="number" id="editDeductionAmount" class="deduction-form-control" step="0.01" min="0" placeholder="0.00">
            </div>
            
            <div class="deduction-form-row">
                <div class="deduction-form-group">
                    <label><i class="fas fa-calendar-alt"></i> Start Date</label>
                    <div class="date-picker-wrapper">
                        <div class="date-input-group">
                            <input type="date" id="editDeductionStartDate" class="deduction-form-control">
                            <button type="button" class="calendar-dropdown-btn" onclick="toggleCalendar('edit_deduction_start')">
                                <i class="fas fa-chevron-down"></i>
                            </button>
                        </div>
                        <div class="calendar-wrapper" id="calendar_edit_deduction_start"></div>
                    </div>
                </div>
                <div class="deduction-form-group">
                    <label><i class="fas fa-calendar-alt"></i> End Date</label>
                    <div class="date-picker-wrapper">
                        <div class="date-input-group">
                            <input type="date" id="editDeductionEndDate" class="deduction-form-control">
                            <button type="button" class="calendar-dropdown-btn" onclick="toggleCalendar('edit_deduction_end')">
                                <i class="fas fa-chevron-down"></i>
                            </button>
                        </div>
                        <div class="calendar-wrapper" id="calendar_edit_deduction_end"></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button class="modal-btn cancel" onclick="closeModal('editAddDeductionModal')">
                <i class="fas fa-times"></i> Cancel
            </button>
            <button class="modal-btn confirm" onclick="addEditDeduction()">
                <i class="fas fa-plus"></i> Add Deduction
            </button>
        </div>
    </div>
</div>

<!-- Notification Modal -->
<div id="notificationModal" class="notification-modal">
    <div class="notification-modal-content">
        <div class="notification-modal-header" id="notificationHeader">
            <i class="fas" id="notificationIcon"></i>
            <h3 id="notificationTitle"></h3>
            <button class="close-btn" onclick="closeNotificationModal()"><i class="fas fa-times"></i></button>
        </div>
        <div class="notification-modal-body">
            <p id="notificationMessage"></p>
        </div>
        <div class="notification-modal-footer">
            <button class="notification-modal-btn" id="notificationBtn" onclick="closeNotificationModal()">OK</button>
        </div>
    </div>
</div>

<!-- Loading Overlay -->
<div class="loading-overlay" id="loadingOverlay">
    <div class="loading-spinner"></div>
    <p>Processing...</p>
</div>

<?php include_once("./modal/logout-modal.php"); ?>
<?php include_once("./includes/footer.php"); ?>

<script>
    // Global variables
    let employees = [];
    let selectedEmployee = null;
    let currentPayrollData = null;
    let currentDeductions = [];
    let currentStep = 1;
    let currentDeletePayrollId = null;
    let editPayrollId = null;
    let editEmployeeId = null;
    let editDeductions = [];
    
    // Calendar variables
    let activeCalendar = null;
    let calendarDates = {
        date_from: { currentDate: new Date(), selectedDate: '<?php echo date('Y-m-01'); ?>' },
        date_to: { currentDate: new Date(), selectedDate: '<?php echo date('Y-m-t'); ?>' },
        deduction_start: { currentDate: new Date(), selectedDate: null },
        deduction_end: { currentDate: new Date(), selectedDate: null },
        edit_from: { currentDate: new Date(), selectedDate: null },
        edit_to: { currentDate: new Date(), selectedDate: null },
        edit_deduction_start: { currentDate: new Date(), selectedDate: null },
        edit_deduction_end: { currentDate: new Date(), selectedDate: null }
    };

    // Initialize
    document.addEventListener('DOMContentLoaded', function() {
        loadEmployees();
        initializeAllCalendars();
        
        // Set min dates for date inputs
        const dateFrom = document.getElementById('payroll_date_from');
        const dateTo = document.getElementById('payroll_date_to');
        
        if (dateFrom) {
            dateFrom.addEventListener('change', function() {
                dateTo.min = this.value;
                if (dateTo.value < this.value) {
                    dateTo.value = this.value;
                }
            });
        }

        // Main page payroll search functionality
        const mainSearchInput = document.getElementById('mainSearchInput');
        if (mainSearchInput) {
            mainSearchInput.addEventListener('input', function() {
                const query = this.value.trim();
                if (query.length >= 2) {
                    performPayrollSearch();
                } else {
                    document.getElementById('mainSearchResults').classList.remove('show');
                    // Show all payroll rows
                    document.querySelectorAll('.payroll-row').forEach(row => {
                        row.style.display = '';
                    });
                }
            });
            
            mainSearchInput.addEventListener('focus', function() {
                const query = this.value.trim();
                if (query.length >= 2) {
                    performPayrollSearch();
                }
            });
            
            // Close results when clicking outside
            document.addEventListener('click', function(e) {
                const container = document.querySelector('.main-search-container');
                const results = document.getElementById('mainSearchResults');
                if (container && !container.contains(e.target) && results) {
                    results.classList.remove('show');
                }
            });
        }

        // Modal employee search
        const modalSearchInput = document.getElementById('employeeSearch');
        if (modalSearchInput) {
            modalSearchInput.addEventListener('input', function() {
                const query = this.value.trim().toLowerCase();
                filterEmployeeGrid(query);
            });
        }
        
        // Close calendar when clicking outside
        document.addEventListener('click', function(e) {
            if (activeCalendar && !e.target.closest('.date-picker-wrapper')) {
                document.getElementById(activeCalendar).style.display = 'none';
                activeCalendar = null;
            }
        });
    });

    // Filter employee grid in modal
    function filterEmployeeGrid(query) {
        const gridItems = document.querySelectorAll('.employee-grid-item');
        let visibleCount = 0;
        
        gridItems.forEach(item => {
            const name = item.querySelector('.employee-grid-name').textContent.toLowerCase();
            const details = item.querySelector('.employee-grid-details').textContent.toLowerCase();
            
            if (name.includes(query) || details.includes(query) || query === '') {
                item.style.display = 'flex';
                visibleCount++;
            } else {
                item.style.display = 'none';
            }
        });
    }

    // Perform main page payroll search
    function performPayrollSearch() {
        const searchInput = document.getElementById('mainSearchInput');
        const resultsDiv = document.getElementById('mainSearchResults');
        const query = searchInput.value.trim().toLowerCase();
        
        if (query.length < 2) {
            resultsDiv.classList.remove('show');
            // Show all payroll rows
            document.querySelectorAll('.payroll-row').forEach(row => {
                row.style.display = '';
            });
            return;
        }
        
        // Filter table rows
        const rows = document.querySelectorAll('.payroll-row');
        let visibleCount = 0;
        
        rows.forEach(row => {
            const name = row.getAttribute('data-name') || '';
            const position = row.getAttribute('data-position') || '';
            const dateFrom = row.getAttribute('data-date-from') || '';
            const dateTo = row.getAttribute('data-date-to') || '';
            const rowText = `${name} ${position} ${dateFrom} ${dateTo}`.toLowerCase();
            
            if (rowText.includes(query)) {
                row.style.display = '';
                visibleCount++;
            } else {
                row.style.display = 'none';
            }
        });
        
        // Show search results in dropdown
        if (visibleCount > 0) {
            resultsDiv.innerHTML = `<div style="padding: 15px; text-align: center; color: #666;"><i class="fas fa-check-circle" style="color: #28a745;"></i> Found ${visibleCount} matching payroll records</div>`;
        } else {
            resultsDiv.innerHTML = '<div style="padding: 15px; text-align: center; color: #999;">No matching payroll records found</div>';
        }
        resultsDiv.classList.add('show');
    }

    // Initialize all calendars
    function initializeAllCalendars() {
        const calendarIds = ['date_from', 'date_to', 'deduction_start', 'deduction_end', 'edit_from', 'edit_to', 'edit_deduction_start', 'edit_deduction_end'];
        calendarIds.forEach(id => {
            const calendarElement = document.getElementById(`calendar_${id}`);
            if (calendarElement) {
                generateCalendarHTML(id, calendarElement);
            }
        });
    }

    // Generate calendar HTML
    function generateCalendarHTML(calendarId, container) {
        const date = calendarDates[calendarId].currentDate || new Date();
        const year = date.getFullYear();
        const month = date.getMonth();
        const selectedDate = calendarDates[calendarId].selectedDate;
        
        const firstDay = new Date(year, month, 1).getDay();
        const daysInMonth = new Date(year, month + 1, 0).getDate();
        const today = new Date();
        
        let html = `
            <div class="calendar-box">
                <div class="calendar-header">
                    <div class="calendar-month-year">${date.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}</div>
                    <div class="calendar-nav">
                        <button type="button" class="calendar-nav-btn" onclick="navigateCalendar('${calendarId}', -1)">‹</button>
                        <button type="button" class="calendar-nav-btn" onclick="navigateCalendar('${calendarId}', 1)">›</button>
                    </div>
                </div>
                
                <div class="calendar-selectors">
                    <select id="monthSelect_${calendarId}" class="calendar-select" onchange="changeCalendarMonthYear('${calendarId}')">
                        <option value="0" ${month === 0 ? 'selected' : ''}>January</option>
                        <option value="1" ${month === 1 ? 'selected' : ''}>February</option>
                        <option value="2" ${month === 2 ? 'selected' : ''}>March</option>
                        <option value="3" ${month === 3 ? 'selected' : ''}>April</option>
                        <option value="4" ${month === 4 ? 'selected' : ''}>May</option>
                        <option value="5" ${month === 5 ? 'selected' : ''}>June</option>
                        <option value="6" ${month === 6 ? 'selected' : ''}>July</option>
                        <option value="7" ${month === 7 ? 'selected' : ''}>August</option>
                        <option value="8" ${month === 8 ? 'selected' : ''}>September</option>
                        <option value="9" ${month === 9 ? 'selected' : ''}>October</option>
                        <option value="10" ${month === 10 ? 'selected' : ''}>November</option>
                        <option value="11" ${month === 11 ? 'selected' : ''}>December</option>
                    </select>
                    
                    <select id="yearSelect_${calendarId}" class="calendar-select" onchange="changeCalendarMonthYear('${calendarId}')">
        `;
        
        for (let y = year - 10; y <= year + 10; y++) {
            html += `<option value="${y}" ${y === year ? 'selected' : ''}>${y}</option>`;
        }
        
        html += `
                    </select>
                </div>
                
                <div class="calendar-weekdays">
                    <div>Su</div>
                    <div>Mo</div>
                    <div>Tu</div>
                    <div>We</div>
                    <div>Th</div>
                    <div>Fr</div>
                    <div>Sa</div>
                </div>
                
                <div class="calendar-days-grid">
        `;
        
        // Previous month days
        const prevMonthDays = new Date(year, month, 0).getDate();
        for (let i = firstDay - 1; i >= 0; i--) {
            const day = prevMonthDays - i;
            const dateStr = `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
            html += `<div class="calendar-day other-month" onclick="selectCalendarDate('${calendarId}', '${dateStr}')">${day}</div>`;
        }
        
        // Current month days
        for (let day = 1; day <= daysInMonth; day++) {
            const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
            const isToday = today.getFullYear() === year && today.getMonth() === month && today.getDate() === day;
            const isSelected = selectedDate === dateStr;
            const isWeekend = new Date(year, month, day).getDay() === 0 || new Date(year, month, day).getDay() === 6;
            
            let classes = 'calendar-day';
            if (isToday) classes += ' today';
            if (isSelected) classes += ' selected';
            if (isWeekend) classes += ' weekend';
            
            html += `<div class="${classes}" onclick="selectCalendarDate('${calendarId}', '${dateStr}')">${day}</div>`;
        }
        
        // Next month days
        const totalCells = 42;
        const cellsUsed = firstDay + daysInMonth;
        const nextMonthDays = totalCells - cellsUsed;
        for (let day = 1; day <= nextMonthDays; day++) {
            const dateStr = `${year}-${String(month + 2).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
            html += `<div class="calendar-day other-month" onclick="selectCalendarDate('${calendarId}', '${dateStr}')">${day}</div>`;
        }
        
        html += `
                </div>
                
                <div class="calendar-footer">
                    <button type="button" class="calendar-action-btn clear" onclick="clearCalendarDate('${calendarId}')">
                        <i class="fas fa-times"></i> Clear
                    </button>
                    <button type="button" class="calendar-action-btn today" onclick="setCalendarToday('${calendarId}')">
                        <i class="fas fa-calendar-check"></i> Today
                    </button>
                </div>
            </div>
        `;
        
        container.innerHTML = html;
    }

    // Toggle calendar
    function toggleCalendar(calendarId) {
        const calendar = document.getElementById(`calendar_${calendarId}`);
        if (calendar) {
            if (calendar.style.display === 'block') {
                calendar.style.display = 'none';
                activeCalendar = null;
            } else {
                document.querySelectorAll('.calendar-wrapper').forEach(cal => {
                    cal.style.display = 'none';
                });
                calendar.style.display = 'block';
                activeCalendar = `calendar_${calendarId}`;
                generateCalendarHTML(calendarId, calendar);
            }
        }
    }

    // Navigate calendar month
    function navigateCalendar(calendarId, direction) {
        const date = calendarDates[calendarId].currentDate;
        date.setMonth(date.getMonth() + direction);
        const calendar = document.getElementById(`calendar_${calendarId}`);
        generateCalendarHTML(calendarId, calendar);
    }

    // Change calendar month/year
    function changeCalendarMonthYear(calendarId) {
        const monthSelect = document.getElementById(`monthSelect_${calendarId}`);
        const yearSelect = document.getElementById(`yearSelect_${calendarId}`);
        
        if (monthSelect && yearSelect) {
            const newMonth = parseInt(monthSelect.value);
            const newYear = parseInt(yearSelect.value);
            
            calendarDates[calendarId].currentDate = new Date(newYear, newMonth, 1);
            const calendar = document.getElementById(`calendar_${calendarId}`);
            generateCalendarHTML(calendarId, calendar);
        }
    }

    // Select calendar date
    function selectCalendarDate(calendarId, dateStr) {
        calendarDates[calendarId].selectedDate = dateStr;
        
        let inputId = '';
        switch(calendarId) {
            case 'date_from':
                inputId = 'payroll_date_from';
                break;
            case 'date_to':
                inputId = 'payroll_date_to';
                break;
            case 'deduction_start':
                inputId = 'deductionStartDate';
                break;
            case 'deduction_end':
                inputId = 'deductionEndDate';
                break;
            case 'edit_from':
                inputId = 'edit_date_from';
                break;
            case 'edit_to':
                inputId = 'edit_date_to';
                break;
            case 'edit_deduction_start':
                inputId = 'editDeductionStartDate';
                break;
            case 'edit_deduction_end':
                inputId = 'editDeductionEndDate';
                break;
        }
        
        if (inputId) {
            document.getElementById(inputId).value = dateStr;
        }
        
        document.getElementById(`calendar_${calendarId}`).style.display = 'none';
        activeCalendar = null;
        
        if (calendarId === 'date_from') {
            document.getElementById('payroll_date_to').min = dateStr;
        } else if (calendarId === 'edit_from') {
            document.getElementById('edit_date_to').min = dateStr;
            recalculateEditPayroll();
        } else if (calendarId === 'edit_to') {
            recalculateEditPayroll();
        }
    }

    // Clear calendar date
    function clearCalendarDate(calendarId) {
        calendarDates[calendarId].selectedDate = null;
        
        let inputId = '';
        switch(calendarId) {
            case 'date_from':
                inputId = 'payroll_date_from';
                break;
            case 'date_to':
                inputId = 'payroll_date_to';
                break;
            case 'deduction_start':
                inputId = 'deductionStartDate';
                break;
            case 'deduction_end':
                inputId = 'deductionEndDate';
                break;
            case 'edit_from':
                inputId = 'edit_date_from';
                break;
            case 'edit_to':
                inputId = 'edit_date_to';
                break;
            case 'edit_deduction_start':
                inputId = 'editDeductionStartDate';
                break;
            case 'edit_deduction_end':
                inputId = 'editDeductionEndDate';
                break;
        }
        
        if (inputId) {
            document.getElementById(inputId).value = '';
        }
        
        const calendar = document.getElementById(`calendar_${calendarId}`);
        generateCalendarHTML(calendarId, calendar);
    }

    // Set calendar to today
    function setCalendarToday(calendarId) {
        const today = new Date();
        const year = today.getFullYear();
        const month = String(today.getMonth() + 1).padStart(2, '0');
        const day = String(today.getDate()).padStart(2, '0');
        const dateStr = `${year}-${month}-${day}`;
        
        calendarDates[calendarId].currentDate = new Date(dateStr);
        selectCalendarDate(calendarId, dateStr);
    }

    // Load employees from PHP
    function loadEmployees() {
        <?php if ($employees_result && $employees_result->num_rows > 0): ?>
            <?php 
            $employees_result->data_seek(0);
            while ($emp = $employees_result->fetch_assoc()): 
            ?>
            employees.push({
                id: <?php echo $emp['id']; ?>,
                name: '<?php echo htmlspecialchars($emp['first_name'] . ' ' . $emp['last_name'], ENT_QUOTES); ?>',
                first_name: '<?php echo htmlspecialchars($emp['first_name'], ENT_QUOTES); ?>',
                last_name: '<?php echo htmlspecialchars($emp['last_name'], ENT_QUOTES); ?>',
                position: '<?php echo htmlspecialchars($emp['position'], ENT_QUOTES); ?>',
                address: '<?php echo htmlspecialchars($emp['address'], ENT_QUOTES); ?>',
                contact: '<?php echo htmlspecialchars($emp['contact_num'] ?? '', ENT_QUOTES); ?>',
                daily_salary: <?php echo floatval($emp['daily_salary']); ?>
            });
            <?php endwhile; ?>
        <?php endif; ?>
    }

    // Select employee from grid
    function selectEmployeeFromGrid(employeeId) {
        const employee = employees.find(e => e.id === employeeId);
        if (!employee) return;
        
        // Remove selected class from all grid items
        document.querySelectorAll('.employee-grid-item').forEach(item => {
            item.classList.remove('selected');
        });
        
        // Add selected class to clicked item
        const selectedItem = Array.from(document.querySelectorAll('.employee-grid-item')).find(
            item => item.querySelector('.employee-grid-name').textContent.includes(employee.name)
        );
        if (selectedItem) {
            selectedItem.classList.add('selected');
        }
        
        // Update selected display
        selectedEmployee = employee;
        document.getElementById('selectedEmployeeInfo').style.display = 'block';
        document.getElementById('selectedEmpName').textContent = employee.name;
        document.getElementById('selectedEmpId').textContent = employee.id;
        document.getElementById('selectedEmpPosition').textContent = employee.position;
        document.getElementById('selectedEmpContact').textContent = employee.contact || 'N/A';
        document.getElementById('selectedEmpAddress').textContent = employee.address || 'N/A';
        document.getElementById('selectedEmpSalary').textContent = '₱' + parseFloat(employee.daily_salary).toFixed(2);
        document.getElementById('currentEmployeeId').value = employee.id;
        document.getElementById('employeeSearch').value = employee.name;
    }

    // Change employee
    function changeEmployee() {
        selectedEmployee = null;
        document.getElementById('selectedEmployeeInfo').style.display = 'none';
        document.getElementById('employeeSearch').value = '';
        document.getElementById('currentEmployeeId').value = '';
        
        // Remove selected class from all grid items
        document.querySelectorAll('.employee-grid-item').forEach(item => {
            item.classList.remove('selected');
        });
    }

    // Modal functions
    function openModal(modalId) {
        document.getElementById(modalId).classList.add('show');
        document.body.classList.add('modal-open');
    }

    function closeModal(modalId) {
        document.getElementById(modalId).classList.remove('show');
        document.body.classList.remove('modal-open');
        
        if (modalId === 'generatePayrollModal') {
            resetPayrollModal();
        } else if (modalId === 'addDeductionModal') {
            resetDeductionModal();
        } else if (modalId === 'editAddDeductionModal') {
            resetEditDeductionModal();
        }
        
        document.querySelectorAll('.calendar-wrapper').forEach(cal => {
            cal.style.display = 'none';
        });
        activeCalendar = null;
    }

    function closeModalAndRefresh() {
        closeModal('generateSuccessModal');
        location.reload();
    }

    // Notification modal functions
    function showNotificationModal(message, type = 'info') {
        const modal = document.getElementById('notificationModal');
        const header = document.getElementById('notificationHeader');
        const icon = document.getElementById('notificationIcon');
        const title = document.getElementById('notificationTitle');
        const messageEl = document.getElementById('notificationMessage');
        const btn = document.getElementById('notificationBtn');
        
        header.className = 'notification-modal-header ' + type;
        btn.className = 'notification-modal-btn ' + type;
        
        if (type === 'success') {
            icon.className = 'fas fa-check-circle';
            title.textContent = 'Success';
        } else if (type === 'error') {
            icon.className = 'fas fa-exclamation-circle';
            title.textContent = 'Error';
        } else if (type === 'warning') {
            icon.className = 'fas fa-exclamation-triangle';
            title.textContent = 'Warning';
        } else {
            icon.className = 'fas fa-info-circle';
            title.textContent = 'Information';
        }
        
        messageEl.textContent = message;
        modal.classList.add('show');
    }

    function closeNotificationModal() {
        document.getElementById('notificationModal').classList.remove('show');
    }

    // Open generate payroll modal
    function openGeneratePayrollModal() {
        resetPayrollModal();
        goToStep(1);
        openModal('generatePayrollModal');
    }

    // Reset payroll modal
    function resetPayrollModal() {
        currentStep = 1;
        currentPayrollData = null;
        currentDeductions = [];
        selectedEmployee = null;
        
        document.getElementById('selectedEmployeeInfo').style.display = 'none';
        document.getElementById('employeeSearch').value = '';
        document.getElementById('payroll_date_from').value = '<?php echo date('Y-m-01'); ?>';
        document.getElementById('payroll_date_to').value = '<?php echo date('Y-m-t'); ?>';
        document.getElementById('currentEmployeeId').value = '';
        
        // Remove selected class from all grid items
        document.querySelectorAll('.employee-grid-item').forEach(item => {
            item.classList.remove('selected');
        });
        
        calendarDates.date_from.selectedDate = '<?php echo date('Y-m-01'); ?>';
        calendarDates.date_to.selectedDate = '<?php echo date('Y-m-t'); ?>';
        
        updateStepIndicators(1);
        document.getElementById('modalStepTitle').textContent = 'Generate Payroll - Step 1: Select Date and Employee';
    }

    // Go to step
    function goToStep(step) {
        currentStep = step;
        updateStepIndicators(step);
        
        document.getElementById('step1Content').classList.toggle('active', step === 1);
        document.getElementById('step2Content').classList.toggle('active', step === 2);
        document.getElementById('step3Content').classList.toggle('active', step === 3);
        
        document.getElementById('step1CancelBtn').style.display = step === 1 ? 'inline-block' : 'none';
        document.getElementById('step2BackBtn').style.display = step === 2 ? 'inline-block' : 'none';
        document.getElementById('step3BackBtn').style.display = step === 3 ? 'inline-block' : 'none';
        document.getElementById('step1NextBtn').style.display = step === 1 ? 'inline-block' : 'none';
        document.getElementById('step2NextBtn').style.display = step === 2 ? 'inline-block' : 'none';
        document.getElementById('step3SaveBtn').style.display = step === 3 ? 'inline-block' : 'none';
        
        // Update modal title
        const titles = [
            'Generate Payroll - Step 1: Select Date and Employee',
            'Generate Payroll - Step 2: Review and Add Deductions',
            'Generate Payroll - Step 3: Save Payroll'
        ];
        document.getElementById('modalStepTitle').textContent = titles[step - 1];
    }

    // Update step indicators
    function updateStepIndicators(activeStep) {
        const step1 = document.getElementById('step1Indicator');
        const step2 = document.getElementById('step2Indicator');
        const step3 = document.getElementById('step3Indicator');
        
        step1.classList.toggle('active', activeStep === 1);
        step2.classList.toggle('active', activeStep === 2);
        step3.classList.toggle('active', activeStep === 3);
        
        step1.classList.toggle('completed', activeStep > 1);
        step2.classList.toggle('completed', activeStep > 2);
        step3.classList.toggle('completed', false);
    }

    // Process payroll step 1
    async function processPayrollStep1() {
        const employeeId = document.getElementById('currentEmployeeId').value;
        const dateFrom = document.getElementById('payroll_date_from').value;
        const dateTo = document.getElementById('payroll_date_to').value;
        
        if (!employeeId) {
            showNotificationModal('Please select an employee', 'error');
            return;
        }
        
        if (!dateFrom || !dateTo) {
            showNotificationModal('Please select date range', 'error');
            return;
        }
        
        showLoading();
        
        try {
            const response = await fetch('payrollList.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'generate_payroll_ajax=1&date_from=' + encodeURIComponent(dateFrom) + 
                      '&date_to=' + encodeURIComponent(dateTo) + 
                      '&employee_id=' + encodeURIComponent(employeeId)
            });
            
            const text = await response.text();
            
            try {
                const data = JSON.parse(text);
                
                if (data.success) {
                    currentPayrollData = data.payroll;
                    currentDeductions = data.payroll.deductions || [];
                    displayPayrollSummary(data.payroll);
                    goToStep(2);
                    hideLoading();
                } else if (data.exists) {
                    // Show existing payroll modal
                    hideLoading();
                    openModal('existingPayrollModal');
                } else {
                    showNotificationModal(data.message, 'error');
                    hideLoading();
                }
            } catch (e) {
                console.error('Failed to parse JSON:', text);
                showNotificationModal('Server returned invalid response. Check console for details.', 'error');
                hideLoading();
            }
        } catch (error) {
            console.error('Error:', error);
            showNotificationModal('Error processing payroll: ' + error.message, 'error');
            hideLoading();
        }
    }

    // Display payroll summary
    function displayPayrollSummary(data) {
        const container = document.getElementById('payrollSummary');
        const emp = data.employee;
        
        let deductionsHtml = '';
        if (data.deductions && data.deductions.length > 0) {
            data.deductions.forEach(d => {
                deductionsHtml += `
                    <div class="computation-row">
                        <div class="computation-label">
                            <i class="fas fa-minus-circle" style="color:#dc3545;"></i>
                            ${d.deduction_name}
                        </div>
                        <div class="computation-value">- ₱${parseFloat(d.amount).toFixed(2)}</div>
                    </div>
                `;
            });
        }
        
        const html = `
            <div class="attendance-summary">
                <div class="summary-item">
                    <div class="summary-label">Total Days</div>
                    <div class="summary-value">${data.total_days}</div>
                </div>
                <div class="summary-item">
                    <div class="summary-label">Days Present</div>
                    <div class="summary-value">${data.days_present}</div>
                </div>
                <div class="summary-item">
                    <div class="summary-label">Days On Leave</div>
                    <div class="summary-value">${data.days_on_leave}</div>
                </div>
            </div>
            
            <div class="computation-box">
                <div class="computation-header">
                    <i class="fas fa-calculator"></i> Salary Computation
                </div>
                <div class="computation-row">
                    <div class="computation-label">
                        <i class="fas fa-clock"></i> Total Work Hours
                    </div>
                    <div class="computation-value">${parseFloat(data.total_work_hours).toFixed(2)} hrs</div>
                </div>
                <div class="computation-row">
                    <div class="computation-label">
                        <i class="fas fa-clock"></i> Regular Hours
                    </div>
                    <div class="computation-value">${parseFloat(data.regular_hours).toFixed(2)} hrs</div>
                </div>
                <div class="computation-row">
                    <div class="computation-label">
                        <i class="fas fa-clock"></i> Overtime Hours (1.25x)
                    </div>
                    <div class="computation-value">${parseFloat(data.overtime_hours).toFixed(2)} hrs</div>
                </div>
                <div class="computation-row">
                    <div class="computation-label">
                        <i class="fas fa-tag"></i> Hourly Rate
                    </div>
                    <div class="computation-value">₱${parseFloat(data.hourly_rate).toFixed(2)}</div>
                </div>
                <div class="computation-row">
                    <div class="computation-label">
                        <i class="fas fa-money-bill"></i> Regular Pay
                    </div>
                    <div class="computation-value">₱${parseFloat(data.regular_pay).toFixed(2)}</div>
                </div>
                <div class="computation-row">
                    <div class="computation-label">
                        <i class="fas fa-money-bill"></i> Overtime Pay
                    </div>
                    <div class="computation-value">₱${parseFloat(data.overtime_pay).toFixed(2)}</div>
                </div>
                <div class="computation-row">
                    <div class="computation-label">
                        <i class="fas fa-money-bill"></i> Base Salary
                    </div>
                    <div class="computation-value">₱${parseFloat(data.base_salary).toFixed(2)}</div>
                </div>
                ${deductionsHtml}
                <div class="computation-row total">
                    <div class="computation-label">
                        <i class="fas fa-calculator"></i> Total Deductions
                    </div>
                    <div class="computation-value">- ₱${parseFloat(data.total_deductions).toFixed(2)}</div>
                </div>
                <div class="computation-row net">
                    <div class="computation-label">
                        <i class="fas fa-check-circle"></i> Net Pay
                    </div>
                    <div class="computation-value">₱${parseFloat(data.net_pay).toFixed(2)}</div>
                </div>
            </div>
        `;
        
        container.innerHTML = html;
        
        document.getElementById('currentBaseSalary').value = data.base_salary;
        document.getElementById('currentTotalDeductions').value = data.total_deductions;
        document.getElementById('currentNetPay').value = data.net_pay;
        document.getElementById('currentWorkHours').value = data.total_work_hours;
        
        updateDeductionsList();
    }

    // Update deductions list
    function updateDeductionsList() {
        const container = document.getElementById('deductionsList');
        
        if (currentDeductions.length === 0) {
            container.innerHTML = `
                <div class="empty-deductions">
                    <i class="fas fa-receipt"></i>
                    <p>No deductions added yet</p>
                </div>
            `;
            return;
        }
        
        let html = '';
        currentDeductions.forEach((d, index) => {
            html += `
                <div class="deduction-item">
                    <div class="deduction-info">
                        <span class="deduction-name">${d.deduction_name}</span>
                    </div>
                    <span class="deduction-amount">- ₱${parseFloat(d.amount).toFixed(2)}</span>
                    <div class="deduction-actions">
                        <button class="deduction-delete" onclick="removeDeduction(${index})" title="Remove">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
            `;
        });
        
        container.innerHTML = html;
    }

    // Open add deduction modal
    function openAddDeductionModal() {
        if (!selectedEmployee) {
            showNotificationModal('Please select an employee first', 'error');
            return;
        }
        
        document.getElementById('deductionEmployeeId').value = selectedEmployee.id;
        
        const dateFrom = document.getElementById('payroll_date_from').value;
        const dateTo = document.getElementById('payroll_date_to').value;
        document.getElementById('deductionStartDate').value = dateFrom;
        document.getElementById('deductionEndDate').value = dateTo;
        
        calendarDates.deduction_start.selectedDate = dateFrom;
        calendarDates.deduction_end.selectedDate = dateTo;
        
        document.getElementById('deductionName').value = '';
        document.getElementById('customDeductionName').value = '';
        document.getElementById('deductionAmount').value = '';
        document.getElementById('customNameGroup').style.display = 'none';
        
        openModal('addDeductionModal');
    }

    // Handle deduction name change
    document.getElementById('deductionName').addEventListener('change', function() {
        const customGroup = document.getElementById('customNameGroup');
        customGroup.style.display = this.value === 'Other' ? 'block' : 'none';
    });

    // Handle edit deduction name change
    document.getElementById('editDeductionName').addEventListener('change', function() {
        const customGroup = document.getElementById('editCustomNameGroup');
        customGroup.style.display = this.value === 'Other' ? 'block' : 'none';
    });

    // Add deduction
    async function addDeduction() {
        const employeeId = document.getElementById('deductionEmployeeId').value;
        let deductionName = document.getElementById('deductionName').value;
        const customName = document.getElementById('customDeductionName').value;
        const amount = document.getElementById('deductionAmount').value;
        const startDate = document.getElementById('deductionStartDate').value;
        const endDate = document.getElementById('deductionEndDate').value;
        
        if (!deductionName) {
            showNotificationModal('Please select deduction type', 'error');
            return;
        }
        
        if (deductionName === 'Other') {
            if (!customName) {
                showNotificationModal('Please enter deduction name', 'error');
                return;
            }
            deductionName = customName;
        }
        
        if (!amount || parseFloat(amount) <= 0) {
            showNotificationModal('Please enter a valid amount', 'error');
            return;
        }
        
        if (!startDate || !endDate) {
            showNotificationModal('Please select date range', 'error');
            return;
        }
        
        showLoading();
        
        try {
            const formData = new URLSearchParams();
            formData.append('add_custom_deduction', '1');
            formData.append('employee_id', employeeId);
            formData.append('deduction_name', deductionName);
            formData.append('amount', amount);
            formData.append('start_date', startDate);
            formData.append('end_date', endDate);
            
            const response = await fetch('payrollList.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: formData
            });
            
            const data = await response.json();
            
            if (data.success) {
                currentDeductions.push({
                    id: data.deduction.id,
                    deduction_name: deductionName,
                    amount: parseFloat(amount)
                });
                
                recalculatePayroll();
                updateDeductionsList();
                closeModal('addDeductionModal');
                showNotificationModal('Deduction added successfully', 'success');
                hideLoading();
            } else {
                showNotificationModal(data.message, 'error');
                hideLoading();
            }
        } catch (error) {
            console.error('Error:', error);
            showNotificationModal('Error adding deduction: ' + error.message, 'error');
            hideLoading();
        }
    }

    // Remove deduction
    function removeDeduction(index) {
        if (!confirm('Are you sure you want to remove this deduction?')) return;
        
        const deduction = currentDeductions[index];
        
        if (deduction.id) {
            deleteDeductionFromDB(deduction.id, index);
        } else {
            currentDeductions.splice(index, 1);
            recalculatePayroll();
            updateDeductionsList();
        }
    }

    // Delete deduction from database
    async function deleteDeductionFromDB(deductionId, index) {
        showLoading();
        
        try {
            const formData = new URLSearchParams();
            formData.append('delete_deduction', '1');
            formData.append('deduction_id', deductionId);
            
            const response = await fetch('payrollList.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: formData
            });
            
            const data = await response.json();
            
            if (data.success) {
                currentDeductions.splice(index, 1);
                recalculatePayroll();
                updateDeductionsList();
                showNotificationModal('Deduction removed', 'success');
            } else {
                showNotificationModal(data.message, 'error');
            }
        } catch (error) {
            console.error('Error:', error);
            showNotificationModal('Error deleting deduction: ' + error.message, 'error');
        } finally {
            hideLoading();
        }
    }

    // Recalculate payroll after adding/removing deductions
    function recalculatePayroll() {
        if (!currentPayrollData) return;
        
        let totalDeductions = 0;
        currentDeductions.forEach(d => {
            totalDeductions += parseFloat(d.amount);
        });
        
        const baseSalary = parseFloat(currentPayrollData.base_salary);
        const netPay = baseSalary - totalDeductions;
        
        currentPayrollData.total_deductions = totalDeductions;
        currentPayrollData.net_pay = netPay;
        currentPayrollData.deductions = currentDeductions;
        
        document.getElementById('currentTotalDeductions').value = totalDeductions;
        document.getElementById('currentNetPay').value = netPay;
        
        displayPayrollSummary(currentPayrollData);
    }

    // Save payroll
    async function savePayroll() {
        const employeeId = document.getElementById('currentEmployeeId').value;
        const dateFrom = document.getElementById('payroll_date_from').value;
        const dateTo = document.getElementById('payroll_date_to').value;
        const baseSalary = document.getElementById('currentBaseSalary').value;
        const totalDeductions = document.getElementById('currentTotalDeductions').value;
        const netPay = document.getElementById('currentNetPay').value;
        const workHours = document.getElementById('currentWorkHours').value;
        
        if (!employeeId) {
            showNotificationModal('Employee ID missing', 'error');
            return;
        }
        
        showLoading();
        
        try {
            const formData = new URLSearchParams();
            formData.append('save_payroll', '1');
            formData.append('employee_id', employeeId);
            formData.append('date_from', dateFrom);
            formData.append('date_to', dateTo);
            formData.append('base_salary', baseSalary);
            formData.append('total_deductions', totalDeductions);
            formData.append('net_pay', netPay);
            formData.append('total_work_hours', workHours);
            formData.append('deductions', JSON.stringify(currentDeductions));
            
            const response = await fetch('payrollList.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: formData
            });
            
            const text = await response.text();
            
            try {
                const data = JSON.parse(text);
                
                if (data.success) {
                    closeModal('generatePayrollModal');
                    showSuccessModal('Payroll saved successfully!');
                } else {
                    showNotificationModal(data.message, 'error');
                }
            } catch (e) {
                console.error('Failed to parse JSON:', text);
                showNotificationModal('Server returned invalid response. Check console for details.', 'error');
            }
        } catch (error) {
            console.error('Error:', error);
            showNotificationModal('Error saving payroll: ' + error.message, 'error');
        } finally {
            hideLoading();
        }
    }

    // Show success modal
    function showSuccessModal(message) {
        document.getElementById('successMessage').textContent = message;
        openModal('generateSuccessModal');
    }

    // View payroll
    async function viewPayroll(payrollId) {
        showLoading();
        
        try {
            const response = await fetch('payrollList.php?get_payroll=' + payrollId);
            const data = await response.json();
            
            if (data.success) {
                const p = data.data;
                const date_from = new Date(p.date_from).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
                const date_to = new Date(p.date_to).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
                
                let deductionsHtml = '';
                if (p.deductions && p.deductions.length > 0) {
                    p.deductions.forEach(d => {
                        deductionsHtml += `
                            <div class="computation-row">
                                <div class="computation-label">
                                    <i class="fas fa-minus-circle" style="color:#dc3545;"></i>
                                    ${d.deduction_name}
                                </div>
                                <div class="computation-value">- ₱${parseFloat(d.amount).toFixed(2)}</div>
                            </div>
                        `;
                    });
                }
                
                const html = `
                    <div class="employee-details-card" style="margin-top: 0;">
                        <h4><i class="fas fa-user-circle"></i> Employee Information</h4>
                        <div class="employee-details-grid">
                            <div class="detail-item">
                                <div class="detail-label">Name</div>
                                <div class="detail-value">${p.first_name} ${p.last_name}</div>
                            </div>
                            <div class="detail-item">
                                <div class="detail-label">Position</div>
                                <div class="detail-value">${p.position}</div>
                            </div>
                            <div class="detail-item">
                                <div class="detail-label">Daily Salary</div>
                                <div class="detail-value">₱${parseFloat(p.daily_salary).toFixed(2)}</div>
                            </div>
                            <div class="detail-item">
                                <div class="detail-label">Contact</div>
                                <div class="detail-value">${p.contact_num || 'N/A'}</div>
                            </div>
                            <div class="detail-item">
                                <div class="detail-label">Pay Period</div>
                                <div class="detail-value">${date_from} - ${date_to}</div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="computation-box">
                        <div class="computation-header">
                            <i class="fas fa-calculator"></i> Salary Details
                        </div>
                        <div class="computation-row">
                            <div class="computation-label">
                                <i class="fas fa-clock"></i> Total Work Hours
                            </div>
                            <div class="computation-value">${parseFloat(p.total_work_hours).toFixed(2)} hrs</div>
                        </div>
                        <div class="computation-row">
                            <div class="computation-label">
                                <i class="fas fa-money-bill"></i> Base Salary
                            </div>
                            <div class="computation-value">₱${parseFloat(p.base_salary).toFixed(2)}</div>
                        </div>
                        ${deductionsHtml}
                        <div class="computation-row total">
                            <div class="computation-label">
                                <i class="fas fa-calculator"></i> Total Deductions
                            </div>
                            <div class="computation-value">- ₱${parseFloat(p.total_deductions).toFixed(2)}</div>
                        </div>
                        <div class="computation-row net">
                            <div class="computation-label">
                                <i class="fas fa-check-circle"></i> Net Pay
                            </div>
                            <div class="computation-value">₱${parseFloat(p.net_pay).toFixed(2)}</div>
                        </div>
                    </div>
                    
                    <div style="margin-top: 15px; text-align: right;">
                        <span class="status-badge ${p.status === 'paid' ? 'status-paid' : 'status-pending'}">
                            <i class="fas ${p.status === 'paid' ? 'fa-check-circle' : 'fa-clock'}"></i>
                            ${p.status.charAt(0).toUpperCase() + p.status.slice(1)}
                        </span>
                    </div>
                `;
                
                document.getElementById('viewPayrollContent').innerHTML = html;
                openModal('viewPayrollModal');
                hideLoading();
            } else {
                showNotificationModal('Error loading payroll data', 'error');
                hideLoading();
            }
        } catch (error) {
            console.error('Error:', error);
            showNotificationModal('Error: ' + error.message, 'error');
            hideLoading();
        }
    }

    // Edit payroll
    function editPayroll(payrollId) {
        fetch('payrollList.php?get_payroll=' + payrollId)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const p = data.data;
                editPayrollId = p.id;
                editEmployeeId = p.employee_id;
                editDeductions = p.deductions || [];
                
                document.getElementById('edit_payroll_id').value = p.id;
                document.getElementById('edit_employee_id').value = p.employee_id;
                document.getElementById('edit_employee_name').value = p.first_name + ' ' + p.last_name;
                document.getElementById('edit_date_from').value = p.date_from;
                document.getElementById('edit_date_to').value = p.date_to;
                document.getElementById('edit_status').value = p.status;
                
                calendarDates.edit_from.selectedDate = p.date_from;
                calendarDates.edit_to.selectedDate = p.date_to;
                
                // Display edit payroll summary
                displayEditPayrollSummary(p);
                
                openModal('editPayrollModal');
            } else {
                showNotificationModal('Error loading payroll data', 'error');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showNotificationModal('Error: ' + error.message, 'error');
        });
    }

    // Display edit payroll summary
    function displayEditPayrollSummary(data) {
        const container = document.getElementById('editPayrollSummary');
        
        let deductionsHtml = '';
        let totalDeductions = 0;
        if (editDeductions && editDeductions.length > 0) {
            editDeductions.forEach(d => {
                totalDeductions += parseFloat(d.amount);
                deductionsHtml += `
                    <div class="computation-row">
                        <div class="computation-label">
                            <i class="fas fa-minus-circle" style="color:#dc3545;"></i>
                            ${d.deduction_name}
                        </div>
                        <div class="computation-value">- ₱${parseFloat(d.amount).toFixed(2)}</div>
                    </div>
                `;
            });
        }
        
        const baseSalary = parseFloat(data.base_salary);
        const netPay = baseSalary - totalDeductions;
        
        const html = `
            <div class="computation-box">
                <div class="computation-header">
                    <i class="fas fa-calculator"></i> Salary Computation
                </div>
                <div class="computation-row">
                    <div class="computation-label">
                        <i class="fas fa-clock"></i> Total Work Hours
                    </div>
                    <div class="computation-value">${parseFloat(data.total_work_hours).toFixed(2)} hrs</div>
                </div>
                <div class="computation-row">
                    <div class="computation-label">
                        <i class="fas fa-money-bill"></i> Base Salary
                    </div>
                    <div class="computation-value">₱${baseSalary.toFixed(2)}</div>
                </div>
                ${deductionsHtml}
                <div class="computation-row total">
                    <div class="computation-label">
                        <i class="fas fa-calculator"></i> Total Deductions
                    </div>
                    <div class="computation-value">- ₱${totalDeductions.toFixed(2)}</div>
                </div>
                <div class="computation-row net">
                    <div class="computation-label">
                        <i class="fas fa-check-circle"></i> Net Pay
                    </div>
                    <div class="computation-value">₱${netPay.toFixed(2)}</div>
                </div>
            </div>
        `;
        
        container.innerHTML = html;
        
        // Update deductions list
        updateEditDeductionsList();
    }

    // Update edit deductions list
    function updateEditDeductionsList() {
        const container = document.getElementById('editDeductionsList');
        
        if (editDeductions.length === 0) {
            container.innerHTML = `
                <div class="empty-deductions">
                    <i class="fas fa-receipt"></i>
                    <p>No deductions added yet</p>
                </div>
            `;
            return;
        }
        
        let html = '';
        editDeductions.forEach((d, index) => {
            html += `
                <div class="deduction-item">
                    <div class="deduction-info">
                        <span class="deduction-name">${d.deduction_name}</span>
                    </div>
                    <span class="deduction-amount">- ₱${parseFloat(d.amount).toFixed(2)}</span>
                    <div class="deduction-actions">
                        <button class="deduction-delete" onclick="removeEditDeduction(${index})" title="Remove">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
            `;
        });
        
        container.innerHTML = html;
    }

    // Open edit add deduction modal
    function openEditAddDeductionModal() {
        document.getElementById('editDeductionEmployeeId').value = editEmployeeId;
        
        const dateFrom = document.getElementById('edit_date_from').value;
        const dateTo = document.getElementById('edit_date_to').value;
        document.getElementById('editDeductionStartDate').value = dateFrom;
        document.getElementById('editDeductionEndDate').value = dateTo;
        
        calendarDates.edit_deduction_start.selectedDate = dateFrom;
        calendarDates.edit_deduction_end.selectedDate = dateTo;
        
        document.getElementById('editDeductionName').value = '';
        document.getElementById('editCustomDeductionName').value = '';
        document.getElementById('editDeductionAmount').value = '';
        document.getElementById('editCustomNameGroup').style.display = 'none';
        
        openModal('editAddDeductionModal');
    }

    // Add edit deduction
    async function addEditDeduction() {
        const employeeId = document.getElementById('editDeductionEmployeeId').value;
        let deductionName = document.getElementById('editDeductionName').value;
        const customName = document.getElementById('editCustomDeductionName').value;
        const amount = document.getElementById('editDeductionAmount').value;
        const startDate = document.getElementById('editDeductionStartDate').value;
        const endDate = document.getElementById('editDeductionEndDate').value;
        
        if (!deductionName) {
            showNotificationModal('Please select deduction type', 'error');
            return;
        }
        
        if (deductionName === 'Other') {
            if (!customName) {
                showNotificationModal('Please enter deduction name', 'error');
                return;
            }
            deductionName = customName;
        }
        
        if (!amount || parseFloat(amount) <= 0) {
            showNotificationModal('Please enter a valid amount', 'error');
            return;
        }
        
        if (!startDate || !endDate) {
            showNotificationModal('Please select date range', 'error');
            return;
        }
        
        showLoading();
        
        try {
            const formData = new URLSearchParams();
            formData.append('add_custom_deduction', '1');
            formData.append('employee_id', employeeId);
            formData.append('deduction_name', deductionName);
            formData.append('amount', amount);
            formData.append('start_date', startDate);
            formData.append('end_date', endDate);
            
            const response = await fetch('payrollList.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: formData
            });
            
            const data = await response.json();
            
            if (data.success) {
                editDeductions.push({
                    id: data.deduction.id,
                    deduction_name: deductionName,
                    amount: parseFloat(amount)
                });
                
                // Recalculate with new deduction
                const baseSalary = parseFloat(currentPayrollData?.base_salary || 0);
                let totalDeductions = 0;
                editDeductions.forEach(d => {
                    totalDeductions += parseFloat(d.amount);
                });
                const netPay = baseSalary - totalDeductions;
                
                // Update display
                const p = {
                    ...currentPayrollData,
                    total_deductions: totalDeductions,
                    net_pay: netPay
                };
                displayEditPayrollSummary(p);
                
                closeModal('editAddDeductionModal');
                showNotificationModal('Deduction added successfully', 'success');
                hideLoading();
            } else {
                showNotificationModal(data.message, 'error');
                hideLoading();
            }
        } catch (error) {
            console.error('Error:', error);
            showNotificationModal('Error adding deduction: ' + error.message, 'error');
            hideLoading();
        }
    }

    // Remove edit deduction
    function removeEditDeduction(index) {
        if (!confirm('Are you sure you want to remove this deduction?')) return;
        
        const deduction = editDeductions[index];
        
        if (deduction.id) {
            deleteEditDeductionFromDB(deduction.id, index);
        } else {
            editDeductions.splice(index, 1);
            
            // Recalculate
            let totalDeductions = 0;
            editDeductions.forEach(d => {
                totalDeductions += parseFloat(d.amount);
            });
            const baseSalary = parseFloat(currentPayrollData?.base_salary || 0);
            const netPay = baseSalary - totalDeductions;
            
            const p = {
                ...currentPayrollData,
                total_deductions: totalDeductions,
                net_pay: netPay
            };
            displayEditPayrollSummary(p);
        }
    }

    // Delete edit deduction from database
    async function deleteEditDeductionFromDB(deductionId, index) {
        showLoading();
        
        try {
            const formData = new URLSearchParams();
            formData.append('delete_deduction', '1');
            formData.append('deduction_id', deductionId);
            
            const response = await fetch('payrollList.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: formData
            });
            
            const data = await response.json();
            
            if (data.success) {
                editDeductions.splice(index, 1);
                
                // Recalculate
                let totalDeductions = 0;
                editDeductions.forEach(d => {
                    totalDeductions += parseFloat(d.amount);
                });
                const baseSalary = parseFloat(currentPayrollData?.base_salary || 0);
                const netPay = baseSalary - totalDeductions;
                
                const p = {
                    ...currentPayrollData,
                    total_deductions: totalDeductions,
                    net_pay: netPay
                };
                displayEditPayrollSummary(p);
                
                showNotificationModal('Deduction removed', 'success');
            } else {
                showNotificationModal(data.message, 'error');
            }
        } catch (error) {
            console.error('Error:', error);
            showNotificationModal('Error deleting deduction: ' + error.message, 'error');
        } finally {
            hideLoading();
        }
    }

    // Recalculate edit payroll when dates change
    async function recalculateEditPayroll() {
        const employeeId = editEmployeeId;
        const dateFrom = document.getElementById('edit_date_from').value;
        const dateTo = document.getElementById('edit_date_to').value;
        
        if (!employeeId || !dateFrom || !dateTo) return;
        
        showLoading();
        
        try {
            const formData = new URLSearchParams();
            formData.append('recalculate_payroll', '1');
            formData.append('employee_id', employeeId);
            formData.append('date_from', dateFrom);
            formData.append('date_to', dateTo);
            formData.append('current_deductions', JSON.stringify(editDeductions));
            
            const response = await fetch('payrollList.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: formData
            });
            
            const data = await response.json();
            
            if (data.success) {
                currentPayrollData = data.payroll;
                displayEditPayrollSummary(data.payroll);
            } else {
                showNotificationModal(data.message, 'error');
            }
        } catch (error) {
            console.error('Error:', error);
            showNotificationModal('Error recalculating payroll: ' + error.message, 'error');
        } finally {
            hideLoading();
        }
    }

    // Update payroll status only
    async function updatePayrollStatus() {
        const payrollId = document.getElementById('edit_payroll_id').value;
        const status = document.getElementById('edit_status').value;
        
        if (!payrollId) {
            showNotificationModal('Payroll ID missing', 'error');
            return;
        }
        
        showLoading();
        closeModal('editPayrollModal');
        
        try {
            const formData = new URLSearchParams();
            formData.append('update_payroll_status', '1');
            formData.append('payroll_id', payrollId);
            formData.append('status', status);
            
            const response = await fetch('payrollList.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: formData
            });
            
            const data = await response.json();
            
            if (data.success) {
                showNotificationModal(data.message, 'success');
                setTimeout(() => location.reload(), 1500);
            } else {
                showNotificationModal('Error: ' + data.message, 'error');
            }
        } catch (error) {
            console.error('Error:', error);
            showNotificationModal('Error updating payroll: ' + error.message, 'error');
        } finally {
            hideLoading();
        }
    }

    // Open delete payroll modal
    function openDeletePayrollModal(payrollId, employeeName, dateFrom, dateTo, netPay) {
        currentDeletePayrollId = payrollId;
        
        document.getElementById('deletePayrollDetails').innerHTML = `
            <p><strong>Employee:</strong> ${employeeName}</p>
            <p><strong>Period:</strong> ${dateFrom} to ${dateTo}</p>
            <p><strong>Net Pay:</strong> ${netPay}</p>
        `;
        
        openModal('deletePayrollModal');
    }

    // Confirm delete payroll
    function confirmDeletePayroll() {
        if (!currentDeletePayrollId) return;
        window.location.href = 'payrollList.php?delete_id=' + currentDeletePayrollId;
    }

    // Reset deduction modal
    function resetDeductionModal() {
        document.getElementById('deductionName').value = '';
        document.getElementById('customDeductionName').value = '';
        document.getElementById('deductionAmount').value = '';
        document.getElementById('customNameGroup').style.display = 'none';
    }

    // Reset edit deduction modal
    function resetEditDeductionModal() {
        document.getElementById('editDeductionName').value = '';
        document.getElementById('editCustomDeductionName').value = '';
        document.getElementById('editDeductionAmount').value = '';
        document.getElementById('editCustomNameGroup').style.display = 'none';
    }

    // Loading functions
    function showLoading() {
        document.getElementById('loadingOverlay').style.display = 'flex';
    }

    function hideLoading() {
        document.getElementById('loadingOverlay').style.display = 'none';
    }

    // Close modal when clicking outside
    window.addEventListener('click', function(event) {
        const modals = ['generatePayrollModal', 'editPayrollModal', 'viewPayrollModal', 
                       'generateSuccessModal', 'addDeductionModal', 'deletePayrollModal', 
                       'notificationModal', 'existingPayrollModal', 'editAddDeductionModal'];
        
        modals.forEach(modalId => {
            const modal = document.getElementById(modalId);
            if (event.target === modal) {
                closeModal(modalId);
            }
        });
    });

    // Handle escape key
    document.addEventListener('keydown', function(event) {
        if (event.key === 'Escape') {
            const modals = ['generatePayrollModal', 'editPayrollModal', 'viewPayrollModal', 
                           'generateSuccessModal', 'addDeductionModal', 'deletePayrollModal', 
                           'notificationModal', 'existingPayrollModal', 'editAddDeductionModal'];
            
            modals.forEach(modalId => {
                const modal = document.getElementById(modalId);
                if (modal && modal.classList.contains('show')) {
                    closeModal(modalId);
                }
            });
            
            if (activeCalendar) {
                document.getElementById(activeCalendar).style.display = 'none';
                activeCalendar = null;
            }
        }
    });
</script>

</body>
</html>