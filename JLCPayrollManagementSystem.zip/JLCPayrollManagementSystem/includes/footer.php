<style>
    .footer {
        position: fixed;
        bottom: 0;
        left: 0;
        width: 100%;
        text-align: center;
        padding: 15px 20px;
        background-color: #4bc4b5; /* Matching header color */
        color: #ffffff;
        font-size: 0.95rem;
        border-top: 2px solid rgba(255, 255, 255, 0.2);
        z-index: 900;
        box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.1);
    }
</style>

<footer class="footer">
    © 2026 JLC Payroll Management System. All rights reserved.
</footer>