<?php
// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Get user role from session
$role = $_SESSION['role'] ?? 'user';
$current_page = basename($_SERVER['PHP_SELF']);

// Include access control for menu checking
include_once("check_access.php");

// Map page filenames to display titles
$page_titles = [
    'home.php' => 'HOME',
    'attendance.php' => 'ATTENDANCE',
    'employee.php' => 'EMPLOYEE LIST',
    'site_monitoring.php' => 'EMPLOYEE TRACKING',
    'deductionList.php' => 'DEDUCTION',
    'payrollList.php' => 'PAYROLL',
    'salarySlip.php' => 'SALARY SLIP',
    'user.php' => 'PROFILE'
];

// Get the title for the current page
$page_title = isset($page_titles[$current_page]) ? $page_titles[$current_page] : '';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Management System</title>
    <style>
        /* Header Styling with Sidebar Integration */
        .header {
            width: 100%;
            height: 140px; /* Fixed total height */
            background: linear-gradient(135deg, #75e6da 0%, #5fd6c9 100%);
            padding: 0;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1000;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            border-bottom: 3px solid #4bc4b5;
        }

        /* Top Row: Logo and Page Info */
        .header-top {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 30px;
            height: 80px; /* Fixed height for top section */
            flex-shrink: 0;
            background-color: rgba(255, 255, 255, 0.1);
        }

        .header-logo-container {
            display: flex;
            align-items: center;
            gap: 15px;
            height: 100%;
        }

        .header-logo img {
            height: 70px;
            width: auto;
            border-radius: 10px;
            object-fit: contain;
            max-width: 120px;
            
        }

        .header-logo2 img {
            height: 50px;
            width: auto;
            border-radius: 10px;
            object-fit: contain;
            max-width: 300px;
           
        }

        .header-right {
            display: flex;
            align-items: center;
            gap: 20px;
            height: 100%;
        }

        .current-page-text {
            font-size: 1.5rem;
            font-weight: 800; /* Bolder */
            color: #ffffff;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
            padding: 10px 25px;
            border-radius: 12px;
            text-transform: uppercase;
            letter-spacing: 1px;
            min-width: 180px;
            text-align: center;
            white-space: nowrap;
            border: 2px;
           
        }

        .logout-icon {
            display: flex;
            align-items: center;
            flex-shrink: 0;
        }

        .logout-icon img {
            height: 50px;
            width: 50px;
            cursor: pointer;
            transition: all 0.3s ease;
            padding: 10px;
            background: linear-gradient(135deg, rgba(41, 148, 82, 0.3) 0%, rgba(52, 168, 83, 0.4) 100%);
            border-radius: 12px;
            flex-shrink: 0;
            border: 2px solid rgba(255, 255, 255, 0.2);
        }

        .logout-icon img:hover {
            transform: scale(1.1);
            background: linear-gradient(135deg, rgba(41, 148, 82, 0.6) 0%, rgba(52, 168, 83, 0.7) 100%);
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.3);
            border: 2px solid rgba(255, 255, 255, 0.4);
        }

        /* Navigation Menu (Former Sidebar) */
        .header-nav {
            display: flex;
            justify-content: center;
            background: linear-gradient(135deg, #62d4c8 0%, #52c4b8 100%);
            padding: 0 20px;
            flex-shrink: 0;
            height: 70px; /* Fixed height for nav section */
            border-top: 2px solid rgba(255, 255, 255, 0.2);
        }

        .nav-menu {
            display: flex;
            list-style: none;
            margin: 0;
            padding: 0;
            width: 100%;
            justify-content: space-around;
            align-items: center;
        }

        .nav-menu li {
            flex: 1;
            text-align: center;
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .nav-menu li a {
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 12px 15px;
            color: #ffffff;
            font-weight: 700; /* Bolder */
            text-decoration: none;
            transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
            border-radius: 10px;
            margin: 0 5px;
            white-space: nowrap;
            font-size: 1rem; /* Slightly larger */
            height: 50px;
            text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.2);
            border: 2px solid transparent;
            position: relative;
            overflow: hidden;
        }

        .nav-menu li a::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: left 0.5s ease;
        }

        .nav-menu li a:hover::before {
            left: 100%;
        }

        .nav-menu li a:hover {
            background: linear-gradient(135deg, #9ef0f4 0%, #aff7e5 100%);
            box-shadow: 0 6px 15px rgba(171, 246, 229, 0.4);
            transform: translateY(-3px);
            border: 2px solid rgba(255, 255, 255, 0.5);
            color: #fff;
        }

      .nav-menu li.active a {
    background: linear-gradient(135deg, #2a9d8f 0%, #1d7873 100%);
    color: #ffffff;
    box-shadow: 0 4px 12px rgba(42, 157, 143, 0.3);
    border: 2px solid rgba(255, 255, 255, 0.3);
    font-weight: 700;
    position: relative;
}

        .nav-menu li.active a::after {
            content: '';
            position: absolute;
            bottom: -5px;
            left: 50%;
            transform: translateX(-50%);
            width: 30px;
            height: 3px;
            background: #ffffff;
            border-radius: 2px;
        }

        .nav-icon {
            margin-right: 8px;
            font-size: 18px; /* Slightly larger icons */
            filter: drop-shadow(1px 1px 1px rgba(0, 0, 0, 0.2));
        }

        /* Logout Modal */
        .logout-overlay {
            display: none;
            position: fixed;
            inset: 0;
            background-color: rgba(0, 0, 0, 0.7);
            justify-content: center;
            align-items: center;
            z-index: 2000;
            backdrop-filter: blur(3px);
        }

        .logout-content {
            background: linear-gradient(135deg, #ffffff 0%, #f8fff8 100%);
            padding: 35px;
            width: 450px;
            border-radius: 15px;
            text-align: center;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.4);
            border: 3px solid #75e6da;
        }

        .logout-header {
            font-size: 2rem;
            margin-bottom: 20px;
            font-weight: 900; /* Very bold */
            color: #2c3e50;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .logout-content p {
            font-size: 1.1rem;
            color: #555;
            margin-bottom: 25px;
            font-weight: 600; /* Semi-bold */
            line-height: 1.5;
        }

        .logout-content button {
            font-weight: 700; /* Bold buttons */
            padding: 12px 30px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 1rem;
            transition: all 0.3s ease;
            margin: 0 10px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .logout-content button:first-child {
            background: linear-gradient(135deg, #299452 0%, #34a853 100%);
            color: white;
            border: 2px solid #299452;
        }

        .logout-content button:first-child:hover {
            background: linear-gradient(135deg, #34a853 0%, #299452 100%);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(41, 148, 82, 0.4);
        }

        .logout-content button:last-child {
            background: linear-gradient(135deg, #e74c3c 0%, #c0392b 100%);
            color: white;
            border: 2px solid #e74c3c;
        }

        .logout-content button:last-child:hover {
            background: linear-gradient(135deg, #c0392b 0%, #e74c3c 100%);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(231, 76, 60, 0.4);
        }

        /* Responsive Design */
        @media (max-width: 1200px) {
            .header {
                height: 135px;
            }
            
            .header-top {
                height: 65px;
            }
            
            .nav-menu li a {
                font-size: 0.95rem;
                padding: 10px 12px;
                font-weight: 700;
            }
            
            .nav-icon {
                margin-right: 6px;
                font-size: 16px;
            }
            
            .current-page-text {
                font-size: 1.4rem;
                padding: 9px 20px;
                min-width: 160px;
                font-weight: 800;
            }
            
            .header-logo img {
                height: 65px;
            }
            
            .header-logo2 img {
                height: 55px;
                max-width: 160px;
            }
            
            .header-nav {
                height: 70px;
            }
        }

        @media (max-width: 992px) {
            .header {
                height: 150px;
            }
            
            .header-top {
                height: 70px;
            }
            
            .nav-menu {
                flex-wrap: wrap;
            }
            
            .nav-menu li {
                flex: 0 0 25%;
                margin-bottom: 5px;
            }
            
            .header-logo-container {
                gap: 10px;
            }
            
            .header-logo img {
                height: 60px;
            }
            
            .header-logo2 img {
                height: 50px;
                max-width: 140px;
            }
            
            .logout-icon img {
                height: 45px;
                width: 45px;
            }
            
            .header-nav {
                height: 80px;
            }
            
            .nav-menu li a {
                font-weight: 700;
            }
        }

        @media (max-width: 768px) {
            .header {
                height: 140px;
                padding: 0;
            }
            
            .header-top {
                padding: 12px 15px;
                height: 60px;
            }
            
            .nav-menu li {
                flex: 0 0 33.33%;
            }
            
            .current-page-text {
                font-size: 1.2rem;
                padding: 8px 15px;
                min-width: 140px;
                font-weight: 800;
            }
            
            .header-logo-container {
                flex: 1;
                justify-content: flex-start;
            }
            
            .header-right {
                flex: 1;
                justify-content: flex-end;
                gap: 15px;
            }
            
            .header-logo img {
                height: 55px;
                max-width: 100px;
            }
            
            .header-logo2 img {
                height: 45px;
                max-width: 120px;
            }
            
            .header-nav {
                height: 80px;
                padding: 0 8px;
            }
            
            .nav-menu li a {
                font-size: 0.9rem;
                font-weight: 700;
            }
        }

        @media (max-width: 576px) {
            .header {
                height: 160px;
            }
            
            .header-top {
                height: 70px;
                flex-direction: row;
                padding: 10px 12px;
                gap: 8px;
            }
            
            .nav-menu li {
                flex: 0 0 50%;
            }
            
            .nav-menu li a {
                flex-direction: column;
                padding: 8px 5px;
                font-size: 0.85rem;
                font-weight: 700;
                height: 45px;
            }
            
            .nav-icon {
                margin-right: 0;
                margin-bottom: 4px;
                font-size: 16px;
            }
            
            .current-page-text {
                font-size: 1rem;
                padding: 7px 12px;
                min-width: 120px;
                font-weight: 800;
            }
            
            .logout-icon img {
                height: 40px;
                width: 40px;
                padding: 8px;
            }
            
            .header-logo-container {
                width: auto;
                justify-content: flex-start;
                gap: 6px;
            }
            
            .header-logo img {
                height: 50px;
            }
            
            .header-logo2 img {
                height: 40px;
                max-width: 110px;
            }
            
            .header-right {
                width: auto;
                justify-content: flex-end;
            }
            
            .header-nav {
                height: 90px;
            }
        }

        @media (max-width: 400px) {
            .header {
                height: 170px;
            }
            
            .header-top {
                height: 75px;
            }
            
            .nav-menu li a {
                font-size: 0.8rem;
                padding: 6px 4px;
                font-weight: 700;
            }
            
            .nav-icon {
                font-size: 14px;
            }
            
            .current-page-text {
                font-size: 0.9rem;
                min-width: 100px;
                padding: 6px 10px;
                font-weight: 800;
            }
            
            .logout-icon img {
                height: 36px;
                width: 36px;
                padding: 7px;
            }
            
            .header-logo img {
                height: 45px;
                max-width: 90px;
            }
            
            .header-logo2 img {
                height: 35px;
                max-width: 100px;
            }
            
            .header-logo-container {
                gap: 5px;
            }
            
            .header-nav {
                height: 95px;
            }
            
            .logout-content {
                width: 90%;
                padding: 25px;
            }
            
            .logout-header {
                font-size: 1.6rem;
            }
        }
    </style>
</head>
<body>
    <header class="header">
        <!-- Top Row: Logo and Page Info -->
        <div class="header-top">
            <div class="header-logo-container">
                <div class="header-logo">
                    <img src="assets/images/header_logo.png" alt="Main Logo">
                </div>
                <div class="header-logo2">
                    <img src="assets/images/header_logo2.png" alt="Secondary Logo">
                </div>
            </div>
            
            <div class="header-right">
                <span class="current-page-text"><?php echo $page_title ?: 'DASHBOARD'; ?></span>
                <a href="#" class="logout-icon" onclick="showLogoutConfirmation(event)">
                    <img src="./assets/images/logout2.png" alt="Logout">
                </a>
            </div>
        </div>
        
        <!-- Navigation Menu (Dynamic based on user role) -->
        <nav class="header-nav">
            <ul class="nav-menu">
                <!-- Home - Accessible to all -->
                <?php if (function_exists('checkPageAccess') && checkPageAccess('home.php')): ?>
                <li class="<?php echo ($current_page == 'home.php') ? 'active' : ''; ?>">
                    <a href="home.php"><span class="nav-icon">🏠</span>Home</a>
                </li>
                <?php endif; ?>
                
                <!-- Attendance - Accessible to all -->
                <?php if (function_exists('checkPageAccess') && checkPageAccess('attendance.php')): ?>
                <li class="<?php echo ($current_page == 'attendance.php') ? 'active' : ''; ?>">
                    <a href="attendance.php"><span class="nav-icon">🗓️</span>Attendance</a>
                </li>
                <?php endif; ?>
                
                <!-- Employees - Accessible to all -->
                <?php if (function_exists('checkPageAccess') && checkPageAccess('employee.php')): ?>
                <li class="<?php echo ($current_page == 'employee.php') ? 'active' : ''; ?>">
                    <a href="employee.php"><span class="nav-icon">👥</span>Employees</a>
                </li>
                <?php endif; ?>
                
                <!-- Site Monitoring - Accessible to all -->
                <?php if (function_exists('checkPageAccess') && checkPageAccess('site_monitoring.php')): ?>
                <li class="<?php echo ($current_page == 'site_monitoring.php') ? 'active' : ''; ?>">
                    <a href="site_monitoring.php"><span class="nav-icon">🏢</span>Employee Tracking</a>
                </li>
                <?php endif; ?>
                
                <!-- Deduction - Admin only -->
                <?php if ($role === 'admin'): ?>
                <li class="<?php echo ($current_page == 'deductionList.php') ? 'active' : ''; ?>">
                    <a href="deductionList.php"><span class="nav-icon">➖</span>Deduction</a>
                </li>
                <?php endif; ?>
                
                <!-- Payroll - Admin only -->
                <?php if ($role === 'admin'): ?>
                <li class="<?php echo ($current_page == 'payrollList.php') ? 'active' : ''; ?>">
                    <a href="payrollList.php"><span class="nav-icon">💸</span>Payroll</a>
                </li>
                <?php endif; ?>
                
                <!-- Salary Slip - Admin only -->
                <?php if ($role === 'admin'): ?>
                <li class="<?php echo ($current_page == 'salarySlip.php') ? 'active' : ''; ?>">
                    <a href="salarySlip.php"><span class="nav-icon">📄</span>Salary Slip</a>
                </li>
                <?php endif; ?>
                
                <!-- Profile - Admin only -->
                <?php if ($role === 'admin'): ?>
                <li class="<?php echo ($current_page == 'user.php') ? 'active' : ''; ?>">
                    <a href="user.php"><span class="nav-icon">👤</span>Profile</a>
                </li>
                <?php endif; ?>
            </ul>
        </nav>
    </header>

    <!-- Logout Confirmation Modal -->
    <div id="logoutOverlay" class="logout-overlay">
        <div class="logout-content">
            <div class="logout-header">Confirm Logout</div>
            <p>Are you sure you want to logout?</p>
            <div style="margin-top: 25px;">
                <button onclick="confirmLogout()">Yes, Logout</button>
                <button onclick="cancelLogout()">Cancel</button>
            </div>
        </div>
    </div>

    <script>
        function showLogoutConfirmation(event) {
            event.preventDefault();
            document.getElementById('logoutOverlay').style.display = 'flex';
        }

        function confirmLogout() {
            // Redirect to logout.php which will destroy session and redirect to login
            window.location.href = 'logout.php';
        }

        function cancelLogout() {
            document.getElementById('logoutOverlay').style.display = 'none';
        }
        
        // Ensure content starts below header
        document.addEventListener('DOMContentLoaded', function() {
            const header = document.querySelector('.header');
            const content = document.querySelector('.content');
            
            if (header && content) {
                // Header height will be set via CSS variable
                const headerHeight = header.offsetHeight;
                document.documentElement.style.setProperty('--header-height', headerHeight + 'px');
            }
        });
    </script>
</body>
</html>