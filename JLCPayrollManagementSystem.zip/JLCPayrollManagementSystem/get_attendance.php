<?php
session_start();
include_once("connection.php");

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

header('Content-Type: application/json');

if (!isset($_SESSION['Admin_User'])) {
    echo json_encode(['success' => false, 'message' => 'Not authorized']);
    exit;
}

// Get parameters
$employee_id = isset($_GET['employee_id']) ? intval($_GET['employee_id']) : 0;
$date = isset($_GET['date']) ? $_GET['date'] : '';

if (!$employee_id || !$date) {
    echo json_encode(['success' => false, 'message' => 'Missing parameters']);
    exit;
}

try {
    // UPDATED: Use new AM/PM columns instead of old time_in/time_out
    $sql = "SELECT id, status, 
            time_in_am, time_out_am, 
            time_in_pm, time_out_pm, 
            remarks 
            FROM attendance 
            WHERE employee_id = ? AND DATE(date) = DATE(?)";
    
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        throw new Exception("Prepare failed: " . $conn->error);
    }
    
    $stmt->bind_param("is", $employee_id, $date);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $attendance = $result->fetch_assoc();
        echo json_encode([
            'success' => true,
            'id' => $attendance['id'],
            'status' => $attendance['status'],
            'time_in_am' => $attendance['time_in_am'],
            'time_out_am' => $attendance['time_out_am'],
            'time_in_pm' => $attendance['time_in_pm'],
            'time_out_pm' => $attendance['time_out_pm'],
            'remarks' => $attendance['remarks']
        ]);
    } else {
        // No existing record, but we still want to open the modal for adding
        echo json_encode([
            'success' => true,
            'status' => 'Present',
            'time_in_am' => null,
            'time_out_am' => null,
            'time_in_pm' => null,
            'time_out_pm' => null,
            'remarks' => null
        ]);
    }
    
    $stmt->close();
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false, 
        'message' => $e->getMessage()
    ]);
}

$conn->close();
?>