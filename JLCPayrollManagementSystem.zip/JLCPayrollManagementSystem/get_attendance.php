<?php
session_start();
include_once("connection.php");

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

header('Content-Type: application/json');

if (!isset($_SESSION['Admin_User'])) {
    echo json_encode(['success' => false, 'message' => 'Not authorized']);
    exit;
}

// Get parameters
$employee_id = isset($_GET['employee_id']) ? intval($_GET['employee_id']) : 0;
$date = isset($_GET['date']) ? $_GET['date'] : '';

if (!$employee_id || !$date) {
    echo json_encode(['success' => false, 'message' => 'Missing parameters']);
    exit;
}

try {
    // Check if attendance exists for this employee on this date
    $sql = "SELECT id, status, time_in, time_out, remarks 
            FROM attendance 
            WHERE employee_id = ? AND DATE(date) = DATE(?)";
    
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        throw new Exception("Prepare failed: " . $conn->error);
    }
    
    $stmt->bind_param("is", $employee_id, $date);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $attendance = $result->fetch_assoc();
        echo json_encode([
            'success' => true,
            'id' => $attendance['id'],
            'status' => $attendance['status'],
            'time_in' => $attendance['time_in'],
            'time_out' => $attendance['time_out'],
            'remarks' => $attendance['remarks']
        ]);
    } else {
        // No existing record, but we still want to open the modal for adding
        echo json_encode([
            'success' => true,
            'status' => 'Present',
            'time_in' => null,
            'time_out' => null,
            'remarks' => null
        ]);
    }
    
    $stmt->close();
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false, 
        'message' => $e->getMessage()
    ]);
}

$conn->close();
?>