<?php
session_start();

if (!isset($_SESSION['Admin_User'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

// Enable error reporting for debugging (remove in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

header('Content-Type: application/json');

include_once("connection.php");

$employee_id = isset($_GET['employee_id']) ? intval($_GET['employee_id']) : 0;
$date = isset($_GET['date']) ? $_GET['date'] : '';

if (!$employee_id || !$date) {
    echo json_encode(['success' => false, 'message' => 'Missing parameters']);
    exit;
}

try {
    // Comprehensive query with all fields from your attendance table structure
    $sql = "SELECT id, employee_id, date, status, leave_type,
                   time_in_am, time_out_am, 
                   time_in_pm, time_out_pm, 
                   remarks, total_hours
            FROM attendance 
            WHERE employee_id = ? AND DATE(date) = DATE(?)";
    
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        throw new Exception("Prepare failed: " . $conn->error);
    }
    
    $stmt->bind_param("is", $employee_id, $date);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc()) {
        // Format times for display
        $row['success'] = true;
        
        // Convert NULL to empty string for JSON
        foreach ($row as $key => $value) {
            if ($value === null) {
                $row[$key] = '';
            }
        }
        
        // Format AM times for 12-hour display
        if (!empty($row['time_in_am']) && $row['time_in_am'] != '00:00:00') {
            $time = strtotime($row['time_in_am']);
            $row['time_in_am_formatted'] = date('h:i A', $time);
        } else {
            $row['time_in_am_formatted'] = '';
            $row['time_in_am'] = ''; // Clear 00:00:00
        }
        
        if (!empty($row['time_out_am']) && $row['time_out_am'] != '00:00:00') {
            $time = strtotime($row['time_out_am']);
            $row['time_out_am_formatted'] = date('h:i A', $time);
        } else {
            $row['time_out_am_formatted'] = '';
            $row['time_out_am'] = ''; // Clear 00:00:00
        }
        
        // Format PM times for 12-hour display
        if (!empty($row['time_in_pm']) && $row['time_in_pm'] != '00:00:00') {
            $time = strtotime($row['time_in_pm']);
            $row['time_in_pm_formatted'] = date('h:i A', $time);
        } else {
            $row['time_in_pm_formatted'] = '';
            $row['time_in_pm'] = ''; // Clear 00:00:00
        }
        
        if (!empty($row['time_out_pm']) && $row['time_out_pm'] != '00:00:00') {
            $time = strtotime($row['time_out_pm']);
            $row['time_out_pm_formatted'] = date('h:i A', $time);
        } else {
            $row['time_out_pm_formatted'] = '';
            $row['time_out_pm'] = ''; // Clear 00:00:00
        }
        
        // Format total hours
        if (!empty($row['total_hours']) && floatval($row['total_hours']) > 0) {
            $row['total_hours'] = number_format(floatval($row['total_hours']), 2, '.', '');
        } else {
            $row['total_hours'] = '0.00';
        }
        
        // Determine status based on attendance data
        if (empty($row['status'])) {
            // If no status but has times, set to Present
            if (!empty($row['time_in_am']) || !empty($row['time_in_pm'])) {
                $row['status'] = 'Present';
            }
        }
        
        echo json_encode($row);
    } else {
        // No existing record - return default values for new entry
        echo json_encode([
            'success' => true,
            'id' => '',
            'employee_id' => $employee_id,
            'date' => $date,
            'status' => 'Present',
            'leave_type' => '',
            'time_in_am' => '',
            'time_out_am' => '',
            'time_in_pm' => '',
            'time_out_pm' => '',
            'remarks' => '',
            'total_hours' => '0.00',
            'time_in_am_formatted' => '',
            'time_out_am_formatted' => '',
            'time_in_pm_formatted' => '',
            'time_out_pm_formatted' => ''
        ]);
    }
    
    $stmt->close();
    
} catch (Exception $e) {
    error_log("Error in get_attendance.php: " . $e->getMessage());
    echo json_encode([
        'success' => false, 
        'message' => 'Database error: ' . $e->getMessage()
    ]);
}

$conn->close();
?>