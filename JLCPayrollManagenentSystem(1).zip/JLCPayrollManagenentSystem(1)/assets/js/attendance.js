// attendance.js - COMPLETE VERSION WITH TIME-IN/TIME-OUT
console.log('✅ attendance.js loaded');

let currentTimeField = null;

// ============================================
// MODAL FUNCTIONS - UPDATED
// ============================================

function openAddAttendanceModal() {
    console.log('Opening Add Attendance Modal');
    const modal = document.getElementById('addAttendanceModal');
    if (modal) {
        modal.style.display = 'flex';
        modal.classList.add('show');
        document.body.style.overflow = 'hidden';
        
        // Reset form first
        resetAttendanceForm();
        
        console.log('✅ Modal opened');
    } else {
        console.error('❌ Modal not found!');
        alert('Error: Could not find the modal.');
    }
}

function closeAddAttendanceModal() {
    console.log('Closing Add Attendance Modal');
    const modal = document.getElementById('addAttendanceModal');
    if (modal) {
        modal.style.display = 'none';
        modal.classList.remove('show');
        document.body.style.overflow = 'auto';
        resetAttendanceForm();
    }
}

// ============================================
// NEW: CHECK EXISTING ATTENDANCE
// ============================================

async function checkExistingAttendance() {
    const employeeSelect = document.getElementById('employeeSelect');
    const dateInput = document.getElementById('attendanceDate');
    
    if (!employeeSelect || !employeeSelect.value || !dateInput || !dateInput.value) {
        return;
    }
    
    try {
        const employeeId = employeeSelect.value;
        const date = dateInput.value;
        
        console.log(`Checking existing attendance for Employee ${employeeId} on ${date}`);
        
        // Prepare form data
        const formData = new FormData();
        formData.append('employee_id', employeeId);
        formData.append('date', date);
        
        // Fetch existing attendance record via AJAX
        const response = await fetch('check_attendance.php', {
            method: 'POST',
            body: formData
        });
        
        const data = await response.json();
        console.log('Existing record data:', data);
        
        if (data.error) {
            console.error('Error checking attendance:', data.error);
            return;
        }
        
        if (data.exists) {
            // Populate form with existing data
            populateFormWithExistingData(data.attendance);
            showNotification('📝 Existing record found. Time In is preserved.', 'info');
        }
    } catch (error) {
        console.error('Error checking existing attendance:', error);
    }
}

function populateFormWithExistingData(attendance) {
    console.log('Populating form with existing data:', attendance);
    
    // Set status
    if (attendance.status) {
        if (attendance.status === 'Present') {
            document.getElementById('statusPresent').checked = true;
        } else if (attendance.status === 'Absent') {
            document.getElementById('statusAbsent').checked = true;
        }
    }
    
    // Set time in (if exists and not empty/null)
    if (attendance.time_in && attendance.time_in !== '00:00:00' && attendance.time_in !== null) {
        const time24 = attendance.time_in;
        const time12 = convert24to12Hour(time24);
        
        const timeInDisplay = document.getElementById('timeInDisplay');
        const timeInInput = document.getElementById('timeIn');
        
        if (timeInDisplay) {
            timeInDisplay.className = 'time-display-box';
            timeInDisplay.querySelector('.time-display-content').textContent = time12;
        }
        if (timeInInput) {
            timeInInput.value = time24;
        }
        
        // Disable time-in button if time-in already exists
        const timeInBtn = document.querySelector('button[onclick*="time_in"]');
        if (timeInBtn) {
            timeInBtn.disabled = true;
            timeInBtn.textContent = 'Time In (Already Set)';
            timeInBtn.style.background = '#6c757d';
            timeInBtn.style.cursor = 'not-allowed';
        }
    }
    
    // Set time out (if exists and not empty/null)
    if (attendance.time_out && attendance.time_out !== '00:00:00' && attendance.time_out !== null) {
        const time24 = attendance.time_out;
        const time12 = convert24to12Hour(time24);
        
        const timeOutDisplay = document.getElementById('timeOutDisplay');
        const timeOutInput = document.getElementById('timeOut');
        
        if (timeOutDisplay) {
            timeOutDisplay.className = 'time-display-box';
            timeOutDisplay.querySelector('.time-display-content').textContent = time12;
        }
        if (timeOutInput) {
            timeOutInput.value = time24;
        }
        
        // Disable time-out button if time-out already exists
        const timeOutBtn = document.querySelector('button[onclick*="time_out"]');
        if (timeOutBtn) {
            timeOutBtn.disabled = true;
            timeOutBtn.textContent = 'Time Out (Already Set)';
            timeOutBtn.style.background = '#6c757d';
            timeOutBtn.style.cursor = 'not-allowed';
        }
    }
    
    // Set remarks
    const remarksTextarea = document.querySelector('textarea[name="remarks"]');
    if (remarksTextarea && attendance.remarks) {
        remarksTextarea.value = attendance.remarks;
    }
}

function convert24to12Hour(time24) {
    if (!time24 || time24 === '00:00:00' || time24 === null) return '--:-- --';
    
    const [hours, minutes] = time24.split(':');
    const hour = parseInt(hours);
    const period = hour >= 12 ? 'PM' : 'AM';
    const hour12 = hour % 12 || 12;
    
    return `${hour12.toString().padStart(2, '0')}:${minutes} ${period}`;
}

function showNotification(message, type = 'info') {
    // Remove existing notification
    const existingNotification = document.getElementById('attendanceNotification');
    if (existingNotification) {
        existingNotification.remove();
    }
    
    // Create new notification
    const notification = document.createElement('div');
    notification.id = 'attendanceNotification';
    notification.className = `attendance-notification ${type}`;
    notification.textContent = message;
    
    // Add to modal body
    const modalBody = document.querySelector('.modal-body');
    if (modalBody) {
        modalBody.insertBefore(notification, modalBody.firstChild);
        
        // Auto-remove after 5 seconds
        setTimeout(() => {
            if (notification.parentNode) {
                notification.remove();
            }
        }, 5000);
    }
}

// ============================================
// TIME MODAL FUNCTIONS - UPDATED
// ============================================

function openTimeModal(field) {
    console.log('Opening Time Modal for:', field);
    
    // Check if this field is already set and should be disabled
    const timeInput = document.getElementById(field === 'time_in' ? 'timeIn' : 'timeOut');
    const timeBtn = document.querySelector(`button[onclick*="${field}"]`);
    
    if (timeBtn && timeBtn.disabled) {
        showNotification(`⚠️ ${field.replace('_', ' ').toUpperCase()} is already set`, 'warning');
        return;
    }
    
    currentTimeField = field;
    const modal = document.getElementById('timeModal');
    const title = document.getElementById('timeModalTitle');
    
    if (modal) {
        // Set modal title
        title.textContent = field === 'time_in' ? 'Set Time In' : 'Set Time Out';
        
        // Populate time dropdowns
        populateTimeDropdowns();
        
        // Show modal
        modal.style.display = 'flex';
        modal.classList.add('show');
        document.body.style.overflow = 'hidden';
    }
}

// ============================================
// FORM FUNCTIONS - UPDATED
// ============================================

function updateEmployeeId() {
    const select = document.getElementById('employeeSelect');
    const idDisplay = document.getElementById('employeeIdDisplay');
    
    if (select && select.value) {
        const selectedOption = select.options[select.selectedIndex];
        // Extract ID from the option text
        const match = selectedOption.text.match(/\(ID:\s*(\d+)\)/);
        if (match) {
            idDisplay.textContent = match[1];
        } else {
            idDisplay.textContent = '--';
        }
        
        // Check for existing attendance when employee changes
        setTimeout(() => {
            checkExistingAttendance();
        }, 100);
    } else if (idDisplay) {
        idDisplay.textContent = '--';
    }
}

function resetAttendanceForm() {
    const form = document.getElementById('addAttendanceForm');
    if (form) {
        form.reset();
    }
    
    // Reset displays
    const idDisplay = document.getElementById('employeeIdDisplay');
    const timeInDisplay = document.getElementById('timeInDisplay');
    const timeOutDisplay = document.getElementById('timeOutDisplay');
    const timeInInput = document.getElementById('timeIn');
    const timeOutInput = document.getElementById('timeOut');
    
    if (idDisplay) idDisplay.textContent = '--';
    if (timeInDisplay) {
        timeInDisplay.className = 'time-display-box empty';
        timeInDisplay.querySelector('.time-display-content').textContent = '--:-- --';
    }
    if (timeOutDisplay) {
        timeOutDisplay.className = 'time-display-box empty';
        timeOutDisplay.querySelector('.time-display-content').textContent = '--:-- --';
    }
    if (timeInInput) timeInInput.value = '';
    if (timeOutInput) timeOutInput.value = '';
    
    // Reset status to Present
    const statusPresent = document.getElementById('statusPresent');
    if (statusPresent) statusPresent.checked = true;
    
    // Re-enable all time buttons
    const timeButtons = document.querySelectorAll('.time-manual-btn');
    timeButtons.forEach(btn => {
        btn.disabled = false;
        btn.textContent = btn.textContent.includes('Time In') ? 'Time In' : 'Time Out';
        btn.style.background = '#6c757d';
        btn.style.cursor = 'pointer';
    });
    
    // Clear any notification
    const notification = document.getElementById('attendanceNotification');
    if (notification) {
        notification.remove();
    }
}

// ============================================
// SAVE TIME FUNCTION - UPDATED
// ============================================

function saveTime() {
    if (!currentTimeField) {
        console.error('No current time field set');
        return;
    }
    
    const hour = document.getElementById('timeHour').value;
    const minute = document.getElementById('timeMinute').value;
    const period = document.getElementById('timePeriod').value;
    
    if (!hour || !minute || !period) {
        alert('Please select a valid time');
        return;
    }
    
    // Format time string for display
    const displayHour = parseInt(hour); // Remove leading zero for display
    const timeString = `${displayHour}:${minute} ${period}`;
    
    // Convert to 24-hour format for database
    const time24 = convertTo24Hour(displayHour, minute, period);
    
    console.log(`Saving ${currentTimeField}: ${timeString} (24h: ${time24})`);
    
    // Update the display and hidden input
    if (currentTimeField === 'time_in') {
        const display = document.getElementById('timeInDisplay');
        const input = document.getElementById('timeIn');
        const timeBtn = document.querySelector('button[onclick*="time_in"]');
        
        if (display) {
            display.className = 'time-display-box';
            display.querySelector('.time-display-content').textContent = timeString;
        }
        if (input) input.value = time24;
        if (timeBtn) {
            timeBtn.disabled = true;
            timeBtn.textContent = 'Time In (Set)';
            timeBtn.style.background = '#28a745';
        }
        
        // Add animation effect
        showTimeSetAnimation('timeInDisplay');
    } else if (currentTimeField === 'time_out') {
        const display = document.getElementById('timeOutDisplay');
        const input = document.getElementById('timeOut');
        const timeBtn = document.querySelector('button[onclick*="time_out"]');
        
        if (display) {
            display.className = 'time-display-box';
            display.querySelector('.time-display-content').textContent = timeString;
        }
        if (input) input.value = time24;
        if (timeBtn) {
            timeBtn.disabled = true;
            timeBtn.textContent = 'Time Out (Set)';
            timeBtn.style.background = '#28a745';
        }
        
        // Add animation effect
        showTimeSetAnimation('timeOutDisplay');
    }
    
    // Show success message
    showNotification(`✅ ${currentTimeField.replace('_', ' ').toUpperCase()} set successfully`, 'success');
    
    closeTimeModal();
}

// ============================================
// FORM SUBMISSION - UPDATED WITH VALIDATION
// ============================================

function submitAttendanceForm() {
    console.log('submitAttendanceForm called');
    
    const form = document.getElementById('addAttendanceForm');
    const employeeSelect = document.getElementById('employeeSelect');
    const statusPresent = document.getElementById('statusPresent');
    const statusAbsent = document.getElementById('statusAbsent');
    const timeInInput = document.getElementById('timeIn');
    const timeOutInput = document.getElementById('timeOut');
    
    if (!form || !employeeSelect) {
        console.error('Form elements not found');
        alert('Error: Form not properly loaded.');
        return false;
    }
    
    // Validate required fields
    if (!employeeSelect.value) {
        alert('Please select an employee');
        employeeSelect.focus();
        return false;
    }
    
    if (statusPresent && statusAbsent) {
        if (!statusPresent.checked && !statusAbsent.checked) {
            alert('Please select attendance status');
            return false;
        }
    }
    
    // Validate time-out cannot be before time-in
    if (timeInInput.value && timeOutInput.value) {
        const timeIn = new Date(`2000-01-01 ${timeInInput.value}`);
        const timeOut = new Date(`2000-01-01 ${timeOutInput.value}`);
        
        if (timeOut < timeIn) {
            alert('Time Out cannot be before Time In');
            return false;
        }
    }
    
    // Show what will be submitted
    console.log('Form data:');
    const formData = new FormData(form);
    for (let [key, value] of formData.entries()) {
        console.log(key + ': ' + value);
    }
    
    // Submit form
    console.log('Submitting form...');
    form.submit();
    return true;
}

// ============================================
// TIME FUNCTIONS (keep as is)
// ============================================

function populateTimeDropdowns() {
    const hourSelect = document.getElementById('timeHour');
    const minuteSelect = document.getElementById('timeMinute');
    const periodSelect = document.getElementById('timePeriod');
    
    if (!hourSelect || !minuteSelect || !periodSelect) {
        console.error('Time dropdowns not found');
        return;
    }
    
    // Clear existing options
    hourSelect.innerHTML = '';
    minuteSelect.innerHTML = '';
    periodSelect.innerHTML = '';
    
    // Populate hours (12-hour format)
    for (let i = 1; i <= 12; i++) {
        const option = document.createElement('option');
        option.value = i.toString().padStart(2, '0');
        option.textContent = i.toString().padStart(2, '0');
        hourSelect.appendChild(option);
    }
    
    // Populate minutes
    for (let i = 0; i < 60; i += 5) {
        const option = document.createElement('option');
        option.value = i.toString().padStart(2, '0');
        option.textContent = i.toString().padStart(2, '0');
        minuteSelect.appendChild(option);
    }
    
    // Populate AM/PM
    ['AM', 'PM'].forEach(period => {
        const option = document.createElement('option');
        option.value = period;
        option.textContent = period;
        periodSelect.appendChild(option);
    });
    
    // Set to current time
    setCurrentTime();
}

function setCurrentTime() {
    const hourSelect = document.getElementById('timeHour');
    const minuteSelect = document.getElementById('timeMinute');
    const periodSelect = document.getElementById('timePeriod');
    
    if (!hourSelect || !minuteSelect || !periodSelect) return;
    
    const now = new Date();
    let hours = now.getHours();
    let minutes = now.getMinutes();
    const period = hours >= 12 ? 'PM' : 'AM';
    
    // Convert to 12-hour format
    hours = hours % 12 || 12;
    
    // Round minutes to nearest 5
    minutes = Math.round(minutes / 5) * 5;
    if (minutes === 60) {
        minutes = 0;
        hours = (hours % 12) + 1;
        if (hours === 13) hours = 1;
    }
    
    hourSelect.value = hours.toString().padStart(2, '0');
    minuteSelect.value = minutes.toString().padStart(2, '0');
    periodSelect.value = period;
}

function convertTo24Hour(hour, minute, period) {
    hour = parseInt(hour);
    minute = parseInt(minute);
    
    if (period === 'PM' && hour !== 12) {
        hour += 12;
    }
    if (period === 'AM' && hour === 12) {
        hour = 0;
    }
    
    return `${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}:00`;
}

function showTimeSetAnimation(elementId) {
    const element = document.getElementById(elementId);
    if (!element) return;
    
    const confirmation = document.createElement('div');
    confirmation.className = 'time-set-confirmation';
    confirmation.textContent = '✓ Time Set';
    
    // Remove any existing animation
    const existing = element.querySelector('.time-set-confirmation');
    if (existing) existing.remove();
    
    element.appendChild(confirmation);
    
    // Remove animation after it completes
    setTimeout(() => {
        if (confirmation.parentNode === element) {
            element.removeChild(confirmation);
        }
    }, 3000);
}

// ============================================
// EVENT LISTENERS
// ============================================

document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM fully loaded');
    
    // Initialize employee ID display
    const employeeSelect = document.getElementById('employeeSelect');
    if (employeeSelect) {
        employeeSelect.addEventListener('change', updateEmployeeId);
    }
    
    // Close modals when clicking outside
    window.addEventListener('click', function(event) {
        const addModal = document.getElementById('addAttendanceModal');
        const timeModal = document.getElementById('timeModal');
        
        if (event.target === addModal) {
            closeAddAttendanceModal();
        }
        
        if (event.target === timeModal) {
            closeTimeModal();
        }
    });
    
    // Close modals with Escape key
    document.addEventListener('keydown', function(event) {
        if (event.key === 'Escape') {
            const addModal = document.getElementById('addAttendanceModal');
            const timeModal = document.getElementById('timeModal');
            
            if (addModal && addModal.style.display === 'flex') {
                closeAddAttendanceModal();
            }
            
            if (timeModal && timeModal.style.display === 'flex') {
                closeTimeModal();
            }
        }
    });
    
    // Test if elements exist
    console.log('Modal check:');
    console.log('- Add Attendance Modal:', document.getElementById('addAttendanceModal') ? 'Found' : 'Not Found');
    console.log('- Time Modal:', document.getElementById('timeModal') ? 'Found' : 'Not Found');
    console.log('- Employee Select:', document.getElementById('employeeSelect') ? 'Found' : 'Not Found');
    console.log('- Add Attendance Button:', document.querySelector('.add-attendance-btn') ? 'Found' : 'Not Found');
});
// Alternative edit function using AJAX
function editAttendance(employeeId, date) {
    console.log('Editing attendance for Employee:', employeeId, 'Date:', date);
    
    // Open the modal
    const modal = document.getElementById('addAttendanceModal');
    if (modal) {
        modal.style.display = 'flex';
        modal.classList.add('show');
        document.body.style.overflow = 'hidden';
        
        // Reset form first
        resetAttendanceForm();
        
        // Change modal title
        const modalTitle = document.querySelector('.modal-title');
        if (modalTitle) {
            modalTitle.textContent = 'Edit Attendance Record';
        }
        
        // Set the date
        document.getElementById('attendanceDate').value = date;
        document.getElementById('attendanceDateDisplay').textContent = formatDateForDisplay(date);
        
        // Fetch employee details via AJAX
        fetchEmployeeDetails(employeeId, date);
        
        console.log('Edit modal opened for Employee ID:', employeeId);
    }
}

// Function to fetch employee details via AJAX
async function fetchEmployeeDetails(employeeId, date) {
    try {
        // Show loading message
        showNotification('Loading employee details...', 'info');
        
        // Fetch employee details (you'll need to create this endpoint)
        const response = await fetch('get_employee_details.php?employee_id=' + employeeId);
        const employee = await response.json();
        
        if (employee.error) {
            showNotification('Error: ' + employee.error, 'error');
            return;
        }
        
        // Manually populate the employee selection
        const employeeIdInput = document.getElementById('employeeId');
        const employeeIdDisplay = document.getElementById('employeeIdDisplay');
        const selectedDisplay = document.getElementById('selectedEmployeeDisplay');
        const selectedText = document.getElementById('selectedEmployeeText');
        
        if (employeeIdInput && employeeIdDisplay && selectedDisplay && selectedText) {
            employeeIdInput.value = employeeId;
            employeeIdDisplay.textContent = employeeId;
            
            // Format employee name
            let fullName = employee.first_name;
            if (employee.middle_name) fullName += ' ' + employee.middle_name;
            fullName += ' ' + employee.last_name;
            
            selectedText.textContent = fullName + ' (ID: ' + employeeId + ')';
            selectedDisplay.classList.add('show');
            
            // Now check for existing attendance
            setTimeout(() => {
                checkExistingAttendance();
            }, 200);
        }
        
    } catch (error) {
        console.error('Error fetching employee details:', error);
        showNotification('Error loading employee details', 'error');
    }
}
// ============================================
// EDIT ATTENDANCE FUNCTION
// ============================================

function editAttendance(employeeId, date) {
    console.log('Editing attendance for Employee:', employeeId, 'Date:', date);
    
    // Open the modal
    const modal = document.getElementById('addAttendanceModal');
    if (modal) {
        modal.style.display = 'flex';
        modal.classList.add('show');
        document.body.style.overflow = 'hidden';
        
        // Reset form first
        resetAttendanceForm();
        
        // Change modal title to indicate editing
        const modalTitle = document.querySelector('.modal-title');
        if (modalTitle) {
            modalTitle.textContent = 'Edit Attendance Record';
        }
        
        // Set the date
        document.getElementById('attendanceDate').value = date;
        document.getElementById('attendanceDateDisplay').textContent = formatDateForDisplay(date);
        
        // Store the original employee ID and date for reference
        const originalEmployeeId = employeeId;
        const originalDate = date;
        
        // Try to find and select the employee in the search
        setTimeout(() => {
            // This is a workaround since we need to search for the employee
            // In a real implementation, you might want to fetch employee details via AJAX
            const employeeSearch = document.getElementById('employeeSearch');
            if (employeeSearch) {
                // Trigger search for this employee ID
                employeeSearch.value = employeeId;
                searchEmployees(employeeId.toString());
                
                // After a delay, try to select the employee
                setTimeout(() => {
                    // Look for the employee in the search results
                    const searchResults = document.getElementById('employeeSearchResults');
                    if (searchResults) {
                        const resultItems = searchResults.querySelectorAll('.employee-result-item');
                        resultItems.forEach(item => {
                            const idMatch = item.textContent.match(/ID:\s*(\d+)/);
                            if (idMatch && idMatch[1] === employeeId.toString()) {
                                // Simulate click on the correct employee
                                item.click();
                                
                                // Now check for existing attendance
                                setTimeout(() => {
                                    checkExistingAttendance();
                                }, 200);
                            }
                        });
                    }
                }, 500);
            }
        }, 100);
        
        console.log('Edit modal opened for Employee ID:', employeeId);
    } else {
        console.error('Modal not found!');
        alert('Error: Could not find the modal.');
    }
}

// Helper function to format date for display
function formatDateForDisplay(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
        month: '2-digit',
        day: '2-digit',
        year: 'numeric'
    });
}
// Alternative edit function using AJAX
function editAttendance(employeeId, date) {
    console.log('Editing attendance for Employee:', employeeId, 'Date:', date);
    
    // Open the modal
    const modal = document.getElementById('addAttendanceModal');
    if (modal) {
        modal.style.display = 'flex';
        modal.classList.add('show');
        document.body.style.overflow = 'hidden';
        
        // Reset form first
        resetAttendanceForm();
        
        // Change modal title
        const modalTitle = document.querySelector('.modal-title');
        if (modalTitle) {
            modalTitle.textContent = 'Edit Attendance Record';
        }
        
        // Set the date
        document.getElementById('attendanceDate').value = date;
        document.getElementById('attendanceDateDisplay').textContent = formatDateForDisplay(date);
        
        // Fetch employee details via AJAX
        fetchEmployeeDetails(employeeId, date);
        
        console.log('Edit modal opened for Employee ID:', employeeId);
    }
}

// Function to fetch employee details via AJAX
async function fetchEmployeeDetails(employeeId, date) {
    try {
        // Show loading message
        showNotification('Loading employee details...', 'info');
        
        // Fetch employee details (you'll need to create this endpoint)
        const response = await fetch('get_employee_details.php?employee_id=' + employeeId);
        const employee = await response.json();
        
        if (employee.error) {
            showNotification('Error: ' + employee.error, 'error');
            return;
        }
        
        // Manually populate the employee selection
        const employeeIdInput = document.getElementById('employeeId');
        const employeeIdDisplay = document.getElementById('employeeIdDisplay');
        const selectedDisplay = document.getElementById('selectedEmployeeDisplay');
        const selectedText = document.getElementById('selectedEmployeeText');
        
        if (employeeIdInput && employeeIdDisplay && selectedDisplay && selectedText) {
            employeeIdInput.value = employeeId;
            employeeIdDisplay.textContent = employeeId;
            
            // Format employee name
            let fullName = employee.first_name;
            if (employee.middle_name) fullName += ' ' + employee.middle_name;
            fullName += ' ' + employee.last_name;
            
            selectedText.textContent = fullName + ' (ID: ' + employeeId + ')';
            selectedDisplay.classList.add('show');
            
            // Now check for existing attendance
            setTimeout(() => {
                checkExistingAttendance();
            }, 200);
        }
        
    } catch (error) {
        console.error('Error fetching employee details:', error);
        showNotification('Error loading employee details', 'error');
    }
}
// ============================================
// GLOBAL FUNCTIONS (for onclick attributes)
// ============================================

// These functions need to be globally accessible
window.openAddAttendanceModal = openAddAttendanceModal;
window.closeAddAttendanceModal = closeAddAttendanceModal;
window.openTimeModal = openTimeModal;
window.closeTimeModal = closeTimeModal;
window.updateEmployeeId = updateEmployeeId;
window.resetAttendanceForm = resetAttendanceForm;
window.submitAttendanceForm = submitAttendanceForm;
window.saveTime = saveTime;
window.checkExistingAttendance = checkExistingAttendance;