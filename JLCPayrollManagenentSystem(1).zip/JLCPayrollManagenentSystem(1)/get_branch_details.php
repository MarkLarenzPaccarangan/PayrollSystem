<?php
session_start();
include 'connection.php';

header('Content-Type: application/json');

if (!isset($_SESSION['Admin_User'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$branch_id = isset($_GET['branch_id']) ? (int)$_GET['branch_id'] : 0;

if ($branch_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid branch ID']);
    exit;
}

try {
    // Get branch details
    $query = "SELECT branch_name, department_manager, department_address 
              FROM branch 
              WHERE id = ?";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $branch_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $branch = $result->fetch_assoc();
        echo json_encode([
            'success' => true,
            'branch' => $branch
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Branch not found'
        ]);
    }
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Database error: ' . $e->getMessage()
    ]);
}
?>