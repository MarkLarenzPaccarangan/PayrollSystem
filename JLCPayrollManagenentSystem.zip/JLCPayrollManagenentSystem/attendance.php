<?php
session_start();

// Debug: Check if we have success/error messages
if (isset($_SESSION['success'])) {
    error_log("SUCCESS MESSAGE: " . $_SESSION['success']);
}
if (isset($_SESSION['error'])) {
    error_log("ERROR MESSAGE: " . $_SESSION['error']);
}

if (!isset($_SESSION['Admin_User'])) {
    header("Location: login.php");
    exit;
}
// ... rest of your code ...
?>
<?php 
session_start();

if (!isset($_SESSION['Admin_User'])) {
    header("Location: login.php");
    exit;
}

include_once("connection.php");

// Date filter - default to current date
$selected_date = isset($_GET['date']) ? $_GET['date'] : date('Y-m-d');
$search = isset($_GET['search']) ? trim($_GET['search']) : "";

// Extract month, year, and day from selected date
$month = date('m', strtotime($selected_date));
$year = date('Y', strtotime($selected_date));
$day = date('d', strtotime($selected_date));

// BASE QUERY (LEFT JOIN = important)
$sql = "SELECT 
            e.id AS employee_id,
            e.first_name,
            e.middle_name,
            e.last_name,
            a.date,
            a.status,
            a.time_in,
            a.time_out
        FROM employees e
        LEFT JOIN attendance a 
            ON a.employee_id = e.id 
            AND DATE(a.date) = ?";

$params = [$selected_date];
$param_types = "s";

// Search
if (!empty($search)) {
    $sql .= " WHERE (e.first_name LIKE ? 
              OR e.middle_name LIKE ? 
              OR e.last_name LIKE ? 
              OR e.id LIKE ?)";
    $search_param = "%$search%";
    $params = array_merge($params, [$search_param, $search_param, $search_param, $search_param]);
    $param_types .= "ssss";
}

$sql .= " ORDER BY e.last_name ASC, a.date DESC";

$stmt = $conn->prepare($sql);

if ($stmt === false) {
    die("Error preparing query: " . $conn->error);
}

// Bind parameters dynamically
$stmt->bind_param($param_types, ...$params);
$stmt->execute();
$result = $stmt->get_result();

// Get month name
$month_name = date('F', strtotime($selected_date));

// Get number of days in selected month
$days_in_month = date('t', strtotime($selected_date));

// Get first day of month (0=Sunday, 1=Monday, etc.)
$first_day_of_month = date('w', strtotime("$year-$month-01"));

// Get employees for modal dropdown
$employee_sql = "SELECT id, first_name, middle_name, last_name FROM employees ORDER BY last_name, first_name";
$employee_result = $conn->query($employee_sql);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Attendance</title>
    <link rel="stylesheet" href="./assets/css/employee.css">
    <link rel="stylesheet" href="./assets/css/attendance.css">
</head>
<body>

<?php include("./includes/header.php"); ?>
<?php include("./includes/sidebar.php"); ?>

<main class="content">
    <div class="welcome-box2">ATTENDANCE LIST</div>
    
    <!-- Search Container Box -->
    <div class="search-container">
        <form method="GET" action="attendance.php" id="attendanceForm">
            <div class="filter-row">
                <div class="filter-group">
                    <span class="filter-label">Date:</span>
                    <div class="calendar-container">
                        <input type="text" id="dateInput" class="date-input" 
                               onclick="toggleCalendar()" readonly>
                        <input type="hidden" id="selectedDate" name="date" value="<?= $selected_date ?>">
                        
                        <!-- Calendar Dropdown -->
                        <div class="calendar-wrapper" id="calendarWrapper">
                            <div class="calendar-box">
                                <div class="calendar-header">
                                    <div class="calendar-month-year">
                                        <?= $month_name ?> <?= $year ?> ▼
                                    </div>
                                    <div class="calendar-nav">
                                        <button type="button" class="calendar-nav-btn" onclick="navigateMonth(-1)">‹</button>
                                        <button type="button" class="calendar-nav-btn" onclick="navigateMonth(1)">›</button>
                                    </div>
                                </div>
                                
                                <div class="calendar-weekdays">
                                    <div class="weekday">Su</div>
                                    <div class="weekday">Mo</div>
                                    <div class="weekday">Tu</div>
                                    <div class="weekday">We</div>
                                    <div class="weekday">Th</div>
                                    <div class="weekday">Fr</div>
                                    <div class="weekday">Sa</div>
                                </div>
                                
                                <div class="calendar-days-grid">
                                    <?php
                                    // Fill in days from previous month
                                    for ($i = 0; $i < $first_day_of_month; $i++) {
                                        $prev_month_day = date('j', strtotime("-$i days", strtotime("$year-$month-01")));
                                        echo '<div class="calendar-day other-month">' . $prev_month_day . '</div>';
                                    }
                                    
                                    // Current month days
                                    $today = date('Y-m-d');
                                    for ($day_num = 1; $day_num <= $days_in_month; $day_num++) {
                                        $current_date = date('Y-m-d', strtotime("$year-$month-" . str_pad($day_num, 2, '0', STR_PAD_LEFT)));
                                        $is_today = ($current_date == $today);
                                        $is_selected = ($current_date == $selected_date);
                                        $weekday = date('w', strtotime($current_date));
                                        $is_weekend = ($weekday == 0 || $weekday == 6);
                                        
                                        $classes = 'calendar-day';
                                        if ($is_today) $classes .= ' today';
                                        if ($is_selected) $classes .= ' selected';
                                        if ($is_weekend) $classes .= ' weekend';
                                        
                                        echo '<a href="javascript:void(0)" class="' . $classes . '" onclick="selectDate(\'' . $current_date . '\')">';
                                        echo $day_num;
                                        echo '</a>';
                                    }
                                    
                                    // Fill remaining cells
                                    $total_cells = 42; // 6 rows * 7 columns
                                    $cells_used = $first_day_of_month + $days_in_month;
                                    $cells_remaining = $total_cells - $cells_used;
                                    
                                    for ($i = 1; $i <= $cells_remaining; $i++) {
                                        echo '<div class="calendar-day other-month">' . $i . '</div>';
                                    }
                                    ?>
                                </div>
                                
                                <div class="calendar-footer">
                                    <a href="javascript:void(0)" class="calendar-action-btn clear" onclick="selectDate('')">Clear</a>
                                    <a href="javascript:void(0)" class="calendar-action-btn today" 
                                       onclick="selectDate('<?= date('Y-m-d') ?>')">Today</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="filter-group" style="flex-grow:1;">
                    <input type="text" id="searchInput" name="search" placeholder="Search by name or ID" 
                           class="search-bar" value="<?= htmlspecialchars($search) ?>">
                </div>
                
                <button type="submit" class="search-btn">
                    Search
                </button>
                
                <a href="attendance.php" class="clear-btn">
                    Clear Filters
                </a>
                
                <!-- Add Attendance Button -->
                <button type="button" class="add-attendance-btn" onclick="openAddAttendanceModal()">
                    <span style="font-size:18px;">+</span> Add Attendance
                </button>
            </div>
        </form>
    </div>

    <table class="Employee-table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Employee</th>
                <th>Date</th>
                <th>Status</th>
                <th>Time In</th>
                <th>Time Out</th>
            </tr>
        </thead>
        <tbody>
        <?php if($result && $result->num_rows > 0): ?>
            <?php while($row = $result->fetch_assoc()): ?>
                <?php
                // Format times for display
                $time_in_display = "-";
                $time_out_display = "-";
                
                if (!empty($row['time_in'])) {
                    $time_in = strtotime($row['time_in']);
                    $time_in_display = date('h:i A', $time_in);
                }
                
                if (!empty($row['time_out'])) {
                    $time_out = strtotime($row['time_out']);
                    $time_out_display = date('h:i A', $time_out);
                }
                
                // Determine AM/PM
                $time_in_ampm = !empty($row['time_in']) ? date('A', strtotime($row['time_in'])) : '';
                $time_out_ampm = !empty($row['time_out']) ? date('A', strtotime($row['time_out'])) : '';
                
                // Determine status class
                $status_class = 'status-no-record';
                $status_text = 'No Record';
                if (!empty($row['status'])) {
                    $status_class = $row['status'] == 'Present' ? 'status-present' : 'status-absent';
                    $status_text = htmlspecialchars($row['status']);
                }
                ?>
                <tr>
                    <td data-label="ID" style="text-align: center;"><?= htmlspecialchars($row['employee_id']) ?></td>
                    <td data-label="Employee">
                        <?= htmlspecialchars($row['first_name'] . " " . 
                           (!empty($row['middle_name']) ? $row['middle_name'] . " " : "") . 
                           $row['last_name']) ?>
                    </td>
                    <td data-label="Date" style="text-align: center;">
                        <?= !empty($row['date']) ? date('M d, Y', strtotime($row['date'])) : '-' ?>
                    </td>
                    <td data-label="Status" style="text-align: center;">
                        <span class="<?= $status_class ?>"><?= $status_text ?></span>
                    </td>
                    <td data-label="Time In" style="text-align: center;">
                        <?php if (!empty($row['time_in'])): ?>
                            <div class="time-container">
                                <span class="time-label"><?= $time_in_ampm ?></span>
                                <span class="<?= strtolower($time_in_ampm) == 'am' ? 'am-time' : 'pm-time' ?>">
                                    <?= $time_in_display ?>
                                </span>
                            </div>
                        <?php else: ?>
                            <span style="color:#adb5bd;">-</span>
                        <?php endif; ?>
                    </td>
                    <td data-label="Time Out" style="text-align: center;">
                        <?php if (!empty($row['time_out'])): ?>
                            <div class="time-container">
                                <span class="time-label"><?= $time_out_ampm ?></span>
                                <span class="<?= strtolower($time_out_ampm) == 'am' ? 'am-time' : 'pm-time' ?>">
                                    <?= $time_out_display ?>
                                </span>
                            </div>
                        <?php else: ?>
                            <span style="color:#adb5bd;">-</span>
                        <?php endif; ?>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr>
                <td colspan="6" style="text-align:center;color:gray;padding:30px;">
                    <?php 
                    if (!empty($search)) {
                        echo "<div style='font-size:16px;margin-bottom:10px;'>🔍</div>";
                        echo "No employees found matching <strong>'".htmlspecialchars($search)."'</strong> for ";
                        echo "<strong>" . date('F j, Y', strtotime($selected_date)) . "</strong>.";
                    } else {
                        echo "<div style='font-size:16px;margin-bottom:10px;'>📅</div>";
                        echo "No attendance records found for <strong>" . date('l, F j, Y', strtotime($selected_date)) . "</strong>.";
                        echo "<br><small style='color:#6c757d;'>Try selecting a different date or search for employees.</small>";
                    }
                    ?>
                </td>
            </tr>
        <?php endif; ?>
        </tbody>
    </table>
    
    <!-- Add Attendance Modal -->
    <div class="modal" id="addAttendanceModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title">Add Attendance Record</h3>
                <button type="button" class="modal-close" onclick="closeAddAttendanceModal()">×</button>
            </div>
            <div class="modal-body">
                <form id="addAttendanceForm" method="POST" action="add_attendance.php">
                    <!-- Employee Selection -->
                    <div class="form-group">
                        <label class="form-label required">Employee</label>
                        <select id="employeeSelect" name="employee_id" class="form-control" required onchange="updateEmployeeId()">
                            <option value="">Select Employee</option>
                            <?php while($employee = $employee_result->fetch_assoc()): ?>
                                <option value="<?= $employee['id'] ?>">
                                    <?= htmlspecialchars($employee['first_name'] . ' ' . 
                                       (!empty($employee['middle_name']) ? $employee['middle_name'] . ' ' : '') . 
                                       $employee['last_name']) ?> (ID: <?= $employee['id'] ?>)
                                </option>
                            <?php endwhile; 
                            // Reset pointer for future use if needed
                            $employee_result->data_seek(0);
                            ?>
                        </select>
                    </div>
                    
                    <!-- Date and ID Row -->
                    <div class="form-row">
                        <div class="form-col">
                            <label class="form-label">Date</label>
                            <div class="date-display" id="attendanceDateDisplay">
                                <?= date('m/d/Y', strtotime($selected_date)) ?>
                            </div>
                            <input type="hidden" id="attendanceDate" name="date" value="<?= $selected_date ?>">
                        </div>
                        
                        <div class="form-col">
                            <label class="form-label">ID</label>
                            <div class="date-display" id="employeeIdDisplay">--</div>
                        </div>
                    </div>
                    
                    <!-- Status Selection -->
                    <div class="form-group">
                        <label class="form-label required">Status</label>
                        <div class="status-options">
                            <div class="status-option">
                                <input type="radio" id="statusPresent" name="status" value="Present" class="status-radio" checked>
                                <label for="statusPresent" class="status-label">
                                    <span class="status-dot present"></span>
                                    <span>Present</span>
                                </label>
                            </div>
                            
                            <div class="status-option">
                                <input type="radio" id="statusAbsent" name="status" value="Absent" class="status-radio">
                                <label for="statusAbsent" class="status-label">
                                    <span class="status-dot absent"></span>
                                    <span>Absent</span>
                                </label>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Time In -->
                    <div class="form-group">
                        <div class="time-input-container">
                            <div class="time-display-wrapper">
                                <div class="time-display-box empty" id="timeInDisplay">
                                    <div class="time-display-content">--:-- --</div>
                                </div>
                                <input type="hidden" id="timeIn" name="time_in">
                            </div>
                            <button type="button" class="time-manual-btn" onclick="openTimeModal('time_in')">
                                Time In
                            </button>
                        </div>
                    </div>
                    
                    <!-- Time Out -->
                    <div class="form-group">
                        <div class="time-input-container">
                            <div class="time-display-wrapper">
                                <div class="time-display-box empty" id="timeOutDisplay">
                                    <div class="time-display-content">--:-- --</div>
                                </div>
                                <input type="hidden" id="timeOut" name="time_out">
                            </div>
                            <button type="button" class="time-manual-btn" onclick="openTimeModal('time_out')">
                                Time Out
                            </button>
                        </div>
                    </div>
                    
                    <!-- Remarks -->
                    <div class="form-group">
                        <label class="form-label">Remarks (Optional)</label>
                        <textarea name="remarks" class="form-control" rows="3" placeholder="Add any remarks or notes..."></textarea>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeAddAttendanceModal()">Cancel</button>
                <button type="button" class="btn btn-success" onclick="submitAttendanceForm()">Save Attendance</button>
            </div>
        </div>
    </div>
    
    <!-- Time Input Modal -->
    <div class="time-modal" id="timeModal">
        <div class="time-modal-content">
            <div class="time-modal-header">
                <h3 class="time-modal-title" id="timeModalTitle">Set Time</h3>
                <button type="button" class="modal-close" onclick="closeTimeModal()">×</button>
            </div>
            <div class="time-modal-body">
                <div class="time-input-group">
                    <select id="timeHour" class="time-input-select">
                        <!-- Hours will be populated by JavaScript -->
                    </select>
                    
                    <span class="time-input-separator">:</span>
                    
                    <select id="timeMinute" class="time-input-select">
                        <!-- Minutes will be populated by JavaScript -->
                    </select>
                    
                    <select id="timePeriod" class="time-period-select">
                        <!-- AM/PM will be populated by JavaScript -->
                    </select>
                </div>
            </div>
            <div class="time-modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeTimeModal()">Cancel</button>
                <button type="button" class="btn btn-primary" onclick="saveTime()">Set Time</button>
            </div>
        </div>
    </div>
    
    <?php
    // Close statements
    if (isset($stmt)) {
        $stmt->close();
    }
    if (isset($employee_result)) {
        $employee_result->close();
    }
    ?>
</main>

<?php include("./includes/footer.php"); ?>

<script src="./assets/js/attendance.js"></script>
<!-- Add Attendance Modal -->
<div class="modal" id="addAttendanceModal">
    <div class="modal-content">
        <div class="modal-header">
            <h3 class="modal-title">Add Attendance Record</h3>
            <button type="button" class="modal-close" onclick="closeAddAttendanceModal()">×</button>
        </div>
        <div class="modal-body">
            <form id="addAttendanceForm" method="POST" action="add_attendance.php">
                <!-- Employee Selection -->
                <div class="form-group">
                    <label class="form-label required">Employee</label>
                    <select id="employeeSelect" name="employee_id" class="form-control" required onchange="updateEmployeeId()">
                        <option value="">Select Employee</option>
                        <?php while($employee = $employee_result->fetch_assoc()): ?>
                            <option value="<?= $employee['id'] ?>">
                                <?= htmlspecialchars($employee['first_name'] . ' ' . 
                                   (!empty($employee['middle_name']) ? $employee['middle_name'] . ' ' : '') . 
                                   $employee['last_name']) ?> (ID: <?= $employee['id'] ?>)
                            </option>
                        <?php endwhile; 
                        // Reset pointer for future use if needed
                        $employee_result->data_seek(0);
                        ?>
                    </select>
                </div>
                
                <!-- Date and ID Row -->
                <div class="form-row">
                    <div class="form-col">
                        <label class="form-label">Date</label>
                        <div class="date-display" id="attendanceDateDisplay">
                            <?= date('m/d/Y', strtotime($selected_date)) ?>
                        </div>
                        <input type="hidden" id="attendanceDate" name="date" value="<?= $selected_date ?>">
                    </div>
                    
                    <div class="form-col">
                        <label class="form-label">ID</label>
                        <div class="date-display" id="employeeIdDisplay">--</div>
                    </div>
                </div>
                
                <!-- Status Selection -->
                <div class="form-group">
                    <label class="form-label required">Status</label>
                    <div class="status-options">
                        <div class="status-option">
                            <input type="radio" id="statusPresent" name="status" value="Present" class="status-radio" checked>
                            <label for="statusPresent" class="status-label">
                                <span class="status-dot present"></span>
                                <span>Present</span>
                            </label>
                        </div>
                        
                        <div class="status-option">
                            <input type="radio" id="statusAbsent" name="status" value="Absent" class="status-radio">
                            <label for="statusAbsent" class="status-label">
                                <span class="status-dot absent"></span>
                                <span>Absent</span>
                            </label>
                        </div>
                    </div>
                </div>
                
                <!-- Time In -->
                <div class="form-group">
                    <div class="time-input-container">
                        <div class="time-display-wrapper">
                            <div class="time-display-box empty" id="timeInDisplay">
                                <div class="time-display-content">--:-- --</div>
                            </div>
                            <input type="hidden" id="timeIn" name="time_in">
                        </div>
                        <button type="button" class="time-manual-btn" onclick="openTimeModal('time_in')">
                            Time In
                        </button>
                    </div>
                </div>
                
                <!-- Time Out -->
                <div class="form-group">
                    <div class="time-input-container">
                        <div class="time-display-wrapper">
                            <div class="time-display-box empty" id="timeOutDisplay">
                                <div class="time-display-content">--:-- --</div>
                            </div>
                            <input type="hidden" id="timeOut" name="time_out">
                        </div>
                        <button type="button" class="time-manual-btn" onclick="openTimeModal('time_out')">
                            Time Out
                        </button>
                    </div>
                </div>
                
                <!-- Remarks -->
                <div class="form-group">
                    <label class="form-label">Remarks (Optional)</label>
                    <textarea name="remarks" class="form-control" rows="3" placeholder="Add any remarks or notes..."></textarea>
                </div>
            </form>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" onclick="closeAddAttendanceModal()">Cancel</button>
            <button type="button" class="btn btn-success" onclick="submitAttendanceForm()">Save Attendance</button>
        </div>
    </div>
</div>

<!-- Time Input Modal -->
<div class="time-modal" id="timeModal">
    <div class="time-modal-content">
        <div class="time-modal-header">
            <h3 class="time-modal-title" id="timeModalTitle">Set Time</h3>
            <button type="button" class="modal-close" onclick="closeTimeModal()">×</button>
        </div>
        <div class="time-modal-body">
            <div class="time-input-group">
                <select id="timeHour" class="time-input-select">
                    <!-- Hours will be populated by JavaScript -->
                </select>
                
                <span class="time-input-separator">:</span>
                
                <select id="timeMinute" class="time-input-select">
                    <!-- Minutes will be populated by JavaScript -->
                </select>
                
                <select id="timePeriod" class="time-period-select">
                    <!-- AM/PM will be populated by JavaScript -->
                </select>
            </div>
        </div>
        <div class="time-modal-footer">
            <button type="button" class="btn btn-secondary" onclick="closeTimeModal()">Cancel</button>
            <button type="button" class="btn btn-primary" onclick="saveTime()">Set Time</button>
        </div>
    </div>
</div>
</body>
</html>