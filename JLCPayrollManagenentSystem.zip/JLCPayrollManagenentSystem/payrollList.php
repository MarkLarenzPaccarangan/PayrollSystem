<?php 
session_start();

if (!isset($_SESSION['Admin_User'])) {
    header("Location: login.php");
    exit;
}

include_once("connection.php");

$month = isset($_GET['month']) ? $_GET['month'] : date('m');
$year = isset($_GET['year']) ? $_GET['year'] : date('Y');

if (isset($_GET['delete_id'])) {
    $payrollId = $_GET['delete_id'];
    $stmt = $conn->prepare("DELETE FROM payroll WHERE id = ?");
    $stmt->bind_param("i", $payrollId);
    if ($stmt->execute()) {
        echo "<script>alert('Payroll record deleted successfully'); window.location.href='payrollList.php';</script>";
    } else {
        echo "<script>alert('Error deleting payroll record');</script>";
    }
}

$sql = "
    SELECT p.id, p.date_from, p.date_to, 
           CONCAT(e.first_name, ' ', e.last_name) AS employee_name, 
           e.position,
           (e.monthly_salary - COALESCE(SUM(d.amount), 0)) AS net_pay
    FROM payroll p
    LEFT JOIN employees e ON e.id = p.employee_id
    LEFT JOIN deduction d ON d.employee_id = e.id
    WHERE MONTH(p.date_from) = ? AND YEAR(p.date_from) = ?
    GROUP BY p.id, e.id, e.monthly_salary
    ORDER BY p.date_from DESC
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $month, $year);
$stmt->execute();
$result = $stmt->get_result();

$searchTerm = isset($_POST['search']) ? $_POST['search'] : '';
$searchSql = "SELECT id, first_name, last_name FROM employees WHERE CONCAT(first_name, ' ', last_name) LIKE ?";
$searchStmt = $conn->prepare($searchSql);
$searchTerm = '%' . $searchTerm . '%';
$searchStmt->bind_param("s", $searchTerm);
$searchStmt->execute();
$employeesResult = $searchStmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Payroll List</title>

<style>
/* =========================
   GENERAL RESET & TYPOGRAPHY
========================= */
body {
    margin: 0;
    font-family: "Inter", "Segoe UI", sans-serif;
    background: #f4f6f8;
    color: #1a202c;
}

h1, h2 {
    margin: 0;
}

/* =========================
   WELCOME / HEADER BOX
========================= */
.welcome-box2 {
    font-size: 1.5rem;
    font-weight: 700;
    color: #077932;
    margin-bottom: 20px;
}

/* =========================
   FILTER CONTROLS
========================= */
.controls {
    display: flex;
    justify-content: flex-start;
    align-items: center;
    margin-bottom: 25px;
    flex-wrap: wrap;
}

.controls label {
    margin-right: 10px;
    font-weight: 600;
}

.controls select,
.controls input[type="number"],
.controls button {
    padding: 8px 12px;
    margin-right: 15px;
    border-radius: 6px;
    border: 1px solid #ddd;
    font-size: 14px;
}

.controls button {
    background-color: #077932;
    color: #fff;
    border: none;
    cursor: pointer;
    transition: 0.3s ease;
}

.controls button:hover {
    background-color: #0fa85a;
}

/* =========================
   PAYROLL TABLE
========================= */
.payroll-table {
    width: 100%;
    border-collapse: collapse;
    background: #fff;
    box-shadow: 0 5px 15px rgba(0,0,0,0.08);
    border-radius: 10px;
    overflow: hidden;
}

.payroll-table thead {
    background: linear-gradient(90deg, #2ee98a, #0fa85a);
    color: #fff;
    font-weight: 600;
}

.payroll-table th, .payroll-table td {
    padding: 12px 15px;
    text-align: left;
}

.payroll-table tbody tr {
    border-bottom: 1px solid #f1f1f1;
    transition: background 0.2s ease;
}

.payroll-table tbody tr:hover {
    background-color: #e6f7ee;
}

.payroll-table tbody tr:last-child {
    border-bottom: none;
}

.payroll-table td {
    color: #333;
}

/* =========================
   EMPTY STATE
========================= */
.payroll-table td[colspan] {
    text-align: center;
    color: #777;
    font-style: italic;
}

/* =========================
   MODAL STYLING
========================= */
.modal {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0,0,0,0.5);
    z-index: 1000;
    justify-content: center;
    align-items: center;
}

.modal-content {
    background: #fff;
    padding: 25px;
    border-radius: 12px;
    width: 400px;
    text-align: center;
    box-shadow: 0 8px 25px rgba(0,0,0,0.2);
}

.modal-content h2 {
    margin-bottom: 20px;
    color: #077932;
}

.modal-content input,
.modal-content select {
    width: 100%;
    padding: 10px;
    margin-bottom: 12px;
    border: 1px solid #ddd;
    border-radius: 6px;
}

.modal-content button {
    padding: 10px 20px;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    background-color: #28a745;
    color: white;
    transition: 0.3s ease;
}

.modal-content button:hover {
    background-color: #0fa85a;
}

.modal-content .close-btn {
    background-color: #f44336;
}

.modal-content .close-btn:hover {
    background-color: #d32f2f;
}
</style>
</head>
<body>

<?php include_once("./includes/header.php"); ?>
<?php include_once("./includes/sidebar.php"); ?>

<main class="content">
    <div class="welcome-box2">Payroll List</div>

    <div class="controls">
        <form method="GET" action="payrollList.php">
            <label for="month">Month:</label>
            <select name="month" id="month">
                <?php for ($m=1; $m<=12; $m++): ?>
                    <option value="<?= $m ?>" <?= $month == $m ? 'selected' : '' ?>>
                        <?= date('F', mktime(0,0,0,$m,10)) ?>
                    </option>
                <?php endfor; ?>
            </select>

            <label for="year">Year:</label>
            <input type="number" name="year" id="year" value="<?= $year ?>" required>

            <button type="submit">Filter</button>
        </form>
    </div>

    <table class="payroll-table">
        <thead>
            <tr>
                <th>Payroll ID</th>
                <th>Employee Name</th>
                <th>Net Pay</th>
                <th>Month</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($row['id']) ?></td>
                        <td><?= htmlspecialchars($row['employee_name']) ?></td>
                        <td>₱<?= number_format($row['net_pay'], 2) ?></td>
                        <td><?= date('F', mktime(0,0,0,$month,10)) . ' ' . $year ?></td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="4">No payroll records found for the selected date range.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</main>

<?php include_once("./modal/logout-modal.php"); ?>
<?php include_once("./includes/footer.php"); ?>

</body>
</html>
