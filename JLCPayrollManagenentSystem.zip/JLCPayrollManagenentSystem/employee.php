<?php
session_start();

if (!isset($_SESSION['Admin_User'])) {
    header("Location: login.php"); 
    exit;
}
// Connection to the database
include_once("connection.php");

// Handle Add Employee
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['save_employee'])) {
    $first_name = $_POST['first_name'];
    $middle_name = $_POST['middle_name'];
    $last_name = $_POST['last_name'];
    $address = $_POST['address'];
    $contact_num = $_POST['contact_num'];
    $position = $_POST['position'];
    $email = $_POST['email'];
    $gender = $_POST['gender'];
    $civil_status = $_POST['civil_status'];
    $date_hired = $_POST['date_hired'];
    $monthly_salary = $_POST['monthly_salary'];
    $dob = $_POST['dob'];
    $sss_number = $_POST['sss_number'] ?? '';
    $pagibig_number = $_POST['pagibig_number'] ?? '';
    $tin_number = $_POST['tin_number'] ?? '';
    $philhealth_number = $_POST['philhealth_number'] ?? '';

    $sql = "INSERT INTO employees (first_name, middle_name, last_name, address, contact_num, position, email, gender, civil_status, date_hired, monthly_salary, dob, sss_number, pagibig_number, tin_number, philhealth_number) 
            VALUES ('$first_name', '$middle_name', '$last_name', '$address', '$contact_num', '$position', '$email', '$gender', '$civil_status', '$date_hired', '$monthly_salary', '$dob', '$sss_number', '$pagibig_number', '$tin_number', '$philhealth_number')";
    $conn->query($sql);
    echo "<script>alert('Employee added successfully!'); window.location.href='employee.php';</script>";
    exit();
}

if (isset($_GET['toggle_status']) && isset($_GET['employee_id'])) {
    $employee_id = $_GET['employee_id'];
    $current_status = $_GET['status'];

    // Toggle the employee status between active and inactive
    $new_status = ($current_status === 'active') ? 'inactive' : 'active';

    // Update the employee's status in the database
    $stmt = $conn->prepare("UPDATE employees SET status = ? WHERE id = ?");
    $stmt->bind_param("si", $new_status, $employee_id);
    
    if ($stmt->execute()) {
        // If the employee is disabled, disable all their deductions as well
        if ($new_status === 'inactive') {
            // Disable the employee's deductions if deduction table exists
            $stmt = $conn->prepare("UPDATE deduction SET status = 'inactive' WHERE employee_id = ?");
            $stmt->bind_param("i", $employee_id);
            $stmt->execute();
            
            // Remove employee from branch assignments (use correct table name: branch_employee)
            $stmt = $conn->prepare("DELETE FROM branch_employee WHERE employee_id = ?");
            $stmt->bind_param("i", $employee_id);
            $stmt->execute();
        }
        
        echo "<script>alert('Employee status updated successfully!'); window.location.href='employee.php';</script>";
    } else {
        echo "<script>alert('Error updating employee status!'); window.location.href='employee.php';</script>";
    }
    exit();
}

// Fetch Employee Details for View
if (isset($_GET['view'])) {
    $id = $_GET['view'];
    $view_result = $conn->query("SELECT * FROM employees WHERE id = $id");
    $employee = $view_result->fetch_assoc(); // Fetch as associative array
}

// Fetch Employee Details for Edit
if (isset($_GET['edit'])) {
    $id = $_GET['edit'];
    $edit_result = $conn->query("SELECT * FROM employees WHERE id = $id");
    $employee_edit = $edit_result->fetch_assoc(); // Fetch as associative array
}

// Handle Update Employee
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_employee'])) {
    $id = $_POST['id'];
    $first_name = $_POST['first_name'];
    $middle_name = $_POST['middle_name'];
    $last_name = $_POST['last_name'];
    $address = $_POST['address'];
    $contact_num = $_POST['contact_num'];
    $position = $_POST['position'];
    $email = $_POST['email'];
    $gender = $_POST['gender'];
    $civil_status = $_POST['civil_status'];
    $date_hired = $_POST['date_hired'];
    $monthly_salary = $_POST['monthly_salary'];
    $dob = $_POST['dob'];
    $sss_number = $_POST['sss_number'] ?? '';
    $pagibig_number = $_POST['pagibig_number'] ?? '';
    $tin_number = $_POST['tin_number'] ?? '';
    $philhealth_number = $_POST['philhealth_number'] ?? '';

    $sql = "UPDATE employees SET first_name='$first_name', middle_name='$middle_name', last_name='$last_name', address='$address', 
            contact_num='$contact_num', position='$position', email='$email', gender='$gender', civil_status='$civil_status', 
            date_hired='$date_hired', monthly_salary='$monthly_salary', dob='$dob', sss_number='$sss_number', 
            pagibig_number='$pagibig_number', tin_number='$tin_number', philhealth_number='$philhealth_number' 
            WHERE id=$id";

    $conn->query($sql);
    echo "<script>alert('Employee updated successfully!'); window.location.href='employee.php';</script>";
    exit();
}

// First, check if the new columns exist in the table, if not add them
$check_columns = $conn->query("SHOW COLUMNS FROM employees LIKE 'sss_number'");
if ($check_columns->num_rows == 0) {
    // Add the new columns if they don't exist
    $alter_sql = "ALTER TABLE employees 
                  ADD COLUMN sss_number VARCHAR(50) NULL,
                  ADD COLUMN pagibig_number VARCHAR(50) NULL,
                  ADD COLUMN tin_number VARCHAR(50) NULL,
                  ADD COLUMN philhealth_number VARCHAR(50) NULL";
    $conn->query($alter_sql);
}

// Fetch employees based on search query
$search_query = "";
if (isset($_GET['search'])) {
    $search_query = $conn->real_escape_string($_GET['search']);
    $result = $conn->query("SELECT * FROM employees WHERE 
                            first_name LIKE '%$search_query%' OR 
                            middle_name LIKE '%$search_query%' OR 
                            last_name LIKE '%$search_query%' OR
                            id LIKE '%$search_query%' OR
                            position LIKE '%$search_query%'");
} else {
    $result = $conn->query("SELECT * FROM employees ORDER BY id DESC");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Management</title>
    <link rel="stylesheet" href="./assets/css/employee2.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* Fix for content positioning with new header */
        :root {
            --header-height: 220px;
        }
        
        .content {
            margin-left: 0 !important; /* Remove sidebar margin */
            width: 100% !important; /* Full width */
            padding-top: var(--header-height) !important;
            padding: 20px;
            height: auto !important;
            min-height: calc(100vh - 120px);
            overflow-y: auto;
            background-color: #f8fff8;
            position: relative;
        }
        
        .content-wrapper {
            min-height: calc(100vh - 250px);
        }
        
        /* Fix for controls container */
        .controls-container {
            margin-top: 10px;
            margin-bottom: 20px;
        }
        
        /* Status badge styling */
        .status-badge {
            padding: 4px 10px;
            border-radius: 15px;
            font-size: 0.8rem;
            font-weight: 600;
            text-transform: uppercase;
            display: inline-flex;
            align-items: center;
            gap: 5px;
        }
        
        .status-active {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .status-inactive {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        /* Action buttons */
        .action-buttons {
            display: flex;
            gap: 8px;
            align-items: center;
            flex-wrap: wrap;
        }
        
        .action-btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 32px;
            height: 32px;
            border-radius: var(--border-radius);
            border: none;
            cursor: pointer;
            transition: var(--transition);
            text-decoration: none;
            color: white;
            flex-shrink: 0;
        }
        
        .view-btn {
            background-color: #2196F3;
        }
        
        .view-btn:hover {
            background-color: #1976D2;
        }
        
        .edit-btn {
            background-color: var(--warning-color);
        }
        
        .edit-btn:hover {
            background-color: #e67e22;
        }
        
        .toggle-status-btn {
            background-color: var(--info-color);
            color: white;
            border: none;
            padding: 6px 12px;
            border-radius: var(--border-radius);
            font-size: 0.85rem;
            font-weight: 500;
            cursor: pointer;
            transition: var(--transition);
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 5px;
            white-space: nowrap;
            flex-shrink: 0;
        }
        
        .toggle-status-btn:hover {
            background-color: #0b7dda;
            transform: translateY(-1px);
        }
        
        .toggle-status-btn.inactive {
            background-color: #6c757d;
        }
        
        .toggle-status-btn.inactive:hover {
            background-color: #5a6268;
        }
        
        /* Employee info in table */
        .employee-info {
            display: grid;
            gap: 6px;
        }
        
        .employee-info div {
            font-size: 0.9rem;
            line-height: 1.4;
        }
        
        .employee-info strong {
            color: var(--sidebar-dark-green);
            font-weight: 600;
            min-width: 100px;
            display: inline-block;
        }
        
        /* Modal improvements */
        .modal-header {
            background-color: var(--sidebar-green);
            color: white;
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-radius: var(--border-radius) var(--border-radius) 0 0;
        }
        
        .modal-header h3 {
            margin: 0;
            font-size: 1.3rem;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .modal-close {
            background: none;
            border: none;
            color: white;
            font-size: 1.5rem;
            cursor: pointer;
            transition: var(--transition);
            padding: 0;
            width: 30px;
            height: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .modal-close:hover {
            color: var(--light-green);
            background: rgba(255, 255, 255, 0.1);
            border-radius: 50%;
        }
        
        /* Form improvements */
        .employee-form {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }
        
        .form-section {
            display: grid;
            gap: 12px;
        }
        
        .form-section h4 {
            color: var(--sidebar-dark-green);
            margin-bottom: 5px;
            font-size: 1rem;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        /* Government ID section */
        .govt-id-section {
            grid-column: 1 / -1;
            margin-top: 10px;
            padding: 15px;
            background-color: #f8fff8;
            border-radius: var(--border-radius);
            border: 1px solid #e0e0e0;
        }
        
        .govt-id-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 15px;
            margin-top: 10px;
        }
        
        @media (max-width: 768px) {
            .govt-id-grid {
                grid-template-columns: 1fr;
            }
            
            .content {
                padding-top: 180px !important;
            }
        }
        
        /* Empty state */
        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: #7f8c8d;
        }
        
        .empty-state i {
            font-size: 2.5rem;
            color: #C8E6C9;
            margin-bottom: 10px;
        }
        
        .empty-state p {
            font-size: 1rem;
        }
        
        /* Responsive table */
        @media (max-width: 768px) {
            .content {
                padding-top: 180px !important;
            }
            
            .employee-table {
                display: block;
                overflow-x: auto;
            }
            
            .employee-table th,
            .employee-table td {
                padding: 10px;
                font-size: 0.85rem;
            }
            
            .action-buttons {
                flex-direction: column;
                align-items: stretch;
                gap: 6px;
            }
            
            .action-btn, .toggle-status-btn {
                width: 100%;
                justify-content: center;
                height: 36px;
            }
            
            .employee-form {
                grid-template-columns: 1fr;
            }
        }
        
        /* Ensure modal doesn't exceed viewport */
        .modal-open {
            overflow: hidden;
        }
        
        /* Information badges in view modal */
        .govt-id-badge {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 6px 12px;
            background-color: #e3f2fd;
            border-radius: var(--border-radius);
            font-size: 0.85rem;
            margin: 3px;
        }
        
        .govt-id-badge i {
            color: var(--info-color);
        }
        
        .govt-id-container {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-top: 10px;
        }
        
        /* Adjust for footer */
        .content {
            padding-bottom: 80px;
        }
    </style>
</head>
<body>
    <!-- Header with Navigation -->
    <?php include_once("./includes/header.php"); ?>

    <main class="content">
        <div class="content-wrapper">
            <!-- Controls Container with Search and Add Button -->
            <div class="controls-container">
                <div class="search-section">
                    <div class="search-container">
                        <form method="GET" action="employee.php" style="display: flex; align-items: center; width: 100%;">
                            <input type="text" name="search" 
                                   value="<?php echo htmlspecialchars($search_query); ?>" 
                                   placeholder="Search employees by name, ID, or position..." 
                                   class="search-bar">
                            <button type="submit" class="search-btn">
                                <i class="fas fa-search"></i>
                            </button>
                        </form>
                    </div>
                </div>
                
                <button class="add-employee-btn" onclick="showAddEmployeeModal()">
                    <i class="fas fa-user-plus"></i>
                    Add Employee
                </button>
            </div>

            <!-- Employee Table -->
            <div class="table-responsive">
                <div class="employee-table-container">
                    <table class="employee-table">
                        <thead>
                            <tr>
                                <th>Employee Information</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php if ($result && $result->num_rows > 0): ?>
                            <?php while ($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td>
                                    <div class="employee-info">
                                        <div><strong>Name:</strong> <?php echo htmlspecialchars($row['first_name'] . ' ' . $row['last_name']); ?></div>
                                        <div><strong>ID:</strong> <?php echo $row['id']; ?></div>
                                        <div><strong>Position:</strong> <?php echo htmlspecialchars($row['position']); ?></div>
                                        <div><strong>Contact:</strong> <?php echo htmlspecialchars($row['contact_num']); ?></div>
                                        <div><strong>Email:</strong> <?php echo htmlspecialchars($row['email']); ?></div>
                                        <?php if (!empty($row['sss_number']) || !empty($row['pagibig_number']) || !empty($row['tin_number']) || !empty($row['philhealth_number'])): ?>
                                        <div><strong>Gov't IDs:</strong> 
                                            <?php 
                                            $govt_ids = [];
                                            if (!empty($row['sss_number'])) $govt_ids[] = 'SSS';
                                            if (!empty($row['pagibig_number'])) $govt_ids[] = 'PAG-IBIG';
                                            if (!empty($row['tin_number'])) $govt_ids[] = 'TIN';
                                            if (!empty($row['philhealth_number'])) $govt_ids[] = 'PhilHealth';
                                            echo implode(', ', $govt_ids);
                                            ?>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                </td>
                                <td>
                                    <span class="status-badge <?php echo ($row['status'] ?? 'active') == 'active' ? 'status-active' : 'status-inactive'; ?>">
                                        <i class="fas fa-circle" style="font-size: 0.6rem;"></i>
                                        <?php echo ucfirst($row['status'] ?? 'active'); ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="action-buttons">
                                        <button class='action-btn view-btn' 
                                                onclick='showViewEmployeeModal(<?php echo $row['id']; ?>)'
                                                title="View Details">
                                            <i class="fas fa-eye"></i>
                                        </button>

                                        <button class='action-btn edit-btn' 
                                                onclick='showEditEmployeeModal(<?php echo $row['id']; ?>)'
                                                title="Edit">
                                            <i class="fas fa-edit"></i>
                                        </button>

                                        <a href='employee.php?toggle_status=1&employee_id=<?php echo $row['id']; ?>&status=<?php echo $row['status'] ?? 'active'; ?>' 
                                           class='toggle-status-btn <?php echo ($row['status'] ?? 'active') == 'active' ? '' : 'inactive'; ?>' 
                                           onclick='return confirmToggleStatus(event, "<?php echo $row['first_name'] . ' ' . $row['last_name']; ?>", "<?php echo $row['status'] ?? 'active'; ?>")'
                                           title="<?php echo ($row['status'] ?? 'active') == 'active' ? 'Disable' : 'Enable'; ?> Employee">
                                            <i class="fas <?php echo ($row['status'] ?? 'active') == 'active' ? 'fa-user-slash' : 'fa-user-check'; ?>"></i>
                                            <?php echo ($row['status'] ?? 'active') == 'active' ? 'Disable' : 'Enable'; ?>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="3">
                                    <div class="empty-state">
                                        <i class="fas fa-users"></i>
                                        <p>No employees found</p>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>

    <!-- Footer -->
    <?php include_once("./includes/footer.php"); ?>
    
    <?php include_once("./modal/logout-modal.php"); ?>

    <!-- Add Employee Modal -->
    <div id="addEmployeeModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-user-plus"></i> Add New Employee</h3>
                <button class="modal-close" onclick="closeAddEmployeeModal()">&times;</button>
            </div>
            <form method="POST" action="employee.php">
                <div class="modal-body">
                    <div class="employee-form">
                        <div class="form-section">
                            <h4><i class="fas fa-user"></i> Personal Information</h4>
                            <div class="form-group">
                                <label for="first_name">First Name *</label>
                                <input type="text" id="first_name" name="first_name" 
                                       required placeholder="Enter first name" 
                                       autocomplete="off">
                            </div>
                            <div class="form-group">
                                <label for="middle_name">Middle Name</label>
                                <input type="text" id="middle_name" name="middle_name" 
                                       placeholder="Enter middle name" 
                                       autocomplete="off">
                            </div>
                            <div class="form-group">
                                <label for="last_name">Last Name *</label>
                                <input type="text" id="last_name" name="last_name" 
                                       required placeholder="Enter last name" 
                                       autocomplete="off">
                            </div>
                            <div class="form-group">
                                <label for="dob">Date of Birth *</label>
                                <input type="date" id="dob" name="dob" required>
                            </div>
                            <div class="form-group">
                                <label for="gender">Gender *</label>
                                <select id="gender" name="gender" required>
                                    <option value="" disabled selected>Select gender</option>
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="civil_status">Civil Status *</label>
                                <select id="civil_status" name="civil_status" required>
                                    <option value="" disabled selected>Select civil status</option>
                                    <option value="Single">Single</option>
                                    <option value="Married">Married</option>
                                    <option value="Widowed">Widowed</option>
                                    <option value="Separated">Separated</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="form-section">
                            <h4><i class="fas fa-briefcase"></i> Employment Details</h4>
                            <div class="form-group">
                                <label for="position">Position *</label>
                                <input type="text" id="position" name="position" 
                                       required placeholder="Enter position" 
                                       autocomplete="off">
                            </div>
                            <div class="form-group">
                                <label for="date_hired">Date Hired *</label>
                                <input type="date" id="date_hired" name="date_hired" required>
                            </div>
                            <div class="form-group">
                                <label for="monthly_salary">Monthly Salary *</label>
                                <input type="number" id="monthly_salary" name="monthly_salary" 
                                       required placeholder="Enter monthly salary" 
                                       autocomplete="off" step="0.01">
                            </div>
                            <div class="form-group">
                                <label for="email">Email Address *</label>
                                <input type="email" id="email" name="email" 
                                       required placeholder="Enter email address" 
                                       autocomplete="off">
                            </div>
                            <div class="form-group">
                                <label for="contact_num">Contact Number *</label>
                                <input type="text" id="contact_num" name="contact_num" 
                                       required placeholder="Enter contact number" 
                                       autocomplete="off">
                            </div>
                            <div class="form-group">
                                <label for="address">Address *</label>
                                <input type="text" id="address" name="address" 
                                       required placeholder="Enter address" 
                                       autocomplete="off">
                            </div>
                        </div>
                        
                        <div class="govt-id-section">
                            <h4><i class="fas fa-id-card"></i> Government Identification Numbers</h4>
                            <p style="color: #666; font-size: 0.9rem; margin-bottom: 15px;">Optional: Provide government identification numbers for payroll processing</p>
                            <div class="govt-id-grid">
                                <div class="form-group">
                                    <label for="sss_number">SSS Number</label>
                                    <input type="text" id="sss_number" name="sss_number" 
                                           placeholder="XX-XXXXXXX-X" 
                                           pattern="[0-9]{2}-[0-9]{7}-[0-9]{1}"
                                           title="Format: XX-XXXXXXX-X"
                                           autocomplete="off">
                                    <small style="color: #888; font-size: 0.8rem;">Format: XX-XXXXXXX-X</small>
                                </div>
                                <div class="form-group">
                                    <label for="pagibig_number">PAG-IBIG Number</label>
                                    <input type="text" id="pagibig_number" name="pagibig_number" 
                                           placeholder="XXXX-XXXX-XXXX" 
                                           pattern="[0-9]{4}-[0-9]{4}-[0-9]{4}"
                                           title="Format: XXXX-XXXX-XXXX"
                                           autocomplete="off">
                                    <small style="color: #888; font-size: 0.8rem;">Format: XXXX-XXXX-XXXX</small>
                                </div>
                                <div class="form-group">
                                    <label for="tin_number">TIN Number</label>
                                    <input type="text" id="tin_number" name="tin_number" 
                                           placeholder="XXX-XXX-XXX-XXX" 
                                           pattern="[0-9]{3}-[0-9]{3}-[0-9]{3}-[0-9]{3}"
                                           title="Format: XXX-XXX-XXX-XXX"
                                           autocomplete="off">
                                    <small style="color: #888; font-size: 0.8rem;">Format: XXX-XXX-XXX-XXX</small>
                                </div>
                                <div class="form-group">
                                    <label for="philhealth_number">PhilHealth Number</label>
                                    <input type="text" id="philhealth_number" name="philhealth_number" 
                                           placeholder="XX-XXXXXXXXX-X" 
                                           pattern="[0-9]{2}-[0-9]{9}-[0-9]{1}"
                                           title="Format: XX-XXXXXXXXX-X"
                                           autocomplete="off">
                                    <small style="color: #888; font-size: 0.8rem;">Format: XX-XXXXXXXXX-X</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-cancel" onclick="closeAddEmployeeModal()">Cancel</button>
                    <button type="submit" name="save_employee" class="btn btn-save">Save Employee</button>
                </div>
            </form>
        </div>
    </div>

    <!-- View Employee Modal -->
    <div id="viewEmployeeModal" class="modal" style="<?= isset($_GET['view']) ? 'display: flex;' : 'display: none;' ?>">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-user"></i> Employee Details</h3>
                <button class="modal-close" onclick="closeViewEmployeeModal()">&times;</button>
            </div>
            <div class="modal-body">
                <?php if (isset($employee)): ?>
                <div class="employee-details">
                    <div class="form-section">
                        <h4><i class="fas fa-id-card"></i> Personal Information</h4>
                        <div class="form-group">
                            <label>Full Name:</label>
                            <p><?= htmlspecialchars($employee['first_name'] . ' ' . ($employee['middle_name'] ? $employee['middle_name'] . ' ' : '') . $employee['last_name']) ?></p>
                        </div>
                        <div class="form-group">
                            <label>Date of Birth:</label>
                            <p><?= htmlspecialchars($employee['dob']) ?></p>
                        </div>
                        <div class="form-group">
                            <label>Gender:</label>
                            <p><?= htmlspecialchars($employee['gender']) ?></p>
                        </div>
                        <div class="form-group">
                            <label>Civil Status:</label>
                            <p><?= htmlspecialchars($employee['civil_status']) ?></p>
                        </div>
                        <div class="form-group">
                            <label>Address:</label>
                            <p><?= htmlspecialchars($employee['address']) ?></p>
                        </div>
                    </div>
                    
                    <div class="form-section">
                        <h4><i class="fas fa-briefcase"></i> Employment Details</h4>
                        <div class="form-group">
                            <label>Employee ID:</label>
                            <p><?= $employee['id'] ?></p>
                        </div>
                        <div class="form-group">
                            <label>Position:</label>
                            <p><?= htmlspecialchars($employee['position']) ?></p>
                        </div>
                        <div class="form-group">
                            <label>Date Hired:</label>
                            <p><?= htmlspecialchars($employee['date_hired']) ?></p>
                        </div>
                        <div class="form-group">
                            <label>Monthly Salary:</label>
                            <p>₱<?= number_format($employee['monthly_salary'], 2) ?></p>
                        </div>
                        <div class="form-group">
                            <label>Email:</label>
                            <p><?= htmlspecialchars($employee['email']) ?></p>
                        </div>
                        <div class="form-group">
                            <label>Contact Number:</label>
                            <p><?= htmlspecialchars($employee['contact_num']) ?></p>
                        </div>
                        <div class="form-group">
                            <label>Status:</label>
                            <p><span class="status-badge <?php echo ($employee['status'] ?? 'active') == 'active' ? 'status-active' : 'status-inactive'; ?>">
                                <i class="fas fa-circle" style="font-size: 0.6rem;"></i>
                                <?php echo ucfirst($employee['status'] ?? 'active'); ?>
                            </span></p>
                        </div>
                    </div>
                    
                    <!-- Government IDs Section -->
                    <?php if (!empty($employee['sss_number']) || !empty($employee['pagibig_number']) || !empty($employee['tin_number']) || !empty($employee['philhealth_number'])): ?>
                    <div class="form-section" style="grid-column: 1 / -1;">
                        <h4><i class="fas fa-id-card"></i> Government Identification Numbers</h4>
                        <div class="govt-id-container">
                            <?php if (!empty($employee['sss_number'])): ?>
                            <div class="govt-id-badge">
                                <i class="fas fa-shield-alt"></i>
                                <div>
                                    <strong>SSS:</strong> <?= htmlspecialchars($employee['sss_number']) ?>
                                </div>
                            </div>
                            <?php endif; ?>
                            
                            <?php if (!empty($employee['pagibig_number'])): ?>
                            <div class="govt-id-badge">
                                <i class="fas fa-home"></i>
                                <div>
                                    <strong>PAG-IBIG:</strong> <?= htmlspecialchars($employee['pagibig_number']) ?>
                                </div>
                            </div>
                            <?php endif; ?>
                            
                            <?php if (!empty($employee['tin_number'])): ?>
                            <div class="govt-id-badge">
                                <i class="fas fa-file-invoice-dollar"></i>
                                <div>
                                    <strong>TIN:</strong> <?= htmlspecialchars($employee['tin_number']) ?>
                                </div>
                            </div>
                            <?php endif; ?>
                            
                            <?php if (!empty($employee['philhealth_number'])): ?>
                            <div class="govt-id-badge">
                                <i class="fas fa-heartbeat"></i>
                                <div>
                                    <strong>PhilHealth:</strong> <?= htmlspecialchars($employee['philhealth_number']) ?>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-cancel" onclick="closeViewEmployeeModal()">Close</button>
            </div>
        </div>
    </div>

    <!-- Edit Employee Modal -->
    <div id="editEmployeeModal" class="modal" style="<?= isset($_GET['edit']) ? 'display: flex;' : 'display: none;' ?>">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-edit"></i> Edit Employee</h3>
                <button class="modal-close" onclick="closeEditEmployeeModal()">&times;</button>
            </div>
            <form method="POST" action="employee.php">
                <input type="hidden" name="id" value="<?= $employee_edit['id'] ?? '' ?>">
                
                <div class="modal-body">
                    <div class="employee-form">
                        <div class="form-section">
                            <h4><i class="fas fa-user"></i> Personal Information</h4>
                            <div class="form-group">
                                <label for="edit_first_name">First Name *</label>
                                <input type="text" id="edit_first_name" name="first_name" 
                                       value="<?= $employee_edit['first_name'] ?? '' ?>" 
                                       required placeholder="Enter first name" 
                                       autocomplete="off">
                            </div>
                            <div class="form-group">
                                <label for="edit_middle_name">Middle Name</label>
                                <input type="text" id="edit_middle_name" name="middle_name" 
                                       value="<?= $employee_edit['middle_name'] ?? '' ?>" 
                                       placeholder="Enter middle name" 
                                       autocomplete="off">
                            </div>
                            <div class="form-group">
                                <label for="edit_last_name">Last Name *</label>
                                <input type="text" id="edit_last_name" name="last_name" 
                                       value="<?= $employee_edit['last_name'] ?? '' ?>" 
                                       required placeholder="Enter last name" 
                                       autocomplete="off">
                            </div>
                            <div class="form-group">
                                <label for="edit_dob">Date of Birth *</label>
                                <input type="date" id="edit_dob" name="dob" 
                                       value="<?= $employee_edit['dob'] ?? '' ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="edit_gender">Gender *</label>
                                <select id="edit_gender" name="gender" required>
                                    <option value="Male" <?= ($employee_edit['gender'] ?? '') == 'Male' ? 'selected' : '' ?>>Male</option>
                                    <option value="Female" <?= ($employee_edit['gender'] ?? '') == 'Female' ? 'selected' : '' ?>>Female</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="edit_civil_status">Civil Status *</label>
                                <select id="edit_civil_status" name="civil_status" required>
                                    <option value="Single" <?= ($employee_edit['civil_status'] ?? '') == 'Single' ? 'selected' : '' ?>>Single</option>
                                    <option value="Married" <?= ($employee_edit['civil_status'] ?? '') == 'Married' ? 'selected' : '' ?>>Married</option>
                                    <option value="Widowed" <?= ($employee_edit['civil_status'] ?? '') == 'Widowed' ? 'selected' : '' ?>>Widowed</option>
                                    <option value="Separated" <?= ($employee_edit['civil_status'] ?? '') == 'Separated' ? 'selected' : '' ?>>Separated</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="form-section">
                            <h4><i class="fas fa-briefcase"></i> Employment Details</h4>
                            <div class="form-group">
                                <label for="edit_position">Position *</label>
                                <input type="text" id="edit_position" name="position" 
                                       value="<?= $employee_edit['position'] ?? '' ?>" 
                                       required placeholder="Enter position" 
                                       autocomplete="off">
                            </div>
                            <div class="form-group">
                                <label for="edit_date_hired">Date Hired *</label>
                                <input type="date" id="edit_date_hired" name="date_hired" 
                                       value="<?= $employee_edit['date_hired'] ?? '' ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="edit_monthly_salary">Monthly Salary *</label>
                                <input type="number" id="edit_monthly_salary" name="monthly_salary" 
                                       value="<?= $employee_edit['monthly_salary'] ?? '' ?>" 
                                       required placeholder="Enter monthly salary" 
                                       autocomplete="off" step="0.01">
                            </div>
                            <div class="form-group">
                                <label for="edit_email">Email Address *</label>
                                <input type="email" id="edit_email" name="email" 
                                       value="<?= $employee_edit['email'] ?? '' ?>" 
                                       required placeholder="Enter email address" 
                                       autocomplete="off">
                            </div>
                            <div class="form-group">
                                <label for="edit_contact_num">Contact Number *</label>
                                <input type="text" id="edit_contact_num" name="contact_num" 
                                       value="<?= $employee_edit['contact_num'] ?? '' ?>" 
                                       required placeholder="Enter contact number" 
                                       autocomplete="off">
                            </div>
                            <div class="form-group">
                                <label for="edit_address">Address *</label>
                                <input type="text" id="edit_address" name="address" 
                                       value="<?= $employee_edit['address'] ?? '' ?>" 
                                       required placeholder="Enter address" 
                                       autocomplete="off">
                            </div>
                        </div>
                        
                        <div class="govt-id-section">
                            <h4><i class="fas fa-id-card"></i> Government Identification Numbers</h4>
                            <p style="color: #666; font-size: 0.9rem; margin-bottom: 15px;">Optional: Provide government identification numbers for payroll processing</p>
                            <div class="govt-id-grid">
                                <div class="form-group">
                                    <label for="edit_sss_number">SSS Number</label>
                                    <input type="text" id="edit_sss_number" name="sss_number" 
                                           value="<?= $employee_edit['sss_number'] ?? '' ?>" 
                                           placeholder="XX-XXXXXXX-X" 
                                           pattern="[0-9]{2}-[0-9]{7}-[0-9]{1}"
                                           title="Format: XX-XXXXXXX-X"
                                           autocomplete="off">
                                    <small style="color: #888; font-size: 0.8rem;">Format: XX-XXXXXXX-X</small>
                                </div>
                                <div class="form-group">
                                    <label for="edit_pagibig_number">PAG-IBIG Number</label>
                                    <input type="text" id="edit_pagibig_number" name="pagibig_number" 
                                           value="<?= $employee_edit['pagibig_number'] ?? '' ?>" 
                                           placeholder="XXXX-XXXX-XXXX" 
                                           pattern="[0-9]{4}-[0-9]{4}-[0-9]{4}"
                                           title="Format: XXXX-XXXX-XXXX"
                                           autocomplete="off">
                                    <small style="color: #888; font-size: 0.8rem;">Format: XXXX-XXXX-XXXX</small>
                                </div>
                                <div class="form-group">
                                    <label for="edit_tin_number">TIN Number</label>
                                    <input type="text" id="edit_tin_number" name="tin_number" 
                                           value="<?= $employee_edit['tin_number'] ?? '' ?>" 
                                           placeholder="XXX-XXX-XXX-XXX" 
                                           pattern="[0-9]{3}-[0-9]{3}-[0-9]{3}-[0-9]{3}"
                                           title="Format: XXX-XXX-XXX-XXX"
                                           autocomplete="off">
                                    <small style="color: #888; font-size: 0.8rem;">Format: XXX-XXX-XXX-XXX</small>
                                </div>
                                <div class="form-group">
                                    <label for="edit_philhealth_number">PhilHealth Number</label>
                                    <input type="text" id="edit_philhealth_number" name="philhealth_number" 
                                           value="<?= $employee_edit['philhealth_number'] ?? '' ?>" 
                                           placeholder="XX-XXXXXXXXX-X" 
                                           pattern="[0-9]{2}-[0-9]{9}-[0-9]{1}"
                                           title="Format: XX-XXXXXXXXX-X"
                                           autocomplete="off">
                                    <small style="color: #888; font-size: 0.8rem;">Format: XX-XXXXXXXXX-X</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-cancel" onclick="closeEditEmployeeModal()">Cancel</button>
                    <button type="submit" name="update_employee" class="btn btn-save">Update Employee</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        // Add Employee Modal functions
        function showAddEmployeeModal() {
            document.getElementById('addEmployeeModal').style.display = 'flex';
            document.body.classList.add('modal-open');
            document.getElementById('first_name').focus();
        }

        function closeAddEmployeeModal() {
            document.getElementById('addEmployeeModal').style.display = 'none';
            document.body.classList.remove('modal-open');
            // Clear form fields
            const form = document.querySelector('#addEmployeeModal form');
            if (form) form.reset();
        }

        // View Employee Modal functions
        function showViewEmployeeModal(employeeId) {
            window.location.href = 'employee.php?view=' + employeeId;
        }

        function closeViewEmployeeModal() {
            window.location.href = 'employee.php';
        }

        // Edit Employee Modal functions
        function showEditEmployeeModal(employeeId) {
            window.location.href = 'employee.php?edit=' + employeeId;
        }

        function closeEditEmployeeModal() {
            window.location.href = 'employee.php';
        }
        
        // Toggle status confirmation
        function confirmToggleStatus(event, employeeName, currentStatus) {
            const action = currentStatus === 'active' ? 'disable' : 'enable';
            const message = `Are you sure you want to ${action} employee "${employeeName}"?\n\n` +
                           `This will ${action} their account and remove them from any assigned branches.`;
            
            if (!confirm(message)) {
                event.preventDefault();
                return false;
            }
            return true;
        }

        // Close modal when clicking outside
        window.onclick = function(event) {
            const addModal = document.getElementById('addEmployeeModal');
            const viewModal = document.getElementById('viewEmployeeModal');
            const editModal = document.getElementById('editEmployeeModal');
            
            if (event.target === addModal) closeAddEmployeeModal();
            if (event.target === viewModal) closeViewEmployeeModal();
            if (event.target === editModal) closeEditEmployeeModal();
        }

        // Close modal with Escape key
        document.addEventListener('keydown', function(event) {
            if (event.key === 'Escape') {
                closeAddEmployeeModal();
                closeViewEmployeeModal();
                closeEditEmployeeModal();
            }
        });

        // Auto-open modals if URL parameters exist
        document.addEventListener('DOMContentLoaded', function() {
            const urlParams = new URLSearchParams(window.location.search);
            if (urlParams.has('view') || urlParams.has('edit')) {
                document.body.classList.add('modal-open');
            }
            
            // Format input masks for government IDs
            const sssInput = document.getElementById('sss_number');
            const pagibigInput = document.getElementById('pagibig_number');
            const tinInput = document.getElementById('tin_number');
            const philhealthInput = document.getElementById('philhealth_number');
            
            function formatSSS(input) {
                let value = input.value.replace(/\D/g, '');
                if (value.length > 0) {
                    value = value.substring(0, 2) + (value.length > 2 ? '-' + value.substring(2, 9) : '') + 
                           (value.length > 9 ? '-' + value.substring(9, 10) : '');
                }
                input.value = value;
            }
            
            function formatPagibig(input) {
                let value = input.value.replace(/\D/g, '');
                if (value.length > 0) {
                    value = value.substring(0, 4) + (value.length > 4 ? '-' + value.substring(4, 8) : '') + 
                           (value.length > 8 ? '-' + value.substring(8, 12) : '');
                }
                input.value = value;
            }
            
            function formatTIN(input) {
                let value = input.value.replace(/\D/g, '');
                if (value.length > 0) {
                    value = value.substring(0, 3) + (value.length > 3 ? '-' + value.substring(3, 6) : '') + 
                           (value.length > 6 ? '-' + value.substring(6, 9) : '') + 
                           (value.length > 9 ? '-' + value.substring(9, 12) : '');
                }
                input.value = value;
            }
            
            function formatPhilhealth(input) {
                let value = input.value.replace(/\D/g, '');
                if (value.length > 0) {
                    value = value.substring(0, 2) + (value.length > 2 ? '-' + value.substring(2, 11) : '') + 
                           (value.length > 11 ? '-' + value.substring(11, 12) : '');
                }
                input.value = value;
            }
            
            if (sssInput) sssInput.addEventListener('input', function() { formatSSS(this); });
            if (pagibigInput) pagibigInput.addEventListener('input', function() { formatPagibig(this); });
            if (tinInput) tinInput.addEventListener('input', function() { formatTIN(this); });
            if (philhealthInput) philhealthInput.addEventListener('input', function() { formatPhilhealth(this); });
        });
    </script>
</body>
</html>