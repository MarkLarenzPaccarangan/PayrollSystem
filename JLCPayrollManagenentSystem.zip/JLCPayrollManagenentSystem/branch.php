<?php 
session_start();

if (!isset($_SESSION['Admin_User'])) {
    header("Location: login.php"); 
    exit;
}

include 'connection.php';

// Save branch to database
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Add new branch
    if (isset($_POST['save_branch'])) {
        $branch_name = $_POST['branch_name'];
        $manager = $_POST['department_manager'];
        $address = $_POST['department_address'];

        $query = "INSERT INTO branch (branch_name, department_manager, department_address) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("sss", $branch_name, $manager, $address);

        if ($stmt->execute()) {
            echo "<script>alert('Branch added successfully!'); window.location.href='branch.php';</script>";
        } else {
            echo "<script>alert('Error adding branch: " . $conn->error . "');</script>";
        }
    }
    
    // Update branch information
    if (isset($_POST['update_branch'])) {
        $branch_id = $_POST['branch_id'];
        $branch_name = $_POST['edit_branch_name'];
        $manager = $_POST['edit_department_manager'];
        $address = $_POST['edit_department_address'];
        
        // Update branch details
        $query = "UPDATE branch SET branch_name = ?, department_manager = ?, department_address = ? WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("sssi", $branch_name, $manager, $address, $branch_id);
        
        if ($stmt->execute()) {
            // Remove selected employees if any
            if (isset($_POST['remove_employees']) && !empty($_POST['remove_employees'])) {
                foreach ($_POST['remove_employees'] as $employee_id) {
                    $delete_query = "DELETE FROM branch_employee WHERE branch_id = ? AND employee_id = ?";
                    $delete_stmt = $conn->prepare($delete_query);
                    $delete_stmt->bind_param("ii", $branch_id, $employee_id);
                    $delete_stmt->execute();
                }
            }
            echo "<script>alert('Branch updated successfully!'); window.location.href='branch.php';</script>";
        } else {
            echo "<script>alert('Error updating branch: " . $conn->error . "');</script>";
        }
    }
    
    // Add employees to branch
    if (isset($_POST['add_employees_to_branch'])) {
        $branch_id = $_POST['add_branch_id'];
        
        if (isset($_POST['selected_employees']) && !empty($_POST['selected_employees'])) {
            $success_count = 0;
            $error_count = 0;
            
            foreach ($_POST['selected_employees'] as $employee_id) {
                // Check if employee is already assigned to this branch
                $check_query = "SELECT * FROM branch_employee WHERE branch_id = ? AND employee_id = ?";
                $check_stmt = $conn->prepare($check_query);
                $check_stmt->bind_param("ii", $branch_id, $employee_id);
                $check_stmt->execute();
                $check_result = $check_stmt->get_result();
                
                if ($check_result->num_rows == 0) {
                    // Check if assigned_date column exists
                    $table_check = $conn->query("SHOW COLUMNS FROM branch_employee LIKE 'assigned_date'");
                    
                    if ($table_check->num_rows > 0) {
                        $insert_query = "INSERT INTO branch_employee (branch_id, employee_id, assigned_date) VALUES (?, ?, NOW())";
                    } else {
                        $insert_query = "INSERT INTO branch_employee (branch_id, employee_id) VALUES (?, ?)";
                    }
                    
                    $insert_stmt = $conn->prepare($insert_query);
                    $insert_stmt->bind_param("ii", $branch_id, $employee_id);
                    
                    if ($insert_stmt->execute()) {
                        $success_count++;
                    } else {
                        $error_count++;
                    }
                }
            }
            
            if ($success_count > 0) {
                echo "<script>alert('Successfully added " . $success_count . " employee(s) to branch!'); window.location.href='branch.php';</script>";
            } else {
                echo "<script>alert('No new employees were added. They may already be assigned to this branch.'); window.location.href='branch.php';</script>";
            }
        } else {
            echo "<script>alert('Please select at least one employee to add.');</script>";
        }
    }
}

// Delete branch
if (isset($_GET['delete'])) {
    $branch_id = (int)$_GET['delete'];

    $delete_branch_employee = "DELETE FROM branch_employee WHERE branch_id = ?";
    $stmt1 = $conn->prepare($delete_branch_employee);
    $stmt1->bind_param("i", $branch_id);

    if ($stmt1->execute()) {
        $delete_branch = "DELETE FROM branch WHERE id = ?";
        $stmt2 = $conn->prepare($delete_branch);
        $stmt2->bind_param("i", $branch_id);

        if ($stmt2->execute()) {
            echo "<script>alert('Branch deleted successfully!'); window.location.href='branch.php';</script>";
        } else {
            echo "<script>alert('Error deleting branch: " . $conn->error . "');</script>";
        }
    } else {
        echo "<script>alert('Error deleting associated records: " . $conn->error . "');</script>";
    }
}

// Function to get branch employees for view modal
function getBranchEmployees($conn, $branch_id) {
    $employees = [];
    
    // First, check what columns exist in the employees table
    $columns = ['id', 'first_name', 'last_name', 'position'];
    
    // Check if email column exists
    $email_check = $conn->query("SHOW COLUMNS FROM employees LIKE 'email'");
    if ($email_check->num_rows > 0) {
        $columns[] = 'email';
    }
    
    // Build query with only existing columns
    $columns_str = implode(', ', $columns);
    $query = "SELECT $columns_str 
              FROM employees e 
              INNER JOIN branch_employee be ON e.id = be.employee_id 
              WHERE be.branch_id = ?
              ORDER BY e.first_name, e.last_name";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $branch_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while ($row = $result->fetch_assoc()) {
        $employees[] = $row;
    }
    
    return $employees;
}

// Function to get available employees for modal
function getAvailableEmployees($conn, $branch_id) {
    $available_employees = [];
    
    $query = "SELECT e.id, e.first_name, e.last_name, e.position 
              FROM employees e 
              WHERE e.id NOT IN (
                  SELECT employee_id 
                  FROM branch_employee 
                  WHERE branch_id = ?
              )
              ORDER BY e.first_name, e.last_name";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $branch_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while ($row = $result->fetch_assoc()) {
        $available_employees[] = $row;
    }
    
    return $available_employees;
}

// Get branch details for editing
$branch_details = null;
$branch_employees = [];
if (isset($_GET['edit'])) {
    $branch_id = (int)$_GET['edit'];
    
    // Get branch details
    $query = "SELECT * FROM branch WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $branch_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $branch_details = $result->fetch_assoc();
    
    // Get employees assigned to this branch
    $branch_employees = getBranchEmployees($conn, $branch_id);
    
    // Get available employees for add employee modal
    $available_employees = getAvailableEmployees($conn, $branch_id);
}

// Search functionality for branches
$search_query = '';
if (isset($_GET['search']) && !empty($_GET['search'])) {
    $search_query = $_GET['search'];
    $query = "SELECT id, branch_name, department_manager, department_address FROM branch 
              WHERE branch_name LIKE ? OR department_manager LIKE ? OR department_address LIKE ?";
    $stmt = $conn->prepare($query);
    $search_term = '%' . $search_query . '%';
    $stmt->bind_param("sss", $search_term, $search_term, $search_term);
} else {
    $query = "SELECT id, branch_name, department_manager, department_address FROM branch";
    $stmt = $conn->prepare($query);
}
$stmt->execute();
$result = $stmt->get_result();

// Get all branches for add employee modal
$all_branches = [];
$branches_query = "SELECT id, branch_name FROM branch ORDER BY branch_name";
$branches_result = $conn->query($branches_query);
while ($row = $branches_result->fetch_assoc()) {
    $all_branches[] = $row;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Branch Management</title>
    <link rel="stylesheet" href="./assets/css/branch.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* Additional inline styles for better fit */
        .content-wrapper {
            min-height: calc(100vh - 100px);
        }
        
        .table-responsive {
            overflow-x: auto;
        }
        
        /* Ensure modal doesn't exceed viewport */
        .modal-open {
            overflow: hidden;
        }
        
        /* Selected count badge */
        .selected-count {
            background-color: var(--info-color);
            color: white;
            padding: 2px 8px;
            border-radius: 10px;
            font-size: 0.8rem;
            margin-left: 10px;
        }
        
        /* Select All button */
        .select-all-btn {
            background-color: var(--accent-green);
            color: white;
            border: none;
            padding: 6px 12px;
            border-radius: var(--border-radius);
            font-size: 0.85rem;
            cursor: pointer;
            margin-bottom: 10px;
            display: inline-flex;
            align-items: center;
            gap: 5px;
        }
        
        .select-all-btn:hover {
            background-color: var(--sidebar-dark-green);
        }
        
        /* View Modal Header Info */
        .view-modal-header {
            display: flex;
            flex-direction: column;
            gap: 5px;
            margin-top: 5px;
        }
        
        .view-modal-header p {
            margin: 0;
            font-size: 0.9rem;
            color: rgba(255, 255, 255, 0.9);
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .view-modal-header p i {
            width: 16px;
        }
        
        /* Search bar in edit modal */
        .employee-search-container {
            position: relative;
            margin-bottom: 15px;
        }
        
        .employee-search-input {
            width: 100%;
            padding: 8px 35px 8px 12px;
            border: 2px solid #e0e0e0;
            border-radius: var(--border-radius);
            font-size: 0.9rem;
            transition: var(--transition);
        }
        
        .employee-search-input:focus {
            outline: none;
            border-color: var(--accent-green);
            box-shadow: 0 0 0 3px rgba(76, 175, 80, 0.1);
        }
        
        .employee-search-btn {
            position: absolute;
            right: 8px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            color: var(--sidebar-green);
            font-size: 1rem;
            cursor: pointer;
            padding: 5px;
        }
        
        /* No results message */
        .no-results {
            text-align: center;
            padding: 20px;
            color: #7f8c8d;
            font-style: italic;
            font-size: 0.9rem;
        }
        
        /* Employee checkbox list with search */
        .employee-checkbox-list.searchable {
            max-height: 150px;
            overflow-y: auto;
        }
        
        .employee-item.hidden {
            display: none;
        }
    </style>
</head>
<body>
    <!-- Header -->
    <?php include_once("./includes/header.php"); ?>
     
    <!-- Sidebar -->
    
    <main class="content">
        <div class="content-wrapper">
            <div class="content-header">
                
            </div>

            <!-- Controls Container with Search and Add Button -->
            <div class="controls-container">
                <div class="search-section">
                    <div class="search-container">
                        <form method="GET" action="branch.php" style="display: flex; align-items: center; width: 100%;">
                            <input type="text" name="search" 
                                   value="<?php echo htmlspecialchars($search_query); ?>" 
                                   placeholder="Search branches..." 
                                   class="search-bar">
                            <button type="submit" class="search-btn">
                                <i class="fas fa-search"></i>
                            </button>
                        </form>
                    </div>
                </div>
                
                <button class="add-branch-btn" onclick="showAddBranchModal()">
                    <i class="fas fa-plus-circle"></i>
                    Add Branch
                </button>
            </div>

            <!-- Branch Table -->
            <div class="table-responsive">
                <div class="branch-table-container">
                    <table class="branch-table">
                        <thead>
                            <tr>
                                <th>Branch Information</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php if ($result->num_rows > 0): ?>
                            <?php while ($row = $result->fetch_assoc()): 
                                // Get employee count for this branch
                                $employee_count_query = "SELECT COUNT(*) as count FROM branch_employee WHERE branch_id = ?";
                                $count_stmt = $conn->prepare($employee_count_query);
                                $count_stmt->bind_param("i", $row['id']);
                                $count_stmt->execute();
                                $count_result = $count_stmt->get_result();
                                $count_data = $count_result->fetch_assoc();
                                $employee_count = $count_data ? $count_data['count'] : 0;
                            ?>
                            <tr>
                                <td>
                                    <div class="branch-info">
                                        <div><strong>Name:</strong> <?php echo htmlspecialchars($row['branch_name']); ?></div>
                                        <div><strong>Manager:</strong> <?php echo htmlspecialchars($row['department_manager']); ?></div>
                                        <div><strong>Address:</strong> <?php echo htmlspecialchars($row['department_address']); ?></div>
                                        <div><strong>Employees:</strong> <span style="color: var(--info-color); font-weight: 600;"><?php echo $employee_count; ?> assigned</span></div>
                                    </div>
                                </td>
                                <td>
                                    <div class="action-buttons">
                                        <button class='action-btn view-btn' 
                                                onclick='showViewEmployeesModal(<?php echo $row['id']; ?>, "<?php echo htmlspecialchars(addslashes($row['branch_name'])); ?>", "<?php echo htmlspecialchars(addslashes($row['department_manager'])); ?>", "<?php echo htmlspecialchars(addslashes($row['department_address'])); ?>")'
                                                title="View Employees">
                                            <i class="fas fa-eye"></i>
                                        </button>

                                        <a href='branch.php?edit=<?php echo $row['id']; ?>' 
                                           class='action-btn edit-btn' 
                                           title="Edit">
                                            <i class="fas fa-edit"></i>
                                        </a>

                                        <a href='branch.php?delete=<?php echo $row['id']; ?>' 
                                           class='action-btn delete-btn' 
                                           title="Delete"
                                           onclick='return confirm("Delete this branch?");'>
                                            <i class="fas fa-trash-alt"></i>
                                        </a>

                                        <button class='add-employee-btn' 
                                                onclick='showAddEmployeeModal(<?php echo $row['id']; ?>, "<?php echo htmlspecialchars(addslashes($row['branch_name'])); ?>")'
                                                title="Add Employee">
                                            <i class="fas fa-user-plus"></i>
                                            Add Employee
                                        </button>
                                    </div>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="2">
                                    <div class="empty-state">
                                        <i class="fas fa-store-alt"></i>
                                        <p>No branches found</p>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>

    <!-- Footer -->
    <?php include_once("./includes/footer.php"); ?>
    
    <?php include_once("./modal/logout-modal.php"); ?>

    <!-- Add Branch Modal -->
    <div id="addBranchModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-store"></i> Add New Branch</h3>
                <button class="modal-close" onclick="closeAddBranchModal()">&times;</button>
            </div>
            <form method="POST" action="branch.php">
                <div class="modal-body">
                    <div class="branch-form">
                        <div class="form-group">
                            <label for="branch-name">Branch Name *</label>
                            <input type="text" id="branch-name" name="branch_name" 
                                   required placeholder="Enter branch name" 
                                   autocomplete="off">
                        </div>
                        <div class="form-group">
                            <label for="department-manager">Manager *</label>
                            <input type="text" id="department-manager" name="department_manager" 
                                   required placeholder="Enter manager name" 
                                   autocomplete="off">
                        </div>
                        <div class="form-group">
                            <label for="department-address">Address *</label>
                            <input type="text" id="department-address" name="department_address" 
                                   required placeholder="Enter address" 
                                   autocomplete="off">
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-cancel" onclick="closeAddBranchModal()">Cancel</button>
                    <button type="submit" name="save_branch" class="btn btn-save">Save</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Add Employee Modal -->
    <div id="addEmployeeModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-user-plus"></i> Add Employees to Branch</h3>
                <button class="modal-close" onclick="closeAddEmployeeModal()">&times;</button>
            </div>
            <form method="POST" action="branch.php" id="addEmployeeForm">
                <input type="hidden" id="add_branch_id" name="add_branch_id" value="">
                
                <div class="modal-body">
                    <div class="branch-form">
                        <div class="form-group">
                            <label for="branch-select">Select Branch</label>
                            <select id="branch-select" class="form-control" required>
                                <option value="">-- Select a branch --</option>
                                <?php foreach ($all_branches as $branch): ?>
                                <option value="<?php echo $branch['id']; ?>"><?php echo htmlspecialchars($branch['branch_name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="employee-select-section">
                            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                                <h4 style="margin: 0;">
                                    <i class="fas fa-users"></i> Available Employees
                                </h4>
                                <div style="display: flex; align-items: center; gap: 10px;">
                                    <span id="selectedCount" class="selected-count">0 selected</span>
                                    <button type="button" class="select-all-btn" id="selectAllBtn" onclick="selectAllEmployees()">
                                        <i class="fas fa-check"></i> Select All
                                    </button>
                                </div>
                            </div>
                            
                            <div id="employeeSelectList" class="employee-select-list">
                                <div class="no-employees-available">
                                    <i class="fas fa-user-slash"></i>
                                    <p>Select a branch first to see available employees</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-cancel" onclick="closeAddEmployeeModal()">Cancel</button>
                    <button type="submit" name="add_employees_to_branch" class="btn btn-add" id="addEmployeesBtn" disabled>
                        <i class="fas fa-user-plus"></i> Add Selected Employees
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- View Employees Modal -->
    <div id="viewEmployeesModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <div>
                    <h3><i class="fas fa-users"></i> Branch Employees</h3>
                    <div class="view-modal-header">
                        <p id="viewBranchName"></p>
                        <p><i class="fas fa-user-tie"></i> <span id="viewBranchManager"></span></p>
                        <p><i class="fas fa-map-marker-alt"></i> <span id="viewBranchAddress"></span></p>
                    </div>
                </div>
                <button class="modal-close" onclick="closeViewEmployeesModal()">&times;</button>
            </div>
            <div class="modal-body">
                <div id="employeesListContainer">
                    <div class="no-assigned-employees">
                        <i class="fas fa-user-clock"></i>
                        <p>Loading employees...</p>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-cancel" onclick="closeViewEmployeesModal()">Close</button>
            </div>
        </div>
    </div>

    <!-- Edit Branch Modal -->
    <?php if ($branch_details): ?>
    <div id="editBranchModal" class="modal" style="display: flex;">
        <div class="modal-content" style="max-width: 500px;">
            <div class="modal-header">
                <h3><i class="fas fa-edit"></i> Edit Branch</h3>
                <button class="modal-close" onclick="closeEditBranchModal()">&times;</button>
            </div>
            <form method="POST" action="branch.php">
                <input type="hidden" name="branch_id" value="<?php echo $branch_details['id']; ?>">
                
                <div class="modal-body">
                    <div class="branch-form">
                        <div class="form-group">
                            <label for="edit-branch-name">Branch Name *</label>
                            <input type="text" id="edit-branch-name" name="edit_branch_name" 
                                   value="<?php echo htmlspecialchars($branch_details['branch_name']); ?>"
                                   required placeholder="Enter branch name" 
                                   autocomplete="off">
                        </div>
                        <div class="form-group">
                            <label for="edit-department-manager">Manager *</label>
                            <input type="text" id="edit-department-manager" name="edit_department_manager" 
                                   value="<?php echo htmlspecialchars($branch_details['department_manager']); ?>"
                                   required placeholder="Enter manager name" 
                                   autocomplete="off">
                        </div>
                        <div class="form-group">
                            <label for="edit-department-address">Address *</label>
                            <input type="text" id="edit-department-address" name="edit_department_address" 
                                   value="<?php echo htmlspecialchars($branch_details['department_address']); ?>"
                                   required placeholder="Enter address" 
                                   autocomplete="off">
                        </div>
                        
                        <!-- Employee Management Section -->
                        <?php if (!empty($branch_employees)): ?>
                        <div class="employee-list-section">
                            <h4><i class="fas fa-users"></i> Assigned Employees (<?php echo count($branch_employees); ?>)</h4>
                            
                            <div class="remove-employees-section">
                                <h5><i class="fas fa-user-minus"></i> Remove Employees</h5>
                                <p>Select employees to remove from this branch:</p>
                                
                                <!-- Search bar for employees -->
                                <div class="employee-search-container">
                                    <input type="text" 
                                           id="employeeSearch" 
                                           class="employee-search-input" 
                                           placeholder="Search employees by name or ID..." 
                                           onkeyup="searchEmployees()">
                                    <button type="button" class="employee-search-btn">
                                        <i class="fas fa-search"></i>
                                    </button>
                                </div>
                                
                                <div id="employeeCheckboxList" class="employee-checkbox-list searchable">
                                    <?php foreach ($branch_employees as $employee): ?>
                                    <div class="employee-item" data-name="<?php echo strtolower(htmlspecialchars($employee['first_name'] . ' ' . $employee['last_name'])); ?>" data-id="<?php echo $employee['id']; ?>">
                                        <input type="checkbox" 
                                               id="employee_<?php echo $employee['id']; ?>" 
                                               name="remove_employees[]" 
                                               value="<?php echo $employee['id']; ?>">
                                        <label for="employee_<?php echo $employee['id']; ?>">
                                            <div class="employee-info">
                                                <span class="name"><?php echo htmlspecialchars($employee['first_name'] . ' ' . $employee['last_name']); ?></span>
                                                <span class="id">ID: <?php echo $employee['id']; ?> | <?php echo htmlspecialchars($employee['position']); ?></span>
                                            </div>
                                        </label>
                                    </div>
                                    <?php endforeach; ?>
                                </div>
                                <div id="noResultsMessage" class="no-results" style="display: none;">
                                    <i class="fas fa-search"></i>
                                    <p>No employees found matching your search</p>
                                </div>
                            </div>
                            
                            <!-- REMOVED: Add Employee button in edit modal -->
                        </div>
                        <?php else: ?>
                        <div class="employee-list-section">
                            <h4><i class="fas fa-users"></i> Assigned Employees (0)</h4>
                            <div class="no-employees">
                                <i class="fas fa-user-slash"></i>
                                <p>No employees assigned to this branch yet.</p>
                            </div>
                            <!-- REMOVED: Add Employee button in edit modal when no employees -->
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-cancel" onclick="closeEditBranchModal()">Cancel</button>
                    <button type="submit" name="update_branch" class="btn btn-save">Update</button>
                </div>
            </form>
        </div>
    </div>
    <?php endif; ?>

    <script>
        // Add Branch Modal functions
        function showAddBranchModal() {
            document.getElementById('addBranchModal').style.display = 'flex';
            document.body.classList.add('modal-open');
            document.getElementById('branch-name').focus();
        }

        function closeAddBranchModal() {
            document.getElementById('addBranchModal').style.display = 'none';
            document.body.classList.remove('modal-open');
            document.getElementById('branch-name').value = '';
            document.getElementById('department-manager').value = '';
            document.getElementById('department-address').value = '';
        }

        // Add Employee Modal functions
        function showAddEmployeeModal(branchId, branchName) {
            document.getElementById('addEmployeeModal').style.display = 'flex';
            document.body.classList.add('modal-open');
            
            document.getElementById('add_branch_id').value = branchId;
            const branchSelect = document.getElementById('branch-select');
            branchSelect.value = branchId;
            
            document.querySelector('#addEmployeeModal .modal-header h3').innerHTML = 
                `<i class="fas fa-user-plus"></i> Add Employees to ${branchName}`;
            
            loadAvailableEmployees(branchId);
        }

        function closeAddEmployeeModal() {
            document.getElementById('addEmployeeModal').style.display = 'none';
            document.body.classList.remove('modal-open');
            document.getElementById('add_branch_id').value = '';
            document.getElementById('branch-select').value = '';
            document.getElementById('employeeSelectList').innerHTML = 
                '<div class="no-employees-available"><i class="fas fa-user-slash"></i><p>Select a branch first to see available employees</p></div>';
            document.getElementById('selectedCount').textContent = '0 selected';
            document.getElementById('addEmployeesBtn').disabled = true;
            document.getElementById('selectAllBtn').innerHTML = '<i class="fas fa-check"></i> Select All';
        }

        // View Employees Modal functions
        function showViewEmployeesModal(branchId, branchName, branchManager, branchAddress) {
            document.getElementById('viewEmployeesModal').style.display = 'flex';
            document.body.classList.add('modal-open');
            
            // Set modal header info directly from table data
            document.getElementById('viewBranchName').textContent = branchName;
            document.getElementById('viewBranchManager').textContent = branchManager;
            document.getElementById('viewBranchAddress').textContent = branchAddress;
            
            // Fetch employees
            loadBranchEmployees(branchId, branchName);
        }

        function closeViewEmployeesModal() {
            document.getElementById('viewEmployeesModal').style.display = 'none';
            document.body.classList.remove('modal-open');
            document.getElementById('employeesListContainer').innerHTML = 
                '<div class="no-assigned-employees"><i class="fas fa-user-clock"></i><p>Loading employees...</p></div>';
        }

        // Edit Branch Modal functions
        function closeEditBranchModal() {
            window.location.href = 'branch.php';
        }

        // Search employees in edit modal
        function searchEmployees() {
            const searchTerm = document.getElementById('employeeSearch').value.toLowerCase();
            const employeeItems = document.querySelectorAll('.employee-item');
            const noResultsMessage = document.getElementById('noResultsMessage');
            let visibleCount = 0;
            
            employeeItems.forEach(item => {
                const employeeName = item.getAttribute('data-name');
                const employeeId = item.getAttribute('data-id');
                
                if (employeeName.includes(searchTerm) || employeeId.includes(searchTerm)) {
                    item.classList.remove('hidden');
                    visibleCount++;
                } else {
                    item.classList.add('hidden');
                }
            });
            
            // Show/hide no results message
            if (visibleCount === 0 && searchTerm !== '') {
                noResultsMessage.style.display = 'block';
            } else {
                noResultsMessage.style.display = 'none';
            }
        }

        // Load branch employees for view modal
        async function loadBranchEmployees(branchId, branchName) {
            const container = document.getElementById('employeesListContainer');
            
            // Show loading
            container.innerHTML = '<div class="spinner"></div>';
            
            try {
                const response = await fetch(`get_branch_employees.php?branch_id=${branchId}`);
                const data = await response.json();
                
                if (data.success && data.employees && data.employees.length > 0) {
                    let html = '';
                    data.employees.forEach(employee => {
                        html += `
                            <div class="view-employee-item">
                                <div class="view-employee-details">
                                    <div class="view-employee-name">${employee.first_name} ${employee.last_name}</div>
                                    <div class="view-employee-info">
                                        <span><i class="fas fa-id-badge"></i> ID: ${employee.id}</span>
                                        <span><i class="fas fa-briefcase"></i> ${employee.position || 'No position'}</span>
                                        ${employee.email ? `<span><i class="fas fa-envelope"></i> ${employee.email}</span>` : ''}
                                    </div>
                                </div>
                            </div>
                        `;
                    });
                    
                    // Add count badge to modal title
                    const titleElement = document.querySelector('#viewEmployeesModal .modal-header h3');
                    titleElement.innerHTML = `<i class="fas fa-users"></i> Branch Employees <span class="employee-count-badge">${data.employees.length} employees</span>`;
                    
                    container.innerHTML = html;
                } else {
                    container.innerHTML = `
                        <div class="no-assigned-employees">
                            <i class="fas fa-user-slash"></i>
                            <p>No employees assigned to this branch yet.</p>
                        </div>
                    `;
                    
                    // Update title without count badge
                    const titleElement = document.querySelector('#viewEmployeesModal .modal-header h3');
                    titleElement.innerHTML = `<i class="fas fa-users"></i> Branch Employees`;
                }
            } catch (error) {
                console.error('Error loading branch employees:', error);
                container.innerHTML = `
                    <div class="no-assigned-employees">
                        <i class="fas fa-exclamation-triangle"></i>
                        <p>Error loading employees. Please try again.</p>
                    </div>
                `;
            }
        }

        // Load available employees via AJAX
        function loadAvailableEmployees(branchId) {
            const employeeSelectList = document.getElementById('employeeSelectList');
            
            employeeSelectList.innerHTML = '<div class="spinner"></div>';
            
            fetch(`get_available_employees.php?branch_id=${branchId}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success && data.employees && data.employees.length > 0) {
                        let html = '';
                        data.employees.forEach(employee => {
                            html += `
                                <div class="employee-select-item">
                                    <input type="checkbox" 
                                           id="emp_${employee.id}" 
                                           name="selected_employees[]" 
                                           value="${employee.id}"
                                           onchange="updateSelectedCount()">
                                    <label for="emp_${employee.id}">
                                        <div class="employee-details">
                                            <span class="employee-name">${employee.first_name} ${employee.last_name}</span>
                                            <span class="employee-position">${employee.position || 'No position specified'}</span>
                                        </div>
                                    </label>
                                </div>
                            `;
                        });
                        employeeSelectList.innerHTML = html;
                        document.getElementById('selectAllBtn').style.display = 'inline-flex';
                    } else {
                        employeeSelectList.innerHTML = `
                            <div class="no-employees-available">
                                <i class="fas fa-user-check"></i>
                                <p>No available employees. All employees are already assigned to this branch.</p>
                            </div>
                        `;
                        document.getElementById('selectAllBtn').style.display = 'none';
                    }
                    updateSelectedCount();
                })
                .catch(error => {
                    console.error('Error loading employees:', error);
                    employeeSelectList.innerHTML = `
                        <div class="no-employees-available">
                            <i class="fas fa-exclamation-triangle"></i>
                            <p>Error loading employees. Please try again.</p>
                        </div>
                    `;
                    document.getElementById('selectAllBtn').style.display = 'none';
                });
        }

        // Update selected count
        function updateSelectedCount() {
            const checkboxes = document.querySelectorAll('#employeeSelectList input[type="checkbox"]');
            const selected = document.querySelectorAll('#employeeSelectList input[type="checkbox"]:checked');
            const selectedCount = document.getElementById('selectedCount');
            const addEmployeesBtn = document.getElementById('addEmployeesBtn');
            const selectAllBtn = document.getElementById('selectAllBtn');
            
            selectedCount.textContent = `${selected.length} selected`;
            
            if (checkboxes.length > 0 && selected.length === checkboxes.length) {
                selectAllBtn.innerHTML = '<i class="fas fa-times"></i> Deselect All';
            } else {
                selectAllBtn.innerHTML = '<i class="fas fa-check"></i> Select All';
            }
            
            addEmployeesBtn.disabled = selected.length === 0;
        }

        // Select all employees
        function selectAllEmployees() {
            const checkboxes = document.querySelectorAll('#employeeSelectList input[type="checkbox"]');
            const selectAllBtn = document.getElementById('selectAllBtn');
            const isSelectingAll = selectAllBtn.innerHTML.includes('Select All');
            
            checkboxes.forEach(checkbox => {
                checkbox.checked = isSelectingAll;
            });
            
            updateSelectedCount();
        }

        // Branch select change handler
        document.getElementById('branch-select').addEventListener('change', function() {
            const branchId = this.value;
            const addBranchIdField = document.getElementById('add_branch_id');
            
            if (branchId) {
                addBranchIdField.value = branchId;
                loadAvailableEmployees(branchId);
                
                const selectedOption = this.options[this.selectedIndex];
                document.querySelector('#addEmployeeModal .modal-header h3').innerHTML = 
                    `<i class="fas fa-user-plus"></i> Add Employees to ${selectedOption.text}`;
            } else {
                addBranchIdField.value = '';
                document.getElementById('employeeSelectList').innerHTML = 
                    '<div class="no-employees-available"><i class="fas fa-user-slash"></i><p>Select a branch first to see available employees</p></div>';
                document.getElementById('selectedCount').textContent = '0 selected';
                document.getElementById('addEmployeesBtn').disabled = true;
                document.getElementById('selectAllBtn').style.display = 'none';
            }
        });

        // Close modal when clicking outside
        window.onclick = function(event) {
            const addModal = document.getElementById('addBranchModal');
            const editModal = document.getElementById('editBranchModal');
            const addEmployeeModal = document.getElementById('addEmployeeModal');
            const viewEmployeesModal = document.getElementById('viewEmployeesModal');
            
            if (event.target === addModal) closeAddBranchModal();
            if (event.target === editModal) closeEditBranchModal();
            if (event.target === addEmployeeModal) closeAddEmployeeModal();
            if (event.target === viewEmployeesModal) closeViewEmployeesModal();
        }

        // Close modal with Escape key
        document.addEventListener('keydown', function(event) {
            if (event.key === 'Escape') {
                closeAddBranchModal();
                closeAddEmployeeModal();
                closeViewEmployeesModal();
                if (document.getElementById('editBranchModal')) {
                    closeEditBranchModal();
                }
            }
        });

        // Form validation
        document.getElementById('addEmployeeForm').addEventListener('submit', function(e) {
            const selected = document.querySelectorAll('#employeeSelectList input[type="checkbox"]:checked');
            if (selected.length === 0) {
                e.preventDefault();
                alert('Please select at least one employee to add.');
                return false;
            }
            return true;
        });

        // Auto-close edit modal if opened via URL parameter
        <?php if ($branch_details): ?>
        document.addEventListener('DOMContentLoaded', function() {
            document.body.classList.add('modal-open');
            // Focus on search input when edit modal opens
            const searchInput = document.getElementById('employeeSearch');
            if (searchInput) {
                setTimeout(() => {
                    searchInput.focus();
                }, 300);
            }
        });
        <?php endif; ?>
    </script>
</body>
</html>