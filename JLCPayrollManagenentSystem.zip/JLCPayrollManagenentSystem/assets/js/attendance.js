// attendance.js - COMPLETE VERSION
console.log('✅ attendance.js loaded');

let currentTimeField = null;

// ============================================
// MODAL FUNCTIONS
// ============================================

function openAddAttendanceModal() {
    console.log('Opening Add Attendance Modal');
    const modal = document.getElementById('addAttendanceModal');
    if (modal) {
        modal.style.display = 'flex'; // Changed from 'block' to 'flex'
        modal.classList.add('show');
        document.body.style.overflow = 'hidden';
        console.log('✅ Modal opened');
    } else {
        console.error('❌ Modal not found!');
        alert('Error: Could not find the modal.');
    }
}

function closeAddAttendanceModal() {
    console.log('Closing Add Attendance Modal');
    const modal = document.getElementById('addAttendanceModal');
    if (modal) {
        modal.style.display = 'none';
        modal.classList.remove('show');
        document.body.style.overflow = 'auto';
        resetAttendanceForm();
    }
}

function openTimeModal(field) {
    console.log('Opening Time Modal for:', field);
    currentTimeField = field;
    const modal = document.getElementById('timeModal');
    const title = document.getElementById('timeModalTitle');
    
    if (modal) {
        // Set modal title
        title.textContent = field === 'time_in' ? 'Set Time In' : 'Set Time Out';
        
        // Populate time dropdowns
        populateTimeDropdowns();
        
        // Show modal
        modal.style.display = 'flex';
        modal.classList.add('show');
        document.body.style.overflow = 'hidden';
    }
}

function closeTimeModal() {
    console.log('Closing Time Modal');
    const modal = document.getElementById('timeModal');
    if (modal) {
        modal.style.display = 'none';
        modal.classList.remove('show');
        document.body.style.overflow = 'auto';
    }
    currentTimeField = null;
}

// ============================================
// FORM FUNCTIONS
// ============================================

function updateEmployeeId() {
    const select = document.getElementById('employeeSelect');
    const idDisplay = document.getElementById('employeeIdDisplay');
    
    if (select && select.value) {
        const selectedOption = select.options[select.selectedIndex];
        // Extract ID from the option text
        const match = selectedOption.text.match(/\(ID:\s*(\d+)\)/);
        if (match) {
            idDisplay.textContent = match[1];
        } else {
            idDisplay.textContent = '--';
        }
    } else if (idDisplay) {
        idDisplay.textContent = '--';
    }
}

function resetAttendanceForm() {
    const form = document.getElementById('addAttendanceForm');
    if (form) {
        form.reset();
    }
    
    // Reset displays
    const idDisplay = document.getElementById('employeeIdDisplay');
    const timeInDisplay = document.getElementById('timeInDisplay');
    const timeOutDisplay = document.getElementById('timeOutDisplay');
    const timeInInput = document.getElementById('timeIn');
    const timeOutInput = document.getElementById('timeOut');
    
    if (idDisplay) idDisplay.textContent = '--';
    if (timeInDisplay) {
        timeInDisplay.className = 'time-display-box empty';
        timeInDisplay.querySelector('.time-display-content').textContent = '--:-- --';
    }
    if (timeOutDisplay) {
        timeOutDisplay.className = 'time-display-box empty';
        timeOutDisplay.querySelector('.time-display-content').textContent = '--:-- --';
    }
    if (timeInInput) timeInInput.value = '';
    if (timeOutInput) timeOutInput.value = '';
    
    // Reset status to Present
    const statusPresent = document.getElementById('statusPresent');
    if (statusPresent) statusPresent.checked = true;
}

function submitAttendanceForm() {
    console.log('submitAttendanceForm called');
    
    const form = document.getElementById('addAttendanceForm');
    const employeeSelect = document.getElementById('employeeSelect');
    const statusPresent = document.getElementById('statusPresent');
    const statusAbsent = document.getElementById('statusAbsent');
    
    if (!form || !employeeSelect) {
        console.error('Form elements not found');
        alert('Error: Form not properly loaded.');
        return false;
    }
    
    console.log('Employee select value:', employeeSelect.value);
    console.log('Status present checked:', statusPresent ? statusPresent.checked : 'N/A');
    console.log('Status absent checked:', statusAbsent ? statusAbsent.checked : 'N/A');
    
    // Validate required fields
    if (!employeeSelect.value) {
        alert('Please select an employee');
        employeeSelect.focus();
        return false;
    }
    
    if (statusPresent && statusAbsent) {
        if (!statusPresent.checked && !statusAbsent.checked) {
            alert('Please select attendance status');
            return false;
        }
    }
    
    // Show what will be submitted
    console.log('Form data:');
    const formData = new FormData(form);
    for (let [key, value] of formData.entries()) {
        console.log(key + ': ' + value);
    }
    
    // Submit form
    console.log('Submitting form...');
    form.submit();
    return true;
}

// ============================================
// TIME FUNCTIONS
// ============================================

function populateTimeDropdowns() {
    const hourSelect = document.getElementById('timeHour');
    const minuteSelect = document.getElementById('timeMinute');
    const periodSelect = document.getElementById('timePeriod');
    
    if (!hourSelect || !minuteSelect || !periodSelect) {
        console.error('Time dropdowns not found');
        return;
    }
    
    // Clear existing options
    hourSelect.innerHTML = '';
    minuteSelect.innerHTML = '';
    periodSelect.innerHTML = '';
    
    // Populate hours (12-hour format)
    for (let i = 1; i <= 12; i++) {
        const option = document.createElement('option');
        option.value = i.toString().padStart(2, '0');
        option.textContent = i.toString().padStart(2, '0');
        hourSelect.appendChild(option);
    }
    
    // Populate minutes
    for (let i = 0; i < 60; i += 5) {
        const option = document.createElement('option');
        option.value = i.toString().padStart(2, '0');
        option.textContent = i.toString().padStart(2, '0');
        minuteSelect.appendChild(option);
    }
    
    // Populate AM/PM
    ['AM', 'PM'].forEach(period => {
        const option = document.createElement('option');
        option.value = period;
        option.textContent = period;
        periodSelect.appendChild(option);
    });
    
    // Set to current time
    setCurrentTime();
}

function setCurrentTime() {
    const hourSelect = document.getElementById('timeHour');
    const minuteSelect = document.getElementById('timeMinute');
    const periodSelect = document.getElementById('timePeriod');
    
    if (!hourSelect || !minuteSelect || !periodSelect) return;
    
    const now = new Date();
    let hours = now.getHours();
    let minutes = now.getMinutes();
    const period = hours >= 12 ? 'PM' : 'AM';
    
    // Convert to 12-hour format
    hours = hours % 12 || 12;
    
    // Round minutes to nearest 5
    minutes = Math.round(minutes / 5) * 5;
    if (minutes === 60) {
        minutes = 0;
        hours = (hours % 12) + 1;
        if (hours === 13) hours = 1;
    }
    
    hourSelect.value = hours.toString().padStart(2, '0');
    minuteSelect.value = minutes.toString().padStart(2, '0');
    periodSelect.value = period;
}

function saveTime() {
    if (!currentTimeField) {
        console.error('No current time field set');
        return;
    }
    
    const hour = document.getElementById('timeHour').value;
    const minute = document.getElementById('timeMinute').value;
    const period = document.getElementById('timePeriod').value;
    
    if (!hour || !minute || !period) {
        alert('Please select a valid time');
        return;
    }
    
    // Format time string for display
    const displayHour = parseInt(hour); // Remove leading zero for display
    const timeString = `${displayHour}:${minute} ${period}`;
    
    // Convert to 24-hour format for database
    const time24 = convertTo24Hour(displayHour, minute, period);
    
    console.log(`Saving ${currentTimeField}: ${timeString} (24h: ${time24})`);
    
    // Update the display and hidden input
    if (currentTimeField === 'time_in') {
        const display = document.getElementById('timeInDisplay');
        const input = document.getElementById('timeIn');
        if (display) {
            display.className = 'time-display-box';
            display.querySelector('.time-display-content').textContent = timeString;
        }
        if (input) input.value = time24;
        
        // Add animation effect
        showTimeSetAnimation('timeInDisplay');
    } else if (currentTimeField === 'time_out') {
        const display = document.getElementById('timeOutDisplay');
        const input = document.getElementById('timeOut');
        if (display) {
            display.className = 'time-display-box';
            display.querySelector('.time-display-content').textContent = timeString;
        }
        if (input) input.value = time24;
        
        // Add animation effect
        showTimeSetAnimation('timeOutDisplay');
    }
    
    closeTimeModal();
}

function convertTo24Hour(hour, minute, period) {
    hour = parseInt(hour);
    minute = parseInt(minute);
    
    if (period === 'PM' && hour !== 12) {
        hour += 12;
    }
    if (period === 'AM' && hour === 12) {
        hour = 0;
    }
    
    return `${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}:00`;
}

function showTimeSetAnimation(elementId) {
    const element = document.getElementById(elementId);
    if (!element) return;
    
    const confirmation = document.createElement('div');
    confirmation.className = 'time-set-confirmation';
    confirmation.textContent = '✓ Time Set';
    
    // Remove any existing animation
    const existing = element.querySelector('.time-set-confirmation');
    if (existing) existing.remove();
    
    element.appendChild(confirmation);
    
    // Remove animation after it completes
    setTimeout(() => {
        if (confirmation.parentNode === element) {
            element.removeChild(confirmation);
        }
    }, 3000);
}

// ============================================
// EVENT LISTENERS
// ============================================

document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM fully loaded');
    
    // Initialize employee ID display
    const employeeSelect = document.getElementById('employeeSelect');
    if (employeeSelect) {
        employeeSelect.addEventListener('change', updateEmployeeId);
    }
    
    // Close modals when clicking outside
    window.addEventListener('click', function(event) {
        const addModal = document.getElementById('addAttendanceModal');
        const timeModal = document.getElementById('timeModal');
        
        if (event.target === addModal) {
            closeAddAttendanceModal();
        }
        
        if (event.target === timeModal) {
            closeTimeModal();
        }
    });
    
    // Close modals with Escape key
    document.addEventListener('keydown', function(event) {
        if (event.key === 'Escape') {
            const addModal = document.getElementById('addAttendanceModal');
            const timeModal = document.getElementById('timeModal');
            
            if (addModal && addModal.style.display === 'flex') {
                closeAddAttendanceModal();
            }
            
            if (timeModal && timeModal.style.display === 'flex') {
                closeTimeModal();
            }
        }
    });
    
    // Test if elements exist
    console.log('Modal check:');
    console.log('- Add Attendance Modal:', document.getElementById('addAttendanceModal') ? 'Found' : 'Not Found');
    console.log('- Time Modal:', document.getElementById('timeModal') ? 'Found' : 'Not Found');
    console.log('- Employee Select:', document.getElementById('employeeSelect') ? 'Found' : 'Not Found');
    console.log('- Add Attendance Button:', document.querySelector('.add-attendance-btn') ? 'Found' : 'Not Found');
});

// ============================================
// GLOBAL FUNCTIONS (for onclick attributes)
// ============================================

// These functions need to be globally accessible
window.openAddAttendanceModal = openAddAttendanceModal;
window.closeAddAttendanceModal = closeAddAttendanceModal;
window.openTimeModal = openTimeModal;
window.closeTimeModal = closeTimeModal;
window.updateEmployeeId = updateEmployeeId;
window.resetAttendanceForm = resetAttendanceForm;
window.submitAttendanceForm = submitAttendanceForm;
window.saveTime = saveTime;