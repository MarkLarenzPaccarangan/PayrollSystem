<?php
// Get the current page filename
$current_page = basename($_SERVER['PHP_SELF']);

// Map page filenames to display titles
$page_titles = [
    'home.php' => 'HOME',
    'attendance.php' => 'ATTENDANCE',
    'employee.php' => 'EMPLOYEE LIST',
    'branch.php' => 'BRANCH MANAGEMENT',
    'deductionList.php' => 'DEDUCTION',
    'payrollList.php' => 'PAYROLL',
    'salarySlip.php' => 'SALARY SLIP',
    'user.php' => 'PROFILE'
];

// Get the title for the current page
$page_title = isset($page_titles[$current_page]) ? $page_titles[$current_page] : '';
?>

<style>
    /* Header Styling with Sidebar Integration */
    .header {
        width: 100%;
        height: 140px; /* Increased height for navigation */
        background-color: #75e6da; /* Sidebar color */
        padding: 0 30px;
        position: fixed;
        top: 0;
        left: 0;
        z-index: 1000;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
        display: flex;
        flex-direction: column;
    }

    /* Top Row: Logo and Admin Info */
    .header-top {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 15px 0;
        flex: 1;
    }

    .header-logo img {
        height: 80px;
        width: auto;
        border-radius: 10px;
    }

    .header-right {
        display: flex;
        align-items: center;
        gap: 30px;
    }

    .admin-text {
        font-size: 1.6rem;
        font-weight: 700;
        color: #ffffff;
        text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.3);
        padding: 8px 20px;
        background-color: rgba(41, 148, 82, 0.2); /* Highlight color */
        border-radius: 8px;
    }

    .logout-icon {
        display: flex;
        align-items: center;
    }

    .logout-icon img {
        height: 50px;
        width: 50px;
        cursor: pointer;
        transition: transform 0.2s ease;
        padding: 8px;
        background-color: rgba(41, 148, 82, 0.2);
        border-radius: 8px;
    }

    .logout-icon img:hover {
        transform: scale(1.1);
        background-color: rgba(41, 148, 82, 0.4);
    }

    /* Navigation Menu (Former Sidebar) */
    .header-nav {
        display: flex;
        justify-content: center;
        background-color: #62d4c8; /* Slightly darker shade */
        border-radius: 10px 10px 0 0;
        padding: 0 20px;
        margin: 0 -30px;
    }

    .nav-menu {
        display: flex;
        list-style: none;
        margin: 0;
        padding: 0;
        width: 100%;
        justify-content: space-around;
    }

    .nav-menu li {
        flex: 1;
        text-align: center;
    }

    .nav-menu li a {
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 12px 15px;
        color: #ffffff;
        font-weight: 600;
        text-decoration: none;
        transition: all 0.3s ease;
        border-radius: 8px;
        margin: 5px 3px;
        white-space: nowrap;
    }

    .nav-menu li a:hover {
        background-color: #299452; /* Highlight color */
        box-shadow: 0 4px 12px rgba(52, 168, 83, 0.3);
        transform: translateY(-2px);
    }

    .nav-menu li.active a {
        background-color: #323e4c;
        color: #ffffff;
        box-shadow: 0 4px 12px rgba(52, 168, 83, 0.3);
    }

    .nav-icon {
        margin-right: 8px;
        font-size: 16px;
    }

    /* Page Title */
    .page-title-container {
        background-color: #4bc4b5; /* Middle shade */
        padding: 10px 30px;
        margin: 0 -30px;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
    }

    .page-title {
        font-size: 2.2rem;
        font-weight: 800;
        color: #ffffff;
        letter-spacing: 1px;
        text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
        margin: 0;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        text-transform: uppercase;
        text-align: center;
    }

    /* Logout Modal */
    .logout-overlay {
        display: none;
        position: fixed;
        inset: 0;
        background-color: rgba(0, 0, 0, 0.5);
        justify-content: center;
        align-items: center;
        z-index: 2000;
    }

    .logout-content {
        background-color: #ffffff;
        padding: 30px;
        width: 400px;
        border-radius: 10px;
        text-align: center;
        box-shadow: 0px 10px 25px rgba(0, 0, 0, 0.3);
    }

    .logout-header {
        font-size: 1.8rem;
        margin-bottom: 15px;
        font-weight: 800;
        color: #1e293b;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    /* Responsive Design */
    @media (max-width: 1200px) {
        .nav-menu li a {
            font-size: 0.9rem;
            padding: 10px 8px;
        }
        
        .nav-icon {
            margin-right: 5px;
            font-size: 14px;
        }
    }

    @media (max-width: 992px) {
        .header {
            height: 160px;
        }
        
        .nav-menu {
            flex-wrap: wrap;
        }
        
        .nav-menu li {
            flex: 0 0 25%;
            margin-bottom: 5px;
        }
    }

    @media (max-width: 768px) {
        .header {
            height: auto;
            padding: 0 15px;
        }
        
        .header-top {
            flex-direction: column;
            gap: 15px;
        }
        
        .nav-menu li {
            flex: 0 0 33.33%;
        }
        
        .page-title {
            font-size: 1.8rem;
        }
    }

    @media (max-width: 576px) {
        .nav-menu li {
            flex: 0 0 50%;
        }
        
        .nav-menu li a {
            flex-direction: column;
            padding: 8px 5px;
        }
        
        .nav-icon {
            margin-right: 0;
            margin-bottom: 5px;
            font-size: 18px;
        }
        
        .header-right {
            gap: 15px;
        }
        
        .admin-text {
            font-size: 1.2rem;
            padding: 6px 12px;
        }
        
        .logout-icon img {
            height: 40px;
            width: 40px;
        }
    }
</style>

<header class="header">
    <!-- Top Row: Logo and Admin -->
    <div class="header-top">
        <div class="header-logo">
            <img src="assets/images/logo.png" alt="Logo">
        </div>
        
        <div class="header-right">
            <span class="admin-text">ADMINISTRATOR</span>
            <a href="#" class="logout-icon" onclick="showLogoutConfirmation(event)">
                <img src="./assets/images/logout2.png" alt="Logout">
            </a>
        </div>
    </div>
    
    <!-- Navigation Menu (Former Sidebar) -->
    <nav class="header-nav">
        <ul class="nav-menu">
            <li class="<?php echo ($current_page == 'attendance.php') ? 'active' : ''; ?>">
                <a href="attendance.php"><span class="nav-icon">🗓️</span>Attendance</a>
            </li>
            <li class="<?php echo ($current_page == 'home.php') ? 'active' : ''; ?>">
                <a href="home.php"><span class="nav-icon">🏠</span>Home</a>
            </li>
            <li class="<?php echo ($current_page == 'employee.php') ? 'active' : ''; ?>">
                <a href="employee.php"><span class="nav-icon">👥</span>Employees</a>
            </li>
            <li class="<?php echo ($current_page == 'branch.php') ? 'active' : ''; ?>">
                <a href="branch.php"><span class="nav-icon">🏢</span>Branch</a>
            </li>
            <li class="<?php echo ($current_page == 'deductionList.php') ? 'active' : ''; ?>">
                <a href="deductionList.php"><span class="nav-icon">➖</span>Deduction</a>
            </li>
            <li class="<?php echo ($current_page == 'payrollList.php') ? 'active' : ''; ?>">
                <a href="payrollList.php"><span class="nav-icon">💸</span>Payroll</a>
            </li>
            <li class="<?php echo ($current_page == 'salarySlip.php') ? 'active' : ''; ?>">
                <a href="salarySlip.php"><span class="nav-icon">📄</span>Salary Slip</a>
            </li>
            <li class="<?php echo ($current_page == 'user.php') ? 'active' : ''; ?>">
                <a href="user.php"><span class="nav-icon">👤</span>Profile</a>
            </li>
        </ul>
    </nav>
    
    <!-- Page Title -->
    <?php if (!empty($page_title)): ?>
    <div class="page-title-container">
        <h1 class="page-title"><?php echo htmlspecialchars($page_title); ?></h1>
    </div>
    <?php endif; ?>
</header>

<!-- Logout Confirmation Modal -->
<div id="logoutOverlay" class="logout-overlay">
    <div class="logout-content">
        <div class="logout-header">Confirm Logout</div>
        <p>Are you sure you want to logout?</p>
        <div style="margin-top: 20px;">
            <button onclick="confirmLogout()" style="background-color: #299452; color: white; padding: 10px 25px; border: none; border-radius: 5px; cursor: pointer; margin-right: 10px;">Yes, Logout</button>
            <button onclick="cancelLogout()" style="background-color: #e74c3c; color: white; padding: 10px 25px; border: none; border-radius: 5px; cursor: pointer;">Cancel</button>
        </div>
    </div>
</div>

<script>
    function showLogoutConfirmation(event) {
        event.preventDefault();
        document.getElementById('logoutOverlay').style.display = 'flex';
    }

    function confirmLogout() {
        // Redirect to logout page
        window.location.href = 'logout.php';
    }

    function cancelLogout() {
        document.getElementById('logoutOverlay').style.display = 'none';
    }
</script>